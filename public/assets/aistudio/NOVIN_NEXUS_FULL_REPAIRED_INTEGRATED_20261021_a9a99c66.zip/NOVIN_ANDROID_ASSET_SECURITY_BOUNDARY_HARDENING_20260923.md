# NOVIN Android Asset Security Boundary Hardening 2026-09-23

## Scope
این چرخه فقط روی مرز بسته‌بندی Android و WebView Public Assets تمرکز دارد.

## Finding
`dist/server.cjs` و `dist/server.cjs.map` در مسیر synchronization قبلی بدون فیلتر به `android/app/src/main/assets/public/` کپی می‌شدند. این فایل‌ها backend/server-side bundle هستند و می‌توانند شامل منطق سرور، environment lookups، build/deployment tooling و source-map محتوای سورس باشند. وجود آن‌ها در public WebView assets با مرز Client/Server و حداقل‌سازی سطح حمله سازگار نیست.

## Fix
- `scripts/sync-android-assets.ts` اکنون server-side bundle names را fail-closed از Android public assets حذف می‌کند.
- بعد از synchronization، وجود `server.cjs`, `server.cjs.map`, `server.js`, `server.js.map` به‌صورت explicit بررسی می‌شود و در صورت وجود خطا می‌دهد.
- فایل‌های server bundle موجود در archive target حذف شدند.
- تست `scripts/test_android_asset_boundary.ts` اضافه شد.

## Evidence
- `node --experimental-strip-types scripts/test_android_asset_boundary.ts` = PASS
- `index.html` در Android public assets موجود و non-empty است.
- forbidden server assets در target موجود نیستند.
- `node --experimental-strip-types --check scripts/sync-android-assets.ts` = PASS

## Limitation
به‌دلیل نبود `node_modules` در محیط استخراج‌شده، اجرای end-to-end خود `syncAndroidAssets()` که در صورت نبود `dist` نیازمند `npm run build` است، در این محیط قابل اجرا نبود. بنابراین PASS فقط برای source/static boundary و وضعیت فعلی target است، نه برای build کامل Android.

## Status
PASS: Android client/server asset boundary hardened.
NOT VERIFIED: full Android build/install/device execution.
