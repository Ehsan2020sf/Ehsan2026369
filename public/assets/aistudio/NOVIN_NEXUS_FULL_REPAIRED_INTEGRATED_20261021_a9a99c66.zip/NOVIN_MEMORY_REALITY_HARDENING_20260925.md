# NOVIN Memory Layer Reality Hardening — 2026-09-25

## Scope
The Memory layer was re-audited after the Feedback layer was completed. Existing unit tests were green, but the audit identified two boundary weaknesses that could bypass the intended memory truth/lifecycle controls.

## Repairs
1. Added `src/core/memory/memoryRealityAdmissionGovernor.ts`.
   - `VERIFIED_REAL` requires EvidenceMap admission and at least one resolved verified evidence reference.
   - `OBSERVED` requires a resolved evidence reference.
   - Unsupported truth labels are downgraded to `UNKNOWN` instead of being persisted as stronger reality.
   - The governor explicitly cannot grant execution proof or authority.
2. `MemoryFabric` now routes reality admission through the governor on writes and hydration.
3. Hydration persists truth downgrades so an invalid persisted `VERIFIED_REAL` state cannot reappear after restart.
4. Bulk archival now passes through `MemoryLifecycleGovernor`; failures/recoveries and review-gated memories cannot be archived by a bypass path.
5. Added boundary tests for spoofed evidence, observed-evidence requirements, non-proof semantics, and lifecycle archival bypasses.
6. Updated the memory intelligence fixture to provide explicit evidence for `OBSERVED` facts and conflict resolution, keeping the test aligned with the hardened reality contract.

## Verification
- All `src/core/memory/*.test.ts`: PASS
- `scripts/test_memory_intelligence.ts`: PASS
- `src/core/learning/*.test.ts`: PASS
- `src/core/feedback/*.test.ts`: PASS
- Governance memory tests R165/R166/R203: PASS
- No production execution authority is granted by the Memory layer.

## Status
Memory Layer: PASS for source-level reality, lineage, retrieval, conflict, lifecycle, and cross-layer admission boundaries.
Physical/device execution remains outside this source-level claim.
