# NOVIN NEXUS engineering batch: bounded local workflow subset

Date: 2026-10-15
Scope: Android-only NOVIN application. No website or server runtime added.

## Implemented

- Added `src/core/agent/n8nSafeLocalRuntime.ts`, a fail-closed local interpreter for a narrow allowlist of pure-data nodes: manual trigger/start, static Set, no-op, bounded Limit, and non-executable sticky-note metadata.
- Preflights the entire graph before running any node. Refuses active graphs, unsupported node types, credential-bearing nodes, expression/dynamic Set values, duplicate node names, unsupported or malformed connections, more than 50 nodes, oversized inputs/outputs, excessive items, and step-limit violations.
- Does not execute arbitrary code, shell commands, network requests, webhooks, databases, messages, or any external side effects.
- Added a mobile-panel action for an explicit owner click to run the selected graph in this bounded local subset. The result reports `COMPLETED_LOCAL` or `BLOCKED`, lists the nodes run, and displays output; it does not grant production execution permission.
- Updated tests and user-facing documentation to distinguish this subset from the full n8n runtime.

## Evidence

- `npm run test:n8n-catalog`: PASS
- `npm run test:adaptive-display`: PASS
- `npm run test:adaptive-display-integration`: PASS
- Android-only product scope contract: PASS
- New safe local runtime test: PASS for static Set transformation and fail-closed behavior for active workflows, HTTP nodes, expressions, credentials, and oversized inputs.

## Explicit limits

This is not full n8n compatibility. The catalogue has 2,066 graph JSON entries, but they are not all executable agents. Every graph still requires a successful compatibility check, and external integrations remain blocked until implemented as governed native adapters with verified credentials, security review, and owner approval. No APK build or physical-device validation was performed in this batch.
