# NOVIN EHSAN Brain Repair Ledger R28

## هدف
تقویت مغز نوین در مرز Evidence → Reasoning → Safety تا نبود شاهد نتواند با confidence غیرصفر به تصمیم قابل اقدام تبدیل شود.

## اصلاحات واقعی
- در `BrainCoordinator.think` وقتی Evidence Decision Governor وضعیت `BLOCK_DECISION` می‌دهد، confidence مغز دقیقاً `0` می‌شود.
- در `BrainCoordinator.thinkLocal` همین Fail-Closed اعمال شد.
- وضعیت epistemic در این حالت `UNCERTAIN` باقی می‌ماند.
- safety بر اساس `guardedState` و `guardedConfidence` محاسبه می‌شود، نه confidence قبل از Evidence Gate.
- حافظه‌ی inference مغز نیز confidence محافظت‌شده را ذخیره می‌کند تا confidence مسدودشده وارد حافظه نشود.
- شرط `VERIFY_BEFORE_EXTERNAL_ACTION` بر اساس confidence محافظت‌شده تصمیم‌گیری می‌کند.
- تست Brain Hardening برای این مرز اضافه شد.

## Evidence
- `scripts/test_brain_hardening.ts`: PASS
- `scripts/test_brain_diagnostic.ts`: PASS
- `src/core/ai/brainAutonomyController.test.ts`: PASS
- `src/core/ai/brainMemoryTruthBoundary.test.ts`: PASS
- `src/core/ai/brainMissionPlanner.test.ts`: PASS

## وضعیت
- Brain Evidence Fail-Closed: PASS
- Brain safety alignment: PASS
- Full TypeScript/build: BLOCKED تا تکمیل dependency environment
- Android/device/live AI: NOT VERIFIED
