# NOVIN EHSAN STEP 34 | R200 Context Integrity Truth Boundary

R200 hardened to fail-closed on weak reality, missing consent/trust/fresh, and empty or whitespace-only evidence.

Targeted test: `R200 contextIntegrity: PASS`.
