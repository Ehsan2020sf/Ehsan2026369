# NOVIN Product Scope: Android App Only

## Owner decision
NOVIN NEXUS is an Android application product. Do not create, deploy, or advertise a standalone public website for NOVIN unless the owner explicitly changes this decision.

## Build contract
- `npm run build` is the Android APK build entry point and delegates to `npm run android:build`.
- `npm run android:build` performs the real Android pipeline: toolchain gates, dependency checks, internal UI bundle generation, Capacitor sync, Gradle APK build, and artifact verification.
- The Vite bundle in `dist/` is an internal Android WebView asset package. It is not a separately deployed website and must not be deleted while the Capacitor Android app depends on it.
- `npm run build:web` is retained as a low-level internal asset-build command for existing Android automation. It is not the product's default build or a website deployment target.
- `npm run build:server` remains an explicit optional backend packaging command. It is not invoked by the default product build and does not imply a public website.

## Safety and evidence
- No APK is considered built unless Gradle produces the artifact and the configured artifact verification succeeds.
- No device installation or runtime PASS may be claimed without device evidence.
- Website-specific deployment handoff material is removed. Android CI remains the only project deployment workflow currently present.
