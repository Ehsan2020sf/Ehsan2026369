# NOVIN Stage 118: Conversation Trace Preservation

Date: 2026-10-17

## Finding

The final conversation integrity adapter validated correlation, attribution, reality, usage, latency, and confidence, but returned only the reply/reality/providerUsed/confidence fields. The multilingual conversation runtime therefore discarded request/provider/model/usage provenance after validation. The Persian-facing runtime also projected conversation turns down to role/text/time, dropping reality, language, providerUsed, and provenance from the returned turn list.

## Changes

- `src/core/mobile/conversationResponseIntegrity.ts`: verified replies now carry a bounded, typed provenance record copied from the already validated AI response: request ID, provider ID, model ID, latency, token usage, and estimated cost.
- `src/core/mobile/novinMultilingualConversationRuntime.ts`: conversation turns and successful results preserve the verified provenance. The response reality label is not modified by this transfer.
- `src/core/mobile/novinPersianConversationRuntime.ts`: Persian-facing conversation turns now preserve language, reality, provider usage, and optional provenance instead of silently dropping them.
- `src/core/mobile/conversationResponseIntegrity.test.ts`: checks that live and simulated attribution/usage metadata survive the final integrity boundary and that simulated reality is not upgraded.
- `src/core/mobile/novinMultilingualConversationRuntime.test.ts`: asserts simulated turn metadata stays simulated and does not claim provider usage.

## Tests executed

PASS: `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
PASS: `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
PASS: `node --experimental-strip-types src/core/mobile/novinPersianConversationRuntime.test.ts`
PASS: `node --experimental-strip-types src/brain/aiGatewayProvider.test.ts`

These are local deterministic tests. No live provider, full `test:all`, full TypeScript compile, APK build, or device installation was run.

## Release and safety constraints

- No dependencies installed.
- No APK built or installed.
- No second release archive created.
- Only the existing canonical archive was updated in place.
