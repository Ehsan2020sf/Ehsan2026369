# NOVIN EHSAN Repair Ledger R17 — 2026-09-23

## هدف
ادامه رفع واقعی شکاف معماری Core از آخرین Evidence معتبر R16، بدون تکرار اصلاحات قبلی و بدون ادعای Build/Device/Live-AI.

## اصلاحات واقعی
- `core/governance/novinGovernanceRuntimeR175R234.ts` به محل canonical حاکمیتی منتقل شد و مسیر `core/integration` فقط Compatibility Export نگه داشت.
- `core/learning/memoryPromotionGovernor.ts` به‌عنوان مالک canonical قابلیت Promotion قرار گرفت؛ وابستگی معکوس `memory -> learning` حذف شد و `core/index.ts` API را حفظ می‌کند.
- اجرای مستقیم AI از `UnifiedIntelligenceCycle` حذف شد تا لایه Intelligence به `aiGateway` وابستگی runtime نداشته باشد. این چرخه اکنون مسئول plan/decision/outcome است، نه provider execution.
- سیاست `UniversalAIProviderSecurity` به `core/contracts` منتقل شد و مسیر `core/security` فقط Compatibility Export است؛ AI Gateway دیگر مستقیماً به Security module وابسته نیست.
- `EconomicGovernor` به `core/economy` منتقل شد و مسیر `core/governance` فقط Compatibility Export است.
- `HumanUnderstandingEngine` به `core/contracts` منتقل شد و مسیر `core/intelligence` فقط Compatibility Export است.
- حذف importهای بدون استفاده در P83 Android Delivery Engine.
- ممیزی Module Boundary اصلاح شد تا `import type` را dependency runtime حساب نکند و فایل‌های `runP*` audit را وارد production runtime graph نکند.

## Verification
- Module boundary audit: **REQUIRES_REFACTOR / BLOCKED**؛ یک SCC چندماژوله واقعی باقی مانده است.
- Governance integration test: **PASS**.
- Brain/Body/Nervous integration test: **PASS**.
- سایر تست‌های گسترده تا قبل از تکمیل dependency environment به‌عنوان PASS کامل ثبت نمی‌شوند.
- Phase 0 / TypeScript environment: **BLOCKED** به‌دلیل dependencyهای نصب‌نشده.
- Android/device/live AI: **NOT VERIFIED**.

## وضعیت
این نسخه معماری را واقعاً بهبود داده، اما چرخه چندماژوله باقی‌مانده هنوز مانع PASS معماری است. UNKNOWN ≠ SUCCESS.
