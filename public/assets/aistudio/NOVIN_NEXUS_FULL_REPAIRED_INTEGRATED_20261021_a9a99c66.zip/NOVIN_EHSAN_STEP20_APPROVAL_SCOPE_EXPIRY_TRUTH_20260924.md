# NOVIN EHSAN STEP 20 — Approval Scope / Expiry Truth Boundary
Date: 2026-09-24

Real defect:
R178 Approval Scope and R179 Approval Expiry rejected only explicit false/UNKNOWN values. Omitted consent/trust/freshness could therefore pass, and INFERRED/SIMULATED/ASSUMED reality was not uniformly rejected.

Repair:
- consent must be exactly true.
- trusted must be exactly true.
- fresh must be exactly true.
- reality must be exactly OBSERVED or VERIFIED_REAL.
- missing/undefined and weaker reality states fail closed to BLOCK.
- no external action authorization was added.

Verification:
- R178 tests include missing consent/trust/freshness and INFERRED reality.
- R179 tests include missing consent/trust/freshness and INFERRED reality.
- Source-level deterministic verification only; Android/device/production execution remains unproven.
