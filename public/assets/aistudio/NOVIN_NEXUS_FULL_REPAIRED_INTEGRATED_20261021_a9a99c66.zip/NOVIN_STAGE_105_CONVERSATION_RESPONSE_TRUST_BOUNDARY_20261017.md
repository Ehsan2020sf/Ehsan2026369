# NOVIN Stage 105: Conversation response trust boundary
Date: 2026-10-17

## Scope
Harden the adapter between `AIGateway.complete` and the user-facing multilingual conversation runtime. This is a source-level change only; no dependency installation, APK build, or device installation.

## Finding
The conversation runtime previously derived a `providerUsed` boolean from the response reality and a non-`none` provider ID, but it did not verify request correlation, model attribution, empty content, or consistency between the simulator provider and the reality label. That left the conversation boundary more permissive than the gateway contract.

## Changes
- Added `src/core/mobile/conversationResponseIntegrity.ts` as a fail-closed response adapter.
- Requires the response `requestId` to match the exact request, a non-empty content string, provider and model attribution, no error field, and a recognized reality classification.
- Rejects `UNKNOWN` as user-visible provider output, mismatched correlation IDs, missing attribution, empty content, and responses carrying an error.
- Rejects `local-simulated` responses claiming `GENERATED`/`OBSERVED`; rejects a `SIMULATED` response attributed to a different provider.
- Clamps confidence to [0, 1], replacing non-finite confidence with a conservative default.
- Wired the multilingual conversation runtime through the validator. Invalid gateway responses now take the explicit simulated fallback path rather than surfacing as verified output.
- Added focused tests and registered `test:conversation-response-integrity` in `test:all`.

## Validation evidence
Passed:
- `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
- `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
- `node --experimental-strip-types src/core/mobile/novinPersianConversationRuntime.test.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_concurrency.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_failure_recovery.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_runtime_provider_refresh.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_provider_response_integrity.ts`
- `package.json` JSON parse.

The conversation tests observed `SIMULATED/FALLBACK` for Persian and English. This is correct evidence that the current test path is simulated, not proof of a live model connection. The gateway's focused provider-refresh test uses a controlled provider call, not an external live service.

## Explicitly not performed
- No live provider request.
- No full `test:all` run.
- No full TypeScript build.
- No dependency installation.
- No APK build or device installation.

## Status
PASS for focused local source tests and response-contract checks. Live provider behavior and Android end-to-end UI propagation remain NOT TESTED.
