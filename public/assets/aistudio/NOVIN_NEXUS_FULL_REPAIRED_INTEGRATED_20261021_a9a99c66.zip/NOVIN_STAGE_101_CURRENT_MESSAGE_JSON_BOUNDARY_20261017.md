# NOVIN Stage 101 — Current Message JSON Boundary

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Change

Updated `src/core/mobile/novinMultilingualConversationRuntime.ts` so both prior conversation history and the current user message are transported to the gateway as a single JSON-encoded user payload. The current message is no longer concatenated into a delimiter-based prompt string. The system instruction explicitly classifies both history and current user text as untrusted data, and clarifies that JSON encoding preserves embedded newlines and delimiter-like strings as data.

Updated `src/core/mobile/novinMultilingualConversationRuntime.test.ts` with a regression case containing a forged history terminator and system-like text. The message remains one USER turn and does not create additional history turns.

## Verification performed

- `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts` — PASS. Output reported `NOVIN_MULTILINGUAL_CONVERSATION_PASS`; observed response reality was `SIMULATED/FALLBACK`, not live-provider success.
- `node --experimental-strip-types scripts/test_ai_idempotency_concurrency.ts` — PASS. Same request ID with different request fingerprint rejected; one provider call observed.
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts` — PASS. Explicit simulated fallback remained labelled `SIMULATED`.
- `node --experimental-strip-types scripts/test_ai_idempotency_failure_recovery.ts` — PASS. Rejected execution recovered and expired entry was purged.

## Limits

No full `test:all`, full TypeScript build, live-provider request, Android device test, dependency installation, APK build, or install was performed. This change hardens prompt serialization; it does not prove prompt-injection immunity or live AI availability.
