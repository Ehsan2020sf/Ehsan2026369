# NOVIN Economy Control Hardening

## Scope
The Economy layer now has a fail-closed budget admission boundary before model-cost work is started.

## Guarantees
- Model-call estimates must be finite and non-negative.
- A model call cannot be admitted when the economic throttle is active.
- A call that would exceed the daily token limit is blocked before accounting as executed.
- Invalid cost estimates cannot mutate usage accounting and force the governor into a throttled state.
- Deterministic fast paths are denied while throttled.
- Environment command routing performs economic preflight before non-deterministic work.
- Accounting remains explicit and does not fabricate prior usage.

## Reality boundary
The governor controls economic admission and accounting. It does not authorize OWNER actions, prove external execution, or manufacture execution evidence.
