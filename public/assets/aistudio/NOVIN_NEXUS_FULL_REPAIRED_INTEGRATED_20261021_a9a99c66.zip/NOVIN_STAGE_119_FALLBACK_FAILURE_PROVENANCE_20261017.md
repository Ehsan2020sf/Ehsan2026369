# NOVIN Stage 119: Fallback Failure Provenance

Date: 2026-10-17

## Finding
When the primary live provider and one or more fallback providers failed, the gateway's final `UNKNOWN` response reported only the primary provider error. Fallback failures were used to update provider health, but their diagnostic attribution was discarded. This could mislead troubleshooting and obscure which provider actually failed last.

## Change
- `src/core/ai/aiGateway.ts`: retain provider ID and error message for the latest failed fallback. The final failure now reports the primary error and the latest fallback provider/error while still returning empty content, `UNKNOWN` reality, `providerId=none`, `modelId=none`, and zero cost.
- `scripts/test_ai_gateway_marks_fallback_failure.ts`: assert the terminal error retains primary-chain context and fallback provider attribution.

## Focused validation
All commands below were run directly using the existing Node runtime, without installing dependencies:
- `node --experimental-strip-types scripts/test_ai_gateway_marks_fallback_failure.ts` — PASS
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts` — PASS
- `node --experimental-strip-types scripts/test_ai_gateway_request_trace_provenance.ts` — PASS
- `node --experimental-strip-types scripts/test_ai_gateway_blocked_request_trace.ts` — PASS

The fallback failure test observed primaryCalls=3 and fallbackCalls=1, confirmed fallback cooldown, and retained `UNKNOWN` reality. The idempotency test confirmed concurrent callers joined one execution, the explicitly opted-in simulator remained labelled `SIMULATED`, and no simulated cost was counted.

## Limits
- These are controlled local tests with mocked HTTP responses, not live-provider verification.
- Full `test:all` and full TypeScript compilation were not run.
- No dependency installation, APK build, or Android device installation/test was performed.

## Release evidence
Archive integrity, unique paths, changed-file parity, and SHA-256 are recorded in the stage completion message after in-place archive validation.
