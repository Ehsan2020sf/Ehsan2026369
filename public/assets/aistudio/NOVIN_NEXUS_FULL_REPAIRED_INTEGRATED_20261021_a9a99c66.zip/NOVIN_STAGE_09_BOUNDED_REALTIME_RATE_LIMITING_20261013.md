# NOVIN NEXUS Stage 09: Bounded Realtime Broker Rate Limiting

Date: 2026-10-13
Previous version: `0.9.27-unified`
Updated source version: `0.9.28-unified`
Android versionName/versionCode: `0.9.28` / `92800`
Canonical archive path retained: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Risk addressed

The realtime session route previously tracked request counts in an unbounded `Map` keyed by socket remote address. Expired entries were pruned during requests, but a high volume of distinct source addresses inside the active ten-minute window could still grow the map without a hard ceiling. The fixed `Retry-After: 600` also overstated the actual remaining wait after the first request window had elapsed partially.

## Implemented

- Added `BoundedSourceRateLimiter`, a deterministic, injectable-time limiter with a fixed source-table capacity.
- Realtime broker remains limited to six requests per source in ten minutes.
- Active source records are reclaimed after expiry; source identifiers are bounded to 256 characters.
- When the source table reaches 10,000 active entries, new sources are denied closed with HTTP 503 instead of allowing memory growth. Existing sources continue to receive normal rate-limit decisions.
- Per-source request excess returns HTTP 429 and an accurate `Retry-After` based on the remaining window.
- Both denial responses include `clientSecret: null`; credentials are never issued on the limiter-denial branch.
- Added nine direct limiter assertions and seven route integration-contract checks. Both are included in `test:all`.
- Updated package/lockfile, Android/system release metadata, and the production release-audit expectation to `0.9.28-unified` / `0.9.28` / `92800`.
- Regenerated the neural engineering index from the current source tree.

## Verification scope

- `npm run test:all`: PASS, exit 0, including all existing source contracts and the new limiter/route/version checks.
- `npm run test:rebuild-integrity`: PASS, exit 0, including deep-core smoke and Android runtime source contracts.
- Fresh extraction of the canonical archive: `npm run test:all` PASS, `npm run test:rebuild-integrity` PASS, archive permission safety PASS (1,395 directories and 7,825 files), and `unzip -t` PASS. These checks were run before the final status JSON hash refresh; the final archive is revalidated after repacking.

The limiter tests use a deterministic clock and prove request threshold, retry duration, capacity bound, expiry reclamation and constructor validation. The route contract test statically checks that the realtime endpoint consumes the limiter before broker issuance and fails closed on denial. These are source-level checks, not a live HTTP load test.

## Still blocked / not verified

- A fresh `npm ci --include=optional --no-audit --no-fund` retry was attempted after the source tests passed. The npm debug log shows repeated `EAI_AGAIN` errors against `registry.npmjs.org`; the interrupted partial `node_modules` directory was removed to keep the working tree clean.

- TypeScript and production web build remain blocked until exact npm dependencies are restored.
- No APK was built in this stage.
- Live HTTP rate-limit behavior, reverse-proxy address semantics, provider-backed WebRTC and physical-device behavior are not verified.
- The in-memory limiter is per-process and not a distributed rate limit; multi-instance deployments need a shared store and trusted proxy configuration before public production exposure.

## Next actions

1. Restore exact lockfile dependencies on a network-enabled Linux x64 host.
2. Pass TypeScript and production web build, generate and verify the source-digest asset manifest.
3. Run Capacitor sync and pass Android asset freshness checks.
4. Build and inspect the APK, then test on Redmi Note 11 Android 13.
5. Perform an HTTP integration/load test of the limiter and verify source IP handling for the actual deployment topology.
