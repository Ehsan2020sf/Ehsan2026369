# NOVIN Deep Rebuild / Visual Android Audit - 2026-10-01 Cycle 3

## Scope
This cycle started from the current live reference ZIP and inspected the Android entrypoint, WebView root, React Android runtime, 3D avatar scene, visual fallback, voice lifecycle, performance governor, Gradle wrapper/build contracts, archive cleanliness, and core regression gates.

## Root cause addressed
The Android visual page had unnecessary vertical consumers around the avatar: a top status-card row plus the avatar component's own footer/control region. On small Android viewports this could squeeze or clip the actual WebGL stage. The Android avatar component is now a full-height stage with the command bar owned by the Android shell, while the avatar visual footer is suppressed in Android mode.

The runtime also now uses dynamic viewport height (`100dvh`) and Android safe-area padding. The 3D camera was tightened for mobile framing and the humanoid presentation was slightly enlarged.

## Visual runtime
- 3D mount is independent from Native capability verification.
- WebGL Error Boundary exists.
- WebGL context loss is handled with bounded recovery.
- Visual fallback remains animated and visible.
- Living HUD exposes BRAIN / VOICE / REALITY state.
- Environment platform, spatial core, holographic pillars and particles are retained.
- Canvas fills the stage.
- Android mode uses a dedicated full-height shell.
- Mobile dynamic viewport and safe-area contracts are enforced.

## Android voice/runtime
- Native SpeechRecognizer is canonical; Web Speech is fallback.
- TTS stops Native SpeechRecognizer to prevent feedback loops.
- Native TTS completion uses utterance IDs and returns control to continuous listening.
- Session-generation guard prevents late start completions from resurrecting cancelled listening.
- Stale execution and TTS completion guards remain active.
- Graphics profile is session cached.

## Evidence gates
- `npm run test:all`: PASS
- `npm run test:deep-core-smoke`: PASS
- `npm run test:runtime-android-smoke`: PASS in this source environment
- `npm run test:rebuild-integrity`: PASS
- Android Visual Runtime Contract: 19/19 PASS
- Android Visual Quality Governor: 5/5 PASS
- Android Native Runtime Contract: PASS
- Android Avatar Runtime Contract: PASS
- Script Registry: PASS, 372 scripts / 336 referenced files / 4 required contracts
- Archive Cleanliness: PASS
- Reality Claims: PASS, 1676 files scanned
- Automation Hardening: PASS
- JavaScript/MJS syntax: 133 files, 0 failures
- `npm ci --dry-run`: PASS, 520 packages resolved

## Environment limitations
- Full `npm ci` is NOT VERIFIED because the offline cache is missing `zustand-5.0.15.tgz`.
- Full TypeScript type-check is NOT VERIFIED without project type packages installed.
- Gradle 8.13 binary build is BLOCKED by the environment because `services.gradle.org` cannot be resolved.
- Physical Redmi Note 11 execution is NOT_VERIFIED in this environment.

## Integrity policy
No APK/AAB was fabricated. No physical-device PASS was asserted. No private `local.properties`, `.env.local`, `node_modules`, or Git metadata is included in the source reference archive.
