# NOVIN EHSAN R12 Repair Ledger

## Scope
Truth/UI consistency hardening from R11.

## Repairs
- Removed unconditional 100% Green diagnostic presentation.
- Diagnostic success styling now excludes blocking/unverified evidence.
- Software Factory fallback pipeline no longer fabricates a PASS preflight.
- Dev Agent no longer displays READY when zero-quota offline capability is not verified.

## Verification
- Text-level assertions: PASS
- ZIP integrity: pending final packaging
- Real Android build/device/live-provider: NOT VERIFIED
