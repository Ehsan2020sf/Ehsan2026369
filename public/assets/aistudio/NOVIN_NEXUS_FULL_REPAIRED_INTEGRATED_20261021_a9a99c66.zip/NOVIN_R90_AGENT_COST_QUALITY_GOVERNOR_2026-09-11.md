# NOVIN R90 | Agent Cost + Quality Governor

Date: 2026-09-11

## Scope
Added an evidence-aware cost/quality governor for Agent execution. It selects among eligible READY agents using capability proficiency, verified performance, historical average cost, risk compatibility, quality floor, and remaining mission budget.

## Decision policy
- Risk/readiness/capability remain hard eligibility gates.
- Remaining budget is a hard gate.
- Quality floor is a hard gate for candidate selection.
- Verified performance can improve selection but cannot override governance.
- Unknown or simulated history does not become verified success.
- Ties are deterministic by quality, value, cost, then agent ID.
- No external side effects are authorized.

## Integration
AgentSupervisor now consults the governor before initial task assignment, using the task's estimated cost and remaining mission budget.

## Tests
- AGENT_COST_QUALITY_GOVERNOR_PASS
- AGENT_SUPERVISOR_PASS
- AGENT_LEARNING_ENGINE_PASS
- AGENT_ROUTING_ENGINE_PASS
- MISSION_LEARNING_ENGINE_PASS
- AGENT_WORKFORCE_ORCHESTRATOR_PASS
- Source files: 555 TS/TSX files

## Truth
Truth level: STATIC_VERIFIED.
No claim is made for live provider execution, production deployment, Android device execution, or external side effects.

## Next locked direction
Agent Operations Control Plane: connect queue/scheduler, supervisor, routing, cost/quality governance, recovery, evidence, and learning into one bounded mission control loop without creating a parallel orchestration system.
