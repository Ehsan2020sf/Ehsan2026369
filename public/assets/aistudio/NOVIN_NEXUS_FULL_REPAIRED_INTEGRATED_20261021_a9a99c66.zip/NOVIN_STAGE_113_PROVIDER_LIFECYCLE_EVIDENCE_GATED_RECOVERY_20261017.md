# NOVIN Stage 113 — Evidence-Gated Provider Recovery

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding

`MultimodalProviderLifecycle.observe()` previously allowed a successful observation with non-real evidence to overwrite `QUARANTINED` / `RECOVERING` with `DEGRADED`. Since `select()` permits degraded providers, a simulated or unverified success could make a quarantined provider selectable before the required number of real recovery observations. The restore path also trusted persisted snapshots based mainly on two string fields, leaving malformed counters, states, timestamps, or evidence values able to enter routing state.

## Changes

- Recovery qualification now requires `REAL_EXECUTED` when `requireRealEvidence` is enabled.
- Simulated/static/unverified success does not increment real recovery successes and does not release quarantine.
- Real recovery requires the configured consecutive success count before state becomes `ACTIVE`.
- Persisted lifecycle snapshots are validated for state/evidence enums, nonnegative safe-integer counters, parseable timestamp, bounded reason, and nonempty adapter ID before restoring.
- Added `src/core/ai/multimodalProviderLifecycle.evidence-hardening.test.ts` and wired it into `test:all` through `test:multimodal-provider-lifecycle-evidence-hardening`.

## Executed evidence

PASS:
- `node --experimental-strip-types src/core/ai/multimodalProviderLifecycle.test.ts`
- `node --experimental-strip-types src/core/ai/multimodalProviderLifecycle.persistence.test.ts`
- `node --experimental-strip-types src/core/ai/multimodalProviderLifecycle.evidence-hardening.test.ts`
- `node --experimental-strip-types src/core/ai/multimodalProviderTelemetry.test.ts`
- `node --experimental-strip-types src/core/ai/multimodalProviderHealth.test.ts`
- `node --experimental-strip-types src/core/ai/novinUniversalMultimodalRuntime.test.ts`
- `node --experimental-strip-types src/core/ai/providerFailurePolicy.test.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_malformed_http_failure.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_transient_http_retry.ts`
- `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
- `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
- package JSON parsing and test-chain wiring check

The focused lifecycle test confirms: quarantine after two failures; simulated success leaves the provider quarantined and does not count as recovery; first real success enters `RECOVERING`; second real success activates the provider; malformed persisted state is ignored.

## Limitations

- Full `test:all` was not run.
- Full TypeScript compilation was not rerun here.
- No live provider/network call was made; provider behavior tests use controlled responses.
- No dependencies were installed, no APK was built, and no device installation or device test was performed.

## Status

- Provider lifecycle evidence gating: PASS (focused tests)
- Persisted snapshot validation: PASS (focused test)
- Full repository release validation: UNKNOWN / NOT RUN
- Android runtime validation: NOT TESTED
