# NOVIN NEXUS engineering batch: bounded IF routing

Date: 2026-10-15
Scope: Android app project only. No website, server, or full n8n runtime was added.

## Change

Extended `src/core/agent/n8nSafeLocalRuntime.ts` with a small, deterministic `n8n-nodes-base.if` subset. To avoid guessing across n8n versions, it accepts only NOVIN's explicit `parameters.novinSafeCondition` schema:

- `field`: a top-level key in each item's JSON object
- `operator`: `equals`, `notEquals`, `greaterThan`, `lessThan`, `isTrue`, `isFalse`, or `exists`
- `value`: required and scalar for equality/inequality/numeric comparisons
- IF connections must explicitly contain exactly two `main` output branches: true at index 0 and false at index 1

Numeric comparisons only compare finite numeric values. No expression evaluation, nested-field paths, type coercion, arbitrary condition DSL, or n8n-version-specific condition parsing is supported. Unsupported or malformed conditions are rejected during whole-graph preflight before nodes execute.

## Safety contract retained

- Full graph preflight before execution.
- Pure local data only; no network, credentials, shell, arbitrary code, or external side effects.
- `sideEffects: false` and `executionAllowed: false` remain fixed.
- Bounded graph size, steps, items, and serialized input/output.
- This is not full n8n compatibility and does not make the imported workflow library production-executable.

## Test evidence

`src/core/agent/n8nSafeLocalRuntime.test.ts` covers true and false branch routing, unsupported condition format, malformed branch wiring, static Set transformation, and fail-closed cases. Full project `npm run test:all`: PASS (exit code 0), including n8n catalog validation, all 2,066 graph asset checks, adaptive display integration, and the new IF branch tests. APK build and physical-device testing were not performed in this batch.
