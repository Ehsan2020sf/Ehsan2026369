# NOVIN Stage 114: Fallback Provider Health Propagation
Date: 2026-10-17

## Finding
The primary provider failure path updated `ModelRouter` health, but the secondary fallback-provider catch path silently continued without recording that provider's failure. A broken fallback could therefore remain selectable and be retried on subsequent requests despite a known failure.

## Change
- `src/core/ai/aiGateway.ts`: when a non-simulated fallback provider call throws, record `modelRouter.markProviderFailure(fbModel.providerId)` before continuing the fallback chain.
- `scripts/test_ai_gateway_marks_fallback_failure.ts`: controlled local mock integration test. OpenAI returns HTTP 503 with an HTML body and exhausts its bounded retries; Gemini returns HTTP 401 with an HTML body. The test verifies both providers were exercised, the failed fallback enters cooldown, and the final response is empty with `reality=UNKNOWN`.
- `package.json`: add `test:ai-gateway-fallback-failure-health` and include it in `test:all`.

## Evidence
- `node --experimental-strip-types scripts/test_ai_gateway_marks_fallback_failure.ts`: PASS. Observed `primaryCalls=3`, `fallbackCalls=1`, `fallbackCooldown=PASS`, `reality=UNKNOWN`.
- No live external network calls; fetch was replaced with deterministic local responses.
- No dependency installation, APK build, or device installation performed.

## Status
- Targeted fallback-health regression: PASS.
- Full `test:all`: NOT RUN.
- Full TypeScript check: BLOCKED by missing local type packages in the current no-install environment, as documented in the prior stage.
