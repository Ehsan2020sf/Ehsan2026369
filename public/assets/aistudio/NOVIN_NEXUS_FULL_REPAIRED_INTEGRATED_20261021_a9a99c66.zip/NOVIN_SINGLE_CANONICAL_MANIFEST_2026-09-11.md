# NOVIN NEXUS Single Canonical Project

Date: 2026-09-11

This archive is the single canonical NOVIN NEXUS project package.

Sources reconciled:
- NOVIN_NEXUS_UNIFIED_COMPLETE_2026-09-11.zip (latest primary source)
- NOVIN_NEXUS_MASTER_FINAL_2026-09-10.zip
- NOVIN_NEXUS_MASTER_REBUILT_2026-09-10.zip
- NOVIN_NEXUS_UNIFIED_ENGINEERED_2026-09-10-r6.zip
- NOVIN_NEXUS_UNIFIED_ENGINEERED_2026-09-10-r6-COMPLETE.zip
- NOVIN_NEXUS_UNIFIED_ENGINEERED_2026-09-10-r6-REPAIRED.zip

Reconciliation result:
- The latest primary source contains all project source/config/report paths found in the other NOVIN archives.
- Older archives did not contain project paths absent from the latest primary source once generated dependency artifacts were excluded.
- The repaired archive contained node_modules; node_modules is intentionally excluded from the canonical source archive because it is environment-generated and can be reconstructed from package-lock.json.
- No parallel project branch was created.

Canonical rule:
This archive is the only ZIP reference for future NOVIN packaging. Future changes must be applied to the canonical working tree and replace this archive when a new complete package is produced.

Truth rule:
Archive completeness does not imply Android/production verification. Build, device, external-service and live-AI status must remain evidence-based.
