# NOVIN Stage 111: Malformed HTTP provider failure integration
Date: 2026-10-17

## Regression found and fixed
Provider adapters previously parsed the HTTP body as JSON before branching on `response.ok`. If an authentication gateway returned HTML or invalid JSON for HTTP 401/403, JSON parsing could throw a generic error and be wrapped as retryable, losing the authoritative HTTP status.

## Focused integration evidence
- `node --experimental-strip-types scripts/test_ai_gateway_malformed_http_failure.ts`: PASS. Synthetic HTTP 401 with an HTML body produces one provider call, empty content, and reality `UNKNOWN`; it is not retried.
- `node --experimental-strip-types scripts/test_ai_gateway_transient_http_retry.ts`: PASS. Synthetic HTTP 503 with an HTML body uses three total attempts (initial attempt plus two bounded retries), then returns empty content and reality `UNKNOWN`.
- `node --experimental-strip-types scripts/test_ai_gateway_provider_response_integrity.ts`: PASS. Invalid usage is rejected, reality remains `UNKNOWN`, and cost metrics remain finite.
- `node --experimental-strip-types scripts/test_ai_gateway_runtime_provider_refresh.ts`: PASS. Runtime permission boundary remains enforced.

All network responses in these tests are mocked locally; no real service was contacted.
