# NOVIN Governed Agent → Tool → Evidence → Recovery/Commit Chain

Date: 2026-10-05
Reference lineage: `NOVIN_UNIFIED_ENGINEERING_20261004_FINAL.zip`
Reference SHA-256: `4409cd7e8217185a6a6c1cf3854f27b756517c2c5167e2925ad2f730c71d24ee`

## Implemented

A single fail-closed lifecycle was added at:

`src/core/agentRuntime/governedToolExecutionChain.ts`

Pipeline:

`Agent → Capability Selection → Access/Security → Tool Execution → Output Schema → R105 Result Validation → Evidence Decision → Recovery/Retry → Evidence Commit/Defer`

## Guarantees

- Tool selection is capability-aware and authorization-aware.
- No candidate means `BLOCKED`.
- Tool execution uses `executeGoverned()` only.
- Output schema must pass before evidence binding.
- Tool-result validation is installed before chain execution.
- `SIMULATED` results are not treated as observed evidence and are `DEFERRED`.
- `OBSERVED` results can be committed only as observed, not upgraded to verified.
- `VERIFIED_REAL` requires the existing Evidence Decision Governor path.
- Recovery is explicit and bounded to one retry when approved.
- Failed execution without approved retry remains `BLOCKED`.
- `generatedOutputIsProof` remains permanently false.
- `externalActionAuthorized` remains false in this chain contract.

## Evidence / Test Results

- `PASS GOVERNED_AGENT_TOOL_EVIDENCE_RECOVERY_CHAIN 4/4`
- `TOOL_OUTPUT_CONTRACT_GATE_PASS`
- `R101_TOOL_REGISTRY_CAPABILITY_BINDING_PASS`
- `R105_TOOL_RESULT_VALIDATION_EVIDENCE_BINDING_PASS`
- `EVIDENCE_DECISION_GOVERNOR: PASS`
- `python3 -m compileall -q src/core/learning523` PASS

## Real limitation

These tests validate the NOVIN governance/execution chain in the current local runtime. They do not prove external cloud providers, physical Android hardware, camera/microphone, GPU execution, or production network integrations.
