# NOVIN Business Relation Graph Hardening — 2026-09-23

## Scope
فقط Business Relationship Integrity Graph بررسی و اصلاح شد.

## Findings
- یک شرط tenant-check مرده بود و هیچ‌وقت نمی‌توانست violation تولید کند؛ حذف شد چون tenant validation واقعی در typed groups انجام می‌شود.
- رابطه‌های Customer/Opportunity و مقادیر مالی Opportunity بررسی می‌شوند.
- Quote و QuoteItem از نظر grandTotal و totalPrice بررسی می‌شوند.
- Sale از نظر grandTotal، paidAmount و رابطه پرداخت با مبلغ فروش بررسی می‌شود.
- Invoice از نظر tenant/customer با Sale و محدودیت outstandingBalance بررسی می‌شود.
- Payment از نظر tenant با Invoice و مقدار مالی معتبر بررسی می‌شود.
- Warranty اکنون customer↔sale و customer↔invoice را نیز کنترل می‌کند.
- Installation اکنون customer↔sale را کنترل می‌کند.
- Service Ticket اکنون product↔warranty را در صورت وجود warrantyId کنترل می‌کند.

## Evidence
- `businessIntegrityEngine.test.ts`: PASS
- `businessIntegrityEngine.reality.test.ts`: PASS
- `businessTruthHardening.test.ts`: PASS
- `businessExportReality.test.ts`: PASS
- `paymentEngine.reality.test.ts`: PASS

## Reality boundary
این بخش فقط integrity/relationship validation است. این اصلاح به معنی وجود دیتابیس خارجی واقعی، connector واقعی، یا production persistence نیست.

## Status
PASS برای این بخش در سطح source/runtime tests.
Production database integration remains NOT VERIFIED.
