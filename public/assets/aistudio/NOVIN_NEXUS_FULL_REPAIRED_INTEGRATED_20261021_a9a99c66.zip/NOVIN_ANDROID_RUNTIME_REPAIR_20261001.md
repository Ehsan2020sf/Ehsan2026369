# NOVIN Android Runtime Repair — 2026-10-01

## Source repairs applied
- Re-enabled the real React Three Fiber avatar scene.
- Removed the visible `NOVIN WEBGL DIAGNOSTIC` placeholder.
- Removed the English `NOVIN AVATAR / ANDROID RUNTIME` header from the Android runtime UI.
- Removed the HTML boot/debug marker from `index.html`.
- Added a WebGL error boundary so a renderer failure does not kill the command/voice UI.
- Cached the mobile graphics profile so WebGL capability probing is not repeated during every render.
- Removed duplicate Android/QuickJS startup probes from `App.tsx`; Android runtime now owns startup sequencing.
- Added staged Android boot state: BOOTING -> NATIVE -> READY, with fail-closed BLOCKED state.
- Voice/text controls remain disabled until the Android bridge is verified.
- Performance governor starts only after the runtime reaches READY.
- Delayed the observational Device Guardian service by 15 seconds so it does not compete with first WebView/WebGL initialization.

## Verification status
- Source inspection: PASS.
- Diagnostic/boot-marker source strings removed: PASS.
- Existing generated Android bundle/APK was not rebuilt in this environment.
- `npm ci` timed out before dependency installation completed, so a compiled APK success is NOT claimed.

## Next real verification
Build the updated source on the target Redmi Note 11 using the project's normal Android/Termux build path, then verify the installed APK on the physical device.
