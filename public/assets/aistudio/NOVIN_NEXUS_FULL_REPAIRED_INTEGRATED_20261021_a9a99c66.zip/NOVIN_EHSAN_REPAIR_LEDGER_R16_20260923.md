# NOVIN EHSAN Repair Ledger R16 — 2026-09-23

## اصلاح واقعی
- وابستگی مستقیم `ToolRegistry` به `AgentRegistry` حذف و به پورت قراردادی `agentRegistryPort` منتقل شد.
- وابستگی مستقیم `ToolRegistry` به `toolResultValidation` حذف و به پورت قراردادی `toolResultValidationPort` منتقل شد؛ در نبود validator، نتیجه به‌صورت fail-closed رد می‌شود.
- پیوند Health Check به `AgentRegistry` و `jobQueue` مستقیم حذف و از قراردادهای پورت استفاده شد.
- Ledger شواهد عامل از مرز Agent به مرز Evidence استخراج شد؛ فایل Agent فقط compatibility export است.
- قرارداد `Mission` به `contracts/missionTypes.ts` منتقل شد تا Security برای type به Agent وابسته نباشد.
- ممیزی معماری به‌صورت صریح فقط production source را بررسی می‌کند و فایل‌های test را از graph معماری حذف می‌کند؛ این تغییر صرفاً دامنه ممیزی را اصلاح می‌کند و cycle واقعی production را PASS فرض نمی‌کند.

## Evidence نهایی
- `toolRegistry` import: PASS
- `healthChecks` import: PASS
- `test_reality_source_of_truth_fingerprint.mjs`: PASS
- `test_reality_source_of_truth_freshness.mjs`: PASS
- `test_reality_claims.mjs`: PASS
- ZIP integrity: باید با `unzip -t` تأیید شود.
- Architecture boundary: FAIL / REQUIRES_REFACTOR، cycle چندماژولی production هنوز باقی است.
- Phase 0: BLOCKED، به‌دلیل 31 dependency نصب‌نشده و typecheck غیرقابل اجرا.
- Android/device/live AI: NOT VERIFIED.

## اصل حاکم
هیچ cycle معماری حل‌نشده یا build/device/live evidence به‌عنوان PASS گزارش نمی‌شود.
