# NOVIN Brain Deep Hardening — r6.1

## هدف
تقویت مغز NOVIN در همان r6، بدون ساخت شاخه موازی و بدون تغییر فایل سالم خارج از مسیر موردنیاز.

## هسته تقویت‌شده
`src/core/ai/brainCoordinator.ts`

- وضعیت معرفتی خروجی: `KNOWN / OBSERVED / INFERRED / UNCERTAIN / CONFLICTED`
- `evidenceCoverage`: اندازه‌گیری پوشش شواهد برای آیتم‌های زمینه
- `contextQuality`: اندازه‌گیری کیفیت زمینه قبل از نتیجه‌گیری
- کالیبراسیون محافظه‌کارانه confidence بر اساس شواهد
- مدل زبانی فقط explanation را غنی می‌کند و به‌تنهایی evidence یا confidence اضافه نمی‌کند
- `subQuestions`: شکستن پرسش به دانسته‌ها، ناشناخته‌ها و شواهد موردنیاز
- `nextActions`: مسیر بعدی پیشنهادی بر اساس شکاف شواهد و تعارض
- `safety`: تعیین می‌کند خروجی فقط برای اطلاع است یا قبل از اقدام نیاز به راستی‌آزمایی/انسان دارد
- انتقال `evidenceRefs` حافظه به provenance زمینه برای جلوگیری از قطع‌شدن زنجیره شواهد

## تست و کیفیت
- `BRAIN_HARDENING_PASS`
- `BRAIN_TEST_RESULT`: `INSUFFICIENT_CONTEXT`, confidence `0`, reality `UNKNOWN`
- `REASONING_DECISION_SMOKE_PASS`
- `unified_integrity_audit`: PASS، 441 فایل، 0 خطا، 0 هشدار
- `REALITY_CLAIMS_PASS`: PASS، 393 فایل
- تست reasoning/decision برای جلوگیری از وابستگی به memory persistence ایزوله شد.

## مرزهای واقعی
Live AI provider هنوز عمداً در secure build path پیاده‌سازی نشده است. Native Android build نیز تا فراهم‌شدن toolchain خارجی قابل‌تأیید نیست. این ارتقا هیچ ادعای جعلی درباره اجرای مدل زنده یا APK ایجاد نمی‌کند.
