# NOVIN NEXUS Stage 10: Rate Limiter Sweep Efficiency and Clock Integrity

Date: 2026-10-13
Previous version: `0.9.28-unified`
Updated source version: `0.9.29-unified`
Android versionName/versionCode: `0.9.29` / `92900`
Canonical archive path retained: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Risk addressed

The bounded realtime limiter was memory-safe, but it swept every tracked source on every request. With up to 10,000 source records, a hot endpoint could pay O(maxSources) cleanup cost for every request. The clock behavior also depended on wall-clock assumptions, and invalid injected clock values were not explicitly rejected.

## Implemented

- Added a bounded cleanup cadence (default 1,000 ms, never greater than the rate window) so the full source table is not scanned on every request.
- Retained the hard maximum source table size and fail-closed capacity behavior between cleanup sweeps.
- Added deterministic reset behavior when the supplied clock moves backwards, preventing windows created in a later time domain from blocking requests indefinitely.
- Reject non-finite clock values and invalid cleanup intervals.
- Expanded the limiter test to 15 assertions covering allowed requests, rate-limit retry duration, capacity, expiry reclamation, invalid constructor inputs, invalid clock input, clock rollback, and high-cardinality churn.
- Aligned active release metadata to `0.9.29-unified` / `0.9.29` / `92900` and regenerated the static neural engineering index.

## Verification

- `npm run test:all`: PASS, exit 0.
- `npm run test:rebuild-integrity`: PASS, exit 0.
- Direct limiter test: PASS, 15 assertions.
- Realtime route rate-limit source contract: PASS, 7 checks.
- Release version alignment: PASS, 12 checks.
- Android graphics runtime safety contract: PASS.
- Production web build: BLOCKED at platform dependency preflight because `@esbuild/linux-x64` and `@rollup/rollup-linux-x64-gnu` are not installed. The lockfile exists, but this environment's prior npm registry access failed with `EAI_AGAIN`.

## Still blocked / not verified

- TypeScript/lint and production web build are not passed because dependencies are absent.
- Current source-digest web asset manifest is absent; Android packaged assets remain stale/unverified.
- APK: `NOT BUILT`.
- Redmi Note 11 physical-device runtime: `NOT TESTED`.
- Live HTTP load, reverse-proxy/source-IP behavior, and provider-backed WebRTC: `NOT VERIFIED`.
- The limiter remains in-memory and per-process; a public multi-instance deployment requires a shared limiter store and an explicitly validated trusted-proxy topology.

## Next actions

1. Restore exact lockfile dependencies on a network-enabled Linux x64 host.
2. Pass lint and production web build; generate and verify the source-digest asset manifest.
3. Run Capacitor sync and pass the Android asset freshness/hash gate.
4. Build and inspect the APK, then test on Redmi Note 11 Android 13.
5. Exercise the realtime route under real HTTP load and validate the deployment's proxy/source-address behavior.

**Truth boundary:** this stage improves cleanup cost and deterministic testability. It does not claim a live HTTP load test, provider success, APK build, or device pass.
