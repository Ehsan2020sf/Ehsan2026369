# NOVIN Stage 107: Brain gateway correlation and attribution
Date: 2026-10-17

## Finding
`AIGatewayInferenceProvider` previously accepted non-empty gateway content without verifying that the returned `requestId` matched the request. It also did not reject missing provider/model attribution or contradictory simulated/live reality metadata. This adapter feeds the canonical brain contract, so these checks are required even when the lower gateway already validates its own response.

## Change
- The brain adapter now requires exact request correlation.
- Provider and model IDs must be present and must not be `none` (case/whitespace normalized for the sentinel check).
- `GENERATED` cannot be attributed to `local-simulated`; `SIMULATED` must be attributed to `local-simulated`.
- Unsupported/unknown reality is rejected instead of being returned as a successful answer.
- Integrity failures return a failure result with a specific error code and evidence classified as `UNKNOWN`.
- Updated the focused provider test to use the actual request ID and added mismatch, missing attribution, and simulator-spoof cases.

## Validation
Passed:
- `node --experimental-strip-types src/brain/aiGatewayProvider.test.ts`
- `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
- `node --experimental-strip-types src/core/mobile/avatarCommandPresentationIntegrity.test.ts`
- `node scripts/test_avatar_command_presentation_boundary.mjs`
- `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
- `node --experimental-strip-types src/core/mobile/novinPersianConversationRuntime.test.ts`
- `node scripts/test_runtime_reply_reality_boundary.mjs`
- `node --experimental-strip-types scripts/test_ai_gateway_runtime_provider_refresh.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_provider_response_integrity.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_concurrency.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_failure_recovery.ts`
- `package.json` JSON parse.

## Limits
- The `novinAvatarCommandAuthority.test.ts` invocation is BLOCKED because `@capacitor/core` is not installed in this environment. No dependencies were installed.
- Full `test:all` and full TypeScript build were not run.
- No live provider request, APK build, or Android installation was performed.

## Status
PASS for focused adapter and response-boundary tests. Full application build and live provider/device integration remain NOT TESTED.
