# NOVIN EHSAN Repair Ledger R22

## تغییر واقعی
- `scripts/novin_auto_build.mjs`: حذف fallback خطرناک تشخیص ZIP بر اساس نام فایل.
- حذف پیش‌فرض حذف ZIP پس از نصب؛ حذف فایل فقط با `NOVIN_ALLOW_ZIP_CLEANUP=1` و پس از تأیید manifest مجاز است.
- نام آرشیو پیش‌فرض به خط فعلی «زیپ احسان» منتقل شد و با `NOVIN_CANONICAL_ZIP_NAME` قابل تعیین است.

## Evidence
- Node syntax: PASS
- Unified Integrity: PASS
- Reality Claims: PASS
- Architecture Control Plane: PASS
- این تغییر هیچ‌گونه ادعای Build/APK/Device E2E ایجاد نمی‌کند.
