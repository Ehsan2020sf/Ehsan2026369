# NOVIN EHSAN Repair Ledger R39

- Source: NOVIN_NEXUS_EHSAN_20260924_R38
- Real issue found: `scripts/test_ai_provider_failure_fallback.ts` attempted a forced live-provider fallback without satisfying the gateway's owner-approval and explicit simulated-fallback governance requirements.
- Repair: test now supplies `metadata.ownerApproved=true` and `metadata.allowSimulatedFallback=true` because the test explicitly expects local simulated fallback.
- Verification: `node --experimental-strip-types scripts/test_ai_provider_failure_fallback.ts` PASS.
- Verification: `node scripts/test_reality_claims.mjs` PASS, filesScanned=1374.
- Live Gemini/OpenAI was NOT tested and is NOT claimed as verified.
