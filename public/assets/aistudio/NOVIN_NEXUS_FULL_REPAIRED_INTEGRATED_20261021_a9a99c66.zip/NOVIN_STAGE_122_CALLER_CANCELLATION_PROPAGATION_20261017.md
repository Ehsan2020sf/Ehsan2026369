# NOVIN Stage 122: Caller Cancellation Propagation

Date: 2026-10-17
Scope: static source change and focused local regression tests only. No dependency installation, full build, APK build, or device installation.

## Finding

The AI gateway had provider-local timeout cancellation, but `AIRequest` had no caller cancellation signal. A caller could not explicitly stop an active provider request through the gateway. Also, treating a caller-initiated abort as a provider failure would contaminate provider health evidence.

## Changes

- `src/core/ai/types.ts`: added optional `AIRequest.signal?: AbortSignal`. The signal is deliberately excluded from the idempotency fingerprint because it is execution control, not request content.
- `src/core/ai/aiGateway.ts`: combined caller cancellation with bounded provider timeout for OpenAI and Gemini fetches; stopped retries and fallback after caller cancellation; classified caller cancellation as `REQUEST_ABORTED_BY_CALLER`; returned empty content, `UNKNOWN` reality and zero cost for cancellation; did not cache cancelled results; did not mark provider health as failed for caller intent.
- `scripts/test_ai_gateway_caller_cancellation.ts`: added regression coverage for active cancellation, no retry/fallback after abort, pre-aborted requests never reaching fetch, no caching of cancelled response, successful same-key retry after cancellation, and no provider health penalty for cancellation.

## Focused tests executed

All passed using local mocks and Node's experimental type stripping:

1. `scripts/test_ai_gateway_caller_cancellation.ts`
2. `scripts/test_ai_gateway_provider_timeout_classification.ts`
3. `scripts/test_ai_idempotency_concurrency.ts`
4. `scripts/test_ai_idempotency_inflight_ttl.ts`
5. `scripts/test_ai_idempotency_failure_recovery.ts`
6. `scripts/test_ai_gateway_provider_response_integrity.ts`
7. `scripts/test_ai_gateway_blocked_request_trace.ts`

The cancellation test observed one fetch for the cancelled execution and a second fetch for a subsequent retry with the same request ID. The cancellation response was `UNKNOWN`, empty, and costed at zero; the retry succeeded. A pre-aborted request did not reach fetch.

## Limits and status

- Focused regression tests: PASS.
- Full project test suite: NOT RUN.
- Full TypeScript compilation: NOT VERIFIED.
- Live provider/network behavior: NOT TESTED; mocks were used.
- APK build and Android device test: NOT RUN.
- Cancellation is associated with the first execution for an idempotency key; concurrent callers joining that exact execution share its result and cancellation lifecycle. This stage does not introduce independent cancellation semantics for each joiner.
