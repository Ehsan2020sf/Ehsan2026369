# NOVIN EHSAN Repair Ledger R27

شناسه: EHSAN-20260923-27

## اصلاح واقعی
سه مسیر مهندسی Android/Build دارای fallbackهای مسیر ثابت محیطی بودند:
- `server/engineering/qaEngine.ts`
- `server/engineering/buildManager.ts`
- `server/engineering/environmentManager.ts`

اصلاح شد تا SDK فقط از `ANDROID_HOME` یا `ANDROID_SDK_ROOT` و JDK فقط از `JAVA_HOME` دریافت شود. هیچ مسیر ثابت `/opt/android-sdk` یا `/usr/lib/jvm/...` در این سه مسیر باقی نماند.

## تست
- SERVER_ANDROID_ENV_PORTABILITY_PASS
- Unified Integrity: PASS
- Reality Claims: PASS
- Source Fingerprint Guard: PASS
- Freshness Guard: PASS
- TypeScript syntax parse for changed files: verified with Node strip-types parser
- ZIP Integrity: PASS

## وضعیت‌های هنوز حل‌نشده
- Phase 0 dependency/typecheck: BLOCKED by environment
- Android APK build: NOT VERIFIED
- Device E2E: NOT VERIFIED
- Live AI: NOT VERIFIED
