# NOVIN NEXUS Stage 06: npm Cache Evidence Precision

Date: 2026-10-15
Baseline archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`
Source version: `0.9.32-unified`

## Change

Extended `scripts/novin_dependency_recovery_audit.mjs` to expose package-name hints for missing dependencies found in `npm cache ls`. The report explicitly labels these as name-level hints only and never treats them as evidence that the exact lockfile-resolved tarball exists or is intact. The recovery recommendation now distinguishes an empty name-level cache listing from partial name-level hits.

Extended `scripts/test_novin_dependency_recovery_audit.mjs` with assertions for direct-dependency cache hints and the integrity-proof boundary.

## Verification

- `node --test scripts/test_novin_dependency_recovery_audit.mjs`: PASS.
- `node --test scripts/test_novin_diagnostic_recovery_plan.mjs`: PASS, 3 tests.
- `npm run test:all`: PASS, exit code 0.
- Dependency audit on this host: BLOCKED, 31 direct dependencies declared, 33 required package metadata entries missing, registry DNS probe failed, npm cache lists no missing package names.
- Web build: BLOCKED, not claimed as run successfully.
- APK: NOT BUILT.
- Physical Android device: NOT TESTED.

## Safety boundary

Do not bypass dependency preflight, modify the lockfile to hide missing packages, copy native `node_modules` across host architectures, or create placeholder build outputs. Restore dependencies from the exact lockfile on a compatible network-enabled host or from a verified complete cache, then rerun preflight and the web build.
