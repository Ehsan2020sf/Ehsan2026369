# NOVIN Stage 129: Crash Recovery Reconciliation

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding
`JobQueue.recoverInterruptedJobs()` previously changed every persisted `RUNNING` job back to `QUEUED` during startup. That is unsafe for actions with external side effects: the prior action may have succeeded externally even though its terminal state was not persisted, so automatic replay could duplicate the effect.

## Change
- Startup recovery now moves persisted `RUNNING` jobs to `FAILED` with `RECOVERY_REQUIRES_RECONCILIATION`.
- Stale lease owner, lease expiry, and retry schedule are cleared.
- The audit record uses `JOB_FAILED`, `RECOVERY_REQUIRED`, and reality `UNKNOWN`; it explicitly says prior external side effects remain unknown.
- A separate explicit `recover(id)` operation remains available after reconciliation. This does not claim that an external action was rolled back.
- Added `scripts/test_job_queue_crash_recovery_reconciliation.mjs` and package script `test:job-queue-crash-recovery`.

## Evidence
Executed:
- `node --experimental-strip-types scripts/test_job_queue_crash_recovery_reconciliation.mjs` — PASS (6 checks including runtime recovery from a persisted RUNNING snapshot and explicit recovery separation).
- `node scripts/test_job_queue_cancel_terminal_ownership.mjs` — PASS (4 checks).
- `node scripts/test_cancellation_autonomy_retry_boundary.mjs` — PASS (8 checks).

The runtime test used a temporary isolated data directory and a checksum-valid persisted queue snapshot. No network provider was called.

## Limits
- This does not provide distributed locking across multiple queue processes or a transactional outbox for external side effects.
- Explicit `recover(id)` re-queues a failed job; the caller must perform real-world reconciliation before invoking it. The queue cannot independently prove whether an external action occurred.
- Full `test:all`, full TypeScript compilation, APK build, and physical-device validation were not run. No dependencies were installed and no device installation was performed.
