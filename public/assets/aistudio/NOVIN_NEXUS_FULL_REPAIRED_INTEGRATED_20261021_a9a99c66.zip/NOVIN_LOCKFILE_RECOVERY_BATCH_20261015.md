# NOVIN dependency recovery batch — 2026-10-15

## Change

- Added a bounded npm registry connectivity preflight to `scripts/novin_lockfile_repair_pipeline.mjs` before attempting lockfile metadata repair.
- Registry failures now stop quickly with `NPM_REGISTRY_UNREACHABLE_OR_TIMEOUT`, preserve the original lockfile, and report the observed npm error.
- Added a fail-closed regression test for the network-preflight failure path.
- Documented the validation-only and no-false-success boundaries in `README.md`.

## Evidence observed in this environment

- `node scripts/test_novin_lockfile_repair_pipeline.mjs`: PASS.
- `npm run test:all`: PASS, exit code 0.
- Live registry probe: BLOCKED, npm returned `EAI_AGAIN` while resolving `registry.npmjs.org`.
- `package-lock.json` was not changed by the recovery pipeline.
- Lockfile artifact audit remains BLOCKED: 335 of 520 package entries are missing both `resolved` and `integrity` metadata.
- No dependency installation, web build, APK build, APK signature verification, or device installation was performed.

## Truth boundary

This batch improves failure diagnosis and avoids wasted retry time. It does not repair the missing lockfile metadata and does not unblock G1. Restore registry DNS/HTTPS on a trusted networked host, validate a lockfile candidate without changing package versions or root dependency declarations, then continue dependency restoration and the source-to-APK build.
