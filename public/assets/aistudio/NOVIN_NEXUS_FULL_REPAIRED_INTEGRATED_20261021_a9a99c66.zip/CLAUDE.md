# NOVIN NEXUS — Claude Code Project Contract

## Mission
Improve the existing NOVIN NEXUS / نوین هوشمند دید برتر Android-native assistant without restarting its architecture. Work evidence-first, preserve existing contracts, and optimize measurable capabilities rather than claiming AGI or sentience.

## Read once before acting
1. `NOVIN_START_HERE.md`
2. `NOVIN_ENGINEERING_CONTINUATION_STATE_20261013.json`
3. `AGENTS.md`
4. `NOVIN_CODEX_LOW_QUOTA_AGENT_MASTER_PROMPT_FA.md`
5. `NOVIN_VIBE_CODING_MULTI_AGENT_WORKFLOW_FA.md`
6. The directly relevant source and test files only.

## Non-negotiable rules
- The existing repository is authoritative. Reuse before rebuilding; no architecture reset.
- Do not duplicate Codex/Cursor/Windsurf instructions. Claude Code is an additional executor, not a reason to create a competing workflow.
- One owner per patch. Claude Code may own a single coherent patch only when explicitly invoked by the project owner.
- Keep diffs small, reversible, and within the relevant module. Do not reformat unrelated files.
- Do not change package identity, Android versionCode/versionName, public API contracts, persistence formats, or permissions without a concrete reason and regression tests.
- Never claim a test/build/provider/device pass unless that exact command or behavior was observed. Distinguish source tests, mocks/simulation, web build, APK, physical device, and live provider.
- `UNKNOWN` is not success. If a required dependency is unavailable, stop and report evidence rather than retrying network installs blindly.
- Do not add packages or upgrade dependencies merely for novelty. Preserve the lockfile.
- Never put secrets in source, prompts, frontend bundles, logs, or committed `.env` files. Do not weaken AEGIS, authorization, consent, budget, rate limits, cancellation, or cleanup.
- `JVE` and `LAVA` are separate owner-defined AI slots. Do not guess their meanings. Keep them disabled until purpose, provider/model, routing tags, and evidence are explicitly configured. See `NOVIN_CLAUDE_CODE_TOOL_BRIDGE_SPEC_FA.md`.
- Treat voice, memory, camera, avatar, and tool execution as separate capabilities with explicit permission and status boundaries.
- Use Persian for owner-facing explanations; code identifiers and test output remain as-is.

## Low-quota operating loop
1. Inspect git/status and only the files directly related to the task. Avoid broad rereads.
2. State the root cause hypothesis in one or two sentences, tied to evidence.
3. Make one cohesive patch.
4. Run the narrowest relevant test first, then one broader existing test group if practical.
5. Inspect the diff and scan for unsupported reality claims.
6. Update the continuation state/report only with verified facts.
7. Stop. Do not spawn extra agents unless a truly independent review is needed.

## Current known environment blockers (verify before relying on them)
- `node_modules` may be absent; the last recorded state had it missing.
- Prior npm registry DNS resolution failed and five dependencies were missing: `@esbuild/linux-x64`, `@rollup/rollup-linux-x64-gnu`, `@types/node`, `@types/react`, `@types/react-dom`.
- APK was not built; physical Redmi Note 11 runtime and live provider were not verified.
- These are historical observations; re-check current evidence before stating they remain true.

## Required final report
In Persian, concise and factual:
- Change and root cause.
- Exact files changed.
- Exact commands and observed outcomes.
- Statuses: `SOURCE_TESTS`, `TYPECHECK`, `WEB_BUILD`, `APK`, `DEVICE_RUNTIME`, `LIVE_PROVIDER`.
- Remaining blockers and evidence.
- One highest-value next action.

## Stop conditions
Stop before destructive operations, broad rewrites, schema migrations, credential changes, network installs after a known DNS failure, or changes that need owner intent. Ask one direct question only when an essential requirement is ambiguous.
