# NOVIN Stage 117 — Brain Reply Provenance Preservation

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding

The governed gateway adapter validated request correlation, provider/model attribution, reality classification, usage, latency, and confidence. However, successful `BrainReply` values retained only text, reality, and confidence. The provenance remained in evidence records but was lost to downstream consumers that read only the value, weakening end-to-end request tracing.

## Changes

- Added an optional, typed `provenance` object to the canonical `src/brain/contracts.ts` `BrainReply` contract.
- Preserved request ID, provider ID, model ID, latency, input/output/total tokens, and estimated cost in successful `AIGatewayInferenceProvider` reply values.
- Kept provenance optional so non-gateway and local providers remain compatible.
- Expanded the gateway adapter regression test to verify real-provider and simulated-provider attribution survives adaptation without changing the reality label.

## Executed evidence

PASS:
- `node --experimental-strip-types src/brain/aiGatewayProvider.test.ts`
- `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_request_trace_provenance.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_blocked_request_trace.ts`

The tests use controlled local fixtures/mocks. No live provider request was made.

## Limitations

- Full `test:all` was not run.
- Full TypeScript compilation remains unverified because project type definitions/dependencies are unavailable; no dependencies were installed.
- No APK build, Android device test, or installation was performed.

## Status

- Focused provenance preservation: PASS
- Adjacent gateway and conversation regressions: PASS
- Full repository release validation: UNKNOWN / NOT RUN
- Android runtime validation: NOT TESTED
