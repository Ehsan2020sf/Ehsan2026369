# NOVIN NEXUS Stage 05: Build Dependency Recovery Attempt

Date: 2026-10-13
Baseline: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`
Source version: `0.9.24-unified`

## Objective
Unblock deterministic web/Android builds without changing lockfile-resolved package versions or copying native `node_modules` across operating systems/architectures.

## Evidence collected
- Host platform: `linux x64`, Node `v22.16.0`.
- `package-lock.json` exists; lockfile version 3; 521 package entries.
- Lockfile pins `@esbuild/linux-x64` to `0.25.12` and `@rollup/rollup-linux-x64-gnu` to `4.63.0`.
- `npm ci --include=optional --no-audit --no-fund` was attempted to restore exact dependencies.
- Installation could not complete because requests to `https://registry.npmjs.org/` repeatedly failed with `EAI_AGAIN` (DNS/network resolution unavailable in this execution environment). This is an environment/network blocker, not proof of a package-lock conflict.
- The partial `node_modules` directory from the interrupted attempt was removed. No partial dependency tree is retained in the source archive.

## Verification after the blocked install
- `npm run test:all`: PASS, exit 0.
- `npm run test:rebuild-integrity`: PASS, exit 0.
- `npm run preflight:platform-deps`: BLOCKED as expected because the two Linux x64 native packages are not installed.
- `npm run build:web`: NOT RUN after dependency recovery failed; it cannot pass the preflight without the missing packages.
- APK build: NOT BUILT.
- Redmi Note 11 Android 13 runtime: NOT TESTED.

## Decision
Do not bypass the native dependency preflight, edit the lockfile to hide the problem, substitute fake build outputs, or claim APK/device success. Continue source-level work and contract tests, but a network-enabled compatible build environment is required to restore dependencies and generate the web asset digest manifest. Then run web build, Capacitor sync, Gradle freshness gate, APK build/signature/package/hash checks, and only then device tests.

## Next actions
1. Restore dependencies from the existing lockfile on a network-enabled Linux x64 build host (or use a trusted, complete npm cache for the exact lockfile).
2. Confirm `@esbuild/linux-x64` and `@rollup/rollup-linux-x64-gnu` are installed and preflight passes.
3. Run `npm run build:web`; verify `dist/novin-web-build-manifest.json` is generated from source digests.
4. Run `npx cap sync android` and the Android asset freshness/hash gate.
5. Build and inspect the APK before installing it on the user's Redmi Note 11.

## Truth classification
Source tests: PASS. Dependency recovery: BLOCKED_ENVIRONMENT_NETWORK_DNS. Web build: BLOCKED. APK: NOT_BUILT. Device rendering/FPS/thermal/runtime: NOT_TESTED.
