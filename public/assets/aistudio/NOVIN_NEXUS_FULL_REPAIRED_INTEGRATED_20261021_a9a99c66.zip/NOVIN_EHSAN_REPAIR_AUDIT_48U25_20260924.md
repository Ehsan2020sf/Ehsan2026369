# NOVIN EHSAN Repair Audit 48U25

- مشکل واقعی پیدا شد: `android/gradlew` در آرشیو مرجع permission اجرایی نداشت؛ بنابراین حتی با Java و Gradle Wrapper موجود، اجرای مستقیم Wrapper با خطای permission ممکن بود.
- اصلاح: permission اجرایی `android/gradlew` به `0755` بازگردانده شد.
- گارد جدید: `scripts/test_android_wrapper_boundary.mjs` برای جلوگیری از برگشت این نقص.
- تست boundary: PASS؛ executable=true و shebang معتبر.
- `novin_phase0_toolchain_preflight.mjs` نیز اکنون permission Wrapper را به‌صورت صریح مشاهده و گزارش می‌کند.
- اجرای واقعی Wrapper پس از اصلاح به مرحله دانلود Gradle رسید و با `UnknownHostException: services.gradle.org` متوقف شد؛ بنابراین مشکل permission رفع شد، اما شبکه/دریافت distribution همچنان BLOCKED است.
- هیچ ادعای APK build یا Device verification ساخته نشد.
