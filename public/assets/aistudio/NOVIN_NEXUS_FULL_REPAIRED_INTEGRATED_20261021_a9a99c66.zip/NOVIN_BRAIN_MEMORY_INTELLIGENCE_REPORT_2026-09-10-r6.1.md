# NOVIN Brain Adaptive Learning — r6.1

## Implemented
- Added `src/core/learning/adaptiveLearning.ts`.
- Repeated outcomes now produce bounded adaptive-rule candidates.
- Rules mature through repeated outcomes, not model assertions.
- Repeated failure moves a rule to `REVIEW_REQUIRED`.
- Automation is denied without available evidence even when a rule is ACTIVE.
- Learned rules remain INFERRED/OBSERVED and are never promoted to VERIFIED_REAL by learning alone.

## Verification
- `ADAPTIVE_LEARNING_PASS`
- `REALITY_CLAIMS_PASS filesScanned=395`
- Unified integrity audit: PASS, 445 files scanned, 0 errors, 0 warnings.

## Next
Outcome-aware strategy selection and bounded multi-step planning can build on these rules.
