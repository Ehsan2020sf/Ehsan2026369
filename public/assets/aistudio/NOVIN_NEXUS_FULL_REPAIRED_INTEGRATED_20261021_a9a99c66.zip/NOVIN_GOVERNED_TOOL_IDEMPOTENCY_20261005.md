# NOVIN Governed Tool Idempotency Gate — 2026-10-05

## Implemented
The governed Agent → Tool → Evidence → Recovery/Commit chain now has an execution idempotency boundary.

### Contract
- Same mission + task + agent + preferred tool + canonicalized input share one idempotency key.
- Concurrent duplicate requests join the in-flight execution instead of executing the tool twice.
- Completed `COMMITTED`, `OBSERVED`, and `BLOCKED` results suppress later identical replay.
- A distinct canonical input produces a distinct execution.
- Idempotency does not turn generated/simulated output into proof and does not grant external authority.

## Evidence
- `governedToolExecutionChain.test.ts`: PASS GOVERNED_AGENT_TOOL_EVIDENCE_RECOVERY_CHAIN 4/4
- `governedToolExecutionChain.idempotency.test.ts`: PASS GOVERNED_AGENT_TOOL_IDEMPOTENCY 4/4
- Python compile of Learning523: PASS

## Reality boundary
This is an in-process deterministic idempotency gate. It is not yet a durable cross-process/device/distributed idempotency store. Persistence and crash-safe recovery remain a separate implementation boundary.
