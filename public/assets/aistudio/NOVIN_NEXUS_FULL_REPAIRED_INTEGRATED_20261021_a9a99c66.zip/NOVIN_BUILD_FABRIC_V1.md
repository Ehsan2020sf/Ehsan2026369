# NOVIN BUILD FABRIC V1

Implemented as a single integrated development fabric.

- Runtime inspection and requirements
- Local/CI/remote target policy
- Governed build plan
- Real local build execution through the existing RealExecutionFabric
- APK discovery and cryptographic verification
- ADB installation controller with sovereignty gate
- Build evidence persistence
- Server APIs under `/api/build/*`

Truth policy: configuration is never treated as execution; an APK is not claimed until physically discovered and verified. Provisioning plans may identify missing toolchains but never fabricate binaries.
