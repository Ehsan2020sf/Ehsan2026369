
# R11 Repair Ledger

- Fixed stale-evidence promotion in `scripts/novin_reality_source_of_truth.mjs`.
- Evidence older than 24h can no longer promote architecture/dependency/public API/integrity checks to current verified status.
- Phase 0 authoritative PASS now requires fresh evidence.
- Added regression test `scripts/test_reality_source_of_truth_freshness.mjs`.
- Verified with Node syntax check and regression test.
