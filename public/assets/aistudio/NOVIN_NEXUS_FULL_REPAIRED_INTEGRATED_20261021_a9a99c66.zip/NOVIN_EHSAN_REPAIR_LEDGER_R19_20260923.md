# NOVIN EHSAN Repair Ledger R19

Update ID: EHSAN-20260923-19

## Real changes
1. Extracted shared secret-redaction logic into `src/core/contracts/secretRedaction.ts` so security/autonomy boundaries do not depend on each other for this primitive.
2. Moved SecurityGate implementation under the security layer; the old production path remains a compatibility re-export only.
3. Moved runtime observability implementation under the security layer; the old production path remains a compatibility re-export only.
4. Removed the security-layer runtime dependency on the autonomy Evidence Engine. Security-local observability now keeps its in-memory events without creating an autonomy back-edge.
5. Extracted the ToolExecutionIntent contract into `src/core/contracts/toolExecutionIntent.ts`; development code no longer needs to import the agent planner just to consume this contract.

## Verification
- Unified Integrity: PASS
- Reality Claims: PASS
- Changed TypeScript syntax checks: PASS
- Security Command Plane test: PASS
- Security Integrity Ledger test: PASS
- Device Security Fortress test: PASS
- Fingerprint/Freshness guards: PASS

## Remaining truth
- Core module SCC audit: REQUIRES_REFACTOR. Multiple architectural cycles remain and are not falsely marked resolved.
- Phase 0: BLOCKED because the environment has 31 missing declared dependencies and typecheck cannot run.
- Android build/device E2E/live AI: NOT VERIFIED.
