# NOVIN Stage 106: Android avatar reality propagation
Date: 2026-10-17

## Finding
The Android avatar command UI derived its final reality label using `success` and `needsApproval`, then defaulted every non-blocked, non-generated result to `OBSERVED`. An executor returning `success: true` with `UNKNOWN` or `NOT_VERIFIED` could therefore be promoted by the UI to a verified observation and the avatar could show `SUCCESS`.

## Change
- Added `src/core/mobile/avatarCommandPresentationIntegrity.ts` as a pure, fail-closed classifier.
- A command is accepted only when `success === true`, approval is not pending, and reality is explicitly `OBSERVED` or `GENERATED`.
- Unknown/not-verified/blocked results remain `UNKNOWN` and cannot be promoted to `OBSERVED`.
- When a result has a positive success flag but unverified reality, the user-facing message explicitly says the execution status is not verified.
- Wired `AndroidAvatarRuntime.tsx` to use the classifier for status, reality, visible message, voice conversation acceptance, and avatar success/error state.
- Added focused unit tests and a source-level integration contract test, both registered in `test:all`.

## Validation
Passed:
- `node --experimental-strip-types src/core/mobile/avatarCommandPresentationIntegrity.test.ts`
- `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
- `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
- `node --experimental-strip-types src/core/mobile/novinPersianConversationRuntime.test.ts`
- `node scripts/test_runtime_reply_reality_boundary.mjs`
- `node --experimental-strip-types src/brain/aiGatewayProvider.test.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_runtime_provider_refresh.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_provider_response_integrity.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_concurrency.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts`
- `node --experimental-strip-types scripts/test_ai_idempotency_failure_recovery.ts`
- `package.json` JSON parse.

The direct `novinAvatarCommandAuthority.test.ts` invocation was BLOCKED because the environment does not have `@capacitor/core` installed. Dependencies were deliberately not installed. The source-level UI integration contract is used to verify the actual component wiring without dependency installation.

## Explicit limits
- Full `test:all` not run.
- Full TypeScript/build not run.
- No live AI provider call.
- No APK build or Android device installation.

## Status
PASS for the focused classifier, conversation response contract, AI gateway tests, and runtime reality-boundary tests. Full UI build and Android end-to-end behavior remain NOT TESTED/BLOCKED by absent dependencies.
