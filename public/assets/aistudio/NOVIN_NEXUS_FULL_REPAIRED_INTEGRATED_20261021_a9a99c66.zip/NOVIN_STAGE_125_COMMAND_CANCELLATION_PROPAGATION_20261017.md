# NOVIN Stage 125: Command Cancellation Propagation
Date: 2026-10-17

## Scope
Propagate the UI-owned cancellation signal through the Android avatar command boundary into the canonical Mind command executor and environment command engine. Preserve stale-result rejection and avoid claiming unsupported physical cancellation.

## Changes
- `src/core/contracts/mindCommandExecutionPort.ts`: the injected Mind executor contract now accepts an optional `AbortSignal`.
- `src/core/mobile/novinAvatarCommandAuthority.ts`: command execution accepts an optional signal, refuses pre-cancelled work, forwards the signal to the Mind executor, and rejects a late result if cancellation occurred before result acceptance.
- `src/components/mobile/AndroidAvatarRuntime.tsx`: each command creates and owns an `AbortController`; its signal is passed to the command authority. The visible stop action aborts the active controller and still invalidates UI execution ownership. The 45-second watchdog also aborts the active command.
- `src/core/kernel/environmentCommandEngine.ts`: accepts the signal in its context and checks cancellation before preflight, before entering the internal pipeline, at the internal pipeline boundary, and after the internal pipeline returns. A cancelled result is not reflected as a successful completed command.
- `src/core/mobile/novinAvatarCommandAuthority.test.ts`: added regression scenarios for signal propagation, cancellation before execution, and rejection of a late result.
- `scripts/test_command_cancellation_boundary.mjs`: static wiring checks for the UI-to-engine cancellation path. Updated two existing static composition-boundary checks to assert signal forwarding instead of the previous two-argument call.

## Verification
- `node scripts/test_command_cancellation_boundary.mjs`: PASS (9 static source-wiring assertions).
- `node scripts/test_android_conversation_mind_boundary.mjs`: PASS after updating its expected composition signature.
- `node scripts/test_android_avatar_command_authority.mjs`: PASS after updating its expected authority invocation.
- Attempted `node --experimental-strip-types src/core/mobile/novinAvatarCommandAuthority.test.ts`: BLOCKED before test execution because `@capacitor/core` is unavailable in this environment. No dependency was installed, by project constraint.
- Runtime tests for Android UI and remote provider cancellation: NOT TESTED.
- Full TypeScript compile / full test suite / APK / device: NOT TESTED.

## Important limitation
The signal now reaches the command engine boundary. Not every internal command branch or every remote/network operation has been proven to consume the signal and abort its underlying work immediately. The UI and authority reject stale results, but physical cancellation of all downstream work remains PARTIAL / NOT VERIFIED.

## Status
- Source wiring checks: PASS
- Authority runtime test: BLOCKED by missing existing dependency
- End-to-end physical cancellation: PARTIAL / NOT VERIFIED
- Release gates: NOT COMPLETE
