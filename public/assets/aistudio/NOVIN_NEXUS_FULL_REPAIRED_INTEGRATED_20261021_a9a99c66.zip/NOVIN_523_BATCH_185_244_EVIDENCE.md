# NOVIN 523 Batch 185-244 Evidence

Official lesson source: AI Engineering from Scratch ROADMAP.md

Scope: 60 lessons, 185-244.

Implementation policy: each lesson adds a dependency-free executable primitive; external model/provider/GPU availability is never fabricated.

Implemented: 60/60 modules.

- 185: Pre-Training a Mini GPT (124M)
- 186: Scaling — Distributed Training, FSDP, DeepSpeed
- 187: Instruction Tuning — SFT
- 188: RLHF — Reward Model + PPO Training
- 189: DPO — Direct Preference Optimization
- 190: Constitutional AI & Self-Improvement
- 191: Evaluation — Benchmarks, Evals, LM Harness
- 192: Quantization — INT8, GPTQ, AWQ, GGUF
- 193: Inference Optimization
- 194: Building a Complete LLM Pipeline
- 195: Open Models — Architecture Walkthroughs
- 196: Speculative Decoding and EAGLE-3
- 197: Differential Attention (V2)
- 198: Native Sparse Attention (DeepSeek NSA)
- 199: Multi-Token Prediction (MTP)
- 200: DualPipe Parallelism
- 201: DeepSeek-V3 Architecture Walkthrough
- 202: Jamba — Hybrid SSM-Transformer
- 203: Async and Hogwild! Inference
- 204: Speculative Decoding and EAGLE
- 205: Gradient Checkpointing and Activation Recomputation
- 206: Prompt Engineering — Techniques & Patterns
- 207: Few-Shot, Chain-of-Thought, Tree-of-Thought
- 208: Structured Outputs
- 209: Embeddings & Vector Representations
- 210: Context Engineering
- 211: RAG — Retrieval-Augmented Generation
- 212: Advanced RAG
- 213: Fine-Tuning with LoRA & QLoRA
- 214: Function Calling & Tool Use
- 215: Evaluation & Testing LLM Applications
- 216: Caching, Rate Limiting & Cost Optimization
- 217: Guardrails, Safety & Content Filtering
- 218: Building a Production LLM Application
- 219: Model Context Protocol (MCP)
- 220: Prompt Caching & Context Caching
- 221: Agent State Machines — Graphs, Nodes, Checkpoints
- 222: Agent Framework Tradeoffs
- 223: Vision Transformers and the Patch-Token Primitive
- 224: CLIP and Contrastive Vision-Language Pretraining
- 225: BLIP-2 and Q-Former as Modality Bridge
- 226: Flamingo and Gated Cross-Attention
- 227: LLaVA and Visual Instruction Tuning
- 228: Any-Resolution Vision: Patch-n'-Pack and NaFlex
- 229: Open-Weight VLM Recipes: What Actually Matters
- 230: LLaVA-OneVision: Single, Multi, Video
- 231: Qwen-VL Family and Dynamic-FPS Video
- 232: InternVL3 Native Multimodal Pretraining
- 233: Chameleon and Early-Fusion Token-Only
- 234: Emu3 Next-Token Prediction for Generation
- 235: Transfusion Autoregressive + Diffusion
- 236: Show-o and Discrete-Diffusion Unified
- 237: Janus-Pro Decoupled Encoders
- 238: MIO Any-to-Any Streaming
- 239: Video-Language Temporal Grounding
- 240: Long-Video Understanding at Million-Token Context
- 241: Audio-Language Models: Whisper to AF3
- 242: Omni Models: Thinker-Talker
- 243: Embodied VLAs: RT-2, OpenVLA, π0, GR00T
- 244: Document and Diagram Understanding

Verification: Python syntax/functional batch test required before PASS.

## Verified execution
PASS LESSONS_185_244: 60/60
PASS PYTHON_COMPILE_ALL
PASS REGISTRY_001_244: 244
PASS FRONTIER_245
PASS REGRESSION LESSONS_005_034
PASS REGRESSION LESSONS_035_064
PASS REGRESSION LESSONS_065_094
PASS REGRESSION LESSONS_095_124
PASS REGRESSION LESSONS_125_154
PASS REGRESSION LESSONS_155_184
PASS REGRESSION LEARNING ENGINE
PASS LESSONS_005_012: 8/8
PASS LESSON_001
PASS LESSON_002
PASS LESSON_003
PASS LESSON_004

External model/provider/GPU installation was not claimed. Complex model lessons are represented by executable architectural/math primitives with explicit reality status.
