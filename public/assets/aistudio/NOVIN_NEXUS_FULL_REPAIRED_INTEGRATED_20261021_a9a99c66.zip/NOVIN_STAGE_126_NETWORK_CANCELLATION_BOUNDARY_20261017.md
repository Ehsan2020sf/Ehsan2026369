# NOVIN Engineering Stage 126: Network Cancellation Boundary

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding
The cancellation signal already reached `EnvironmentCommandEngine`, but the Android internet command bridge accepted only the command text. That meant the bridge itself could not short-circuit pre-cancelled requests or reject a late native browser result after the caller had cancelled. A Living World command also needed an explicit cancellation check immediately before publishing its command event.

## Changes
- `src/core/intelligence/novinInternetCommandBridge.ts`: added optional `AbortSignal`; pre-aborted requests return `CALLER_CANCELLED` before intent handling; search/open URL/download paths check cancellation before the native browser handoff and again after the awaited result; cancellation is not represented as success.
- `src/core/kernel/environmentCommandEngine.ts`: forwards the caller signal to the internet bridge and rejects a result if the caller cancelled while awaiting the bridge. The error path also returns a cancellation result rather than falling through to another handler. Added a final cancellation guard before publishing a Living World command.
- `scripts/test_cancellation_network_side_effect_boundary.mjs`: added seven static boundary assertions for signal forwarding, pre-cancel guard, late-result rejection, and the Living World publication guard.
- `scripts/test_ui_response_cancel_ownership.mjs`: aligned the existing disclosure assertion with the current Persian UI copy. The UI still honestly discloses that downstream work which does not support cancellation may continue.

## Verification
- `node scripts/test_cancellation_network_side_effect_boundary.mjs`: PASS (7/7 assertions).
- `node scripts/test_command_cancellation_boundary.mjs`: PASS (9/9 assertions).
- `node scripts/test_ui_response_cancel_ownership.mjs`: PASS.
- `node --experimental-strip-types scripts/test_ai_gateway_caller_cancellation.ts`: PASS using controlled local provider responses.
- Attempted direct runtime import/test of `executeInternetCommand` with a pre-aborted signal: BLOCKED before execution because the existing `@capacitor/core` package is absent. No dependencies were installed.
- A previous focused cancellation UI test initially failed because its expected Persian sentence no longer matched the actual truthful disclosure. The test expectation was updated to match the current wording, and the test then passed. This was a test-contract wording mismatch, not a product-code behavior failure.

## Limits
The native browser handoff may already have launched by the time cancellation occurs. This bridge can reject the late result and prevent NOVIN from treating it as success, but it cannot retract an Android browser launch unless the native bridge exposes a cancellable operation. This is therefore cancellation propagation and stale-result rejection, not proof of physical cancellation of every side effect. Full TypeScript compilation, full test suite, APK build, and device testing remain NOT TESTED.

## Status
- Source-level cancellation boundary: PASS
- Focused gateway cancellation regression: PASS
- Direct internet-bridge runtime test: BLOCKED by missing existing dependency
- Cancellation of native browser side effect: PARTIAL / NOT VERIFIED
- Release gates: NOT COMPLETE
