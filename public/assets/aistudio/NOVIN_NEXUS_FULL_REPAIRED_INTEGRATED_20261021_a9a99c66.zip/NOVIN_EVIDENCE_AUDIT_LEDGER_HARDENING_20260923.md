# NOVIN Evidence & Audit Ledger Hardening — 2026-09-23

## Scope
این چرخه فقط روی بخش **Evidence / Audit Ledger** و هماهنگی آن با Reality Gate تمرکز داشت. بخش‌های Build/Deploy و Recovery در این چرخه تغییر داده نشدند.

## یافته واقعی
`AgentEvidenceAuditLedger` دارای نگهداری bounded بود و پس از رسیدن تعداد رکوردها به سقف، رکوردهای قدیمی حذف می‌شدند. اما `verifyIntegrity()` همچنان انتظار داشت شماره توالی retained window از `1` شروع شود و بنابراین بعد از eviction، یک Ledger سالم را می‌توانست `FAIL` اعلام کند.

همچنین مسیر migration نسخه قدیمی، زنجیره را صعودی می‌ساخت اما ترتیب عمومی Ledger را به حالت جدیدترین‌اول حفظ نمی‌کرد.

## اصلاحات
1. Integrity verification اکنون bounded-retention را در نظر می‌گیرد.
2. اولین رکورد retained می‌تواند به predecessor حذف‌شده اشاره کند؛ hash خود آن رکورد همچنان کامل verify می‌شود و از رکورد دوم به بعد زنجیره باید بدون شکست ادامه داشته باشد.
3. gap داخلی در retained window همچنان FAIL است.
4. ادعای `VERIFIED_REAL` همچنان فقط با Evidence معتبر Reality Gate پذیرفته می‌شود.
5. migration نسخه قدیمی پس از rechain، ترتیب جدیدترین‌اول Ledger را حفظ می‌کند.
6. هیچ PASS جدیدی بر اساس شبیه‌سازی یا صرفاً وجود configuration صادر نشده است.

## Evidence
- `AGENT_EVIDENCE_AUDIT_LEDGER_PASS` = PASS
- `AGENT_EVIDENCE_AUDIT_LEDGER_BOUNDED_RETENTION_PASS` = PASS
- `NSCO_RECOVERY_REALITY_GATE` = PASS (regression check)
- آزمون bounded retention: 60 append با سقف 50؛ اندازه retained = 50؛ integrity = PASS؛ آخرین sequence = 60.

## Reality Boundary
این چرخه فقط صحت منطق Source-level و تست اجرایی همین تست‌های Node را تأیید می‌کند. این Evidence به معنی APK build، نصب روی گوشی، اجرای فیزیکی Android یا ثبت Provider واقعی نیست.

## Status
**PASS — Evidence/Audit Ledger hardening completed.**

بخش بعدی هنوز بررسی نشده است و نباید از این گزارش نتیجه‌ای برای آن استنتاج شود.
