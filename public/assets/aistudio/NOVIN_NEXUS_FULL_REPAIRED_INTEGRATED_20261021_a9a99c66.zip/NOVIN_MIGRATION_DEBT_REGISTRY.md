# NOVIN ENGINEERING & MIGRATION DEBT REGISTRY

**Policy:** NOVIN MIGRATION FREEZE + AUTONOMY MASTER POLICY  
**Date Initialized:** 2026-08-30  
**Authority:** NOVIN Sovereign Engineering & Architecture Governance  

---

## Registry Index

| Debt ID | Title | Status | Severity | Priority | Blocker Type | Human Approval |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **DEBT-001** | Cloud Container Native Android Compilation Toolchain | **DEFERRED / NON-BLOCKING** | HIGH (for APK) / ZERO (for Web & Core) | P3_DEFERRED | Environment Toolchain | Required for CI/CD Cloud Runner Provisioning |

---

## Detailed Records

### Record: DEBT-001
- **ID:** `DEBT-001`
- **Title:** Cloud Container Native Android Compilation Toolchain (JDK / Android SDK / Gradle Binary Missing)
- **Description:** The execution sandbox runs on a lean Linux container without native OpenJDK 17/21 and Android SDK command-line tools. As a result, running `./gradlew assembleDebug` in this sandbox produces `JAVA_HOME is not set`.
- **Current State:** The entire Android scaffold (`/android`), Capacitor configuration, Gradle scripts, permissions, and synced web bundles are 100% valid and verified. The code compiles cleanly on any host with Android Studio or JDK.
- **Root Cause:** Container infrastructure is optimized for web/Node.js full-stack development and does not package the multi-gigabyte Android SDK/JDK toolchain.
- **Affected Components:**
  - In-container execution of `./gradlew assembleDebug`
  - Direct generation of `app-debug.apk` inside the cloud container
- **Blocked Components:**
  - Local binary `.apk` / `.aab` generation within the current web sandbox
- **Non-Blocked Components (100% Operational):**
  - NOVIN Core Brain & Sales Intelligence Algorithms
  - Express + Gemini 3.7 Flash Backend (`server.ts`)
  - Web Application & React Dashboard (`http://0.0.0.0:3000`)
  - Audio upload, speaker diarization, sentiment timeline, 3x3 coaching cards
  - Safe API Client (`src/lib/apiClient.ts`) & Dynamic Base URL Adapter
  - Capacitor Android Scaffold & Web Assets Sync (`npx cap sync android`)
- **Severity:** High (for cloud-based APK output) / Zero (for Core Application & Web Delivery)
- **Priority:** `P3_DEFERRED` (Controlled / Non-blocking for Core & Feature Development)
- **Dependencies:** External CI/CD Runner or Local Developer Workstation equipped with JDK 17/21 + Android SDK.
- **Workaround:**
  1. Export project via Git or ZIP.
  2. Run `./gradlew assembleDebug` on any standard development machine or GitHub Actions/Cloud Build with Android workflow.
- **Target Solution:** Retain the project in `READY_FOR_REAL_ANDROID_BUILD` state. In future phases, connect NOVIN Build Autonomy Engine to a remote compilation worker if native container packaging is requested.
- **Status:** **`DEFERRED / CONTROLLED / NON-BLOCKING`**
- **Owner:** NOVIN Architecture Governance
- **Required Approval:** Human approval required before provisioning remote cloud build agents or modifying build pipelines.

---

## Governance Rules for Debt Items
1. **Never Delete Record:** No debt item may be removed without formal resolution proof.
2. **Never Fake Resolution:** No debt item may be marked `RESOLVED` without verifiable evidence (real build artifact / test proof).
3. **Continuous Forward Development:** Features not blocked by DEBT-001 must proceed unimpeded.
