# NOVIN EHSAN Repair Ledger R15

## اصلاح اصلی
محاسبه Source Fingerprint در Evidence Gate و Reality Source of Truth اصلاح شد تا فایل‌های Evidence تولیدشونده توسط خود Gate/Audit وارد fingerprint نشوند.

### مشکل واقعی R14
Auditهای معماری/وابستگی/API فایل‌های JSON تولید می‌کردند. چون این فایل‌ها بعد از محاسبه fingerprint تغییر می‌کردند، Evidence بعد از اجرای Gate می‌توانست به‌صورت کاذب `evidenceMatchesSource=false` شود.

### اصلاح
فایل‌های تولیدی زیر از Source Fingerprint مستثنی شدند:
- `NOVIN_PHASE0_EVIDENCE_GATE_CURRENT.json`
- `NOVIN_REALITY_SOURCE_OF_TRUTH_CURRENT.json`
- `NOVIN_CORE_MODULE_BOUNDARY_AUDIT.json`
- `NOVIN_CORE_DEPENDENCY_BOUNDARY_AUDIT.json`
- `NOVIN_CORE_PUBLIC_API_MANIFEST.json`

## Verification
- Node syntax: PASS
- Phase 0 Evidence Gate اجرا شد: BLOCKED، چون 31 dependency نصب‌شده نیست و typecheck قابل اجرای کامل نیست.
- Reality Source of Truth اجرا شد: BLOCKED به‌دلیل Gate.
- `evidenceMatchesSource`: PASS/TRUE پس از اجرای متوالی Gate → Truth
- fingerprint regression test: PASS
- freshness regression test: PASS
- reality claims scan: PASS
- معماری core: همچنان BLOCKED/REQUIRES_REFACTOR؛ SCC چندماژوله واقعی هنوز وجود دارد و در این مرحله دستکاری گسترده انجام نشد.
- Android/device/live AI: NOT VERIFIED
