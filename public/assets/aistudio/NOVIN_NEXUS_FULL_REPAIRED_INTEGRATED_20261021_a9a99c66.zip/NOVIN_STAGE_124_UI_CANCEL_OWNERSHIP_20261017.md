# NOVIN Stage 124: UI Response Cancellation Ownership
Date: 2026-10-17

## Finding
The Android avatar composer disabled input during processing and had no visible stop-response control. The command authority currently does not accept an AbortSignal, so adding a UI button must not be misrepresented as guaranteed cancellation of internal or remote work.

## Changes
- `src/components/mobile/AndroidAvatarRuntime.tsx`
  - Added an execution epoch to give each visible UI execution explicit ownership.
  - Late success and error continuations are ignored when their execution epoch is stale.
  - A stale `finally` cannot clear processing state owned by a newer execution.
  - The 45-second UI watchdog invalidates the timed-out execution epoch before resetting the UI.
  - Added a visible Persian “توقف پاسخ جاری” control while processing.
  - The control invalidates the current UI epoch, stops browser/native speech on a best-effort basis, and marks the avatar interrupted.
  - The UI explicitly tells the user that a legacy non-cancellable internal operation may continue in the background. No claim is made that provider/network work is physically aborted.
- `scripts/test_ui_response_cancel_ownership.mjs`
  - Static regression contract checks stale-result suppression, ownership-safe finalization, speech-stop requests, visible control, and disclosure of the cancellation limitation.

## Verification
PASS: `node scripts/test_ui_response_cancel_ownership.mjs`
PASS: `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
PASS: `node --experimental-strip-types src/core/mobile/novinPersianConversationRuntime.test.ts`
PASS: `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`

These are targeted source/runtime tests. They do not establish full TypeScript compilation, full-suite success, live-provider cancellation, APK build success, or physical Android UI behavior.

## Remaining limitation
The UI control stops visible response/audio and prevents stale results from taking over the UI, but the command authority and some legacy executors do not yet carry `AbortSignal` end-to-end. A later stage must extend the actual command/provider path before claiming guaranteed network/provider cancellation.

## Archive policy
Only the canonical archive is updated in place. No parallel ZIP is created. No dependency installation, APK build, or device installation is performed.
