# NOVIN EHSAN Repair Ledger R48 Update

- Identifier: EHSAN-20260924-48U2
- Base: NOVIN_NEXUS_EHSAN_20260924_R48
- Rule: REALITY > ASSUMPTION; generated reports do not override executable evidence.

## Real finding
The canonical master manifest contained `currentReality.sourceTruth = STATIC_VERIFIED`. That wording could be misread as a current runtime verification state even though the same manifest correctly declared build, Android device, and live-provider states as NOT_VERIFIED. This was a truth-boundary inconsistency.

## Repair
- Replaced the ambiguous source-truth value with `EVIDENCE_GATED_CURRENT`.
- Added an explicit rule that production/device/APK/live-provider claims require executable evidence plus artifact/device proof.
- Marked historical claims as non-authoritative.
- Added `scripts/test_master_reality_consistency.mjs` and registered it as `test:master-reality-consistency`.
- Regenerated Phase-0 evidence and Reality Source of Truth after the source change so the source fingerprint matches the repaired tree.

## Verification
- Master Reality Consistency: PASS
- Current Evidence Isolation: PASS, unquarantined claims=0, stale APK=0, partial node_modules=0
- Persisted Evidence Truth Boundary: PASS, 408 records checked, invalid VERIFIED_REAL=0, checksum failures=0
- Reality Claims: PASS, 1375 files scanned
- Runtime Wiring: PASS, 9/9
- Unified Integrity: PASS, 1568 files, errors=0, warnings=0
- Phase-0 decision: BLOCKED, because 31 declared dependencies are not installed and typecheck is blocked
- APK/device/live AI: NOT VERIFIED, deliberately not promoted to PASS

## Dependency recovery attempt
A real `npm ci --offline` attempt was made. It failed because the npm cache did not contain the required `zustand` tarball (`ENOTCACHED`). No partial `node_modules` tree was retained.
