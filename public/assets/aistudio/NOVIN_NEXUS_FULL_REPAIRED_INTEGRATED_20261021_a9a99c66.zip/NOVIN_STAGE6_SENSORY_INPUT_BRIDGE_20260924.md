# NOVIN Stage 6 — Sensory Input Bridge

## Scope
Text, voice, vision, and device observations are normalized into the governed nervous system without granting authority.

## Implemented
- Added `src/core/nervous/sensoryInputBridge.ts`.
- Enforces input identity/source.
- Refuses raw-media persistence requests.
- Emits perception signals with `UNVERIFIED` trust.
- Preserves tenant/correlation metadata.
- Uses nervous-system deduplication by sensory kind + input ID.
- Explicitly returns `authorityGranted: false`.

## Evidence
- Sensory bridge test: PASS (text, voice, vision policy, dedupe, authority boundary).
- Nervous hardening test: PASS.
- Integrity audit: PASS, 1609 files, 0 errors, 0 warnings.

## Reality boundary
This stage creates the governed sensory ingress boundary. It does not claim real microphone/camera hardware E2E execution. Physical-device execution remains separately unverified.
