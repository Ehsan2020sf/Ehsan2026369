Device bridge + legacy automation core tests PASS in session.
