R43 forensic correction: historical P80-P83 regression details explicitly marked NOT_REEXECUTED; P85 configuration verdicts made state-dependent.
