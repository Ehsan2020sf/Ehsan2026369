# NOVIN NSCO Autonomous Operating Plane

## هدف
تبدیل NSCO به حلقه عملیاتی خودگردان و تحت حاکمیت:
OBSERVE -> UNDERSTAND -> PLAN -> AUTHORIZE -> EXECUTE -> VERIFY -> RECOVER -> RECORD

## اجزای جدید
- `src/core/agent/nscoAutonomousOperatingPlane.ts`
- `src/core/agent/nscoAutonomousOperatingPlane.test.ts`
- APIهای worker برای status/start/pause/stop/mission

## اتصال
LLM Provider -> NSCO Planner -> HumanSovereigntyGate -> NSCO Officer -> ToolGateway -> Execution -> Evidence/Audit

## قانون حقیقت
پاسخ مدل، برنامه، لاگ یا ادعا هرگز به تنهایی `VERIFIED_REAL` محسوب نمی‌شود.
فقط نتیجه واقعی ToolGateway و Evidence معتبر می‌تواند اجرای واقعی را نشان دهد.

## خودکارسازی
- LOW/read-only: خودکار
- MEDIUM/HIGH/CRITICAL: توقف و درخواست تأیید Owner
- شکست: retry محدود
- تغییرات: از ToolGateway عبور می‌کنند
- Verification بعد از مرحله، در صورت تعریف verifyCommand، اجباری است

## اتصال Worker
متغیر محیطی `NOVIN_NSCO_AUTOSTART=1` برای شروع NSCO هنگام بالا آمدن Worker فراهم شده است.
به‌صورت پیش‌فرض خاموش است تا نصب اولیه بدون فراخوانی ناخواسته مدل انجام شود.

## وضعیت
SOURCE IMPLEMENTATION: COMPLETED
PHYSICAL DEVICE EXECUTION: NOT VERIFIED
REAL EXTERNAL PROVIDER EXECUTION: DEPENDS ON REGISTERED AI PROVIDER
OWNER SOVEREIGNTY: PRESERVED
