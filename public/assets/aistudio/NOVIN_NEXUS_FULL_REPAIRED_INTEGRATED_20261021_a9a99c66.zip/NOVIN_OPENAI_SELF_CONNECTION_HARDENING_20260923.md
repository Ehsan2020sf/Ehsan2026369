# NOVIN OpenAI Self-Connection Hardening - 2026-09-23

## Scope
Single focus: connect NOVIN's canonical AI Gateway to the OpenAI API as a governed provider, without bypassing NOVIN routing, sovereignty, security, idempotency, retry, fallback, evidence and audit boundaries.

## Implemented
- Added OpenAI provider registration to the canonical `src/core/ai/aiGateway.ts`.
- Added GPT-5.6 Luna and GPT-5.6 Sol model descriptors based on the current OpenAI model catalog.
- OpenAI provider is enabled only when `OPENAI_API_KEY` is present AND `NOVIN_ALLOW_LIVE_AI=1`.
- Added a server-side REST adapter for `POST /v1/responses`.
- API key is read only from `process.env.OPENAI_API_KEY` and sent via Bearer authorization, never in URL/client assets.
- `store:false` is explicit for NOVIN's default request path.
- OpenAI tool execution is fail-closed until a dedicated governed tool adapter exists.
- Responses with real provider output are classified `GENERATED`, not `VERIFIED_REAL`.
- Existing HumanSovereigntyGate, Universal AI Provider Security, EconomicGovernor, ModelRouter, idempotency and fallback remain upstream of provider execution.

## Verification
- `openaiProviderReality.test.ts`: PASS
- Source contract checks: PASS
- Existing AI Gateway router tests: PASS where runnable in the current dependency-free environment.
- Live OpenAI request: NOT VERIFIED because no OpenAI API key is registered in the current environment.

## Reality Boundary
This change creates the real integration path. It does NOT claim that NOVIN is currently connected to OpenAI. A real connection requires a valid `OPENAI_API_KEY` supplied server-side and `NOVIN_ALLOW_LIVE_AI=1`, followed by a live request and evidence.

## Status
Source integration: PASS
Live provider registration: NOT VERIFIED
Live API execution: NOT VERIFIED
Client-side key exposure: BLOCKED by design
