# NOVIN NEXUS — Avatar Worker Target-Job Hardening — 2026-09-23

## Scope

فقط بخش Avatar ↔ Persistent JobQueue بررسی و اصلاح شد.

## Finding

`NovinAvatarOperatingSystem.executeOwnerCommand()` مأموریت را در JobQueue ثبت می‌کرد اما `processNext()` بدون شناسه هدف اجرا می‌شد. بنابراین اگر صف هم‌زمان Job دیگری با اولویت بالاتر داشت، ممکن بود Worker آن Job دیگر را پردازش کند و نتیجه همان Job را به Caller مأموریت Avatar برگرداند.

این یک نقض واقعی در اتصال Command → Target Job → Result بود.

## Fix

- `JobQueue.processNext(targetJobId?)` اضافه شد.
- وقتی شناسه هدف داده شود، فقط همان Job در وضعیت `QUEUED` قابل انتخاب است.
- مسیر عادی `processNext()` بدون شناسه، رفتار اولویت‌بندی قبلی را حفظ می‌کند.
- `executeOwnerCommand()` اکنون دقیقاً Job ایجادشده برای همان Command را با شناسه خودش پردازش می‌کند.
- هیچ Job موازی یا Executor جدیدی ایجاد نشد.

## Evidence

- `NOVIN_AVATAR_WORKER_TARGET_JOB_REALITY_PASS` — PASS
  - هدف Avatar دقیقاً همان Job ایجادشده بود.
  - Job عمومی با اولویت CRITICAL عمداً `QUEUED` باقی ماند.
  - `resultData.missionId` با نتیجه برگشتی همان مأموریت منطبق بود.
- `NOVIN_AVATAR_WORKER_INTEGRATION_PASS` — PASS
  - tasks=3
  - batches=2
  - queue status=COMPLETED
  - reality=GENERATED

## Reality Boundary

این چرخه فقط Target-Job routing و Integration داخل Runtime/Queue را اثبات می‌کند.
APK build/install/device E2E، Provider خارجی و Side Effect بیرونی همچنان NOT VERIFIED هستند.
