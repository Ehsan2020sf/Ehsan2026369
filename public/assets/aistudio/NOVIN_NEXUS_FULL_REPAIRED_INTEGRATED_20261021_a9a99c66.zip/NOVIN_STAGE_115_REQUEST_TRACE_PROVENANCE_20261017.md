# NOVIN Stage 115 — Request Trace Provenance

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding

The gateway's recent request log retained only request ID, timestamp, model, boolean success, and cost. That was insufficient to audit whether a response came from a named provider, what reality classification was assigned, how long it took, or which terminal error/finish reason applied.

## Changes

- Extended in-memory recent request entries with provider attribution, reality classification, latency, finish reason, and bounded terminal error visibility.
- Failed gateway responses record `provider=none`, `model=none`, `reality=UNKNOWN`, zero cost, and the failure reason rather than suggesting a provider success.
- Successful response records now retain the response's provider/model attribution, reality, latency, finish reason, and cost. The log's `ok` flag also requires nonempty content and no response error.
- Added `scripts/test_ai_gateway_request_trace_provenance.ts` and wired `test:ai-gateway-request-trace-provenance` into `test:all`.

## Executed evidence

PASS:
- `node --experimental-strip-types scripts/test_ai_gateway_request_trace_provenance.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_marks_fallback_failure.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_provider_response_integrity.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_runtime_provider_refresh.ts`
- `node --experimental-strip-types src/brain/aiGatewayProvider.test.ts`
- `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
- package JSON parsing and `test:all` wiring check

The new trace test used a controlled local fetch mock and verified request ID, provider/model attribution, `GENERATED` reality, latency, finish reason, cost, and exactly one mocked provider call. No live provider/network request was made.

## Limitations

- Full `test:all` was not run.
- Full TypeScript compilation remains unverified because this environment lacks the project's installed type definitions; no dependencies were installed.
- No APK build, Android device test, or installation was performed.

## Status

- Focused request-trace provenance: PASS
- Focused adjacent regressions: PASS
- Full repository release validation: UNKNOWN / NOT RUN
- Android runtime validation: NOT TESTED
