# NOVIN NEXUS — Sovereign Avatar Command Interface

هدف:
رابط کاربری NOVIN باید از حالت دکمه‌محور خارج شود و یک رابط ساده با یک آواتار اصلی داشته باشد.

الزامات قطعی:

1. تمام دکمه‌های اضافی و منوهای شلوغ رابط کاربری مخفی یا حذف شوند.
2. صفحه اصلی فقط یک AVATAR مرکزی NOVIN داشته باشد.
3. آواتار نقطه اصلی تعامل کاربر با NOVIN باشد.
4. فرمان متنی از طریق Chat/Input به Command Engine ارسال شود.
5. فرمان صوتی از طریق Microphone به Command Engine ارسال شود.
6. دوربین دستگاه به‌عنوان Tool رسمی NOVIN در اختیار Command Engine قرار گیرد.
7. آواتار باید وضعیت NOVIN را نمایش دهد:
   IDLE
   LISTENING
   PROCESSING
   CAMERA
   EXECUTING
   SUCCESS
   BLOCKED
   ERROR
8. هر فرمان ابتدا وارد Sovereignty Gate و Reality Gate شود.
9. فرمانی که نیاز به اجازه مالک دارد بدون تأیید مالک اجرا نشود.
10. NOVIN نباید از فرمان کاربر فراتر برود.
11. فرمان صوتی و متنی باید از یک Command Engine مشترک استفاده کنند.
12. Camera نیز باید Tool همان Runtime باشد، نه یک سیستم جداگانه.
13. هیچ قابلیت موجود NOVIN دوباره ساخته نشود. قابلیت موجود باید پیدا و به این رابط متصل شود.
14. Android UI نباید منطق اصلی NOVIN را در خود نگه دارد.
15. UI فقط Interface باشد و اجرای واقعی در NOVIN Runtime انجام شود.
16. اگر Microphone یا Camera مجوز نداشته باشد، وضعیت BLOCKED گزارش شود و ادعای اجرای موفق نشود.
17. اگر Internet در دسترس نباشد، وضعیت واقعی Offline گزارش شود.
18. اتصال Internet باید از طریق Network/Environment Manager موجود پروژه انجام شود.
19. اجرای فرمان باید Evidence تولید کند:
   commandId
   input
   inputType
   intent
   status
   action
   evidence
   timestamp
20. وضعیت‌ها فقط یکی از این موارد باشند:
   PASS
   FAIL
   BLOCKED
   NOT_IMPLEMENTED
21. هیچ چیزی فقط به‌دلیل وجود کد PASS اعلام نشود.
22. Reality > Assumption
23. Evidence > Claim
24. Execution > Configuration
25. Verification > Report
26. Reuse > Recreate
27. Integrate > Duplicate
28. UNKNOWN != SUCCESS

معماری هدف:

AVATAR
 ├── CHAT INPUT
 ├── VOICE INPUT
 └── CAMERA
        ↓
NOVIN COMMAND ENGINE
        ↓
SOVEREIGNTY GATE
        ↓
REALITY GATE
        ↓
ORCHESTRATOR
        ↓
AGENT RUNTIME
        ↓
TOOLS
 ├── INTERNET / NETWORK
 ├── ENVIRONMENT MANAGER
 ├── CAMERA
 ├── VOICE
 └── OTHER EXISTING NOVIN TOOLS
        ↓
VALIDATION
        ↓
EXECUTION
        ↓
EVIDENCE
        ↓
AVATAR STATUS

قانون مهم:
قبل از ایجاد هر فایل جدید، ابتدا فایل‌ها و قابلیت‌های موجود پروژه برای Command Engine، Environment Manager، Voice، Chat، Camera، Network و Avatar جستجو شوند.
اگر قابلیت موجود است، همان قابلیت Integrate شود.
از ساخت نسخه دوم یک قابلیت موجود جلوگیری شود.

هدف نهایی:
کاربر فقط با آواتار NOVIN تعامل کند.
کاربر بتواند صحبت کند، متن بنویسد، دوربین را فعال کند و فرمان بدهد.
NOVIN فرمان را دریافت، اعتبارسنجی، اجرا و نتیجه واقعی را از طریق همان آواتار نمایش دهد.

هر قابلیت بدون Evidence واقعی:
NOT_IMPLEMENTED یا BLOCKED

هر تغییر باید قابل Build و قابل Verification باشد.
