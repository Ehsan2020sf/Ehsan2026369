# NOVIN NEXUS
# MASTER ENGINEERING TASK
# 3D AVATAR + PERSIAN/ENGLISH VOICE + CHAT + CAMERA + COMMAND ENGINE

PROJECT_ROOT:
~/NOVIN_APK_BUILD

MISSION:
ساخت یک رابط انسانی یکپارچه برای NOVIN که کاربر در حالت عادی فقط آواتار سه‌بعدی NOVIN را ببیند و بتواند با آن به فارسی و انگلیسی صحبت کند، چت کند، فرمان بدهد، پاسخ صوتی دریافت کند، دوربین را فعال کند و نتیجه واقعی عملیات را دریافت کند.

==================================================
1. NON-NEGOTIABLE NOVIN PRINCIPLES
==================================================

REALITY & SAFETY > CORRECTNESS > VERIFICATION > COMPLETION > PERFORMANCE > QUOTA SAVING

REALITY > ASSUMPTION
EVIDENCE > CLAIM
EXECUTION > CONFIGURATION
VERIFICATION > REPORT
REUSE > RECREATE
INTEGRATE > DUPLICATE
UNKNOWN != SUCCESS

هیچ قابلیت بدون اجرای واقعی و Evidence واقعی PASS نیست.

وجود فایل، کلاس، تابع، API، Permission، Mock، Stub یا Configuration به معنی اجرای واقعی نیست.

وضعیت‌ها فقط:

PASS
FAIL
BLOCKED
NOT_IMPLEMENTED

==================================================
2. FIRST ACTION: REAL AUDIT
==================================================

قبل از هر تغییر، کل پروژه موجود را بررسی کن.

به‌خصوص پیدا کن:

runtime/
runtime/tools/
Android application
Command Engine
Persian Understanding
English Understanding
Voice
STT
TTS
Avatar
Camera
Chat
AI Gateway
Orchestrator
Agent Runtime
Security
Governance
Memory
UI
Permissions

فایل مهم موجود:

runtime/tools/novin-persian-understanding.mjs

اگر Command Engine یا قابلیت مشابه قبلاً ساخته شده است:

REUSE
REPAIR
INTEGRATE

نه:

RECREATE

هیچ قابلیت موجودی را بدون دلیل حذف نکن.

==================================================
3. TARGET ARCHITECTURE
==================================================

USER
↓
VOICE / TEXT
↓
LANGUAGE DETECTION
↓
PERSIAN / ENGLISH UNDERSTANDING
↓
CONVERSATION CONTEXT
↓
UNIFIED NOVIN COMMAND ENGINE
↓
SOVEREIGNTY GATE
↓
REALITY GATE
↓
TOOL ORCHESTRATOR
↓
REAL TOOL
↓
EVIDENCE
↓
RESULT VALIDATION
↓
CONVERSATION RESPONSE
↓
TTS
↓
3D AVATAR

Avatar فقط رابط انسانی است.

Core نباید به Avatar وابسته باشد.

==================================================
4. 3D NOVIN AVATAR
==================================================

هدف:

یک آواتار سه‌بعدی قدرتمند، زنده و قابل تعامل.

ابتدا Avatar موجود پروژه را پیدا کن.

اگر وجود دارد:

REUSE + UPGRADE

اگر وجود ندارد:

بررسی کن چه موتور سه‌بعدی سازگار با Android و محدودیت دستگاه موجود است.

Avatar باید حداقل وضعیت‌های زیر را داشته باشد:

IDLE
LISTENING
THINKING
EXECUTING
SPEAKING
SUCCESS
ERROR
CAMERA_ACTIVE
ONLINE
OFFLINE

تغییر وضعیت باید بر اساس Event واقعی سیستم باشد.

==================================================
5. AVATAR SPEAKING
==================================================

وقتی NOVIN واقعاً صحبت می‌کند:

Avatar = SPEAKING

در صورت امکان Lip Sync واقعی:

Audio
↓
Phoneme / Viseme
↓
Mouth Animation

اگر Lip Sync واقعی وجود ندارد:

NOT_IMPLEMENTED

Animation ساده را Lip Sync واقعی اعلام نکن.

==================================================
6. MAIN UI
==================================================

صفحه اصلی باید بسیار مینیمال باشد.

در حالت عادی:

فقط Avatar NOVIN.

دکمه‌های اضافی:
HIDE

Toolbar اضافی:
HIDE

Menu اضافی:
HIDE

پنل‌های غیرضروری:
HIDE

Chat و Voice و Camera باید از طریق Interaction طبیعی با Avatar یا Overlay بسیار مینیمال قابل دسترسی باشند.

Owner/Admin controls حذف نشوند.

آن‌ها باید در مسیر محافظت‌شده باقی بمانند.

==================================================
7. PERSIAN VOICE
==================================================

مسیر:

Microphone
↓
Speech Detection
↓
Speech-to-Text
↓
Persian Understanding
↓
Command Engine
↓
Execution
↓
Response
↓
Text-to-Speech
↓
Avatar

هدف:

کاربر بتواند آزادانه فارسی صحبت کند.

سیستم فقط نباید چند عبارت ثابت را تشخیص دهد.

==================================================
8. ENGLISH VOICE
==================================================

همان معماری برای English.

مثال:

Open the camera.

Take a picture of the front door.

Check the front door.

Talk to me.

Check my internet.

هر دو زبان باید به یک Command Engine مشترک برسند.

==================================================
9. MIXED LANGUAGE
==================================================

تا حد امکان جملات ترکیبی را نیز بفهم:

نوین camera رو باز کن

نوین check کن اینترنت وصله

Take a عکس از جلوی در

اما هرگز در صورت ابهام حدس نزن.

==================================================
10. ONLINE VOICE
==================================================

اگر اینترنت موجود است:

Voice
↓
Secure AI Gateway
↓
STT / AI / TTS
↓
Avatar

API Key نباید به شکل ناامن داخل APK قرار گیرد.

اگر AI Gateway موجود است از همان استفاده کن.

==================================================
11. OFFLINE VOICE
==================================================

در صورت وجود موتور واقعی Offline:

Microphone
↓
Offline STT
↓
Local Understanding
↓
Command Engine
↓
Offline TTS
↓
Avatar

اگر موتور Offline واقعی موجود نیست:

BLOCKED یا NOT_IMPLEMENTED

هرگز Fake Offline را PASS نکن.

==================================================
12. CHAT
==================================================

NOVIN باید Chat داشته باشد.

Chat باید بتواند:

Persian
English
Conversation Context
Natural Response

را پشتیبانی کند.

Chat نباید معماری Command Engine را دور بزند.

فرمان داخل Chat نیز باید وارد Command Engine شود.

==================================================
13. UNIFIED COMMAND ENGINE
==================================================

تمام فرمان‌ها باید به یک Command Engine برسند.

مثال فارسی:

دوربین رو روشن کن

مثال انگلیسی:

Open the camera

هر دو باید به:

CAMERA.OPEN

تبدیل شوند.

همچنین:

CAMERA.CAPTURE
CAMERA.ANALYZE
VOICE.START
VOICE.STOP
CHAT.TALK
INTERNET.CHECK
ENVIRONMENT.CHANGE
SYSTEM.*

در صورت وجود معماری مناسب، از همان استفاده کن.

==================================================
14. NATURAL LANGUAGE
==================================================

عبارت‌های مختلف با معنی یکسان باید به یک Intent برسند.

مثال:

دوربین رو روشن کن
دوربین را باز کن
دوربین را فعال کن
برو دوربین رو باز کن

همگی:

CAMERA.OPEN

ولی فقط با Ruleهای پراکنده سیستم را بزرگ نکن.

هدف Semantic Understanding است.

==================================================
15. CONTEXT
==================================================

NOVIN باید Context مکالمه جاری را حفظ کند.

مثال:

کاربر:
دوربین رو روشن کن.

NOVIN:
دوربین روشن شد.

کاربر:
حالا جلوی در رو ببین.

NOVIN باید Context قبلی را بفهمد.

اگر Context کافی نیست:

CLARIFICATION REQUIRED

و:

BLOCKED

نه حدس.

==================================================
16. CAMERA
==================================================

فرمان:

دوربین رو روشن کن

→ CAMERA.OPEN

فرمان:

از جلوی در عکس بگیر

→ CAMERA.CAPTURE

فرمان:

ببین جلوی در چه خبره

→ CAMERA.ANALYZE

فرمان ترکیبی:

دوربین رو روشن کن، از جلوی در عکس بگیر و ببین کسی اونجاست یا نه.

باید بتواند:

CAMERA.OPEN
↓
CAMERA.CAPTURE
↓
CAMERA.ANALYZE
↓
RESPONSE

را به‌صورت زنجیره‌ای اجرا کند.

اگر یک مرحله شکست خورد:

مرحله‌های وابسته موفق اعلام نشوند.

==================================================
17. CAMERA + CONVERSATION
==================================================

کاربر باید بتواند هنگام مشاهده Camera بگوید:

چی می‌بینی؟

جلوی در کسی هست؟

این تصویر رو بررسی کن.

و NOVIN باید آخرین تصویر معتبر را در Context داشته باشد.

اگر تصویر موجود نیست:

نباید حدس بزند.

==================================================
18. REALITY GATE
==================================================

قبل از هر Execution:

Tool موجود؟
Permission موجود؟
Capability موجود؟
Network لازم است؟
User authorized؟
Tool واقعاً اجرا شد؟
Result واقعی برگشت؟

اگر پاسخ منفی است:

PASS ممنوع.

==================================================
19. SOVEREIGNTY GATE
==================================================

مالک نهایی انسان است.

NOVIN نباید اختیار مالک را دور بزند.

برای عملیات حساس:

Authorization
↓
Execution

برای عملیات مبهم:

Clarification
↓
Execution

==================================================
20. ONLINE / OFFLINE
==================================================

وضعیت واقعی:

ONLINE
OFFLINE
DEGRADED

در Offline:

قابلیت‌های محلی اجرا شوند.

قابلیت‌های نیازمند اینترنت:

BLOCKED

علت به کاربر اعلام شود.

==================================================
21. AUDIO SESSION SAFETY
==================================================

از چند Audio Session همزمان جلوگیری کن.

از چند Microphone Session همزمان جلوگیری کن.

از چند Camera Session همزمان جلوگیری کن.

Lifecycle Android باید رعایت شود.

Background execution فقط در صورت مجاز بودن و نیاز واقعی.

==================================================
22. SECURITY
==================================================

Permission فقط برای قابلیت واقعی مورد نیاز.

بررسی:

CAMERA
RECORD_AUDIO
INTERNET
NETWORK STATE

کلیدهای حساس داخل UI یا APK به شکل ناامن ذخیره نشوند.

==================================================
23. PERFORMANCE
==================================================

دستگاه هدف منابع محدودی دارد.

بررسی:

RAM
CPU
Battery
GPU
Storage

Avatar باید بهینه باشد.

مدل سه‌بعدی بیش از حد سنگین نباشد.

Memory Leak وجود نداشته باشد.

پردازش AI سنگین بدون نیاز دائمی اجرا نشود.

==================================================
24. EVENT MODEL
==================================================

Avatar باید از Eventهای واقعی سیستم تغذیه شود.

مثال:

VOICE_LISTENING
VOICE_TRANSCRIBING
AI_THINKING
COMMAND_EXECUTING
CAMERA_OPENED
CAMERA_CAPTURING
CAMERA_ANALYZING
RESPONSE_GENERATING
TTS_SPEAKING
ERROR
OFFLINE

UI نباید وضعیت جعلی نمایش دهد.

==================================================
25. EVIDENCE
==================================================

هر Execution واقعی باید Evidence داشته باشد.

حداقل:

status
intent
action
parameters
tool
execution
timestamp
verification
result
error

مثال واقعی:

status=PASS
execution=REAL
verification=VERIFIED

اگر فقط Parser اجرا شده:

execution=NOT_EXECUTED

==================================================
26. TEST MATRIX
==================================================

تست فارسی:

سلام نوین

نوین با من صحبت کن

دوربین رو روشن کن

از جلوی در عکس بگیر

ببین جلوی در چه خبره

این تصویر رو بررسی کن

وضعیت اینترنت رو بررسی کن

==================================================

تست انگلیسی:

Hello NOVIN

Talk to me

Open the camera

Take a picture of the front door

Check the front door

Check my internet

==================================================

تست ترکیبی:

نوین camera رو باز کن

نوین check کن اینترنت وصله

==================================================

تست ابهام:

اونجا رو نگاه کن

اون کار رو انجام بده

این رو باز کن

باید:

BLOCKED

و سؤال تکمیلی تولید شود.

==================================================
27. E2E TEST
==================================================

سناریوی اصلی:

کاربر:

سلام نوین.

NOVIN:

پاسخ صوتی طبیعی.

کاربر:

دوربین رو روشن کن.

NOVIN:

دوربین واقعی را فعال کند.

کاربر:

از جلوی در عکس بگیر.

NOVIN:

عکس واقعی بگیرد.

کاربر:

ببین چی می‌بینی.

NOVIN:

تصویر واقعی را تحلیل کند، اگر Vision واقعی متصل است.

سپس پاسخ صوتی فارسی بدهد.

همین سناریو باید با English نیز تست شود.

==================================================
28. BUILD
==================================================

پس از تغییرات:

Syntax Check
↓
Unit Test
↓
Integration Test
↓
Android Build
↓
Install
↓
Launch
↓
Runtime Test
↓
E2E Evidence

اگر Build موفق شد ولی Runtime تست نشده:

PASS برای قابلیت صادر نکن.

==================================================
29. DO NOT BREAK EXISTING WORK
==================================================

هیچ قابلیت موجود را بدون دلیل حذف نکن.

هیچ فایل موجود را فقط برای ساده‌سازی بازنویسی نکن.

Dockerfile و docker-compose.yml فعلاً جدا باقی بمانند.

Master State و فایل‌های مرجع بدون نیاز تغییر نکنند.

==================================================
30. DEVELOPMENT ORDER
==================================================

مرحله 1:
REAL AUDIT

مرحله 2:
مقایسه قابلیت‌های موجود

مرحله 3:
Unified Conversation Layer

مرحله 4:
Unified Command Engine

مرحله 5:
Persian + English Understanding

مرحله 6:
Context + Clarification

مرحله 7:
Sovereignty Gate

مرحله 8:
Reality Gate

مرحله 9:
Tool Registry

مرحله 10:
Voice Online

مرحله 11:
Voice Offline

مرحله 12:
Chat

مرحله 13:
Camera

مرحله 14:
Vision

مرحله 15:
3D Avatar

مرحله 16:
Avatar Event System

مرحله 17:
TTS + Speaking

مرحله 18:
Lip Sync

مرحله 19:
Minimal UI

مرحله 20:
E2E

مرحله 21:
Build + Install + Runtime Evidence

==================================================
31. IMPORTANT EXECUTION RULE
==================================================

این پروژه را با ادعای «کامل شد» تمام نکن.

تا زمانی که اجرای واقعی هر قابلیت روی محیط هدف اثبات نشده:

PASS نده.

اگر ابزار یا dependency لازم وجود ندارد:

BLOCKED

اگر قابلیت هنوز ساخته نشده:

NOT_IMPLEMENTED

اگر تست شکست خورد:

FAIL

==================================================
32. FINAL REPORT
==================================================

در پایان فقط گزارش واقعی بده:

3D Avatar:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Avatar States:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Lip Sync:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Persian STT:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

English STT:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Persian TTS:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

English TTS:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Online Voice:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Offline Voice:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Persian Chat:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

English Chat:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Camera Open:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Camera Capture:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Camera Vision:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Unified Command Engine:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Context:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Sovereignty Gate:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Reality Gate:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

Minimal Avatar UI:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

E2E:
PASS / FAIL / BLOCKED / NOT_IMPLEMENTED

برای هر PASS باید Evidence واقعی ارائه شود.

END
