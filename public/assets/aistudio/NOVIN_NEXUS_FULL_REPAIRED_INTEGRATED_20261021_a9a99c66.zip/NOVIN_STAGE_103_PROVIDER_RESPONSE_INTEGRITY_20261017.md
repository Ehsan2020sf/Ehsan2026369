# NOVIN Stage 103 — Provider Response Integrity

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding

The OpenAI and Gemini response adapters converted provider token usage fields with `Number(value || 0)`. Malformed values could become `NaN`, and negative values could enter the response accounting path. Whitespace-only output could also be accepted as content. Provider response bodies and usage telemetry must be treated as untrusted input.

## Change

- Added strict non-negative finite integer validation for token usage counts.
- Missing token usage fields retain the explicit zero/default behavior; malformed provided values are rejected.
- Rejects totals smaller than input plus output token counts.
- Rejects whitespace-only model output.
- Added `scripts/test_ai_gateway_provider_response_integrity.ts`, which injects a local mocked provider response with negative token usage and verifies fail-closed behavior (`error`, empty content, `UNKNOWN` reality), no retry for non-retryable schema/accounting failure, and finite cost telemetry.
- Registered the test in `package.json` and the `test:all` chain.

## Verification

- Controlled mocked-provider integrity test — PASS.
- Runtime provider availability test — PASS.
- Router integration test — PASS.
- Provider fallback test — PASS.
- Conversation JSON-boundary test — PASS.
- `package.json` JSON parse — PASS.

## Limits

The provider was mocked locally. No real model call, full test suite, full TypeScript build, dependency install, APK build, or device install was performed. This verifies the response-validation boundary, not production provider connectivity.
