# NOVIN Adaptive Display + Workflow-Agent Bridge
Date: 2026-10-15
Scope: Android app only. No public website or standalone web server is added.

## Implemented
- Added an adaptive display controller that reads viewport size, device-pixel ratio, reduced-motion preference, data-saver hints, and browser battery data when available.
- Applies bounded UI density scaling and conservative 3D render-quality changes through the existing graphics governor.
- Critical thermal or memory pressure forces the SAFE tier even if the owner selected a higher quality preference.
- Added a settings panel for auto-optimization, render quality policy, reduced motion, app-only dimming, and optional current-activity window brightness.
- Added native `NovinDeviceControl` methods to set/reset brightness for the NOVIN activity window only. The system brightness setting is not modified, and system resolution is not changed.
- Added build-time staging of all 2,066 indexed n8n graph JSONs as separate Android assets. Only the selected graph is loaded; its SHA-256 and node count are verified before parsing.
- Added conversion from an n8n graph to a NOVIN agent task-plan blueprint, including node dependencies, inferred capabilities, credential flags, side-effect risk and unmapped node types.
- Added workflow-adaptation, integration-mapping, adaptive-display and graphics-optimization capabilities to the existing NOVIN specialist agents.

## Source inventory
- 2,061 official workflow JSONs, 30,774 official workflow nodes.
- 2 AI Stack templates, 2 repository templates and 1 Playwright fixture.
- 2,066 graph JSON assets, 36,733,499 bytes uncompressed.
- The upstream repository is preserved under `integrations/n8n-workflows/upstream-repository`.
- The Android build stages only indexed graph JSON assets and a compact manifest. Website/server/Docker files are not staged into the app.

## Safety and reality boundary
- All workflow templates remain inactive.
- Workflow-to-agent output is a plan/blueprint, not proof of execution.
- `executionAllowed` remains `false`. The app does not embed the n8n runtime. Native tool adapters, verified credentials, owner approval, and runtime verification are still required before any external workflow can execute.
- Native brightness control is limited to the current NOVIN activity window and resets to Android-managed brightness when disabled or when the runtime stops.
- Android system resolution, global system brightness, root access and privileged device-owner capabilities are not assumed.
- No APK build or physical-device test was performed in this environment.

## Verification performed
- n8n source catalogue validation: PASS.
- Asset staging source/hash/node-count verification: PASS (2,066 entries).
- On-demand graph loader hash verification and traversal rejection test: PASS.
- Workflow-to-agent adapter and dependency-plan tests: PASS.
- Adaptive display policy tests: PASS.
- Android visual runtime/resilience/quality-governor tests: PASS.
- Android native runtime contract, management wiring, Java truth-boundary, security-static and Android-only product-scope tests: PASS.
- Core TypeScript checks for the new controller/adapter/catalogue passed using a minimal type declaration because npm dependencies are not installed in this extraction environment; TSX files passed syntax transpilation.
- Full `npm run test:all`, Android APK build and physical-device verification remain unverified here.
