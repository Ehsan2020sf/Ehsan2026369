# NOVIN Stage 104: Separate simulated outcomes from live-provider success
Date: 2026-10-17

## Finding
`AIGateway.recordSuccess` counted simulated responses in the generic `successful` counter. That counter is useful as successful execution count, but by itself could be misread as evidence that a real model/provider succeeded. The response reality tag was correct, yet the aggregate statistics did not expose the distinction.

## Change
- Preserved `successful` as successful gateway executions for compatibility.
- Added `liveProviderSuccesses`, incremented only for `OBSERVED` or `GENERATED` responses.
- Added `simulatedResponses`, incremented only for `SIMULATED` responses.
- Extended the controlled fallback interaction test to prove a simulated fallback increments the simulated counter and does not increment live-provider success.

## Validation
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts`: PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_concurrency.ts`: PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_failure_recovery.ts`: PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_retry_interaction.ts`: PASS.
- `package.json` JSON parse: PASS.
- ZIP CRC and duplicate-path validation: PASS after repack.

## Limits
No live provider was contacted. These tests use controlled/mock network responses. No dependencies were installed, no APK was built, and no device installation was performed.

Status: PASS for the focused local tests; live-provider behavior remains NOT TESTED.
