# NOVIN EHSAN STEP 32 — R198 Model Policy Truth Boundary

- Target: `src/core/governance/modelPolicyR198.ts`
- Weak reality classes now BLOCK; only OBSERVED/VERIFIED_REAL are accepted.
- consent/trusted/fresh are fail-closed and must be exactly true.
- evidence must be a non-empty array with no empty/whitespace-only entries.
- Existing duplicate, high-risk owner-review, and critical rollback controls preserved.
- Targeted test: `R198 modelPolicy: PASS`.
