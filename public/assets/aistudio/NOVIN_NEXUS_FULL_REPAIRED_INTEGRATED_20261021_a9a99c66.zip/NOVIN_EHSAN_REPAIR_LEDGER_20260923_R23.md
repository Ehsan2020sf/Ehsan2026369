# NOVIN EHSAN Repair Ledger R23

## تغییر واقعی
مسیر Android SDK از `android/local.properties` حذف شد چون مسیر مطلق `/data/data/com.termux/...` مخصوص یک محیط و قابل انتقال به محیط دیگر نبود.

به‌جای آن `scripts/novin_android_prepare.mjs` اضافه شد تا هنگام Build، مسیر SDK فقط از `ANDROID_SDK_ROOT` یا `ANDROID_HOME` دریافت و `local.properties` را همان لحظه تولید کند.

## هدف
- جلوگیری از قفل شدن سورس/ZIP به مسیر SDK یک دستگاه خاص
- جلوگیری از Build سبز کاذب در محیط دیگر
- حفظ سازگاری با Termux و سایر محیط‌های Android build

## وضعیت
- Script syntax: PASS
- Package script wiring: PASS
- Stale machine-specific local.properties: REMOVED
- Android native build: NOT VERIFIED در این محیط، چون Gradle distribution قابل دانلود نیست.
