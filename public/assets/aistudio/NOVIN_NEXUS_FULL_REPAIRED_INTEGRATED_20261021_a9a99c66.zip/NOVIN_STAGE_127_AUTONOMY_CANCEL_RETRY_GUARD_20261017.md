# NOVIN Stage 127 — Autonomy Cancellation and Retry Guard

Date: 2026-10-17
Scope: source-level cancellation handling for the Avatar autonomy mission queue.

## Finding
The Avatar command authority accepted an AbortSignal, but its bootstrap AUTONOMY path called `novinAvatarOperatingSystem.executeOwnerCommand(raw)` without forwarding it. The operating system's persistent queue handler also had no request-local cancellation context, and its task retry loop could continue without checking cancellation.

## Changes
- `NovinAvatarOperatingSystem.executeOwnerCommand(command, signal?)` now fails closed if the signal is already aborted.
- The signal is held in an in-memory map keyed by the queued job ID only for the duration of `processNext`; it is not serialized into durable queue state.
- The registered mission handler resolves that ephemeral signal using the job ID.
- Mission execution checks cancellation before starting each dependency batch and prevents new batches after cancellation.
- Task retry logic checks cancellation before every attempt and before scheduling another retry.
- A cancelled mission reports `BLOCKED`; it does not label the overall mission successful. In-flight synchronous task work may still finish to its next safe boundary, and already-applied internal state changes are not rolled back.
- `NovinAvatarCommandAuthority` forwards the signal into the autonomy path and rejects late results after cancellation.
- Added source-contract test `scripts/test_cancellation_autonomy_retry_boundary.mjs` and pre-cancel runtime test `src/core/nexusAutonomy/novinAvatarOperatingSystem.cancellation.test.ts`.

## Verification
PASS:
- `node scripts/test_cancellation_autonomy_retry_boundary.mjs` (8 source-contract assertions)
- `node --experimental-strip-types src/core/nexusAutonomy/novinAvatarOperatingSystem.cancellation.test.ts`
- `node --experimental-strip-types src/core/nexusAutonomy/novinAvatarOperatingSystem.test.ts`
- `node --experimental-strip-types scripts/test_command_cancellation_boundary.mjs`
- `node --experimental-strip-types scripts/test_cancellation_network_side_effect_boundary.mjs`

BLOCKED / not run:
- Direct runtime test of `novinAvatarCommandAuthority` could not load because `@capacitor/core` is not installed (`ERR_MODULE_NOT_FOUND`). No dependencies were installed, per project constraints.
- Full `test:all`, full TypeScript compile, APK build, and device test were not run.

## Safety boundary
This improves cooperative cancellation at mission/batch/retry boundaries. It does not interrupt a synchronous task in the middle of its operation and does not roll back internal mutations already applied before cancellation. Those limits must not be represented as full transactional cancellation.

## Archive
The single canonical archive was updated in place. No parallel archive was created.
