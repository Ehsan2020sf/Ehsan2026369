# NOVIN OpenAI Connection Hardening — 2026-09-23

## Scope
Only the NOVIN ↔ OpenAI connection boundary was hardened. No unrelated subsystem was changed.

## Repairs
- Remote providers no longer silently degrade to `SIMULATED` when credentials are missing. The response is fail-closed with `PROVIDER_CREDENTIAL_UNAVAILABLE:<provider>`.
- OpenAI credentials must be non-empty after trimming.
- OpenAI endpoint is validated as HTTPS and exactly `api.openai.com`.
- OpenAI request timeout is bounded to 1s..120s, with a 45s fallback for invalid configuration.
- OpenAI tool execution remains explicitly gated because the NOVIN Tool Execution Adapter is not implemented for this path.
- `store:false` remains explicit.

## Evidence
- OPENAI_NOVIN_CONNECTION_CONTRACT_PASS
- OPENAI_NOVIN_CONNECTION_HARDENING_PASS
- Existing AI Gateway / provider governance tests preserved.

## Reality boundary
A live OpenAI API call was NOT VERIFIED because no real `OPENAI_API_KEY` is available in the current environment. Therefore live provider connectivity remains NOT VERIFIED.
