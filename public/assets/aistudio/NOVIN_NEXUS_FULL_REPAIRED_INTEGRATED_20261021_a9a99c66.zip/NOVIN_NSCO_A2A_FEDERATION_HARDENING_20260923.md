# NOVIN NSCO A2A / Federation Hardening — 2026-09-23

## Scope

فقط بخش A2A / Federation بررسی و سخت‌سازی شد. بخش‌های دیگر در این چرخه تغییر داده نشدند.

## Finding

در Federation Gateway، Envelope دارای sender/recipient بود اما ارتباط آن‌ها با identity داخل payload به‌صورت مستقل enforce نمی‌شد. همچنین A2A Gateway می‌توانست task را از source ناشناخته route کند. Federation nonce نیز replay protection مستقل نداشت.

## Fix

- A2A task قبل از route شدن، id/from/to/skill را Fail-Closed اعتبارسنجی می‌کند.
- source agent باید در registry شناخته‌شده باشد.
- Federation sender باید دقیقاً با A2A `from` و recipient با `to` منطبق باشد.
- MCP Federation actorId و origin به sender bind شدند.
- Federation nonce برای جلوگیری از replay ثبت می‌شود.
- قرارداد Agent Card نیز ساختار آرایه‌های skills/accepts/emits را اعتبارسنجی می‌کند.
- هیچ Authority موازی یا bypass ایجاد نشد.

## Evidence

- Federation Gateway regression: PASS
- Federation Reality test: PASS
- A2A Message Security: PASS
- NOVIN A2A Protocol: PASS
- Protocol Gate: PASS
- Valid identity binding: PASS
- Unknown source: BLOCKED
- Identity mismatch: BLOCKED
- Replay: BLOCKED
- MCP actor/origin mismatch: BLOCKED

## Reality status

- A2A/Federation source-level hardening: PASS
- Physical Android execution: NOT VERIFIED
- External federation deployment: NOT VERIFIED
- Full NOVIN build/device E2E: NOT VERIFIED

PASS above refers only to focused source-level tests for this section.
