# NOVIN EHSAN Repair Ledger R24

## تغییر واقعی
مسیر Build اندروید هنوز یک fallback سخت‌کدشده برای JDK و SDK داشت:
- `/usr/lib/jvm/java-17-openjdk-amd64`
- `/opt/android-sdk`

این fallbackها حذف شدند.

## رفتار جدید
- `JAVA_HOME` فقط در صورت ارائه توسط محیط Build به Gradle منتقل می‌شود.
- `ANDROID_SDK_ROOT` و `ANDROID_HOME` فقط در صورت ارائه توسط محیط منتقل می‌شوند.
- مسیر SDK توسط `scripts/novin_android_prepare.mjs` و فقط از متغیرهای محیطی معتبر آماده می‌شود.
- نبود Toolchain باعث BLOCKED می‌شود، نه استفاده از مسیر حدسی.

## تست‌های واقعی
- Android build environment portability: PASS
- Android Gradle alignment: PASS
- Unified Integrity: PASS
- Reality Claims: PASS
- Phase 0: BLOCKED به‌دلیل typecheck/dependency environment
- Android native APK build: NOT VERIFIED
- Device E2E: NOT VERIFIED
- Live AI: NOT VERIFIED
