# NOVIN NEXUS | 10 ابرپرامپت ممیزی، تست و رفع عیب

**هدف:** اجرای مهندسی کم‌مصرف، بدون بازنویسی معماری، بدون ادعای ساختگی و بدون ساخت ZIPهای تکراری. این پرامپت‌ها به ترتیب اجرا شوند. هر پرامپت باید از خروجی قبلی استفاده کند و از اسکن دوباره کل مخزن پرهیز کند.

## قرارداد مشترک برای هر ۱۰ پرامپت
- پروژهٔ مرجع: NOVIN NEXUS، سورس موجود و فایل lock فعلی؛ ابتدا version/hash را ثبت کن.
- Reality-first: `PASS` فقط با خروجی واقعی آزمون؛ `UNKNOWN` مساوی `PASS` نیست؛ تست mock، تست قرارداد و شبیه‌سازی را از تست دستگاه/سرویس زنده جدا کن.
- ابتدا با `git status` یا هش فایل‌ها تغییرات موجود را حفظ کن. هیچ حذف گسترده، reset معماری، بازتولید بی‌دلیل lockfile، نصب global یا تغییر secrets انجام نده.
- هر اصلاح باید کوچک، قابل بازگشت و همراه آزمون رگرسیون باشد. قبل از تغییر فایل، علت و آزمون شکست‌پذیر را مشخص کن.
- سهمیه را با یک بار خواندن فایل‌های مرتبط، دستورات گروهی و استفاده از گزارش قبلی حفظ کن. تست‌های پرهزینه فقط پس از عبور گیت‌های ارزان اجرا شوند.
- پایان هر مرحله: فایل/خط تغییرکرده، دلیل، فرمان اجراشده، کد خروج، PASS/PARTIAL/FAIL/BLOCKED/UNKNOWN و گام بعدی را ثبت کن.

## 1. ابرپرامپت فرماندهٔ ممیزی
تو مهندس ارشد مسئول NOVIN NEXUS هستی. ابتدا `NOVIN_START_HERE.md`، فایل وضعیت ادامهٔ مهندسی، آخرین گزارش stage و `package.json` را فقط یک بار بخوان. یک نقشهٔ کوتاه از گیت‌ها بساز: source tests، dependency integrity، typecheck، web build، web-asset manifest، Capacitor sync، Android build، نصب/اجرای واقعی. سپس تست‌های ارزان موجود را اجرا کن و خروجی‌ها را به یک جدول evidence وصل کن. هیچ قابلیت جدیدی نساز تا موانع انتشار شناسایی شوند. هر ادعا باید به خروجی یا مسیر فایل متصل باشد.

## 2. ابرپرامپت وابستگی‌ها و بازیابی ساخت
`package.json` و `package-lock.json` را تطبیق بده؛ برای وابستگی‌های مستقیم/اختیاری، پکیج‌های بومی میزبان و type packages وضعیت LOCKED/INSTALLED/CACHE_EVIDENCE/REGISTRY_DNS را جدا کن. از اجرای تکراری `npm ci` وقتی DNS در دسترس نیست خودداری کن. `node_modules` را بین سیستم‌عامل‌ها یا معماری‌های متفاوت کپی نکن. اگر دسترسی registry برقرار بود، فقط `npm ci --include=optional --no-audit --no-fund` را از روی lockfile اجرا کن؛ سپس audit را دوباره اجرا کن. هیچ نسخه‌ای را برای رفع سریع به‌صورت حدسی تغییر نده.

## 3. ابرپرامپت TypeScript و Build
ابتدا اسکریپت‌های `lint` و `build:web` و preflight مربوط را بخوان. خطای typecheck را از خطای نبود dependency جدا کن. پس از نصب معتبر وابستگی‌ها، lint و build وب را اجرا کن. اولین خطای ریشه‌ای را اصلاح کن، نه پیامدهای زنجیره‌ای را. بعد از هر اصلاح فقط تست مربوط و سپس lint/build کامل را دوباره اجرا کن. اگر dependency یا شبکه مانع است، BLOCKED ثبت کن و به اصلاحات بی‌ارتباط ادامه نده.

## 4. ابرپرامپت صحت شواهد و Release Gate
همهٔ ادعاهای PASS، سلامت، آمادگی انتشار و version alignment را پیدا کن. مطمئن شو تست mock یا وجود فایل به‌تنهایی به‌عنوان تست واقعی معرفی نشده باشد. وضعیت APK را به NOT_BUILT/PRESENT_UNVERIFIED/VERIFIED_DEVICE_TEST تفکیک کن. gate باید در نبود `novin-web-build-manifest.json` متناظر با سورس، sync و بسته‌بندی را متوقف کند. برای هر ادعای مثبت، آزمون منفی یا tamper test داشته باش.

## 5. ابرپرامپت Android و Termux
مسیر build واقعی، Gradle wrapper، SDK/NDK، compileSdk/buildTools و namespace/applicationId را با منبع canonical تطبیق بده. اسکریپت Termux را برای گوشی arm64 و محدودیت حافظه بررسی کن. قبل از ساخت APK، از موفقیت build:web و manifest هش‌دار اطمینان حاصل کن. از `cap sync` روی خروجی وب قدیمی اجتناب کن. اگر SDK یا dependency موجود نیست، دستور تشخیصی دقیق ارائه بده؛ موفقیت دستگاه را از روی تست ایستا نتیجه نگیر.

## 6. ابرپرامپت Voice/STT/TTS/Realtime
مسیر فرمان صوتی را از شروع میکروفن تا STT، تصمیم‌گیری، پاسخ، TTS و بازگشت به شنود ترسیم کن. رقابت Native STT و WebRTC mic، لغو session، رویدادهای دیررس، background/unmount، قطع شبکه و خطاهای provider را تست کن. کلید provider نباید به کلاینت نشت کند. در هر خطا منابع microphone/peer/channel/audio آزاد شوند. transcript ساختگی را از گفت‌وگوی زنده جدا کن و هیچ سرویس زنده‌ای را بدون دسترسی واقعی PASS اعلام نکن.

## 7. ابرپرامپت Brain/Memory/Governance
مسیر AndroidConversation → Mind Core → AI Gateway → Evidence/Memory را بررسی کن. bypass خام، تکرار منطق، حافظهٔ بدون checksum، اجرای ابزار بدون admission، و ادعای یادگیری بدون شاهد را پیدا کن. تغییرات باید از مسیر رسمی governance و evidence عبور کنند. تست‌های determinism، persistence/reload، corruption، duplicate action، retry و fail-closed را اجرا کن. UI یا Avatar را معادل هوش یا حافظهٔ واقعی فرض نکن.

## 8. ابرپرامپت امنیت و محدودسازی
ورودی‌ها، APIها، session issuance، secrets، rate limiter، proxy/IP trust، log privacy و resource cleanup را بررسی کن. ظرفیت حافظه و رفتار fail-closed باید محدود و قابل آزمون باشند. محدودکنندهٔ درون‌حافظه‌ای را distributed یا production-ready معرفی نکن. درخواست‌های هم‌زمان، ساعت عقب‌گرد، منبع ناشناخته، پرشدن ظرفیت و Retry-After را تست کن. تغییر امنیتی باید تست مثبت و منفی داشته باشد.

## 9. ابرپرامپت UX، Avatar، Camera و Accessibility
از قراردادهای موجود برای صفحهٔ Android، HUD، WebGL، fallback، دوربین و دسترس‌پذیری استفاده کن. مسیر تعامل را در viewport کوچک، landscape، safe-area، background/resume، WebGL unsupported/context loss و کاهش حرکت بررسی کن. دادهٔ سخت‌افزاری را جعل نکن. UI را فقط پس از تضمین عملکرد اصلی بهبود بده؛ از ساخت تصویر نمایشی به‌جای قابلیت عملیاتی اجتناب کن.

## 10. ابرپرامپت انتشار نهایی و بستهٔ شواهد
پس از اصلاحات، به ترتیب اجرا کن: تست‌های هدفمند، `npm run test:all`، `npm run test:rebuild-integrity`، lint، build:web، manifest verify، Capacitor sync، Android build، APK inspection و در دسترس بودن دستگاه تست. هر مرحله به‌صورت مستقل وضعیت داشته باشد. آرشیو مرجع را در همان مسیر به‌روزرسانی کن، SHA-256 و sidecar را بساز، از آرشیو تازه استخراج کن و تست‌های لازم را دوباره اجرا کن. اگر lint/build/APK/device اجرا نشده، صریحاً NOT_RUN/BLOCKED بنویس؛ هرگز از PASSهای سورس نتیجهٔ موفقیت دستگاه نگیر.
