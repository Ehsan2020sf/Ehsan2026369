# NOVIN MCP Gateway Hardening — 2026-09-23

## Scope
NSCO / Agent Protocols → MCP Gateway only.

## Finding
The MCP gateway defined `allowedOrigins` but did not enforce it during authorization. Its evidence hash also did not bind the authorized request arguments, so two different argument payloads could produce the same authorization evidence when the request id and actor were unchanged.

## Fix
- Added `origin` to `McpCall`.
- Enforced `allowedOrigins` fail-closed when configured.
- Bound authorization evidence to tool, canonicalized arguments, actor, and origin.
- Added recursive deterministic canonicalization so nested argument changes alter the evidence hash.
- Existing destructive `OWNER_APPROVAL` gate remains intact.

## Evidence
- MCP Gateway focused regression test: PASS
- Allowed origin: PASS
- Disallowed origin: BLOCKED
- Argument tampering changes evidence hash: PASS
- Destructive owner approval gate: PASS
- Registry behavior: PASS

## Reality boundary
This is source-level protocol hardening and focused regression evidence only. It does not prove Android APK build/install/run, physical-device E2E, or external MCP server execution.

## Scope discipline
No other NOVIN subsystem was intentionally modified in this cycle.
