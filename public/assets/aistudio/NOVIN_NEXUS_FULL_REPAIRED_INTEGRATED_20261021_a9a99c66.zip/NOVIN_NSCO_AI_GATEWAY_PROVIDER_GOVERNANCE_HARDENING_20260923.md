# NOVIN NSCO — AI Gateway / Provider Governance Hardening — 2026-09-23

## Scope
این چرخه فقط روی هماهنگی NSCO با AI Gateway / Model Router / Provider Governance تمرکز داشت.
هیچ بخش دیگری از NOVIN در این چرخه تغییر داده نشد.

## Finding
Model Router وضعیت `AIProviderConfig.enabled` را به‌صورت مستقل در انتخاب مدل اعمال نمی‌کرد. در نتیجه یک provider غیرفعال می‌توانست از مسیر selection یا forced model وارد تصمیم Router شود.

## Fix
- وضعیت فعال/غیرفعال provider در Model Router ثبت و enforce شد.
- provider غیرفعال از candidate selection و fallback chain حذف می‌شود.
- forced model متعلق به provider غیرفعال صریحاً رد می‌شود.
- AIGateway هنگام ثبت provider، وضعیت `enabled` را به Router منتقل می‌کند.

## Evidence
- `AI_PROVIDER_GOVERNANCE_REALITY_GATE_PASS`
- `AI gateway/router contract: PASS`
- `test_ai_gateway_router_integration: PASS`
- `test_ai_provider_failure_fallback: PASS`

## Reality Status
- AI Gateway / Provider Governance hardening: PASS
- Disabled-provider selection protection: PASS
- Disabled-provider forced-model protection: PASS
- Disabled-provider fallback protection: PASS
- Real external AI provider registration: NOT VERIFIED
- Physical Android execution: NOT VERIFIED
- APK build/install/device E2E: NOT VERIFIED
- PASS در این گزارش فقط مربوط به تست‌های واقعی source-level همین بخش است.

## Change Boundary
تغییرات این چرخه فقط در:
- `src/core/ai/modelRouter.ts`
- `src/core/ai/aiGateway.ts`
- `src/core/ai/modelRouter.providerGovernance.test.ts`
- این گزارش

بخش‌های Memory، Security/Authorization، Recovery، Evidence Ledger، Build/Deploy و Android در این چرخه دستکاری نشدند.
