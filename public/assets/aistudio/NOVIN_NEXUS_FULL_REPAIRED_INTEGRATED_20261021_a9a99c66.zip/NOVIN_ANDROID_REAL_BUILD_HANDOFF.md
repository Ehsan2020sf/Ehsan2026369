# NOVIN P64.13 — ANDROID REAL BUILD HANDOFF PACKAGE

**Project Name:** NOVIN SalesPulse Intelligence  
**Handoff Package Version:** P64.13 Final Handoff  
**Generated Date:** 2026-08-25  
**Current Build Environment Status:** `BLOCKED_BY_TOOLCHAIN` (JDK/Android SDK missing in cloud container)

---

## 1. Project Identity
- **Application Display Name:** NOVIN SalesPulse
- **Project Type:** Hybrid Native Mobile App (React 19 + TypeScript + Vite + Tailwind CSS + Capacitor 8 + Express Backend)
- **Primary Domain:** B2B AI Sales Call Intelligence, Sentiment Inflection Graphs & 3x3 AI Coaching

## 2. Application ID & Namespace
- **Application ID (`applicationId`):** `com.novin.salespulse`
- **Android Namespace (`namespace`):** `com.novin.salespulse`
- **Version Code (`versionCode`):** `1`
- **Version Name (`versionName`):** `"1.0"`

## 3. Capacitor Version & Plugins
- **Capacitor Core / CLI:** `^8.5.0`
- **Capacitor Android:** `^8.5.0`
- **Active Native Plugins:**
  - `@capacitor/app@8.1.1` (Hardware back button lifecycle & app state)
  - `@capacitor/keyboard@8.0.5` (Native keyboard resize & input handling)
  - `@capacitor/status-bar@8.0.3` (Dark theme status bar styling)

## 4. Gradle Version
- **Gradle Distribution:** `8.14.3`
- **Gradle Wrapper:** `android/gradle/wrapper/gradle-wrapper.jar` (Wrapper binary present & executable `rwxr-xr-x`)
- **Distribution URL:** `https\://services.gradle.org/distributions/gradle-8.14.3-all.zip`

## 5. Android Gradle Plugin (AGP) Version
- **AGP Version:** `8.13.0` (`com.android.tools.build:gradle:8.13.0`)

## 6. compileSdk
- **compileSdk:** `36` (Defined in `android/variables.gradle` — fully supporting Android 15 & 16 preview)

## 7. targetSdk
- **targetSdk:** `36` (Latest Google Play Store compliance)

## 8. minSdk
- **minSdk:** `24` (Android 7.0 Nougat — guarantees backward compatibility for 95%+ of active devices)

## 9. Java Requirement
- **Required JDK:** OpenJDK 17 or OpenJDK 21
- **JVM Target:** Java 21 / 17 Bytecode Compatibility

## 10. Android SDK Requirement
- **Android SDK Command-line Tools:** `latest` or version `12.0+`
- **SDK Build Tools:** `34.0.0` or `36.0.0`
- **Platform Tools:** `adb` version 34+

## 11. Required SDK Platforms
- Android SDK Platform `android-36` (and `android-34`)

## 12. Required Build Tools
- Android SDK Build-Tools `36.0.0` / `34.0.0`

## 13. Core Build Commands
```bash
# 1. Install workspace dependencies
npm install

# 2. Build production web bundle
npm run build

# 3. Synchronize assets and plugins into Android project
npx cap sync android
```

## 14. Debug APK Compilation Command
```bash
cd android
./gradlew assembleDebug
```
*Output Artifact:* `android/app/build/outputs/apk/debug/app-debug.apk`

## 15. Release APK Compilation Command
```bash
cd android
./gradlew assembleRelease
```
*Output Artifact:* `android/app/build/outputs/apk/release/app-release-unsigned.apk`

## 16. Google Play App Bundle (AAB) Command
```bash
cd android
./gradlew bundleRelease
```
*Output Artifact:* `android/app/build/outputs/bundle/release/app-release.aab`

## 17. Device Installation & Run Command
```bash
# Verify attached USB device / emulator
adb devices

# Install debug APK
adb install -r android/app/build/outputs/apk/debug/app-debug.apk

# Launch MainActivity
adb shell am start -n com.novin.salespulse/com.novin.salespulse.MainActivity
```

## 18. API Configuration & Bridge
- **Centralized API Client:** `/src/lib/apiClient.ts`
- **Dynamic Endpoint Resolver:** `getApiUrl(path)`
- **Web Runtime:** Uses relative URLs (`/api/analyze-audio`, `/api/analyze-text`, `/api/health`).
- **Android Standalone Build:** Resolves endpoints against `VITE_API_BASE_URL` when provided.

## 19. Production Backend Requirement
- When running as a standalone Android APK, the app connects to the remote backend specified in `VITE_API_BASE_URL` (e.g. `https://your-salespulse-backend.run.app`).
- Configurable via `.env` or build-time environment variable without hardcoded secrets.

## 20. Gemini AI Architecture
- **Isolation Model:** 100% Server-Side Execution.
- **Model:** `gemini-3.7-flash` via `@google/genai` in `server.ts`.
- **Schema & Structured Output:** `SALES_ANALYSIS_SCHEMA` and `SALES_COACHING_SYSTEM_PROMPT`.
- **Audio & Text Pipeline:** Inline Base64 audio transcription, Speaker A/B diarization, sentiment timeline synthesis, 3x3 coaching cards generation.

## 21. Android Permissions (`AndroidManifest.xml`)
- `android.permission.INTERNET`: Backend communication and AI sync.
- `android.permission.ACCESS_NETWORK_STATE`: Connectivity detection.
- `android.permission.RECORD_AUDIO`: Live sales call microphone recording.
- `android.permission.MODIFY_AUDIO_SETTINGS`: Audio routing configuration.
- `android.permission.READ_MEDIA_AUDIO`: Android 13+ audio file picker access.
- `android.permission.READ_EXTERNAL_STORAGE` (`maxSdkVersion="32"`): Legacy storage compatibility.

## 22. P63 Protected Core Integrity & SHA-256 Checksums
All P63 core components have been strictly preserved without unauthorized modifications:
```
812bc0097d004d925a9f1cf815e4aeb66a29b46082ef0403c53dcb0308fb5cfa  src/components/SentimentGraphView.tsx
8dd3d0d3b10b17b49928164ee757e099ad2898396bdc84eae179772f5784cc2e  src/components/CoachingCardView.tsx
b1ea52a7d71f6b82122ee4efcf6c6371c4a68a3cdb2a71214c33925486af8f0a  src/components/DiarizedTranscriptView.tsx
b4a9519b2caf716176f70de2e501572275ee8da53d5d43f1229f0c3cca19f090  src/components/DealSummaryView.tsx
91f98fc85d127c167f85788543ca64858c891376e9bce8d0791888a1aba4adbb  src/components/MetricsOverview.tsx
59804fa4da8c1b9f78ca5434610355acef46ada33be37d26e7eec0eca6c12271  src/data/sampleCalls.ts
56edfb7e1147f33b3314db7b7ac5426b31131835a2b1ac117da609dc80a299ce  src/types.ts
a41abf162d5ef161741b463568e6ee5a33ae3c0f881d9aa23d40e8a9008db02b  server.ts
```

## 23. Security Scan & Client Secret Audit
- Scan Targets: `src/`, `dist/assets/`, `android/app/src/main/assets/public/assets/`, `index.html`, `capacitor.config.ts`.
- Result: **ZERO CLIENT SECRETS FOUND (100% Clean)**.

## 24. Known Environment Limitations
- The cloud execution container lacks native binary compilers (`javac`, `aapt2`, `d8`, `gradle`, `adb`).
- Release APK signing requires a private release `.keystore` file provided during production CI/CD.

## 25. Exact Remaining Blocker
- **Toolchain Blocker:** Container environment lacks OpenJDK 17/21 and Android SDK command-line tools.
- **Remedy:** Execute Step 13 & 14 on any workstation or CI/CD runner equipped with Android Studio or Android SDK command line tools.

---

### FINAL HANDOFF STATUS:
```text
STATUS: BLOCKED_BY_TOOLCHAIN
```
*(The repository is 100% prepared, verified, and ready for immediate compilation upon export to an environment with the standard Android SDK toolchain).*

## 2026-09-12 Automation consolidation

The Android CI path has been consolidated to one canonical workflow: `.github/workflows/android-ci-cd-build.yml`.
The duplicate `.github/workflows/android-apk.yml` workflow was removed. The canonical workflow targets Android SDK 36, JDK 17, runs locked npm installation, web build, Capacitor sync, Gradle APK compilation, package/version verification, APK signature verification, SHA-256 generation, and smoke gates. Successful builds upload the real APK as an artifact; version tags additionally publish a GitHub Release.
