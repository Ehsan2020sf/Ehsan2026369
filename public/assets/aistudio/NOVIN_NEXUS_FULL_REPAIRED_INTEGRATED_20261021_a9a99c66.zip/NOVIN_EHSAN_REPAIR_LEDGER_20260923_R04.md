# NOVIN EHSAN Repair Ledger R04

## Scope
Continue from the current EHSAN reference without recreating the project.

## Repairs
1. Universal AI security now distinguishes an explicitly requested local simulated model from live remote-provider execution. This prevents the offline simulated path from being blocked by the remote-live lock while preserving fail-closed behavior for live providers.
2. Model-router governance test was corrected to match the hard-budget contract: an over-budget request is rejected rather than silently falling back.
3. AI gateway integration test now explicitly supplies owner approval for the simulated test path and remains explicit about simulated reality.
4. Android permission documentation no longer claims that camera access itself performs biometric owner recognition.
5. Checked-in Android web bundle was aligned with the governed source behavior so unknown commands are not reported as successfully executed.

## Verification
- AI gateway integration test: PASS
- Model router governance test: PASS
- Reality claims audit: PASS
- Brain hardening: PASS
- Vision observation bridge: PASS
- Vision multimodal runtime bridge: PASS
- Security command plane: PASS
- Real execution readiness: PASS
- ZIP integrity: to be checked after packaging

## Still not proven
- Full TypeScript/Vite build in this isolated environment because project dependencies are not installed.
- Android APK rebuild/install on the user's Redmi device.
- Live external AI provider execution with real credentials.
- Real camera-frame -> vision-model -> brain E2E on a physical device.
