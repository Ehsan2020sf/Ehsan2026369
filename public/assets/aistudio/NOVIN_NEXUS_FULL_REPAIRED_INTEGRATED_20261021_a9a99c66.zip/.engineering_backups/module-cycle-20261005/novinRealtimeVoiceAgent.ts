/**
 * NOVIN Realtime Voice Agent boundary.
 *
 * Security rule: no long-lived provider/API key is accepted by the Android UI.
 * A real transport must receive a short-lived session credential from a
 * trusted backend/native broker. Without that broker this module stays
 * NOT_VERIFIED and never pretends to be live.
 */
export type RealtimeVoiceState = 'DISCONNECTED'|'CONNECTING'|'CONNECTED'|'LISTENING'|'THINKING'|'SPEAKING'|'INTERRUPTED'|'BLOCKED'|'FAILED';
export type RealtimeReality = 'VERIFIED_REAL'|'NOT_VERIFIED'|'BLOCKED'|'UNKNOWN';

export interface RealtimeVoiceStatus {
  state: RealtimeVoiceState;
  reality: RealtimeReality;
  provider: 'OPENAI_REALTIME'|'CUSTOM'|'NONE';
  transport: 'WEBRTC'|'WEBSOCKET'|'NONE';
  ephemeralCredentialRequired: true;
  longLivedKeyInClient: false;
  sessionId: string|null;
  interruptionSupported: boolean;
  streamingSupported: boolean;
  evidence: string[];
}

export interface RealtimeVoiceAdapter {
  readonly provider: 'OPENAI_REALTIME'|'CUSTOM';
  readonly transport: 'WEBRTC'|'WEBSOCKET';
  connect(sessionCredential: string): Promise<{sessionId:string}>;
  disconnect(): Promise<void>;
  interrupt(): Promise<void>;
  sendText?(text:string): Promise<void>;
}

export class NovinRealtimeVoiceAgent {
  private adapter: RealtimeVoiceAdapter|null = null;
  private state: RealtimeVoiceState = 'DISCONNECTED';
  private sessionId: string|null = null;

  registerAdapter(adapter: RealtimeVoiceAdapter){
    this.adapter = adapter;
    this.state = 'DISCONNECTED';
  }

  async connect(sessionCredential?: string): Promise<RealtimeVoiceStatus>{
    if (!this.adapter) {
      this.state = 'BLOCKED';
      return this.status('REALTIME_ADAPTER_REQUIRED');
    }
    if (!sessionCredential || /^sk-[A-Za-z0-9]/.test(sessionCredential)) {
      this.state = 'BLOCKED';
      return this.status('EPHEMERAL_SESSION_CREDENTIAL_REQUIRED');
    }
    this.state = 'CONNECTING';
    try {
      const session = await this.adapter.connect(sessionCredential);
      this.sessionId = session.sessionId;
      this.state = 'CONNECTED';
      return this.status('REALTIME_SESSION_CONNECTED');
    } catch (error) {
      this.state = 'FAILED';
      return this.status(`REALTIME_CONNECT_FAILED:${error instanceof Error ? error.message : 'UNKNOWN_ERROR'}`);
    }
  }

  async interrupt(): Promise<RealtimeVoiceStatus>{
    if (!this.adapter || !this.sessionId) {
      this.state = 'BLOCKED';
      return this.status('NO_ACTIVE_REALTIME_SESSION');
    }
    try {
      await this.adapter.interrupt();
      this.state = 'INTERRUPTED';
      return this.status('REALTIME_INTERRUPTED');
    } catch (error) {
      this.state = 'FAILED';
      return this.status(`REALTIME_INTERRUPT_FAILED:${error instanceof Error ? error.message : 'UNKNOWN_ERROR'}`);
    }
  }

  async disconnect(){
    if (this.adapter) await this.adapter.disconnect();
    this.sessionId = null;
    this.state = 'DISCONNECTED';
  }

  status(evidence = 'REALTIME_NOT_CONNECTED'): RealtimeVoiceStatus {
    const live = Boolean(this.adapter && this.sessionId && this.state !== 'FAILED');
    return {
      state: this.state,
      reality: live ? 'VERIFIED_REAL' : this.state === 'BLOCKED' ? 'BLOCKED' : 'NOT_VERIFIED',
      provider: this.adapter?.provider ?? 'NONE',
      transport: this.adapter?.transport ?? 'NONE',
      ephemeralCredentialRequired: true,
      longLivedKeyInClient: false,
      sessionId: this.sessionId,
      interruptionSupported: Boolean(this.adapter),
      streamingSupported: Boolean(this.adapter),
      evidence: [evidence],
    };
  }
}

export const novinRealtimeVoiceAgent = new NovinRealtimeVoiceAgent();
