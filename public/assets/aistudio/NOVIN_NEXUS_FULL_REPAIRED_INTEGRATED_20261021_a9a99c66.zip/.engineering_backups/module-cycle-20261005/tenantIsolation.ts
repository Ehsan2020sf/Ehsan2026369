/**
 * NOVIN MULTI-TENANT ISOLATION & PRIVACY ENGINE (P66)
 * Enforces strict tenant boundary constraints and audits datasets for cross-tenant data leaks.
 */

import type { CallRecord, TenantContext  } from './types.ts';

export interface TenantAuditReport {
  tenantId: string;
  totalCallsChecked: number;
  isolatedCallsCount: number;
  leakedCallsDetected: number;
  leakedCallIds: string[];
  isCompliant: boolean;
  timestamp: string;
}

/**
 * Filters and validates that all provided call records strictly belong to the specified tenant.
 */
export function enforceTenantIsolation(
  tenant: TenantContext,
  calls: CallRecord[]
): {
  scopedCalls: CallRecord[];
  auditReport: TenantAuditReport;
} {
  const scopedCalls: CallRecord[] = [];
  const leakedCallIds: string[] = [];

  for (const call of calls) {
    if (call.tenantId === tenant.tenantId) {
      scopedCalls.push(call);
    } else {
      leakedCallIds.push(call.callId);
    }
  }

  const isCompliant = leakedCallIds.length === 0;

  const auditReport: TenantAuditReport = {
    tenantId: tenant.tenantId,
    totalCallsChecked: calls.length,
    isolatedCallsCount: scopedCalls.length,
    leakedCallsDetected: leakedCallIds.length,
    leakedCallIds,
    isCompliant,
    timestamp: new Date().toISOString(),
  };

  return {
    scopedCalls,
    auditReport,
  };
}
