/**
 * NOVIN GA Realtime WebRTC adapter.
 * Browser/WebView only. Accepts short-lived ek_* credentials, never sk-* keys.
 */
import type { RealtimeVoiceAdapter } from './novinRealtimeVoiceAgent.ts';

export interface RealtimeWebRtcEvents {
  onConnected?: (sessionId: string | null) => void;
  onEvent?: (event: unknown) => void;
  onDisconnected?: () => void;
  onError?: (error: Error) => void;
}

export class NovinOpenAIRealtimeWebRtcAdapter implements RealtimeVoiceAdapter {
  readonly provider = 'OPENAI_REALTIME' as const;
  readonly transport = 'WEBRTC' as const;
  private pc: RTCPeerConnection | null = null;
  private dc: RTCDataChannel | null = null;
  private localStream: MediaStream | null = null;
  private audio: HTMLAudioElement | null = null;
  private sessionId: string | null = null;
  private events: RealtimeWebRtcEvents;

  constructor(events: RealtimeWebRtcEvents = {}) { this.events = events; }

  async connect(sessionCredential: string): Promise<{sessionId:string}> {
    if (!/^ek_[A-Za-z0-9_-]+$/.test(sessionCredential)) throw new Error('EPHEMERAL_REALTIME_CREDENTIAL_REQUIRED');
    if (!globalThis.RTCPeerConnection || !navigator.mediaDevices?.getUserMedia) throw new Error('WEBRTC_OR_MICROPHONE_UNAVAILABLE');

    this.pc = new RTCPeerConnection();
    this.audio = document.createElement('audio');
    this.audio.autoplay = true;
    this.pc.ontrack = (event) => {
      if (this.audio) this.audio.srcObject = event.streams[0] ?? null;
    };
    this.pc.onconnectionstatechange = () => {
      if (this.pc?.connectionState === 'failed' || this.pc?.connectionState === 'closed') this.events.onDisconnected?.();
    };

    this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    for (const track of this.localStream.getAudioTracks()) this.pc.addTrack(track, this.localStream);

    this.dc = this.pc.createDataChannel('oai-events');
    this.dc.onmessage = (event) => {
      try { this.events.onEvent?.(JSON.parse(event.data)); }
      catch { this.events.onEvent?.(event.data); }
    };

    const offer = await this.pc.createOffer();
    await this.pc.setLocalDescription(offer);
    const sdp = this.pc.localDescription?.sdp;
    if (!sdp) throw new Error('WEBRTC_LOCAL_SDP_MISSING');

    const response = await fetch('https://api.openai.com/v1/realtime/calls', {
      method: 'POST',
      body: sdp,
      headers: { Authorization: `Bearer ${sessionCredential}`, 'Content-Type': 'application/sdp' },
    });
    if (!response.ok) throw new Error(`REALTIME_SDP_HTTP_${response.status}`);
    const answerSdp = await response.text();
    if (!answerSdp.trim()) throw new Error('REALTIME_SDP_ANSWER_EMPTY');
    await this.pc.setRemoteDescription({ type: 'answer', sdp: answerSdp });

    const location = response.headers.get('Location');
    this.sessionId = location?.split('/').pop() || null;
    this.events.onConnected?.(this.sessionId);
    return { sessionId: this.sessionId || `rtc-${Date.now()}` };
  }

  async interrupt(): Promise<void> {
    if (!this.dc || this.dc.readyState !== 'open') throw new Error('REALTIME_DATA_CHANNEL_NOT_OPEN');
    this.dc.send(JSON.stringify({ type: 'response.cancel' }));
    this.dc.send(JSON.stringify({ type: 'output_audio_buffer.clear' }));
  }

  async sendText(text: string): Promise<void> {
    if (!text.trim() || !this.dc || this.dc.readyState !== 'open') throw new Error('REALTIME_DATA_CHANNEL_NOT_OPEN');
    this.dc.send(JSON.stringify({ type: 'conversation.item.create', item: { type: 'message', role: 'user', content: [{ type: 'input_text', text }] } }));
    this.dc.send(JSON.stringify({ type: 'response.create' }));
  }

  /** Send one multimodal user turn. The image stays in-memory as a data URL. */
  async sendMultimodalTurn(text: string, imageDataUrl: string): Promise<void> {
    if (!text.trim() || !this.dc || this.dc.readyState !== 'open') throw new Error('REALTIME_DATA_CHANNEL_NOT_OPEN');
    if (!/^data:image\/(?:jpeg|jpg|png|webp);base64,[A-Za-z0-9+/=]+$/i.test(imageDataUrl)) {
      throw new Error('REALTIME_IMAGE_DATA_URL_INVALID');
    }
    this.dc.send(JSON.stringify({
      type: 'conversation.item.create',
      item: {
        type: 'message',
        role: 'user',
        content: [
          { type: 'input_text', text },
          { type: 'input_image', image_url: imageDataUrl },
        ],
      },
    }));
    this.dc.send(JSON.stringify({ type: 'response.create' }));
  }

  async disconnect(): Promise<void> {
    this.dc?.close();
    this.localStream?.getTracks().forEach(track => track.stop());
    this.pc?.close();
    this.dc = null; this.localStream = null; this.pc = null; this.audio?.remove(); this.audio = null; this.sessionId = null;
    this.events.onDisconnected?.();
  }
}
