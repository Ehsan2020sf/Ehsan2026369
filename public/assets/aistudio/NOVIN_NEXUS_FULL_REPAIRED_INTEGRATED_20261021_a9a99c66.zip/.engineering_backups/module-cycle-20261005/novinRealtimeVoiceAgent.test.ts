import { novinRealtimeVoiceAgent } from './novinRealtimeVoiceAgent.ts';

const blocked = await novinRealtimeVoiceAgent.connect('sk-test-long-lived-key');
if (blocked.state !== 'BLOCKED' || blocked.reality !== 'BLOCKED') throw new Error('long-lived key was not blocked');

const missing = await novinRealtimeVoiceAgent.connect();
if (missing.state !== 'BLOCKED') throw new Error('missing credential was not blocked');

const before = novinRealtimeVoiceAgent.status();
if (before.reality !== 'BLOCKED') throw new Error('expected fail-closed realtime state');

console.log(`NOVIN_REALTIME_VOICE_AGENT_PASS state=${before.state} provider=${before.provider}`);
