import type { EnvironmentCommandResult,
  EnvironmentDefinition,
  LayoutMode,
 } from './contracts.ts';
import { environmentRegistry } from './environmentRegistry.ts';
import { environmentStack } from './environmentStack.ts';
import { worldRegistry } from '../world/worldRegistry.ts';
import { EconomicGovernor } from '../economy/economicGovernor.ts';
import { HumanSovereigntyGate } from '../governance/humanSovereigntyGate.ts';
import { RealityGate } from '../evidence/realityGate.ts';
import { resolveSurfaceCommand } from './surfaceCommandPort.ts';
import { brainCoordinator } from '../ai/brainCoordinator.ts';
import { workspaceController } from './workspaceController.ts';
import { resolveLivingWorldCommand } from './novinLivingWorldCommand.ts';
import { publishLivingWorldCommand } from './novinLivingWorldCommandBus.ts';
import { novinKernel } from '../kernel/novinKernel.ts';
import { novinEnvironmentKernel } from './novinEnvironmentKernel.ts';
import { runNovin60StageVerify } from '../kernel/novin60StageVerify.ts';
import { tryLocalIntelligence, recordSessionTurn } from '../intelligence/novinLocalIntelligence.ts';
import { executeInternetCommand } from '../intelligence/novinInternetCommandBridge.ts';
import { buildAgentsStatusReportFa, buildCoordinationReportFa, resolveAgentAutomationIntent } from '../intelligence/novinAgentAutomationBridge.ts';
import { featureCatalogReportFa, isFeatureCatalogIntent } from '../intelligence/novinFeatureCatalog.ts';
import { executeOwnerNotes } from '../intelligence/novinOwnerNotes.ts';

export class EnvironmentCommandEngine {
  public static async executeCommand(
    commandText: string,
    multimodalContext?: {
      sourceModality?: 'VOICE' | 'TEXT' | 'CAMERA' | 'FILE';
      attachedFile?: { name: string; type: string };
      imagePayload?: string;
    }
  ): Promise<EnvironmentCommandResult> {
    const raw = commandText.trim();
    const lower = raw.toLowerCase();
    const currentEnv = environmentRegistry.getActiveEnvironment();
    recordSessionTurn(raw, multimodalContext?.sourceModality);

    // In-runtime 60-stage verification (Source/Runtime only — never Device PASS)
    const isStage60 =
      /^(verify\s*60|stage\s*60|60\s*stage|تأیید\s*۶۰|تایید\s*۶۰|شصت\s*مرحله|۶۰\s*مرحله)$/i.test(raw) ||
      (lower.includes('verify') && lower.includes('60')) ||
      (raw.includes('۶۰') && (raw.includes('مرحله') || raw.includes('تأیید') || raw.includes('تایید')));
    if (isStage60) {
      try {
        const report = await runNovin60StageVerify();
        const evidence = RealityGate.classify(
          'Novin60StageVerify',
          report.overall === 'PASS' ? 'OBSERVED' : 'UNKNOWN',
          report.overall === 'PASS' ? 1 : 0.4,
          `pass=${report.pass} fail=${report.fail}`,
        );
        return {
          action: 'BRAIN_THINK',
          success: report.fail === 0,
          messageFa: report.messageFa,
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      } catch (e) {
        const evidence = RealityGate.classify(
          'Novin60StageVerify',
          'UNKNOWN',
          0,
          e instanceof Error ? e.message : String(e),
        );
        return {
          action: 'BRAIN_THINK',
          success: false,
          messageFa: `تأیید ۶۰مرحله‌ای ناموفق: ${e instanceof Error ? e.message : String(e)}`,
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      }
    }

    // Engineering diagnostics: doctor / health / status / self-test (source-level, no Device PASS claim)
    const isDoctor =
      /^(doctor|novin\s*doctor|دکتر|وضعیت\s*سیستم|وضعیت\s*محیط|health|self[-\s]?test|خودآزمایی|تشخیص)$/i.test(raw) ||
      (lower.includes('وضعیت') && (lower.includes('سیستم') || lower.includes('محیط') || lower.includes('هسته')));
    if (isDoctor) {
      try {
        const health = novinKernel.health();
        const env = novinEnvironmentKernel.snapshot();
        const lines = [
          `هسته: ${health.overall} | چرخه محیط: ${env.state}`,
          ...health.items.map((i) => `• ${i.id}: ${i.status} — ${i.evidence}`),
          health.capabilitiesFa ? `\n${health.capabilitiesFa}` : '',
          buildCoordinationReportFa().split('\n')[0] || '',
          'توجه: این گزارش سطح Source/Kernel است؛ Build و Device جداگانه تأیید می‌شوند.',
        ].filter(Boolean);
        const evidence = RealityGate.classify(
          'NovinKernelHealth',
          'OBSERVED',
          1,
          `kernel overall=${health.overall} env=${env.state}`,
        );
        return {
          action: 'BRAIN_THINK',
          success: true,
          messageFa: lines.join('\n'),
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      } catch (e) {
        const evidence = RealityGate.classify(
          'NovinKernelHealth',
          'UNKNOWN',
          0,
          e instanceof Error ? e.message : String(e),
        );
        return {
          action: 'BRAIN_THINK',
          success: false,
          messageFa: `تشخیص هسته ناموفق بود: ${e instanceof Error ? e.message : String(e)}`,
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      }
    }

    // Offline-first local intelligence (no network)
    try {
      const local = tryLocalIntelligence(raw);
      if (local.handled) {
        const evidence = RealityGate.classify(
          'NovinLocalIntelligence',
          'OBSERVED',
          1,
          `intent=${local.intent}`,
        );
        return {
          action: 'BRAIN_THINK',
          success: true,
          messageFa: local.messageFa,
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      }
    } catch (e) {
      // non-fatal: continue pipeline
      console.warn('[NOVIN] local intelligence error', e);
    }

    // Owner notes (localStorage / memory)
    try {
      const notes = executeOwnerNotes(raw);
      if (notes.handled) {
        const evidence = RealityGate.classify('NovinOwnerNotes', 'OBSERVED', 1, 'notes');
        return {
          action: 'BRAIN_THINK',
          success: true,
          messageFa: notes.messageFa,
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      }
    } catch (e) {
      console.warn('[NOVIN] owner notes error', e);
    }

    // Full feature catalog
    if (isFeatureCatalogIntent(raw)) {
      const evidence = RealityGate.classify('NovinFeatureCatalog', 'OBSERVED', 1, 'catalog');
      return {
        action: 'BRAIN_THINK',
        success: true,
        messageFa: featureCatalogReportFa(),
        activeEnv: currentEnv,
        layout: currentEnv.layoutMode,
        evidenceId: evidence.evidenceId,
      };
    }

    // Internet search / open URL (device browser — needs phone connectivity)
    try {
      const net = await executeInternetCommand(raw);
      if (net.handled) {
        const evidence = RealityGate.classify(
          'NovinInternetBridge',
          net.success ? 'OBSERVED' : 'UNKNOWN',
          net.success ? 0.9 : 0.2,
          net.evidence,
        );
        return {
          action: 'BRAIN_THINK',
          success: net.success,
          messageFa: net.messageFa,
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      }
    } catch (e) {
      console.warn('[NOVIN] internet bridge error', e);
    }

    // Agents + automation status
    const agentIntent = resolveAgentAutomationIntent(raw);
    if (agentIntent !== 'NONE') {
      const messageFa =
        agentIntent === 'COORDINATION'
          ? buildCoordinationReportFa()
          : buildAgentsStatusReportFa();
      const evidence = RealityGate.classify('NovinAgentAutomation', 'OBSERVED', 1, agentIntent);
      return {
        action: 'BRAIN_THINK',
        success: true,
        messageFa,
        activeEnv: currentEnv,
        layout: currentEnv.layoutMode,
        evidenceId: evidence.evidenceId,
      };
    }

    // Living World control is a deterministic local fast-path. It never claims a physical-world effect.
    const livingWorldCommand = resolveLivingWorldCommand(raw);
    if (livingWorldCommand.kind !== 'NONE' &&
        !lower.includes('کنار') && !lower.includes('مقایسه') && !lower.includes('split') &&
        !lower.includes('بزرگ') && !lower.includes('تمام صفحه') && !lower.includes('expand') && !lower.includes('maximize')) {
      publishLivingWorldCommand({ commandFa: raw, command: livingWorldCommand, source: multimodalContext?.sourceModality === 'VOICE' ? 'VOICE' : 'COMMAND_CENTER', issuedAt: new Date().toISOString() });
      const evidence = RealityGate.classify('LivingWorldRuntime', 'SIMULATED', 1.0, `Living World command routed to runtime: ${livingWorldCommand.kind}`);
      return { action: 'BRAIN_THINK', success: true, messageFa: 'فرمان جهان زنده به Runtime سه‌بعدی تحویل شد؛ اثر فقط در جهان شبیه‌سازی‌شده NOVIN اعمال می‌شود.', activeEnv: currentEnv, layout: currentEnv.layoutMode, evidenceId: evidence.evidenceId };
    }

    // Check economic governor: can we use zero-cost deterministic fast-path?
    if (EconomicGovernor.canExecuteDeterministic(raw)) {
      EconomicGovernor.recordDeterministicCall();
    } else {
      const economic = EconomicGovernor.preflightModelCall(120);
      if (economic.admission !== 'ALLOW') {
        return {
          action: 'EXECUTE_GATE',
          success: false,
          messageFa: `اجرای درخواست به‌دلیل کنترل اقتصادی متوقف شد: ${economic.reason}`,
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: RealityGate.classify('EconomicGovernor', 'OBSERVED', 1, economic.reason).evidenceId,
        };
      }
    }

    // 0. Workspace Controller — Avatar-first deterministic navigation.
    // This runs before domain-specific heuristics so every registered room has one canonical owner.
    const workspaceTarget = workspaceController.resolve(raw);
    const creativeIntent = lower.includes('عکس تبلیغاتی') || lower.includes('بنر تبلیغاتی') || lower.includes('محتوا بساز') || lower.includes('تبلیغاتی بساز');
    if (workspaceTarget && !lower.includes('کنار') && !lower.includes('مقایسه') && !lower.includes('split') && !creativeIntent) {
      if (lower.includes('ببند') || lower.includes('بسته') || lower.includes('کوچیک')) {
        const closed = workspaceController.close();
        return { action: 'CLOSE_ENVIRONMENT', success: closed.success, messageFa: closed.messageFa, activeEnv: closed.activeEnv, layout: closed.activeEnv.layoutMode, evidenceId: closed.evidenceId };
      }
      const opened = workspaceController.open(workspaceTarget);
      return { action: 'OPEN_ENVIRONMENT', success: opened.success, messageFa: opened.messageFa, activeEnv: opened.activeEnv, layout: opened.activeEnv.layoutMode, evidenceId: opened.evidenceId };
    }

    // 0. Smart City / Living Surface — instant open (پنل کسب‌کار، فروشگاه، باغ، محیط کار، …)
    // Skip for pure undo/back so stack navigation stays deterministic.
    if (!lower.includes('برگرد') && !lower.includes('قبل') && !lower.includes('undo') && lower !== 'back' &&
        !lower.includes('کنار') && !lower.includes('مقایسه کن') && !lower.includes('دو محیط') && !lower.includes('هر دو') && !lower.includes('split') &&
        !lower.includes('عکس تبلیغاتی') && !lower.includes('بنر تبلیغاتی') && !lower.includes('محتوا بساز')) {
      const surface = resolveSurfaceCommand({
        rawCommand: raw,
        modality: multimodalContext?.sourceModality,
      });
      if (surface?.ok && surface.result.matched) {
        const active = environmentRegistry.getActiveEnvironment();
        const evidence = RealityGate.classify(
          'LivingSurface',
          'SIMULATED',
          surface.result.confidence,
          surface.result.messageFa
        );
        return {
          action: 'OPEN_ENVIRONMENT',
          success: true,
          messageFa: surface.result.messageFa,
          activeEnv: active,
          layout: active.layoutMode,
          evidenceId: evidence.evidenceId,
        };
      }
    }

    // Record state in stack before transition (unless it's an undo/restore command)
    if (!lower.includes('برگرد') && !lower.includes('قبل') && !lower.includes('undo')) {
      environmentStack.recordState(currentEnv, raw);
    }

    // 1. Return / Back / Step Back ("برگرد", "سه مرحله قبل", "بازگشت")
    if (lower.includes('برگرد') || lower.includes('بازگشت') || lower === 'back' || lower === 'return') {
      const restored = environmentStack.popPrevious();
      const active = restored || currentEnv;
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('EnvironmentStack', active.realityLayer, 1.0, 'Restored previous environment snapshot');

      return {
        action: 'RESTORE_PREVIOUS_ENVIRONMENT',
        success: true,
        messageFa: `محیط قبلی («${active.titleFa}») با حفظ کامل وضعیت و زمینه بازیابی شد.`,
        activeEnv: active,
        layout: active.layoutMode,
        evidenceId: evidence.evidenceId,
      };
    }

    // Step back count ("۳ مرحله قبل", "سه مرحله قبل", "دو مرحله قبل")
    if (lower.includes('مرحله قبل') || lower.includes('قدم قبل')) {
      let count = 1;
      if (lower.includes('دو') || lower.includes('۲')) count = 2;
      if (lower.includes('سه') || lower.includes('۳')) count = 3;
      if (lower.includes('چهار') || lower.includes('۴')) count = 4;
      if (lower.includes('پنج') || lower.includes('۵')) count = 5;

      const restored = environmentStack.stepBack(count);
      const active = restored || currentEnv;
      const evidence = RealityGate.classify('EnvironmentStack', active.realityLayer, 1.0, `Step back ${count} levels in history`);

      return {
        action: 'UNDO_STEP',
        success: true,
        messageFa: `سیستم ${count} مرحله به عقب بازگشت و محیط «${active.titleFa}» را احیا نمود.`,
        activeEnv: active,
        layout: active.layoutMode,
        evidenceId: evidence.evidenceId,
      };
    }

    // 2. Real Execution Request with Human Sovereignty Gate ("واقعی اجراش کن", "انجام بده به صورت واقعی")
    if (lower.includes('واقعی اجرا') || lower.includes('اجرای واقعی') || lower.includes('تایید و اجرا')) {
      const risk = HumanSovereigntyGate.classifyAction('EXECUTE_ORDER_PAYMENT');
      const needsApproval = risk !== 'LOW';

      if (needsApproval) {
        HumanSovereigntyGate.requestApproval(
          'EXECUTE_OPERATION',
          'درخواست اجرای دستور عملیاتی در دنیای واقعی با اثر اقتصادی یا فیزیکی',
          risk,
          { currentEnv: currentEnv.envId, command: raw }
        );

        return {
          action: 'EXECUTE_GATE',
          success: true,
          messageFa: 'حاکمیت انسانی: این اقدام دارای ریسک است و نیازمند تایید صریح در پنجره اگیس می‌باشد.',
          activeEnv: currentEnv,
          layout: currentEnv.layoutMode,
          evidenceId: RealityGate.classify('HumanSovereigntyGate', 'OBSERVED', 1.0, 'Local approval request created; no real-world action executed').evidenceId,
          needsApproval: true,
        };
      }
    }

    // 3. Split Environment / Multi-World View ("فروشگاه را کنار باغ بگذار", "هر دو را مقایسه کن", "کنار هم بگذار")
    if (
      lower.includes('کنار') ||
      lower.includes('مقایسه کن') ||
      lower.includes('دو محیط') ||
      lower.includes('هر دو') ||
      lower.includes('split')
    ) {
      const storeEnv = environmentRegistry.getEnvironment('ENV_STORE')!;
      const gardenEnv = environmentRegistry.getEnvironment('ENV_GARDEN')!;

      environmentRegistry.setActiveEnvironment('ENV_STORE');
      environmentRegistry.setSecondaryEnvironment('ENV_GARDEN');
      storeEnv.layoutMode = 'SPLIT';

      const evidence = RealityGate.classify('MultiWorldComposer', 'OBSERVED', 0.98, 'Split multi-world layout initialized');

      return {
        action: 'MULTI_WORLD_VIEW',
        success: true,
        messageFa: 'نمای همزمان چندجهان (دوقلوی کالبدی فروشگاه + شبکه حسگرهای باغ پسته) در دو پنل تطبیقی فعال شد.',
        activeEnv: storeEnv,
        secondaryEnv: gardenEnv,
        layout: 'SPLIT',
        evidenceId: evidence.evidenceId,
      };
    }

    // 4. Expand / Maximize ("همین را بزرگ کن", "بزرگش کن", "تمام صفحه")
    if (lower.includes('بزرگ') || lower.includes('تمام صفحه') || lower.includes('expand') || lower.includes('maximize')) {
      currentEnv.layoutMode = 'EXPANDED';
      currentEnv.panels.forEach((p) => (p.isExpanded = true));
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('LayoutComposer', currentEnv.realityLayer, 1.0, 'Environment expanded to full workspace');

      return {
        action: 'EXPAND_ENVIRONMENT',
        success: true,
        messageFa: `محیط جاری («${currentEnv.titleFa}») به حالت گسترده و تمام‌عرض ارتقا یافت.`,
        activeEnv: currentEnv,
        layout: 'EXPANDED',
        evidenceId: evidence.evidenceId,
      };
    }

    // 5. Close / Minimize / Back to Single ("ببندش", "ببند", "کوچیکش کن", "ساده کن", "close")
    if (lower.includes('ببند') || lower.includes('کوچیک') || lower.includes('ساده') || lower.includes('close')) {
      if (environmentRegistry.getSecondaryEnvironment()) {
        environmentRegistry.setSecondaryEnvironment(null);
        currentEnv.layoutMode = 'SINGLE';
        return {
          action: 'CLOSE_ENVIRONMENT',
          success: true,
          messageFa: 'پنل ثانویه بسته شد و محیط اصلی متمرکز گردید.',
          activeEnv: currentEnv,
          layout: 'SINGLE',
          evidenceId: RealityGate.classify('LayoutComposer', currentEnv.realityLayer, 1.0, 'Secondary panel closed').evidenceId,
        };
      } else {
        currentEnv.layoutMode = 'SINGLE';
        // collapse non-essential panels for simple mode
        currentEnv.panels.forEach((p, idx) => (p.isExpanded = idx === 0));
        return {
          action: 'SIMPLE_MODE',
          success: true,
          messageFa: 'محیط ساده‌سازی شد و تنها اطلاعات حیاتی در کانون دید قرار گرفت.',
          activeEnv: currentEnv,
          layout: 'SINGLE',
          evidenceId: RealityGate.classify('LayoutComposer', currentEnv.realityLayer, 1.0, 'Simplified layout mode').evidenceId,
        };
      }
    }

    // 6. CCTV Room: a separate workspace, never mixed into the main NOVIN surface.
    if (/اتاق دوربین|پنل دوربین|cctv|اتاق cctv|cctv room/i.test(raw)) {
      const cctv = environmentRegistry.setActiveEnvironment('ENV_CCTV');
      cctv.layoutMode = 'SINGLE';
      cctv.isSuspended = false;
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('CCTVWorkspace', 'OBSERVED', 1.0, 'CCTV workspace opened; live camera evidence is not implied by workspace availability');
      return {
        action: 'OPEN_ENVIRONMENT', success: true,
        messageFa: 'اتاق مستقل دوربین مداربسته باز شد. فید واقعی فقط پس از اتصال و تأیید دوربین نمایش داده می‌شود.',
        activeEnv: cctv, layout: 'SINGLE', evidenceId: evidence.evidenceId,
      };
    }

    // 6. Focus Cameras / Telemetry ("فقط دوربینها را نشان بده", "دوربین", "فقط سنسورها")
    if (lower.includes('فقط دوربین') || lower.includes('دوربینها را نشان') || lower.includes('دوربین‌ها')) {
      const storeEnv = environmentRegistry.setActiveEnvironment('ENV_STORE');
      worldRegistry.setActiveWorld('WORLD-STORE-01');
      storeEnv.layoutMode = 'FOCUS';
      // expand camera panel only
      storeEnv.panels.forEach((p) => {
        p.isExpanded = p.componentType === 'CAMERA_FEED' || p.componentType === 'STORE_MAP';
      });

      return {
        action: 'FILTER_CAMERAS',
        success: true,
        messageFa: 'محیط بر روی فیدهای تصویری و دوربین‌های تله‌متری متمرکز شد.',
        activeEnv: storeEnv,
        layout: 'FOCUS',
        evidenceId: RealityGate.classify('CameraVisionFabric', 'OBSERVED', 0.99, 'Focused on optical camera telemetry').evidenceId,
      };
    }

    // 7. Garden World / Environment ("برو باغ من", "برو باغ", "باغ من", "کشاورزی")
    if (lower.includes('باغ') || lower.includes('مزرعه') || lower.includes('garden')) {
      worldRegistry.setActiveWorld('WORLD-GARDEN-01');
      const gardenEnv = environmentRegistry.setActiveEnvironment('ENV_GARDEN');
      gardenEnv.layoutMode = 'SINGLE';
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('WorldRegistry', 'OBSERVED', 0.97, 'Switched to Precision Agri World');

      return {
        action: 'SWITCH_WORLD',
        success: true,
        messageFa: 'محیط پیشین به حالت تعلیق درآمد (Suspended) و محیط اختصاصی «باغ و مزرعه هوشمند» گشوده شد.',
        activeEnv: gardenEnv,
        layout: 'SINGLE',
        evidenceId: evidence.evidenceId,
      };
    }

    // 8. Store World / Environment ("فروشگاه", "دوقلوی فروشگاه", "store")
    if (lower.includes('فروشگاه') || lower.includes('مغازه') || lower.includes('store')) {
      worldRegistry.setActiveWorld('WORLD-STORE-01');
      const storeEnv = environmentRegistry.setActiveEnvironment('ENV_STORE');
      storeEnv.layoutMode = 'SINGLE';
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('WorldRegistry', 'OBSERVED', 0.98, 'Switched to Business Store Twin');

      return {
        action: 'SWITCH_WORLD',
        success: true,
        messageFa: 'دوقلوی فیزیکی و هوشمند فروشگاه مرکزی فعال گردید.',
        activeEnv: storeEnv,
        layout: 'SINGLE',
        evidenceId: evidence.evidenceId,
      };
    }

    // 9. Sales Intelligence Environment ("فروش امروز را بررسی کن", "فروش امروز", "فروش")
    if (lower.includes('فروش') || lower.includes('درآمد') || lower.includes('sales')) {
      worldRegistry.setActiveWorld('WORLD-MANAGEMENT');
      const salesEnv = environmentRegistry.setActiveEnvironment('ENV_SALES');
      salesEnv.layoutMode = 'SINGLE';
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('SalesIntelligence', 'OBSERVED', 0.98, 'Sales intelligence software surface opened; live financial retrieval is not asserted');

      return {
        action: 'OPEN_ENVIRONMENT',
        success: true,
        messageFa: 'محیط هوش فروش و تحلیل فروش باز شد؛ داده زنده تراکنش‌ها بدون اتصال واقعی ادعا نمی‌شود.',
        activeEnv: salesEnv,
        layout: 'SINGLE',
        evidenceId: evidence.evidenceId,
      };
    }

    // 10. Creative Studio Environment ("عکس تبلیغاتی بساز", "تبلیغ بساز", "ویدئو هم بساز", "موسیقی", "استودیو")
    if (
      lower.includes('تبلیغ') ||
      lower.includes('ویدئو') ||
      lower.includes('موسیقی') ||
      lower.includes('پوستر') ||
      lower.includes('عکس') ||
      lower.includes('creative')
    ) {
      worldRegistry.setActiveWorld('WORLD-CREATIVE');
      const creativeEnv = environmentRegistry.setActiveEnvironment('ENV_CREATIVE');
      creativeEnv.layoutMode = 'SINGLE';
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('CreativeFabric', 'GENERATED', 0.95, 'Creative Studio assets synthesized');

      return {
        action: 'CREATIVE_STUDIO',
        success: true,
        messageFa: '[GENERATED] استودیوی چندوجهی خلاق آماده طراحی بنر، ویدئو و تنظیم موسیقی سازگار با برند است.',
        activeEnv: creativeEnv,
        layout: 'SINGLE',
        evidenceId: evidence.evidenceId,
      };
    }

    // 11. Product 3D Environment ("این محصول را سهبعدی کن", "سه بعدی", "محصولات", "محصول")
    if (lower.includes('سه بعدی') || lower.includes('سهبعدی') || lower.includes('محصول') || lower.includes('3d')) {
      worldRegistry.setActiveWorld('WORLD-PRODUCT-01');
      const prodEnv = environmentRegistry.setActiveEnvironment('ENV_PRODUCT_3D');
      prodEnv.layoutMode = 'SINGLE';
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('Product3DFabric', 'GENERATED', 0.0, 'Product 3D environment is a configured software surface; source/CAD evidence not loaded');

      return {
        action: 'OPEN_ENVIRONMENT',
        success: true,
        messageFa: 'دوقلوی سه‌بعدی و هویت هندسی محصول (دوربین خورشیدی ۴K) در محیط آماده تعامل است.',
        activeEnv: prodEnv,
        layout: 'SINGLE',
        evidenceId: evidence.evidenceId,
      };
    }

    // 12. Simulation Environment ("این را شبیهسازی کن", "شبیهسازیاش کن", "اگر قیمت را", "شبیه سازی")
    if (lower.includes('شبیه') || lower.includes('اگر قیمت') || lower.includes('simulation') || lower.includes('what-if')) {
      worldRegistry.setActiveWorld('WORLD-SIMULATION');
      const simEnv = environmentRegistry.setActiveEnvironment('ENV_SIMULATION');
      simEnv.layoutMode = 'SINGLE';
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('WhatIfSimulationEngine', 'SIMULATED', 0.89, 'Simulated counterfactual demand shock scenario');

      return {
        action: 'SIMULATION_MODE',
        success: true,
        messageFa: '[SIMULATED] آزمایشگاه سناریوهای شرطی فعال شد. نتایج تماماً تحلیلی و فاقد اثر در سیستم‌های واقعی است.',
        activeEnv: simEnv,
        layout: 'SINGLE',
        evidenceId: evidence.evidenceId,
      };
    }

    // 13. Management Environment ("پنل مدیریت را نشان بده", "پنل مدیریت", "مدیریت")
    if (lower.includes('مدیریت') || lower.includes('management') || lower.includes('میز کار')) {
      worldRegistry.setActiveWorld('WORLD-MANAGEMENT');
      const mgmtEnv = environmentRegistry.setActiveEnvironment('ENV_MANAGEMENT');
      mgmtEnv.layoutMode = 'SINGLE';
      environmentRegistry.setSecondaryEnvironment(null);
      const evidence = RealityGate.classify('ExecutiveManagement', 'OBSERVED', 0.98, 'Management software surface opened');

      return {
        action: 'OPEN_ENVIRONMENT',
        success: true,
        messageFa: 'پنل مدیریت جامع و نظارت عالی باز شد.',
        activeEnv: mgmtEnv,
        layout: 'SINGLE',
        evidenceId: evidence.evidenceId,
      };
    }

    // Governed Brain fallback: unknown commands must not be falsely reported as
    // executed. Route them through the real Brain Coordinator and expose the
    // resulting epistemic/reality state to the UI. External side effects remain
    // blocked unless an explicit governed execution path exists.
    try {
      // Android standalone/WebView must remain responsive without a backend or model API.
      // Local reasoning is the authoritative offline fallback. Remote model enrichment is
      // intentionally not required for basic command/response functionality.
      const thought = brainCoordinator.thinkLocal(raw);
      const reality = thought.reality === 'VERIFIED_REAL' ? 'VERIFIED_REAL'
        : thought.reality === 'OBSERVED' ? 'OBSERVED'
        : thought.reality === 'GENERATED' ? 'GENERATED'
        : 'SIMULATED';
      const evidence = RealityGate.classify(
        'BrainCoordinator',
        reality,
        thought.confidence,
        `Governed brain response for command: ${raw}`
      );
      const safety = thought.safety === 'HUMAN_REVIEW_REQUIRED' ? 'نیازمند بررسی مالک'
        : thought.safety === 'VERIFY_BEFORE_ACTION' ? 'نیازمند راستی‌آزمایی'
        : 'اطلاعاتی';
      return {
        action: 'BRAIN_THINK',
        success: true,
        messageFa: `[${reality}] ${thought.conclusion.slice(0, 900)}
وضعیت تصمیم: ${safety}`,
        activeEnv: currentEnv,
        layout: currentEnv.layoutMode,
        evidenceId: evidence.evidenceId,
      };
    } catch (error) {
      const evidence = RealityGate.classify(
        'BrainCoordinator',
        'UNKNOWN',
        0,
        `Brain execution failed safely: ${error instanceof Error ? error.message : String(error)}`
      );
      return {
        action: 'BRAIN_THINK',
        success: false,
        messageFa: 'مغز NOVIN در این فرمان پاسخ معتبر تولید نکرد؛ هیچ اجرای بیرونی انجام نشد.',
        activeEnv: currentEnv,
        layout: currentEnv.layoutMode,
        evidenceId: evidence.evidenceId,
      };
    }
  }
}
