import { NovinOpenAIRealtimeWebRtcAdapter } from './novinOpenAIRealtimeWebRtcAdapter.ts';

const adapter = new NovinOpenAIRealtimeWebRtcAdapter();
if (adapter.provider !== 'OPENAI_REALTIME' || adapter.transport !== 'WEBRTC') throw new Error('adapter contract failed');
try { await adapter.connect('sk-test-long-lived-key'); throw new Error('long-lived key was accepted'); }
catch (e) { if (!(e instanceof Error) || e.message !== 'EPHEMERAL_REALTIME_CREDENTIAL_REQUIRED') throw e; }
console.log('NOVIN_OPENAI_REALTIME_WEBRTC_ADAPTER_PASS credential_gate=PASS transport=WEBRTC');
