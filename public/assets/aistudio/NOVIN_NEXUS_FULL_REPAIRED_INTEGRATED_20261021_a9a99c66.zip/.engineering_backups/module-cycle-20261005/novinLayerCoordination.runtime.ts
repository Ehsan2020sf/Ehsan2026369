/**
 * NOVIN Layer Coordination — single readout of major layers for Owner/Doctor.
 * Does not execute missions; coordinates status language across Kernel, Agents, Automation, Runtime.
 */
import { novinKernel } from '../kernel/novinKernel.ts';
import { novinEnvironmentKernel } from '../environment/novinEnvironmentKernel.ts';
import { novinCapabilityRegistry } from '../kernel/novinCapabilityRegistry.ts';
import { agentRegistry } from '../agent/agentRegistry.ts';
import { admitAutomationJob } from '../automation/automationControlPlane.ts';

export interface LayerStatus {
  id: string;
  status: string;
  evidence: string;
}

export function collectLayerCoordination(): { layers: LayerStatus[]; messageFa: string } {
  const health = novinKernel.health();
  const env = novinEnvironmentKernel.snapshot();
  const agents = agentRegistry.all();
  const ready = agentRegistry.countReady();
  const caps = novinCapabilityRegistry.summary();
  const auto = admitAutomationJob({
    goal: 'coordination-probe',
    risk: 'LOW',
    approved: true,
    duplicateActive: false,
    evalGateHealthy: true,
  });

  const layers: LayerStatus[] = [
    { id: 'KERNEL', status: String(health.overall), evidence: `items=${health.items.length}` },
    { id: 'ENVIRONMENT', status: String(env.state), evidence: 'lifecycle' },
    { id: 'CAPABILITIES', status: `avail=${caps.available}`, evidence: `deg=${caps.degraded} unk=${caps.unknown}` },
    { id: 'AGENTS', status: `${ready}/${agents.length} READY`, evidence: agents.map((a) => a.agentId).join(',') },
    { id: 'AUTOMATION', status: auto.decision, evidence: auto.reason },
    { id: 'GOVERNANCE', status: health.items.find((i) => i.id === 'GOVERNANCE')?.status ?? 'UNKNOWN', evidence: 'HumanSovereignty' },
    { id: 'REALITY', status: health.items.find((i) => i.id === 'REALITY_GATE')?.status ?? 'UNKNOWN', evidence: 'RealityGate' },
    { id: 'BRAIN', status: health.items.find((i) => i.id === 'BRAIN_LOCAL')?.status ?? 'UNKNOWN', evidence: 'thinkLocal' },
  ];

  const messageFa = [
    'هماهنگی لایه‌های نوین:',
    ...layers.map((l) => `• ${l.id}: ${l.status} — ${l.evidence}`),
    '',
    `اجنت‌ها: ${ready} آماده از ${agents.length}`,
    'مسیر canonical: Owner → Governance → Kernel → Agents/Tools → Execution → Evidence',
    'لایه‌ها هم‌زبان شده‌اند؛ اجنت‌ها READY هستند و فقط با مأموریت+Governance اجرا می‌شوند.',
  ].join('\n');

  return { layers, messageFa };
}
