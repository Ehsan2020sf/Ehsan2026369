import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { globalAPRRE } from './src/core/development/autonomousProblemResolutionEngine.ts';
import { novinCapabilityRealityCenter } from './src/core/nexus/novinCapabilityRealityCenter.ts';
import { smartCityFabric } from './src/core/city/smartCityFabric.ts';
import { cityBlueprintGenerator } from './src/core/city/cityBlueprintGenerator.ts';
import { globalRealExecutionFabric } from './src/core/development/realExecutionFabric.ts';
import { globalExecutionTargetSelector } from './src/core/development/executionTargetSelector.ts';
import { globalCapabilityIntelligence } from './src/core/development/capabilityIntelligence.ts';
import { globalToolGateway } from './src/core/development/toolGateway.ts';
import { globalDevEvidenceStore } from './src/core/development/devEvidenceStore.ts';
import { globalRuntimeBuildOrchestrator as globalBuildOrchestrator } from './src/core/development/buildOrchestrator.ts';
import { globalBuildRuntimeManager } from './src/core/development/buildRuntimeManager.ts';
import { globalBuildArtifactVerifier } from './src/core/development/buildArtifactVerifier.ts';
import { globalInstallRuntimeController } from './src/core/development/installRuntimeController.ts';
import { EngineeringSystem } from './server/engineering/engineeringSystem.ts';
import { resolveProviderCredential } from './src/core/security/providerCredentialBoundary.ts';
import { governedFetch, governedConfiguredFetch } from './src/core/security/runtime/governedFetch.ts';
import { assertConfiguredProviderEgress } from './src/core/security/runtime/networkEgressGovernor.ts';
import {
  creatorCloudIdentityContract,
  type CreatorDeviceBinding,
} from './src/core/security/creatorCloudIdentity.ts';
import {
  prepareMemoryForSync,
  compareMemoryRevision,
  type CloudMemoryRecord,
} from './src/core/security/creatorCloudMemoryFabric.ts';

dotenv.config();

const __filename = process.argv[1] || process.cwd();
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Allow large payloads for audio base64 uploads
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ limit: '60mb', extended: true }));

// Native Capacitor Android runs from an HTTPS WebView origin (commonly
// https://localhost). Creator APIs therefore need explicit CORS + credentials.
// Never use a wildcard origin with credentialed requests.
app.use((req, res, next) => {
  const origin = String(req.headers.origin || '');
  const configured = String(process.env.NOVIN_CORS_ORIGINS || '').split(',').map(v => v.trim()).filter(Boolean);
  const allowed = configured.length > 0
    ? configured.includes(origin)
    : origin === 'https://localhost' || origin === 'http://localhost' || origin === 'capacitor://localhost';
  if (origin && allowed) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(origin && allowed ? 204 : 403);
  next();
});

// Lazy initialize Gemini client
function getGeminiClient(): GoogleGenAI {
  const credential = resolveProviderCredential('gemini');
  const apiKey = credential.credential;
  if (!credential.configured || !apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is not set. Please configure it in Settings > Secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// System instruction for Sales Coaching AI
const SALES_COACHING_SYSTEM_PROMPT = `
You are an elite, world-class Sales Coaching Intelligence Engine (combining the best methodologies from Challenger Sale, MEDDPICC, Sandler Training, and Gap Selling).
Analyze the provided sales call recording or transcript thoroughly.

Your objectives:
1. Diarize the audio into Speaker A (The Salesperson/Account Executive) and Speaker B (The Prospect/Customer).
2. Assign accurate conversational segments with start/end timestamps (in seconds), exact spoken words, sentiment ('positive', 'neutral', 'negative'), engagement score (0-100), and categorical tags (e.g., "Discovery", "Pain Point", "Value Proposition", "Budget Objection", "Buying Signal", "Competitor Mention", "Closing & Next Steps").
3. Generate a dynamic Sentiment & Engagement Timeline with 8-15 temporal snapshot points spanning the entire call duration, tracking Speaker A engagement, Speaker B engagement, and overall net sentiment (-100 to +100), tagging major turning points and breakthroughs.
4. Generate the AI Coaching Card with:
   - EXACTLY 3 Things the Salesperson Did Well (Strengths): with direct spoken quote snippets, why it was effective, category, and timestamp.
   - EXACTLY 3 Missed Opportunities: with direct spoken quote snippets, why it fell short, timestamp, and a specific, battle-tested "whatToSayInstead" tactical script the rep should use next time.
   - 2 Actionable Roleplay Drill Recommendations.
   - A high-converting Follow-Up Email draft to send to the prospect.
   - 5-Dimension Competency Scores (0-100 each for Discovery, Objection Handling, Value Selling, Active Listening, Closing/Next Steps).
5. Calculate comprehensive metrics: overall score (0-100), grade ('A+' | 'A' | 'B+' | 'B' | 'C+' | 'C' | 'Needs Coaching'), talk-listen ratio (rep % vs prospect %), pacing words per minute (WPM), interruptions, question counts, pain points, competitor mentions, and next steps.
`;

const SALES_ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: 'Descriptive title of the sales call' },
    durationSeconds: { type: Type.NUMBER, description: 'Total duration in seconds' },
    participants: {
      type: Type.OBJECT,
      properties: {
        speakerA: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            role: { type: Type.STRING },
            name: { type: Type.STRING },
            talkTimeSeconds: { type: Type.NUMBER },
            talkPercentage: { type: Type.NUMBER },
          },
          required: ['id', 'role', 'name', 'talkTimeSeconds', 'talkPercentage'],
        },
        speakerB: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            role: { type: Type.STRING },
            name: { type: Type.STRING },
            company: { type: Type.STRING },
            talkTimeSeconds: { type: Type.NUMBER },
            talkPercentage: { type: Type.NUMBER },
          },
          required: ['id', 'role', 'name', 'talkTimeSeconds', 'talkPercentage'],
        },
      },
      required: ['speakerA', 'speakerB'],
    },
    metrics: {
      type: Type.OBJECT,
      properties: {
        overallScore: { type: Type.NUMBER, description: 'Overall sales performance score 0-100' },
        grade: { type: Type.STRING, description: 'Letter grade A+, A, B+, B, C+, C, Needs Coaching' },
        talkListenRatio: {
          type: Type.OBJECT,
          properties: {
            repPercentage: { type: Type.NUMBER },
            prospectPercentage: { type: Type.NUMBER },
          },
          required: ['repPercentage', 'prospectPercentage'],
        },
        pacingWPM: {
          type: Type.OBJECT,
          properties: {
            speakerA: { type: Type.NUMBER },
            speakerB: { type: Type.NUMBER },
          },
          required: ['speakerA', 'speakerB'],
        },
        interruptionCount: {
          type: Type.OBJECT,
          properties: {
            speakerA: { type: Type.NUMBER },
            speakerB: { type: Type.NUMBER },
          },
          required: ['speakerA', 'speakerB'],
        },
        questionCount: {
          type: Type.OBJECT,
          properties: {
            repQuestions: { type: Type.NUMBER },
            prospectQuestions: { type: Type.NUMBER },
            openEndedRatio: { type: Type.NUMBER },
          },
          required: ['repQuestions', 'prospectQuestions', 'openEndedRatio'],
        },
        longestMonologueSec: {
          type: Type.OBJECT,
          properties: {
            speakerA: { type: Type.NUMBER },
            speakerB: { type: Type.NUMBER },
          },
          required: ['speakerA', 'speakerB'],
        },
        customerSentimentTrend: {
          type: Type.STRING,
          description: 'Rapidly Rising, Steady Positive, Mixed / Volatile, Declining',
        },
      },
      required: [
        'overallScore',
        'grade',
        'talkListenRatio',
        'pacingWPM',
        'interruptionCount',
        'questionCount',
        'longestMonologueSec',
        'customerSentimentTrend',
      ],
    },
    summary: {
      type: Type.OBJECT,
      properties: {
        executiveSummary: { type: Type.STRING },
        dealStage: { type: Type.STRING },
        dealRiskScore: { type: Type.NUMBER },
        productDiscussed: { type: Type.STRING },
        customerPainPoints: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        competitorsMentioned: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        buyingSignalsDetected: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        agreedNextSteps: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              action: { type: Type.STRING },
              owner: { type: Type.STRING },
              dueDate: { type: Type.STRING },
            },
            required: ['action', 'owner'],
          },
        },
      },
      required: [
        'executiveSummary',
        'dealStage',
        'dealRiskScore',
        'productDiscussed',
        'customerPainPoints',
        'competitorsMentioned',
        'buyingSignalsDetected',
        'agreedNextSteps',
      ],
    },
    coachingCard: {
      type: Type.OBJECT,
      properties: {
        strengths: {
          type: Type.ARRAY,
          description: 'MUST contain EXACTLY 3 things the salesperson did well',
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              quoteSnippet: { type: Type.STRING },
              category: { type: Type.STRING },
              timestamp: { type: Type.NUMBER },
              timestampFormatted: { type: Type.STRING },
            },
            required: ['title', 'description', 'quoteSnippet', 'category'],
          },
        },
        missedOpportunities: {
          type: Type.ARRAY,
          description: 'MUST contain EXACTLY 3 missed opportunities',
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              quoteSnippet: { type: Type.STRING },
              whatToSayInstead: { type: Type.STRING, description: 'Actionable script for the rep' },
              category: { type: Type.STRING },
              timestamp: { type: Type.NUMBER },
              timestampFormatted: { type: Type.STRING },
            },
            required: ['title', 'description', 'quoteSnippet', 'whatToSayInstead', 'category'],
          },
        },
        drillRecommendations: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              scenario: { type: Type.STRING },
            },
            required: ['title', 'description', 'scenario'],
          },
        },
        followUpEmailDraft: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING },
            body: { type: Type.STRING },
          },
          required: ['subject', 'body'],
        },
        competencyScores: {
          type: Type.OBJECT,
          properties: {
            discovery: { type: Type.NUMBER },
            objectionHandling: { type: Type.NUMBER },
            valueSelling: { type: Type.NUMBER },
            activeListening: { type: Type.NUMBER },
            closingNextSteps: { type: Type.NUMBER },
          },
          required: ['discovery', 'objectionHandling', 'valueSelling', 'activeListening', 'closingNextSteps'],
        },
      },
      required: ['strengths', 'missedOpportunities', 'drillRecommendations', 'followUpEmailDraft', 'competencyScores'],
    },
    sentimentTimeline: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          time: { type: Type.NUMBER },
          timestampFormatted: { type: Type.STRING },
          speakerA_engagement: { type: Type.NUMBER },
          speakerB_engagement: { type: Type.NUMBER },
          overallSentiment: { type: Type.NUMBER },
          currentSpeaker: { type: Type.STRING },
          event: { type: Type.STRING },
          stage: { type: Type.STRING },
        },
        required: ['time', 'timestampFormatted', 'speakerA_engagement', 'speakerB_engagement', 'overallSentiment'],
      },
    },
    diarizedTranscript: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          speaker: { type: Type.STRING, description: 'Speaker A or Speaker B' },
          speakerLabel: { type: Type.STRING },
          startTime: { type: Type.NUMBER },
          endTime: { type: Type.NUMBER },
          text: { type: Type.STRING },
          sentiment: { type: Type.STRING, description: 'positive, neutral, negative' },
          engagementScore: { type: Type.NUMBER },
          tag: { type: Type.STRING },
          notes: { type: Type.STRING },
        },
        required: ['id', 'speaker', 'speakerLabel', 'startTime', 'endTime', 'text', 'sentiment', 'engagementScore'],
      },
    },
  },
  required: [
    'title',
    'durationSeconds',
    'participants',
    'metrics',
    'summary',
    'coachingCard',
    'sentimentTimeline',
    'diarizedTranscript',
  ],
};

// API Route: Health check
app.get('/api/health', (req, res) => {
  const creatorAuthConfigured = Boolean(CREATOR_SESSION_SECRET && CREATOR_ACCOUNT_MASTER_KEY);
  const smsConfigured = accountDeliveryReady('PHONE');
  const emailConfigured = accountDeliveryReady('EMAIL');
  const status = creatorAuthConfigured ? 'HEALTHY' : 'DEGRADED';
  res.status(status === 'HEALTHY' ? 200 : 503).json({
    status,
    service: 'NOVIN Intelligence Backend',
    creatorAuthConfigured,
    contactVerification: { phone: smsConfigured, email: emailConfigured },
    timestamp: new Date().toISOString(),
  });
});

// API Route: Production Readiness check
app.get('/api/readiness', (req, res) => {
  const creatorAuthConfigured = Boolean(CREATOR_SESSION_SECRET && CREATOR_ACCOUNT_MASTER_KEY);
  const contactVerificationConfigured = accountDeliveryReady('PHONE') || accountDeliveryReady('EMAIL');
  const ready = creatorAuthConfigured && contactVerificationConfigured;
  res.status(ready ? 200 : 503).json({
    status: ready ? 'READY' : 'NOT_READY',
    persistence: CREATOR_ACCOUNT_STORE ? 'CONFIGURED' : 'NOT_CONFIGURED',
    creatorAuth: creatorAuthConfigured ? 'CONFIGURED' : 'NOT_CONFIGURED',
    contactVerification: contactVerificationConfigured ? 'CONFIGURED' : 'NOT_CONFIGURED',
    timestamp: new Date().toISOString(),
  });
});

// API Route: Production Runtime details
app.get('/api/production/status', (req, res) => {
  res.json({
    productVersion: '1.74.0',
    coreVersion: 'NOVIN-P74-RELEASE',
    environment: process.env.NODE_ENV || 'development',
    status: 'UNVERIFIED',
    verification: 'ROUTE_REACHABILITY_ONLY',
    message: 'Production runtime details are exposed, but live external/runtime verification is not asserted by this endpoint.',
    timestamp: new Date().toISOString(),
  });
});

// API Route: Audio upload analysis
app.post('/api/analyze-audio', async (req, res) => {
  try {
    const { audioBase64, mimeType, fileName } = req.body;

    if (!audioBase64 || !mimeType) {
      return res.status(400).json({ error: 'Audio base64 data and mimeType are required' });
    }

    const ai = getGeminiClient();

    const audioPart = {
      inlineData: {
        mimeType: mimeType || 'audio/mp3',
        data: audioBase64,
      },
    };

    const promptText = `
Listen to this sales call audio recording (${fileName || 'sales_call.mp3'}).
Perform complete end-to-end sales intelligence analysis:
1. Diarize Speaker A (Salesperson) vs Speaker B (Prospect/Customer).
2. Generate verbatim transcript segments with start and end seconds timestamps, sentiment, engagement level, and coaching tags.
3. Generate the Sentiment & Engagement timeline graph points across the entire call duration with turning points.
4. Generate the AI Coaching Card with EXACTLY 3 things the salesperson did well (with quotes) and EXACTLY 3 missed opportunities (with quotes and actionable "whatToSayInstead" scripts).
5. Generate the executive summary, metrics, competency scores, roleplay drills, and follow-up email.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: {
        parts: [audioPart, { text: promptText }],
      },
      config: {
        systemInstruction: SALES_COACHING_SYSTEM_PROMPT,
        responseMimeType: 'application/json',
        responseSchema: SALES_ANALYSIS_SCHEMA,
      },
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error('No response received from Gemini model.');
    }

    const parsedData = JSON.parse(responseText);
    parsedData.id = 'call-' + Date.now();
    parsedData.uploadedAt = new Date().toISOString();
    parsedData.fileName = fileName || 'uploaded_sales_call.mp3';

    res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Error analyzing audio:', error);
    res.status(500).json({
      error: error?.message || 'Failed to analyze audio recording with Gemini AI',
    });
  }
});

// API Route: Analyze text or transcript
app.post('/api/analyze-text', async (req, res) => {
  try {
    const { transcriptText, callTitle } = req.body;

    if (!transcriptText || transcriptText.trim().length === 0) {
      return res.status(400).json({ error: 'Transcript text is required' });
    }

    const ai = getGeminiClient();

    const promptText = `
Analyze the following sales call transcript (Title: "${callTitle || 'Sales Call'}"):

--- BEGIN TRANSCRIPT ---
${transcriptText}
--- END TRANSCRIPT ---

Perform complete sales intelligence analysis:
1. Diarize into Speaker A (Salesperson) vs Speaker B (Prospect/Customer).
2. Assign accurate start/end timestamps in seconds across the duration.
3. Build the Sentiment Timeline with 8-15 points including key inflection events.
4. Create the AI Coaching Card with EXACTLY 3 things the salesperson did well (with quotes) and EXACTLY 3 missed opportunities (with quotes and "whatToSayInstead" scripts).
5. Generate comprehensive metrics, talk-listen ratio, competencies, drills, and follow-up email.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: promptText,
      config: {
        systemInstruction: SALES_COACHING_SYSTEM_PROMPT,
        responseMimeType: 'application/json',
        responseSchema: SALES_ANALYSIS_SCHEMA,
      },
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error('No response received from Gemini model.');
    }

    const parsedData = JSON.parse(responseText);
    parsedData.id = 'call-' + Date.now();
    parsedData.uploadedAt = new Date().toISOString();

    res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Error analyzing transcript:', error);
    res.status(500).json({
      error: error?.message || 'Failed to analyze transcript with Gemini AI',
    });
  }
});

// ============================================================================
// NOVIN SOFTWARE FACTORY — SELF-BUILD & REMOTE BUILD EXECUTOR API ENDPOINTS
// ============================================================================

const TARGET_GITHUB_REPO = process.env.GITHUB_REPO || 'Ehsan2020sf/Ehsan2026';
const TARGET_WORKFLOW_NAME = 'android-ci-cd-build.yml';

// Helper: Check if local JDK exists
function checkLocalJdkInstalled(): boolean {
  try {
    execSync('javac -version', { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

// NOVIN BUILD FABRIC: runtime inspection, governed planning, real execution, artifacts and install.
app.get('/api/build/runtime', (req, res) => {
  const projectRoot = typeof req.query.projectRoot === 'string' ? req.query.projectRoot : process.cwd();
  try { res.json({ success:true, runtime:globalBuildRuntimeManager.inspect(projectRoot) }); }
  catch (e:any) { res.status(500).json({success:false,status:'FAILED',error:e.message}); }
});

app.post('/api/build/plan', (req, res) => {
  const projectRoot = typeof req.body?.projectRoot === 'string' ? req.body.projectRoot : process.cwd();
  try { res.json({ success:true, plan:globalBuildOrchestrator.plan(projectRoot,{allowCI:req.body?.allowCI!==false,allowRemote:req.body?.allowRemote!==false}) }); }
  catch (e:any) { res.status(500).json({success:false,status:'FAILED',error:e.message}); }
});

app.post('/api/build/execute', async (req, res) => {
  const plan = req.body?.plan;
  if (!plan || typeof plan !== 'object') return res.status(400).json({success:false,status:'BLOCKED',error:'BUILD_PLAN_REQUIRED'});
  try { const run=await globalBuildOrchestrator.execute(plan, typeof req.body?.approvedByHuman==='string' ? req.body.approvedByHuman : undefined); res.json({success:run.status==='PASS',run}); }
  catch (e:any) { res.status(500).json({success:false,status:'FAILED',error:e.message}); }
});

app.get('/api/build/fabric/runs', (req, res) => res.json({success:true,runs:globalBuildOrchestrator.list()}));
app.get('/api/build/fabric/runs/:runId', (req, res) => { const run=globalBuildOrchestrator.get(req.params.runId); return run ? res.json({success:true,run}) : res.status(404).json({success:false,error:'RUN_NOT_FOUND'}); });

app.get('/api/build/fabric/artifacts', (req, res) => { const root=typeof req.query.projectRoot==='string'?req.query.projectRoot:process.cwd(); res.json({success:true,artifacts:globalBuildArtifactVerifier.discover(root)}); });

app.post('/api/build/install', async (req, res) => {
  const apk=typeof req.body?.apk==='string'?req.body.apk:'';
  if(!apk) return res.status(400).json({success:false,status:'BLOCKED',error:'APK_REQUIRED'});
  const result=await globalInstallRuntimeController.install(apk,typeof req.body?.approvedByHuman==='string'?req.body.approvedByHuman:undefined);
  res.status(result.status==='FAILED'?500:200).json({success:result.status==='PASS',result});
});

// 1. GET /api/build/status — Reality status of local and remote builders
app.get('/api/build/status', (req, res) => {
  const token = resolveProviderCredential('github').credential;
  const hasToken = Boolean(token && token.trim().length > 0);
  const hasLocalJdk = checkLocalJdkInstalled();
  const sdkRoot = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || '';
  const hasAndroidSdk = Boolean(sdkRoot && fs.existsSync(sdkRoot));

  // Inspect local artifacts folder
  let existingApk: any = null;
  const apkPath = path.join(process.cwd(), 'artifacts', 'novin-nexus-debug', 'novin-nexus-debug.apk');
  const shaPath = path.join(process.cwd(), 'artifacts', 'novin-nexus-debug', 'novin-nexus-debug.apk.sha256');

  if (fs.existsSync(apkPath)) {
    try {
      const stats = fs.statSync(apkPath);
      const fileBuffer = fs.readFileSync(apkPath);
      const computedSha = crypto.createHash('sha256').update(fileBuffer).digest('hex');
      let registeredSha = computedSha;
      if (fs.existsSync(shaPath)) {
        registeredSha = fs.readFileSync(shaPath, 'utf8').trim();
      }

      existingApk = {
        name: 'novin-nexus-debug.apk',
        filePath: 'artifacts/novin-nexus-debug/novin-nexus-debug.apk',
        sizeBytes: stats.size,
        sha256: computedSha,
        verified: computedSha === registeredSha && stats.size > 0,
      };
    } catch (e: any) {
      console.warn('Could not read existing APK file:', e.message);
    }
  }

  res.json({
    localBuilder: {
      available: hasLocalJdk && hasAndroidSdk,
      reason: hasLocalJdk && hasAndroidSdk
        ? 'JDK and Android SDK environment detected; Gradle execution still requires a successful runtime probe.'
        : `Local native compilation blocked: ${hasLocalJdk ? 'Android SDK missing' : 'JDK missing'}.`,
    },
    remoteBuilder: {
      available: hasToken,
      githubAuth: hasToken ? 'VERIFIED' : 'MISSING',
      repository: TARGET_GITHUB_REPO,
      workflow: TARGET_WORKFLOW_NAME,
      reason: hasToken
        ? 'GitHub Actions CI/CD pipeline authenticated and ready'
        : 'GITHUB_AUTH_REQUIRED: GitHub Personal Access Token is not configured in environment secrets.',
    },
    lastArtifact: existingApk,
  });
});

// 2. POST /api/build/dispatch — Dispatches real GitHub Actions workflow run
app.post('/api/build/dispatch', async (req, res) => {
  const token = resolveProviderCredential('github').credential;
  if (!token || token.trim().length === 0) {
    return res.status(401).json({
      success: false,
      status: 'BLOCKED',
      error: 'GITHUB_AUTH_REQUIRED',
      message: 'GitHub Personal Access Token (GITHUB_TOKEN) is not configured in environment secrets. Automatic remote dispatch is blocked.',
    });
  }

  const repo = req.body.repository || TARGET_GITHUB_REPO;
  const workflow = req.body.workflow || TARGET_WORKFLOW_NAME;
  const branch = req.body.branch || 'main';

  try {
    const dispatchUrl = `https://api.github.com/repos/${repo}/actions/workflows/${workflow}/dispatches`;
    const dispatchRes = await governedFetch(dispatchUrl, 'github', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'User-Agent': 'NOVIN-Software-Factory',
        'X-GitHub-Api-Version': '2022-11-28',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ref: branch }),
    });

    if (!dispatchRes.ok && dispatchRes.status !== 204) {
      const errBody = await dispatchRes.text();
      return res.status(dispatchRes.status).json({
        success: false,
        error: `GitHub API error (HTTP ${dispatchRes.status})`,
        message: errBody || 'Failed to dispatch workflow run.',
      });
    }

    // Bind the result to this dispatch window and branch. Never report an unrelated latest run as ours.
    const dispatchedAt = Date.now();
    const runsUrl = `https://api.github.com/repos/${repo}/actions/workflows/${workflow}/runs?branch=${encodeURIComponent(branch)}&per_page=10`;
    let runId: number | string | null = null;
    let htmlUrl = `https://github.com/${repo}/actions`;

    // GitHub may take several seconds to materialize the workflow run. Poll briefly instead of
    // guessing the latest run, while keeping the operation bounded and cheap.
    for (let attempt = 0; attempt < 6 && runId === null; attempt++) {
      if (attempt > 0) await new Promise((r) => setTimeout(r, 2500));
      const runsRes = await governedFetch(runsUrl, 'github', {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json',
          'User-Agent': 'NOVIN-Software-Factory',
          'X-GitHub-Api-Version': '2022-11-28',
        },
      });
      if (!runsRes.ok) continue;
      const runsData = await runsRes.json();
      const candidates = (runsData.workflow_runs || []).filter((run: any) => {
        const createdAt = Date.parse(run.created_at || '');
        return run.head_branch === branch && Number.isFinite(createdAt) && createdAt >= dispatchedAt - 5000;
      });
      candidates.sort((a: any, b: any) => Date.parse(b.created_at) - Date.parse(a.created_at));
      if (candidates[0]) {
        runId = candidates[0].id;
        htmlUrl = candidates[0].html_url;
      }
    }

    if (runId === null) {
      return res.status(202).json({
        success: false,
        status: 'BLOCKED',
        error: 'WORKFLOW_RUN_NOT_MATERIALIZED_YET',
        repository: repo,
        workflow,
        branch,
        actionsUrl: htmlUrl,
      });
    }

    if (runId === null) {
      return res.status(202).json({
        success: false,
        status: 'NOT_VERIFIED',
        runId: null,
        htmlUrl,
        message: 'Workflow dispatch accepted, but no matching GitHub Actions run has been bound to this request yet.',
      });
    }

    res.json({
      success: true,
      status: 'DISPATCHED',
      runId,
      htmlUrl,
      message: 'Workflow dispatched and bound to the matching GitHub Actions run.',
    });
  } catch (err: any) {
    console.error('Workflow dispatch error:', err);
    res.status(500).json({
      success: false,
      error: err.message || 'Failed to communicate with GitHub Actions API',
    });
  }
});

// 3. GET /api/build/runs/:runId — Polls live workflow run status
app.get('/api/build/runs/:runId', async (req, res) => {
  const token = resolveProviderCredential('github').credential;
  const repo = TARGET_GITHUB_REPO;
  const runId = req.params.runId;

  if (!token) {
    return res.status(401).json({
      success: false,
      status: 'BLOCKED',
      error: 'GITHUB_AUTH_REQUIRED',
    });
  }

  try {
    const runUrl = `https://api.github.com/repos/${repo}/actions/runs/${runId}`;
    const runRes = await governedFetch(runUrl, 'github', {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'User-Agent': 'NOVIN-Software-Factory',
        'X-GitHub-Api-Version': '2022-11-28',
      },
    });

    if (!runRes.ok) {
      return res.status(runRes.status).json({
        success: false,
        error: `GitHub run lookup returned HTTP ${runRes.status}`,
      });
    }

    const runData = await runRes.json();
    let state: string = 'RUNNING';
    let conclusion: string | undefined = undefined;

    if (runData.status === 'queued') {
      state = 'QUEUED';
    } else if (runData.status === 'in_progress') {
      state = 'BUILDING';
    } else if (runData.status === 'completed') {
      if (runData.conclusion === 'success') {
        state = 'ARTIFACT_READY';
        conclusion = 'SUCCESS';
      } else if (runData.conclusion === 'cancelled') {
        state = 'CANCELLED';
        conclusion = 'CANCELLED';
      } else if (runData.conclusion === 'timed_out') {
        state = 'TIMEOUT';
        conclusion = 'TIMEOUT';
      } else {
        state = 'FAILED';
        conclusion = 'FAILED';
      }
    }

    res.json({
      requestId: `gh-${runId}`,
      correlationId: `corr-${runId}`,
      runId: runData.id,
      htmlUrl: runData.html_url,
      provider: 'GITHUB_ACTIONS',
      state,
      conclusion,
      startedAt: runData.run_started_at || runData.created_at,
      completedAt: runData.updated_at,
      logs: [
        `GitHub Actions Run #${runData.run_number} (${runData.name})`,
        `Status: ${runData.status}, Conclusion: ${runData.conclusion || 'RUNNING'}`,
        `Commit: ${runData.head_commit?.id || runData.head_sha}`,
      ],
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. GET /api/build/runs/:runId/artifacts — Discovers artifacts produced by run
app.get('/api/build/runs/:runId/artifacts', async (req, res) => {
  const token = resolveProviderCredential('github').credential;
  const repo = TARGET_GITHUB_REPO;
  const runId = req.params.runId;

  if (!token) {
    return res.status(401).json({ success: false, error: 'GITHUB_AUTH_REQUIRED' });
  }

  try {
    const artUrl = `https://api.github.com/repos/${repo}/actions/runs/${runId}/artifacts`;
    const artRes = await governedFetch(artUrl, 'github', {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'User-Agent': 'NOVIN-Software-Factory',
        'X-GitHub-Api-Version': '2022-11-28',
      },
    });

    if (!artRes.ok) {
      return res.status(artRes.status).json({ success: false, error: `HTTP ${artRes.status}` });
    }

    const artData = await artRes.json();
    const artifacts = (artData.artifacts || []).map((a: any) => ({
      id: a.id,
      name: a.name,
      sizeBytes: a.size_in_bytes,
      url: a.archive_download_url,
    }));

    res.json({ success: true, artifacts });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. POST /api/build/artifacts/fetch — Downloads, extracts, and validates real APK
app.post('/api/build/artifacts/fetch', async (req, res) => {
  const token = resolveProviderCredential('github').credential;
  const repo = TARGET_GITHUB_REPO;
  const { runId, artifactId } = req.body;

  if (!token) {
    return res.status(401).json({ success: false, error: 'GITHUB_AUTH_REQUIRED' });
  }

  try {
    let targetArtifactId = artifactId;

    if (!runId) {
      return res.status(400).json({ success: false, status: 'BLOCKED', error: 'WORKFLOW_RUN_ID_REQUIRED' });
    }

    // Verify the requested workflow run exists before touching any artifact.
    const runCheckUrl = `https://api.github.com/repos/${repo}/actions/runs/${runId}`;
    const runCheckRes = await governedFetch(runCheckUrl, 'github', { headers: {
      Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json',
      'User-Agent': 'NOVIN-Software-Factory', 'X-GitHub-Api-Version': '2022-11-28'
    }});
    if (!runCheckRes.ok) return res.status(runCheckRes.status).json({ success: false, error: `GitHub run lookup returned HTTP ${runCheckRes.status}` });
    const runCheck = await runCheckRes.json();
    if (String(runCheck.id) !== String(runId) || runCheck.status !== 'completed' || runCheck.conclusion !== 'success') {
      return res.status(409).json({ success: false, status: 'NOT_VERIFIED', error: 'REQUESTED_WORKFLOW_RUN_NOT_SUCCESSFUL', runId, workflowStatus: runCheck.status, conclusion: runCheck.conclusion });
    }

    // If artifactId not provided, search by runId
    if (!targetArtifactId && runId) {
      const artListUrl = `https://api.github.com/repos/${repo}/actions/runs/${runId}/artifacts`;
      const artListRes = await governedFetch(artListUrl, 'github', {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json',
          'User-Agent': 'NOVIN-Software-Factory',
          'X-GitHub-Api-Version': '2022-11-28',
        },
      });

      if (artListRes.ok) {
        const artListData = await artListRes.json();
        const found = (artListData.artifacts || []).find((a: any) => typeof a.name === 'string' && a.name.startsWith('novin-nexus-android-')); 
        if (found) targetArtifactId = found.id;
      }
    }

    if (!targetArtifactId) {
      return res.status(404).json({ success: false, error: `Target NOVIN Android artifact for run ${runId} not found.` });
    }

    const artifactCheckUrl = `https://api.github.com/repos/${repo}/actions/artifacts/${targetArtifactId}`;
    const artifactCheckRes = await governedFetch(artifactCheckUrl, 'github', { headers: {
      Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json',
      'User-Agent': 'NOVIN-Software-Factory', 'X-GitHub-Api-Version': '2022-11-28'
    }});
    if (!artifactCheckRes.ok) return res.status(artifactCheckRes.status).json({ success: false, error: `Artifact lookup returned HTTP ${artifactCheckRes.status}` });
    const artifactCheck = await artifactCheckRes.json();
    if (String(artifactCheck.workflow_run?.id) !== String(runId)) {
      return res.status(409).json({ success: false, status: 'NOT_VERIFIED', error: 'ARTIFACT_RUN_PROVENANCE_MISMATCH', runId, artifactId: targetArtifactId, artifactWorkflowRunId: artifactCheck.workflow_run?.id });
    }

    const downloadUrl = `https://api.github.com/repos/${repo}/actions/artifacts/${targetArtifactId}/zip`;
    const downloadRes = await governedFetch(downloadUrl, 'github', {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'User-Agent': 'NOVIN-Software-Factory',
        'X-GitHub-Api-Version': '2022-11-28',
      },
      redirect: 'follow',
    });

    if (!downloadRes.ok) {
      return res.status(downloadRes.status).json({
        success: false,
        error: `Artifact download failed with HTTP ${downloadRes.status}`,
      });
    }

    const zipBuffer = Buffer.from(await downloadRes.arrayBuffer());
    const artifactsDir = path.join(process.cwd(), 'artifacts');
    if (!fs.existsSync(artifactsDir)) {
      fs.mkdirSync(artifactsDir, { recursive: true });
    }

    const tmpZipPath = path.join(artifactsDir, 'downloaded-artifact.zip');
    fs.writeFileSync(tmpZipPath, zipBuffer);

    // Unzip contents into artifacts/
    try {
      execSync(`unzip -o "${tmpZipPath}" -d "${artifactsDir}"`, { stdio: 'ignore' });
      fs.unlinkSync(tmpZipPath);
    } catch (unzipErr: any) {
      return res.status(500).json({
        success: false,
        error: `Failed to unpack downloaded artifact: ${unzipErr.message}`,
      });
    }

    const findArtifactFile = (name: string) => {
      const direct = path.join(artifactsDir, name);
      if (fs.existsSync(direct)) return direct;
      const queue = [artifactsDir];
      while (queue.length) {
        const dir = queue.shift()!;
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const candidate = path.join(dir, entry.name);
          if (entry.isDirectory() && entry.name !== '.git') queue.push(candidate);
          else if (entry.isFile() && entry.name === name) return candidate;
        }
      }
      return null;
    };

    const apkPath = findArtifactFile('novin-nexus-debug.apk');
    const shaPath = findArtifactFile('novin-nexus-debug.apk.sha256');
    const metaPath = findArtifactFile('novin-build-metadata.json');

    if (!apkPath) {
      return res.status(500).json({
        success: false,
        error: 'Artifact package did not contain novin-nexus-debug.apk.',
      });
    }

    const apkStats = fs.statSync(apkPath);
    const apkData = fs.readFileSync(apkPath);
    const actualSha256 = crypto.createHash('sha256').update(apkData).digest('hex');

    let recordedSha = '';
    if (shaPath) {
      const shaText = fs.readFileSync(shaPath, 'utf8').trim();
      recordedSha = (shaText.match(/^[a-fA-F0-9]{64}/)?.[0] || '').toLowerCase();
    }

    let metadata: any = null;
    if (fs.existsSync(metaPath)) {
      try {
        metadata = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
      } catch {
        // ignore
      }
    }

    const hashMatches = Boolean(recordedSha) && actualSha256 === recordedSha;
    if (!hashMatches) {
      return res.status(400).json({
        success: false,
        error: `Cryptographic SHA-256 mismatch! Computed: ${actualSha256}, Recorded: ${recordedSha}`,
      });
    }

    if (!metadata || metadata.truthLevel !== 'REAL_EXECUTION' || metadata.apkBuild !== 'PASS' || metadata.signatureVerification !== 'PASS') {
      return res.status(400).json({ success: false, error: 'Artifact metadata lacks required REAL_EXECUTION/APK/signature evidence.' });
    }
    if (!runId || !metadata.workflowRunId || String(metadata.workflowRunId) !== String(runId)) {
      return res.status(400).json({ success: false, error: `Artifact provenance mismatch: metadata workflowRunId=${metadata.workflowRunId}, requested runId=${runId}.` });
    }

    const validatedArtifact = {
      id: `art-apk-${Date.now()}`,
      name: 'NOVIN Installable Debug APK (novin-nexus-debug.apk)',
      type: 'APK_DEBUG',
      version: metadata?.targetSdk ? `sdk-${metadata.targetSdk}` : '0.0.0-debug',
      buildId: `bld-remote-${runId}`,
      timestamp: new Date().toISOString(),
      sourceRevision: metadata?.gitCommit || 'main',
      filePath: 'artifacts/novin-nexus-debug/novin-nexus-debug.apk',
      sizeBytes: apkStats.size,
      sha256: actualSha256,
      verified: true,
      status: 'READY',
      metadata,
    };

    res.json({
      success: true,
      artifact: validatedArtifact,
      message: 'APK downloaded, unpacked, validated and verified.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// NOVIN APRRE: PROBLEM RESOLUTION ENDPOINTS
// ==========================================

// Get dynamic capability matrix
app.get('/api/capabilities', (req, res) => {
  try {
    const matrix = globalAPRRE.discoverCapabilities();
    res.json({ success: true, matrix });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});


// Runtime truth matrix: distinguishes registered capabilities from executable reality.
app.get('/api/capabilities/reality', (_req, res) => {
  try {
    const snapshot = novinCapabilityRealityCenter.snapshot();
    res.json({ success: true, snapshot, gaps: novinCapabilityRealityCenter.gaps() });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// City-scale reality surface and governed blueprint generation.
app.get('/api/city/reality', (_req, res) => {
  try {
    res.json({ success: true, snapshot: smartCityFabric.snapshot() });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/city/blueprint', (req, res) => {
  try {
    const { goal, cityNameFa } = req.body ?? {};
    if (typeof goal !== 'string' || !goal.trim()) {
      return res.status(400).json({ success: false, error: 'CITY_BLUEPRINT_GOAL_REQUIRED' });
    }
    const blueprint = cityBlueprintGenerator.generate(goal, typeof cityNameFa === 'string' && cityNameFa.trim() ? cityNameFa.trim() : undefined);
    res.json({ success: true, blueprint });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});


// List all observed problems
app.get('/api/problems', (req, res) => {
  try {
    const problems = globalAPRRE.listProblems();
    res.json({ success: true, problems });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Diagnose a new problem from raw log
app.post('/api/problems/diagnose', (req, res) => {
  try {
    const { rawLog, source = 'API', context = {} } = req.body;
    if (!rawLog) {
      return res.status(400).json({ success: false, error: 'rawLog is required' });
    }
    const observed = globalAPRRE.observe(source, rawLog, context);
    const diagnosed = globalAPRRE.diagnose(observed.problemId);
    res.json({ success: true, problem: diagnosed });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Execute resolution strategy
app.post('/api/problems/:problemId/execute', (req, res) => {
  try {
    const { problemId } = req.params;
    const { strategyId } = req.body;
    const result = globalAPRRE.executeStrategy(problemId, strategyId);
    res.json({ success: result.success, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Rollback state for a problem
app.post('/api/problems/:problemId/rollback', (req, res) => {
  try {
    const { problemId } = req.params;
    const result = globalAPRRE.rollback(problemId);
    res.json({ success: result.success, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Run 12-scenario self-test matrix
app.post('/api/aprre/self-test', (req, res) => {
  try {
    const report = globalAPRRE.runSelfTestMatrix();
    res.json({ success: true, report });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// NOVIN P97: REAL EXECUTION FABRIC ENDPOINTS
// ==========================================

// Discover real execution targets (LOCAL, REMOTE, CI, DEVICE)
app.get('/api/execution/targets', (req, res) => {
  try {
    const targets = globalExecutionTargetSelector.discoverTargets();
    res.json({ success: true, targets });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Select optimal execution target adaptively
app.post('/api/execution/select-target', (req, res) => {
  try {
    const criteria = req.body;
    const result = globalExecutionTargetSelector.selectTarget(criteria);
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Execute task via Real Execution Fabric
app.post('/api/execution', async (req, res) => {
  try {
    const request = req.body;
    if (!request.command) {
      return res.status(400).json({ success: false, error: 'Command is required' });
    }
    const fullRequest = {
      executionId: request.executionId || `exec-${Date.now()}`,
      taskId: request.taskId || 'ad-hoc-task',
      target: request.target || 'LOCAL',
      tool: request.tool || 'ShellAdapter',
      command: request.command,
      arguments: request.arguments || [],
      workingDirectory: request.workingDirectory || process.cwd(),
      timeout: request.timeout || 30000,
      riskLevel: request.riskLevel || 'LOW',
      approvalRequired: Boolean(request.approvalRequired),
      snapshotId: request.snapshotId,
      metadata: request.metadata || {},
    };

    const result = await globalRealExecutionFabric.execute(fullRequest as any);
    res.json({ success: result.status === 'PASS', result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// List all executions
app.get('/api/execution', (req, res) => {
  try {
    const executions = globalRealExecutionFabric.listExecutions();
    res.json({ success: true, executions });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get single execution by ID
app.get('/api/execution/:executionId', (req, res) => {
  try {
    const exec = globalRealExecutionFabric.getExecution(req.params.executionId);
    if (!exec) {
      return res.status(404).json({ success: false, error: 'Execution not found' });
    }
    res.json({ success: true, execution: exec });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get evidence for execution
app.get('/api/execution/:executionId/evidence', (req, res) => {
  try {
    const exec = globalRealExecutionFabric.getExecution(req.params.executionId);
    if (!exec) {
      return res.status(404).json({ success: false, error: 'Execution not found' });
    }
    const evidenceItems = exec.evidenceRefs
      .map((ref) => globalDevEvidenceStore.getEvidence(ref))
      .filter(Boolean);
    res.json({ success: true, evidenceRefs: exec.evidenceRefs, evidenceItems });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Discover connected physical Android devices
app.get('/api/execution/devices', (req, res) => {
  try {
    const discovery = globalToolGateway.discoverConnectedDevices();
    res.json({ success: true, discovery });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Run P97 16-Scenario Self-Test Matrix
app.post('/api/execution/self-test', async (req, res) => {
  try {
    const report = await globalRealExecutionFabric.runP97SelfTestMatrix();
    res.json({ success: true, report });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// NOVIN Engineering subsystem integration
const novinEngineering = EngineeringSystem.getInstance();

app.get('/api/novin/engineering/status', async (_req, res) => {
  try {
    res.json({ success: true, state: await novinEngineering.getState() });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

app.get('/api/novin/engineering/doctor', async (_req, res) => {
  try {
    res.json({ success: true, report: await novinEngineering.getDoctorReport() });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

app.post('/api/novin/engineering/qa', async (_req, res) => {
  try {
    res.json({ success: true, report: await novinEngineering.runQaSuite() });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

app.post('/api/novin/engineering/build', async (req, res) => {
  try {
    res.json({ success: true, build: await novinEngineering.executeBuild({ customBuildId: req.body?.buildId }) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});


// -----------------------------------------------------------------------------
// NOVIN Creator Account Service
// Real account recovery boundary for reinstall/device replacement.
// SMS/email delivery is provider-backed; absent provider configuration is BLOCKED.
// -----------------------------------------------------------------------------
import {
  createAccountId,
  normalizeEmail,
  normalizePhoneE164,
  validateCreatorPassword,
  toPublicCreatorProfile,
  type CreatorAccountRecord,
} from './src/core/security/creatorAccountSystem.ts';

const CREATOR_ACCOUNT_STORE = process.env.NOVIN_CREATOR_ACCOUNT_STORE || path.join(process.cwd(), '.novin-data', 'creator-accounts.json');
const CREATOR_SESSION_SECRET = process.env.NOVIN_CREATOR_SESSION_SECRET || '';
const CREATOR_ACCOUNT_MASTER_KEY = process.env.NOVIN_CREATOR_ACCOUNT_MASTER_KEY || '';
const CREATOR_OTP_TTL_MS = 5 * 60 * 1000;
const CREATOR_OTP_MAX_ATTEMPTS = 5;
const CREATOR_OTP_RESEND_COOLDOWN_MS = 30 * 1000;
const CREATOR_OTP_STORE = process.env.NOVIN_CREATOR_OTP_STORE || path.join(process.cwd(), '.novin-data', 'creator-otps.json');
type CreatorOtpRecord = { accountId: string; channel: 'PHONE' | 'EMAIL'; codeHash: string; expiresAt: number; attempts: number; issuedAt: number };
let creatorOtps = new Map<string, CreatorOtpRecord>();
const creatorRateLimits = new Map<string, { count: number; windowStartedAt: number }>();

function pruneCreatorRateLimits(now = Date.now()): void {
  for (const [key, state] of creatorRateLimits) if (now - state.windowStartedAt > 15 * 60 * 1000) creatorRateLimits.delete(key);
}
function creatorRequestKey(req: express.Request): string {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || req.socket.remoteAddress || 'unknown';
}
function enforceCreatorRateLimit(req: express.Request, bucket: string, maxAttempts: number, windowMs = 15 * 60 * 1000): void {
  const now = Date.now(); pruneCreatorRateLimits(now);
  const key = `${bucket}:${creatorRequestKey(req)}`;
  const current = creatorRateLimits.get(key);
  if (!current || now - current.windowStartedAt >= windowMs) {
    creatorRateLimits.set(key, { count: 1, windowStartedAt: now });
    return;
  }
  current.count += 1;
  if (current.count > maxAttempts) throw new Error('CREATOR_RATE_LIMITED');
}
function persistCreatorOtps(): void {
  fs.mkdirSync(path.dirname(CREATOR_OTP_STORE), { recursive: true });
  const records = [...creatorOtps.values()].filter(v => v.expiresAt > Date.now());
  const temp = `${CREATOR_OTP_STORE}.tmp`;
  fs.writeFileSync(temp, encryptCreatorJson(records), { mode: 0o600 });
  fs.renameSync(temp, CREATOR_OTP_STORE);
}
function loadCreatorOtps(): void {
  try {
    if (!fs.existsSync(CREATOR_OTP_STORE)) return;
    const records = decryptCreatorJson<CreatorOtpRecord[]>(fs.readFileSync(CREATOR_OTP_STORE, 'utf8'));
    creatorOtps = new Map(records.filter(v => v.expiresAt > Date.now()).map(v => [`${v.accountId}:${v.channel}`, v]));
  } catch {
    creatorOtps = new Map();
  }
}
function deleteCreatorOtp(accountId: string, channel: 'PHONE' | 'EMAIL'): void {
  creatorOtps.delete(`${accountId}:${channel}`);
  persistCreatorOtps();
}


function hashSecret(value: string, salt: string): string {
  return crypto.scryptSync(value, salt, 32).toString('hex');
}
function passwordHash(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  return `scrypt$${salt}$${hashSecret(password, salt)}`;
}
function verifyPassword(password: string, encoded: string): boolean {
  const [scheme, salt, expected] = encoded.split('$');
  if (scheme !== 'scrypt' || !salt || !expected) return false;
  const actual = hashSecret(password, salt);
  return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
}
function otpHash(accountId: string, channel: string, code: string): string {
  const secret = CREATOR_SESSION_SECRET || CREATOR_ACCOUNT_MASTER_KEY;
  if (!secret) throw new Error('CREATOR_OTP_SECRET_NOT_CONFIGURED');
  return crypto.createHmac('sha256', secret).update(`${accountId}|${channel}|${code}`).digest('hex');
}
function safeSecretEqual(left: string, right: string): boolean {
  const a = Buffer.from(left); const b = Buffer.from(right);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function creatorStoreKey(): Buffer {
  if (!CREATOR_ACCOUNT_MASTER_KEY) throw new Error('CREATOR_ACCOUNT_MASTER_KEY_NOT_CONFIGURED');
  return crypto.createHash('sha256').update(CREATOR_ACCOUNT_MASTER_KEY).digest();
}
function encryptCreatorStore(accounts: CreatorAccountRecord[]): string {
  const iv = crypto.randomBytes(12); const key = creatorStoreKey(); const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(accounts), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({ v:1, iv:iv.toString('base64url'), tag:tag.toString('base64url'), data:ciphertext.toString('base64url') });
}
function decryptCreatorStore(raw: string): CreatorAccountRecord[] {
  const box = JSON.parse(raw) as {v:number;iv:string;tag:string;data:string}; if (box.v !== 1) throw new Error('CREATOR_STORE_VERSION_UNSUPPORTED');
  const decipher = crypto.createDecipheriv('aes-256-gcm', creatorStoreKey(), Buffer.from(box.iv,'base64url')); decipher.setAuthTag(Buffer.from(box.tag,'base64url'));
  const clear = Buffer.concat([decipher.update(Buffer.from(box.data,'base64url')), decipher.final()]).toString('utf8');
  const parsed = JSON.parse(clear); return Array.isArray(parsed) ? parsed : [];
}
function encryptCreatorJson<T>(value: T): string {
  const iv = crypto.randomBytes(12); const key = creatorStoreKey(); const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()]);
  return JSON.stringify({ v:1, iv:iv.toString('base64url'), tag:cipher.getAuthTag().toString('base64url'), data:ciphertext.toString('base64url') });
}
function decryptCreatorJson<T>(raw: string): T {
  const box = JSON.parse(raw) as {v:number;iv:string;tag:string;data:string};
  if (box.v !== 1) throw new Error('CREATOR_STORE_VERSION_UNSUPPORTED');
  const decipher = crypto.createDecipheriv('aes-256-gcm', creatorStoreKey(), Buffer.from(box.iv,'base64url'));
  decipher.setAuthTag(Buffer.from(box.tag,'base64url'));
  return JSON.parse(Buffer.concat([decipher.update(Buffer.from(box.data,'base64url')), decipher.final()]).toString('utf8')) as T;
}
function loadCreatorAccounts(): CreatorAccountRecord[] {
  if (!CREATOR_ACCOUNT_MASTER_KEY) throw new Error('CREATOR_ACCOUNT_MASTER_KEY_NOT_CONFIGURED');
  try { if (!fs.existsSync(CREATOR_ACCOUNT_STORE)) return []; return decryptCreatorStore(fs.readFileSync(CREATOR_ACCOUNT_STORE, 'utf8')); }
  catch (e) { if ((e as Error).message === 'CREATOR_ACCOUNT_MASTER_KEY_NOT_CONFIGURED') throw e; return []; }
}
function saveCreatorAccounts(accounts: CreatorAccountRecord[]): void {
  const temp = `${CREATOR_ACCOUNT_STORE}.tmp`; fs.mkdirSync(path.dirname(CREATOR_ACCOUNT_STORE), { recursive: true });
  fs.writeFileSync(temp, encryptCreatorStore(accounts), { mode: 0o600 }); fs.renameSync(temp, CREATOR_ACCOUNT_STORE);
}
function accountDeliveryReady(channel: 'PHONE' | 'EMAIL'): boolean {
  if (channel === 'PHONE') return Boolean(process.env.NOVIN_SMS_PROVIDER_URL && resolveProviderCredential('sms').credential && process.env.NOVIN_SMS_FROM);
  return Boolean(process.env.NOVIN_EMAIL_PROVIDER_URL && resolveProviderCredential('email').credential && process.env.NOVIN_EMAIL_FROM);
}
async function deliverCreatorOtp(channel: 'PHONE' | 'EMAIL', destination: string, code: string): Promise<void> {
  if (!accountDeliveryReady(channel)) throw new Error(`CREATOR_${channel}_PROVIDER_NOT_CONFIGURED`);
  if (channel === 'PHONE') {
    const smsUrl = assertConfiguredProviderEgress(process.env.NOVIN_SMS_PROVIDER_URL!);
    const response = await governedConfiguredFetch(smsUrl, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${resolveProviderCredential('sms').credential}` },
      body: JSON.stringify({ from: process.env.NOVIN_SMS_FROM, to: destination, message: `کد تأیید NOVIN: ${code}` }),
    });
    if (!response.ok) throw new Error('CREATOR_SMS_DELIVERY_FAILED');
    return;
  }
  const emailUrl = assertConfiguredProviderEgress(process.env.NOVIN_EMAIL_PROVIDER_URL!);
  const response = await governedConfiguredFetch(emailUrl, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${resolveProviderCredential('email').credential}` },
    body: JSON.stringify({ from: process.env.NOVIN_EMAIL_FROM, to: [destination], subject: 'کد تأیید NOVIN', text: `کد تأیید شما: ${code}
این کد ۵ دقیقه اعتبار دارد.` }),
  });
  if (!response.ok) throw new Error('CREATOR_EMAIL_DELIVERY_FAILED');
}
async function issueCreatorOtp(account: CreatorAccountRecord, channel: 'PHONE' | 'EMAIL'): Promise<void> {
  const destination = channel === 'PHONE' ? account.phoneE164 : account.email;
  const key = `${account.accountId}:${channel}`;
  const existing = creatorOtps.get(key);
  if (existing && existing.expiresAt > Date.now() && Date.now() - existing.issuedAt < CREATOR_OTP_RESEND_COOLDOWN_MS) throw new Error('CREATOR_OTP_RESEND_COOLDOWN');
  const code = String(crypto.randomInt(100000, 1000000));
  const candidate: CreatorOtpRecord = { accountId: account.accountId, channel, codeHash: otpHash(account.accountId, channel, code), expiresAt: Date.now() + CREATOR_OTP_TTL_MS, attempts: 0, issuedAt: Date.now() };
  // Deliver first. A failed provider call must never leave a usable OTP behind.
  await deliverCreatorOtp(channel, destination, code);
  creatorOtps.set(key, candidate);
  persistCreatorOtps();
}
function issueCreatorSession(res: express.Response, accountId: string): void {
  if (!CREATOR_SESSION_SECRET) throw new Error('CREATOR_SESSION_SECRET_NOT_CONFIGURED');
  const issued = Date.now().toString();
  const payload = Buffer.from(JSON.stringify({ accountId, issued, exp: Date.now() + 15 * 60 * 1000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', CREATOR_SESSION_SECRET).update(payload).digest('base64url');
  res.setHeader('Set-Cookie', `novin_creator_session=${encodeURIComponent(`${payload}.${sig}`)}; HttpOnly; SameSite=${process.env.NODE_ENV === 'production' ? 'None' : 'Lax'}; Path=/; Max-Age=900${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`);
}
function creatorAuthRequired(req: express.Request): string {
  const token = String((req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('novin_creator_session='))?.slice('novin_creator_session='.length) || '').trim();
  const decodedToken = token ? decodeURIComponent(token) : '';
  if (!decodedToken || !CREATOR_SESSION_SECRET) throw new Error('CREATOR_SESSION_REQUIRED');
  const [payload, sig] = decodedToken.split('.');
  const expected = crypto.createHmac('sha256', CREATOR_SESSION_SECRET).update(payload || '').digest('base64url');
  if (!payload || !sig || !safeSecretEqual(sig, expected)) throw new Error('CREATOR_SESSION_INVALID');
  let parsed: { accountId: string; exp: number };
  try { parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as { accountId: string; exp: number }; } catch { throw new Error('CREATOR_SESSION_INVALID'); }
  if (!parsed.accountId || parsed.exp <= Date.now()) throw new Error('CREATOR_SESSION_EXPIRED');
  return parsed.accountId;
}

loadCreatorOtps();

app.post('/api/creator-account/register', async (req, res) => {
  try {
    enforceCreatorRateLimit(req, 'register', 5);
    if (!CREATOR_SESSION_SECRET) return res.status(503).json({ success: false, status: 'NOT_CONFIGURED', error: 'CREATOR_SESSION_SECRET_NOT_CONFIGURED' });
    const displayName = String(req.body?.displayName || '').trim();
    const email = normalizeEmail(String(req.body?.email || ''));
    const phoneE164 = normalizePhoneE164(String(req.body?.phone || ''));
    const password = String(req.body?.password || '');
    if (!displayName || displayName.length > 120) throw new Error('CREATOR_DISPLAY_NAME_INVALID');
    validateCreatorPassword(password);
    const hasContactVerificationProvider = accountDeliveryReady('PHONE') || accountDeliveryReady('EMAIL');
    if (!hasContactVerificationProvider) throw new Error('CREATOR_CONTACT_VERIFICATION_NOT_CONFIGURED');
    const accounts = loadCreatorAccounts();
    if (accounts.some(a => a.email === email)) throw new Error('CREATOR_EMAIL_ALREADY_REGISTERED');
    if (accounts.some(a => a.phoneE164 === phoneE164)) throw new Error('CREATOR_PHONE_ALREADY_REGISTERED');
    const now = new Date().toISOString();
    const account: CreatorAccountRecord = { accountId: createAccountId(email), role: 'FOUNDER_OWNER', displayName, email, phoneE164, emailVerified: false, phoneVerified: false, passwordHash: passwordHash(password), status: 'PENDING_CONTACT_VERIFICATION', createdAt: now, updatedAt: now, enrolledFactors: ['PASSWORD'], recoveryVersion: 1 };
    accounts.push(account); saveCreatorAccounts(accounts);
    const delivery: string[] = [];
    try { await issueCreatorOtp(account, 'PHONE'); delivery.push('PHONE_OTP_SENT'); } catch (e) { delivery.push((e as Error).message); }
    try { await issueCreatorOtp(account, 'EMAIL'); delivery.push('EMAIL_OTP_SENT'); } catch (e) { delivery.push((e as Error).message); }
    if (!delivery.some(v => v.endsWith('_OTP_SENT'))) {
      const index = accounts.findIndex(a => a.accountId === account.accountId);
      if (index >= 0) { accounts.splice(index, 1); saveCreatorAccounts(accounts); }
      throw new Error('CREATOR_CONTACT_VERIFICATION_DELIVERY_FAILED');
    }
    res.status(201).json({ success: true, status: 'PENDING_CONTACT_VERIFICATION', account: toPublicCreatorProfile(account), delivery });
  } catch (err: any) { res.status(400).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});

async function verifyCreatorOtp(req: express.Request, res: express.Response, channel: 'PHONE' | 'EMAIL') {
  try {
    enforceCreatorRateLimit(req, `verify-otp:${channel}`, 15);
    const accountId = String(req.body?.accountId || '');
    const code = String(req.body?.code || '');
    if (!/^\d{6}$/.test(code)) throw new Error('CREATOR_OTP_INVALID');
    const pending = creatorOtps.get(`${accountId}:${channel}`);
    if (!pending || pending.expiresAt <= Date.now()) throw new Error('CREATOR_OTP_EXPIRED');
    if (pending.attempts >= CREATOR_OTP_MAX_ATTEMPTS) throw new Error('CREATOR_OTP_LOCKED');
    pending.attempts += 1;
    persistCreatorOtps();
    if (!safeSecretEqual(otpHash(accountId, channel, code), pending.codeHash)) { if (pending.attempts >= CREATOR_OTP_MAX_ATTEMPTS) deleteCreatorOtp(accountId, channel); throw new Error('CREATOR_OTP_INVALID'); }
    const accounts = loadCreatorAccounts();
    const account = accounts.find(a => a.accountId === accountId);
    if (!account) throw new Error('CREATOR_ACCOUNT_NOT_FOUND');
    if (channel === 'PHONE') { account.phoneVerified = true; if (!account.enrolledFactors.includes('PHONE_OTP')) account.enrolledFactors.push('PHONE_OTP'); }
    else { account.emailVerified = true; if (!account.enrolledFactors.includes('EMAIL_OTP')) account.enrolledFactors.push('EMAIL_OTP'); }
    if (account.phoneVerified || account.emailVerified) account.status = 'ACTIVE';
    account.updatedAt = new Date().toISOString(); saveCreatorAccounts(accounts); deleteCreatorOtp(accountId, channel); issueCreatorSession(res, accountId);
    res.json({ success: true, status: 'VERIFIED', account: toPublicCreatorProfile(account) });
  } catch (err: any) { res.status(400).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
}
app.post('/api/creator-account/verify-phone', (req, res) => { void verifyCreatorOtp(req, res, 'PHONE'); });
app.post('/api/creator-account/verify-email', (req, res) => { void verifyCreatorOtp(req, res, 'EMAIL'); });

app.post('/api/creator-account/login', async (req, res) => {
  try {
    enforceCreatorRateLimit(req, 'login', 10);
    const identifier = String(req.body?.emailOrPhone || '').trim();
    const password = String(req.body?.password || '');
    const accounts = loadCreatorAccounts();
    const normalized = identifier.includes('@') ? normalizeEmail(identifier) : normalizePhoneE164(identifier);
    const account = accounts.find(a => a.email === normalized || a.phoneE164 === normalized);
    if (!account || !verifyPassword(password, account.passwordHash)) throw new Error('CREATOR_LOGIN_INVALID');
    if (account.status === 'LOCKED') throw new Error('CREATOR_ACCOUNT_LOCKED');
    if (!account.emailVerified && !account.phoneVerified) throw new Error('CREATOR_CONTACT_VERIFICATION_REQUIRED');
    issueCreatorSession(res, account.accountId);
    res.json({ success: true, status: 'VERIFIED', account: toPublicCreatorProfile(account) });
  } catch (err: any) { res.status(401).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});

app.post('/api/creator-account/send-login-otp', async (req, res) => {
  try {
    enforceCreatorRateLimit(req, 'send-login-otp', 5);
    const identifier = String(req.body?.emailOrPhone || '').trim();
    const channel = String(req.body?.channel || '').toUpperCase() as 'PHONE' | 'EMAIL';
    if (!['PHONE', 'EMAIL'].includes(channel)) throw new Error('CREATOR_OTP_CHANNEL_INVALID');
    const normalized = identifier.includes('@') ? normalizeEmail(identifier) : normalizePhoneE164(identifier);
    const accounts = loadCreatorAccounts(); const account = accounts.find(a => a.email === normalized || a.phoneE164 === normalized);
    if (!account) throw new Error('CREATOR_ACCOUNT_NOT_FOUND');
    await issueCreatorOtp(account, channel);
    res.json({ success: true, status: 'OTP_SENT' });
  } catch (err: any) { res.status(400).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});

app.post('/api/creator-account/login-otp', (req, res) => { void verifyCreatorOtp(req, res, String(req.body?.channel || '').toUpperCase() as 'PHONE' | 'EMAIL'); });
app.post('/api/creator-account/recover', async (req, res) => {
  try {
    enforceCreatorRateLimit(req, 'recover', 5);
    const identifier = String(req.body?.emailOrPhone || '').trim();
    const channel = String(req.body?.channel || '').toUpperCase() as 'PHONE' | 'EMAIL';
    const normalized = identifier.includes('@') ? normalizeEmail(identifier) : normalizePhoneE164(identifier);
    const accounts = loadCreatorAccounts(); const account = accounts.find(a => a.email === normalized || a.phoneE164 === normalized);
    if (!account) throw new Error('CREATOR_ACCOUNT_NOT_FOUND');
    await issueCreatorOtp(account, channel);
    res.json({ success: true, status: 'RECOVERY_OTP_SENT', accountId: account.accountId });
  } catch (err: any) { res.status(400).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});

app.post('/api/creator-account/reset-password', (req, res) => {
  try {
    enforceCreatorRateLimit(req, 'reset-password', 10);
    const accountId = String(req.body?.accountId || ''); const channel = String(req.body?.channel || '').toUpperCase() as 'PHONE'|'EMAIL'; const code = String(req.body?.code || ''); const newPassword = String(req.body?.newPassword || '');
    if (!/^\d{6}$/.test(code)) throw new Error('CREATOR_OTP_INVALID');
    const pending = creatorOtps.get(`${accountId}:${channel}`); if (!pending || pending.expiresAt <= Date.now()) throw new Error('CREATOR_OTP_EXPIRED');
    if (pending.attempts >= CREATOR_OTP_MAX_ATTEMPTS) throw new Error('CREATOR_OTP_LOCKED'); pending.attempts += 1; persistCreatorOtps();
    if (!safeSecretEqual(otpHash(accountId, channel, code), pending.codeHash)) { if (pending.attempts >= CREATOR_OTP_MAX_ATTEMPTS) deleteCreatorOtp(accountId, channel); throw new Error('CREATOR_OTP_INVALID'); }
    validateCreatorPassword(newPassword);
    const accounts = loadCreatorAccounts(); const account = accounts.find(a=>a.accountId===accountId); if (!account) throw new Error('CREATOR_ACCOUNT_NOT_FOUND');
    account.passwordHash = passwordHash(newPassword); account.recoveryVersion += 1; account.status='ACTIVE'; account.updatedAt=new Date().toISOString(); saveCreatorAccounts(accounts); deleteCreatorOtp(accountId, channel); issueCreatorSession(res, accountId);
    res.json({success:true,status:'PASSWORD_RESET',account:toPublicCreatorProfile(account)});
  } catch (err:any) { res.status(400).json({success:false,status:'BLOCKED',error:err?.message||String(err)}); }
});

app.get('/api/creator-account/me', (req, res) => {
  try { const accountId = creatorAuthRequired(req); const account = loadCreatorAccounts().find(a => a.accountId === accountId); if (!account) throw new Error('CREATOR_ACCOUNT_NOT_FOUND'); res.json({ success:true, status:'VERIFIED', account:toPublicCreatorProfile(account) }); }
  catch (err:any) { res.status(401).json({ success:false, status:'BLOCKED', error:err?.message || String(err) }); }
});
app.post('/api/creator-account/logout', (req, res) => { res.setHeader('Set-Cookie', `novin_creator_session=; HttpOnly; SameSite=${process.env.NODE_ENV === 'production' ? 'None' : 'Lax'}; Path=/; Max-Age=0${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`); res.json({ success:true, status:'LOGGED_OUT' }); });


// -----------------------------------------------------------------------------
// NOVIN Cloud Identity + Memory Fabric
// The server stores only account metadata, public device keys and governed memory.
// Raw biometrics/private keys are rejected at this boundary.
// -----------------------------------------------------------------------------
const CREATOR_CLOUD_STORE = process.env.NOVIN_CREATOR_CLOUD_STORE || path.join(process.cwd(), '.novin-data', 'creator-cloud.json');
const creatorDeviceChallenges = new Map<string, { accountId: string; challenge: string; expiresAt: number }>();

interface CreatorCloudStore {
  devices: CreatorDeviceBinding[];
  memories: CloudMemoryRecord[];
}

function loadCreatorCloud(): CreatorCloudStore {
  if (!CREATOR_ACCOUNT_MASTER_KEY) throw new Error('CREATOR_ACCOUNT_MASTER_KEY_NOT_CONFIGURED');
  if (!fs.existsSync(CREATOR_CLOUD_STORE)) return { devices: [], memories: [] };
  try {
    const raw = fs.readFileSync(CREATOR_CLOUD_STORE, 'utf8');
    return decryptCreatorJson<CreatorCloudStore>(raw);
  } catch {
    return { devices: [], memories: [] };
  }
}

function saveCreatorCloud(store: CreatorCloudStore): void {
  const temp = `${CREATOR_CLOUD_STORE}.tmp`;
  fs.mkdirSync(path.dirname(CREATOR_CLOUD_STORE), { recursive: true });
  fs.writeFileSync(temp, encryptCreatorJson(store), { mode: 0o600 });
  fs.renameSync(temp, CREATOR_CLOUD_STORE);
}

function publicDeviceKeyOnly(value: unknown): JsonWebKey {
  if (!value || typeof value !== 'object') throw new Error('CREATOR_DEVICE_PUBLIC_KEY_REQUIRED');
  const key = value as Record<string, unknown>;
  if (key.k || key.d || key.key_ops?.toString().includes('decrypt')) throw new Error('CREATOR_DEVICE_PRIVATE_KEY_REJECTED');
  if (key.kty !== 'EC' || key.crv !== 'P-256' || typeof key.x !== 'string' || typeof key.y !== 'string') {
    throw new Error('CREATOR_DEVICE_KEY_ALGORITHM_INVALID');
  }
  return { kty: 'EC', crv: 'P-256', x: key.x, y: key.y, ext: true, key_ops: ['verify'] };
}

function verifyDeviceSignature(publicKeyJwk: JsonWebKey, challenge: string, signatureBase64Url: string): boolean {
  const publicKey = crypto.createPublicKey({ key: publicKeyJwk as crypto.JsonWebKey, format: 'jwk' });
  const verify = crypto.createVerify('SHA256');
  verify.update(challenge); verify.end();
  return verify.verify(publicKey, Buffer.from(signatureBase64Url, 'base64url'));
}

app.get('/api/creator-cloud/contract', (_req, res) => {
  res.json({ success: true, status: 'PASS', contract: creatorCloudIdentityContract() });
});

app.post('/api/creator-cloud/device/challenge', (req, res) => {
  try {
    const accountId = creatorAuthRequired(req);
    const challenge = crypto.randomBytes(32).toString('base64url');
    creatorDeviceChallenges.set(accountId, { accountId, challenge, expiresAt: Date.now() + 2 * 60 * 1000 });
    res.json({ success: true, status: 'CHALLENGE_ISSUED', challenge, expiresAt: new Date(Date.now() + 2 * 60 * 1000).toISOString() });
  } catch (err: any) {
    res.status(401).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) });
  }
});

app.post('/api/creator-cloud/device/enroll', (req, res) => {
  try {
    const accountId = creatorAuthRequired(req);
    const pending = creatorDeviceChallenges.get(accountId);
    if (!pending || pending.expiresAt <= Date.now()) throw new Error('CREATOR_DEVICE_CHALLENGE_EXPIRED');
    const publicKeyJwk = publicDeviceKeyOnly(req.body?.publicKeyJwk);
    const signature = String(req.body?.signature || '');
    if (!signature || !verifyDeviceSignature(publicKeyJwk, pending.challenge, signature)) throw new Error('CREATOR_DEVICE_PROOF_FAILED');
    const store = loadCreatorCloud();
    const binding: CreatorDeviceBinding = {
      bindingId: `device_${crypto.randomBytes(12).toString('hex')}`, accountId,
      devicePublicKeyJwk: publicKeyJwk, deviceKeyAlgorithm: 'ECDSA_P256',
      deviceLabel: String(req.body?.deviceLabel || 'Android device').slice(0, 80), platform: 'ANDROID',
      createdAt: new Date().toISOString(), lastSeenAt: new Date().toISOString(),
    };
    store.devices.push(binding); saveCreatorCloud(store); creatorDeviceChallenges.delete(accountId);
    res.status(201).json({ success: true, status: 'DEVICE_BOUND', binding: { ...binding, devicePublicKeyJwk: undefined } });
  } catch (err: any) {
    res.status(400).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) });
  }
});

app.get('/api/creator-cloud/devices', (req, res) => {
  try {
    const accountId = creatorAuthRequired(req); const store = loadCreatorCloud();
    res.json({ success: true, status: 'PASS', devices: store.devices.filter(d => d.accountId === accountId).map(({ devicePublicKeyJwk: _key, ...safe }) => safe) });
  } catch (err: any) { res.status(401).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});

app.post('/api/creator-cloud/device/revoke', (req, res) => {
  try {
    const accountId = creatorAuthRequired(req); const bindingId = String(req.body?.bindingId || '');
    const store = loadCreatorCloud(); const device = store.devices.find(d => d.accountId === accountId && d.bindingId === bindingId);
    if (!device) throw new Error('CREATOR_DEVICE_NOT_FOUND');
    device.revokedAt = new Date().toISOString(); saveCreatorCloud(store);
    res.json({ success: true, status: 'DEVICE_REVOKED', bindingId });
  } catch (err: any) { res.status(400).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});

app.get('/api/creator-cloud/memory', (req, res) => {
  try {
    const accountId = creatorAuthRequired(req); const store = loadCreatorCloud();
    res.json({ success: true, status: 'PASS', memories: store.memories.filter(m => m.accountId === accountId && m.sensitivity !== 'DEVICE_ONLY') });
  } catch (err: any) { res.status(401).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});

app.post('/api/creator-cloud/memory/sync', (req, res) => {
  try {
    const accountId = creatorAuthRequired(req);
    const incoming = Array.isArray(req.body?.records) ? req.body.records as CloudMemoryRecord[] : [];
    if (incoming.length > 128) throw new Error('CREATOR_MEMORY_BATCH_TOO_LARGE');
    const store = loadCreatorCloud(); const accepted: string[] = []; const conflicts: CloudMemoryRecord[] = [];
    for (const raw of incoming) {
      const record = prepareMemoryForSync(raw);
      if (!record || record.accountId !== accountId) throw new Error('CREATOR_MEMORY_RECORD_INVALID');
      const existing = store.memories.find(m => m.memoryId === record.memoryId && m.accountId === accountId);
      if (!existing) { store.memories.push(record); accepted.push(record.memoryId); continue; }
      const state = compareMemoryRevision(record, existing);
      if (state === 'SYNCED') { accepted.push(record.memoryId); continue; }
      if (record.revision > existing.revision) { store.memories = store.memories.filter(m => m !== existing); store.memories.push(record); accepted.push(record.memoryId); continue; }
      conflicts.push(existing);
    }
    saveCreatorCloud(store);
    res.json({ success: true, status: conflicts.length ? 'CONFLICT' : 'SYNCED', accepted, conflicts, conflictAutoOverwrite: false });
  } catch (err: any) { res.status(400).json({ success: false, status: 'BLOCKED', error: err?.message || String(err) }); }
});


// Start Express and Vite server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SalesPulse Server running on http://localhost:${PORT}`);
  });
}

startServer();
