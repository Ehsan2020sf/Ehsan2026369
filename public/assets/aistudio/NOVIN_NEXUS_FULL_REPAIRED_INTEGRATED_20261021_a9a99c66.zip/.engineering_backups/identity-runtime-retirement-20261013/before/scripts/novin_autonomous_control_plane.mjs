#!/usr/bin/env node
/**
 * NOVIN Autonomous Control Plane
 * Observe -> Diagnose -> Repair-safe -> Integrate -> Verify -> Evidence -> Schedule next cycle
 * Destructive/external actions remain owner-gated. Environment blockers remain blockers.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const stateDir = path.join(root, '.novin');
const evidenceDir = path.join(root, 'docs', 'evidence', 'autonomous-control-plane');
fs.mkdirSync(stateDir, { recursive: true });
fs.mkdirSync(evidenceDir, { recursive: true });
const stateFile = path.join(stateDir, 'autonomous-control-plane.json');

const SAFE_CHECKS = [
  ['integrity', ['node', 'scripts/unified_integrity_audit.mjs']],
  ['architecture', ['node', '--experimental-strip-types', 'scripts/test_architecture_extensions.ts']],
  ['reality', ['node', 'scripts/test_reality_claims.mjs']],
  ['quantum', ['node', '--experimental-strip-types', 'src/core/quantum/quantumCapabilityEngine.test.ts']],
  ['atomic-storage', ['node', '--experimental-strip-types', 'src/core/storage/novinAtomicStorageSpace.test.ts']],
  ['security-fortress', ['node', '--experimental-strip-types', 'src/core/security/deviceSecurityFortress.test.ts']],
  ['security-dlp', ['node', '--experimental-strip-types', 'src/core/security/securityDataLossPrevention.test.ts']],
  ['startup-no-identity-gate', ['node', '--experimental-strip-types', 'scripts/test_bootstrap_optional_identity.mjs']],
  ['multimodal-command-no-identity-gate', ['node', '--experimental-strip-types', 'src/core/mobile/creatorMultimodalCommandBridge.test.ts']],
  ['real-world-ledger', ['node', '--experimental-strip-types', 'src/core/production/realWorldVerificationLedger.test.ts']],
  ['real-execution-readiness', ['node', '--experimental-strip-types', 'src/core/integration/realExecutionReadiness.test.ts']],
  ['self-diagnostic', ['node', '--experimental-strip-types', 'scripts/test_novin_self_diagnostic.ts']],
];

function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function run(label, args, timeout=120000) {
  const t=Date.now();
  const r=spawnSync(args[0], args.slice(1), {cwd:root, encoding:'utf8', shell:false, timeout, stdio:['ignore','pipe','pipe']});
  const output=`${r.stdout||''}\n${r.stderr||''}`.trim();
  const environmentBlocked=/Cannot find module|node_modules|vite: not found|TS2307|TS2688|Gradle|Android SDK|Java 17|toolchain/i.test(output);
  const status=r.status===0?'PASS':environmentBlocked?'BLOCKED_ENVIRONMENT':'FAIL';
  return {label, status, exitCode:r.status, durationMs:Date.now()-t, output:output.slice(-6000)};
}
function atomicWrite(file, value) {
  const tmp=`${file}.${process.pid}.tmp`;
  const bytes=JSON.stringify(value,null,2);
  fs.writeFileSync(tmp,bytes,'utf8');
  const fd=fs.openSync(tmp,'r'); fs.fsyncSync(fd); fs.closeSync(fd);
  fs.renameSync(tmp,file);
}
function loadState(){ try{return JSON.parse(fs.readFileSync(stateFile,'utf8'));}catch{return {};}}

const startedAt=new Date().toISOString();
const state=loadState();
const results=SAFE_CHECKS.map(([label,args])=>run(label,args));
const hardFailures=results.filter(r=>r.status==='FAIL');
const blockers=results.filter(r=>r.status==='BLOCKED_ENVIRONMENT');
const passes=results.filter(r=>r.status==='PASS');

// Safe automatic repairs are limited to generated state/report directories and never mutate business data,
// credentials, external systems, or production artifacts.
const repairs=[];
const staleTempFiles=[];
for (const base of [stateDir,evidenceDir]) {
  if (!fs.existsSync(base)) continue;
  for (const name of fs.readdirSync(base)) {
    if (/\.tmp$/.test(name)) staleTempFiles.push(path.join(base,name));
  }
}
for (const file of staleTempFiles) { try { fs.rmSync(file,{force:true}); repairs.push(`REMOVED_STALE_TEMP:${path.relative(root,file)}`); } catch {} }

const summary={
  pass:passes.length,
  blockedEnvironment:blockers.length,
  fail:hardFailures.length,
  safeRepairs:repairs.length,
  verdict: hardFailures.length ? 'FAIL' : blockers.length ? 'BLOCKED_ENVIRONMENT' : 'PASS',
  truthRule:'No environment blocker or simulated execution is promoted to proven reality.'
};
const evidence={
  evidenceId:`acp-${Date.now()}`,
  generatedAt:new Date().toISOString(),
  sourceStateDigest:sha256(JSON.stringify(results)),
  results:results.map(({output,...r})=>r),
  safeRepairs:repairs,
  summary,
};
const evidencePath=path.join(evidenceDir,`${evidence.evidenceId}.json`);
atomicWrite(evidencePath,evidence);
const nextState={
  schemaVersion:1,
  startedAt,
  endedAt:new Date().toISOString(),
  lastVerdict:summary.verdict,
  lastEvidenceId:evidence.evidenceId,
  lastEvidenceDigest:sha256(JSON.stringify(evidence)),
  pass:summary.pass,
  blockedEnvironment:summary.blockedEnvironment,
  fail:summary.fail,
  safeRepairs:summary.safeRepairs,
  nextCyclePolicy: hardFailures.length ? 'OWNER_REVIEW_REQUIRED' : blockers.length ? 'WAIT_FOR_ENVIRONMENT_CHANGE' : 'RUN_ON_SOURCE_OR_ENVIRONMENT_CHANGE',
};
atomicWrite(stateFile,nextState);
console.log(JSON.stringify({project:'NOVIN NEXUS',operation:'AUTONOMOUS_CONTROL_PLANE',summary,evidence:evidencePath,state:stateFile},null,2));
process.exitCode=hardFailures.length?2:blockers.length?3:0;
