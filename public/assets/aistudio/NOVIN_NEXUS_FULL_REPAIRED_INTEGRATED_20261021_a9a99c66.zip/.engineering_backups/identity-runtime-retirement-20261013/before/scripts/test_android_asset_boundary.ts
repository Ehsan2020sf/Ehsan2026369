import * as fs from 'fs';
import * as path from 'path';

const syncSource = fs.readFileSync(path.resolve('scripts/sync-android-assets.ts'), 'utf8');
const targetDir = path.resolve('android/app/src/main/assets/public');
const forbidden = ['server.cjs', 'server.cjs.map', 'server.js', 'server.js.map'];
const failures: string[] = [];
const runtimeModeSource = fs.readFileSync(path.resolve('src/platform/runtimeMode.ts'), 'utf8');
if (!runtimeModeSource.includes("'ANDROID_NATIVE'") || !runtimeModeSource.includes("'WEB'")) failures.push('runtime mode separation missing');
const androidBuildSource = fs.readFileSync(path.resolve('android/app/build.gradle'), 'utf8');
if (!androidBuildSource.includes('novinVerifyWebAssets') || !androidBuildSource.includes('NOVIN_ANDROID_WEB_ASSET_REALITY_GATE')) failures.push('Gradle Web asset reality gate missing');
const apiBoundarySource = fs.readFileSync(path.resolve('src/lib/androidApiBoundary.ts'), 'utf8');
if (!apiBoundarySource.includes('installAndroidApiBoundary') || !apiBoundarySource.includes('NOT_CONFIGURED')) failures.push('Android API boundary missing');
if (!syncSource.includes('isAndroidPublicAssetAllowed')) failures.push('asset allow/deny gate missing');
if (!syncSource.includes('ANDROID_ASSET_SECURITY_GATE')) failures.push('security gate marker missing');
const generatedIndexPresent = fs.existsSync(path.join(targetDir, 'index.html')) && fs.statSync(path.join(targetDir, 'index.html')).size > 0;
for (const name of forbidden) {
  if (fs.existsSync(path.join(targetDir, name))) failures.push(`forbidden asset present: ${name}`);
}

if (failures.length) {
  console.error('ANDROID_ASSET_SECURITY_BOUNDARY_FAIL');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

if (!generatedIndexPresent) {
  console.log('ANDROID_ASSET_SECURITY_BOUNDARY_PASS_SOURCE_CONTRACT');
  console.log('NOT_VERIFIED | generated Android WebView assets are absent in this source archive; the Gradle reality gate will block packaging until cap sync provides index.html.');
  process.exit(0);
}

console.log('ANDROID_ASSET_SECURITY_BOUNDARY_PASS_GENERATED_OUTPUT');
