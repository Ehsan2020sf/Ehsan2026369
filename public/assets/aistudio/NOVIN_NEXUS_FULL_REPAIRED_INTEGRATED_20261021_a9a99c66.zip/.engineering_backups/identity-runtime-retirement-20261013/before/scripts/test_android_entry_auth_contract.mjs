import fs from 'node:fs';
const app = fs.readFileSync('src/components/mobile/CreatorCommandCenter.tsx','utf8');
const runtime = fs.readFileSync('src/core/mobile/creatorIdentityRuntime.ts','utf8');
const native = fs.readFileSync('android/app/src/main/java/com/novin/salespulse/NovinNativeExecutionPlugin.java','utf8');
const account = fs.readFileSync('src/core/security/creatorAccountApi.ts','utf8');
const server = fs.readFileSync('server.ts','utf8');
const checks = [
 ['COMMAND_CENTER_USES_REAL_BIOMETRIC', app.includes('verifyCreatorWithAndroidBiometric')],
 ['COMMAND_CENTER_BLOCKS_NON_VERIFIED', app.includes("result.status === 'VERIFIED'") && app.includes("setStatus(`BLOCKED")],
 ['RUNTIME_USES_NATIVE_BIOMETRIC', runtime.includes('authenticateCreatorBiometric')],
 ['NATIVE_BIOMETRIC_PROMPT', native.includes('BiometricPrompt') && native.includes('prompt.authenticate')],
 ['KEYSTORE_BOUND_BIOMETRIC', native.includes('AndroidKeyStore') && native.includes('setUserAuthenticationRequired(true)')],
 ['REAL_REGISTER_API', account.includes("'/api/creator-account/register'")],
 ['REAL_LOGIN_API', account.includes("'/api/creator-account/login'")],
 ['SERVER_REGISTER_ROUTE', server.includes("app.post('/api/creator-account/register'")],
 ['SERVER_LOGIN_ROUTE', server.includes("app.post('/api/creator-account/login'")],
 ['ENCRYPTED_ACCOUNT_STORE', server.includes('encryptCreatorStore(accounts)') && server.includes('aes-256-gcm')],
 ['PASSWORD_SCRYPT', server.includes('crypto.scryptSync')],
];
const failed = checks.filter(([,ok])=>!ok);
if (failed.length) { console.error('ANDROID_ENTRY_AUTH_CONTRACT_FAIL', failed.map(([id])=>id).join(',')); process.exit(1); }
console.log(`ANDROID_ENTRY_AUTH_CONTRACT_PASS checks=${checks.length}`);
