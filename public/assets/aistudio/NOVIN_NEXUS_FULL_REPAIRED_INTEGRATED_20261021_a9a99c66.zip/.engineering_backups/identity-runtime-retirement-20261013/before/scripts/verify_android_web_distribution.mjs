import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const dist = path.join(root, 'dist');
const index = path.join(dist, 'index.html');
const failures = [];

if (!fs.existsSync(index) || fs.statSync(index).size === 0) {
  failures.push('dist/index.html missing or empty');
} else {
  const html = fs.readFileSync(index, 'utf8');
  if (!/<script[^>]+type=["']module["'][^>]+src=["'][^"']+["']/i.test(html)) failures.push('dist/index.html has no module entry');
  if (/src=["']\/?src\//i.test(html)) failures.push('unbuilt source entry leaked into dist/index.html');
  if (/https?:\/\/localhost(?::\d+)?/i.test(html)) failures.push('localhost runtime URL leaked into dist/index.html');
  const refs = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/gi)].map(m => m[1]).filter(r => !r.startsWith('http') && !r.startsWith('//') && !r.startsWith('#'));
  for (const ref of refs) {
    const normalized = ref.split('?')[0].split('#')[0];
    const candidate = path.resolve(dist, normalized.startsWith('/') ? `.${normalized}` : normalized);
    if (!fs.existsSync(candidate)) failures.push(`dist asset missing: ${ref}`);
  }
}

for (const forbidden of ['server.cjs', 'server.cjs.map', 'server.js', 'server.js.map']) {
  if (fs.existsSync(path.join(dist, forbidden))) failures.push(`server asset leaked into dist: ${forbidden}`);
}

if (failures.length) {
  console.error('ANDROID_WEB_DISTRIBUTION_REALITY_GATE: FAIL');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}
console.log('ANDROID_WEB_DISTRIBUTION_REALITY_GATE: PASS');
