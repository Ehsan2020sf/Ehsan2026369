import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const root = new URL('../', import.meta.url);
const read = (path) => readFileSync(new URL(path, root), 'utf8');
const app = read('src/App.tsx');
const settings = read('src/components/mobile/AndroidAssistantSettings.tsx');
const avatar = read('src/components/mobile/AndroidAvatarRuntime.tsx');
const bootstrap = read('src/core/mobile/novinLivingBootstrapBrain.ts');
const nativeContract = read('src/core/mobile/novinNativeExecution.ts');
const commandCenter = read('src/components/mobile/CreatorCommandCenter.tsx');
const enrollmentCenter = read('src/components/mobile/CreatorEnrollmentCenter.tsx');
const accountCenter = read('src/components/mobile/CreatorAccountCenter.tsx');
const nativePlugin = read('android/app/src/main/java/com/novin/salespulse/NovinNativeExecutionPlugin.java');
const commandPolicy = read('src/core/security/creatorCommandCenterPolicy.ts');

for (const [label, source] of [['Android app entry', app], ['Android settings', settings], ['Android startup', avatar], ['native TS bridge', nativeContract], ['native Java plugin', nativePlugin]]) {
  assert.equal(/authenticateCreatorBiometric|openCreatorBiometricEnrollment|getCreatorBiometricReadiness|verifyCreatorWithAndroidBiometric|Fingerprint/.test(source), false,
    `${label} must not contain live biometric authentication paths`);
}
assert.equal(/biometric\s*:/.test(bootstrap), false, 'bootstrap must not depend on biometric state');
assert.equal(/AndroidEntryBiometricGate|CreatorAccountCenter|CreatorCommandCenter|CreatorEnrollmentCenter/.test(app + settings), false, 'active app entry/settings must not mount legacy identity/account gates');
assert.equal(/REQUEST_BIOMETRIC_ENROLLMENT|REAUTH_OWNER|BIOMETRIC_BLOCKED/.test(bootstrap), false, 'bootstrap must not request identity enrollment or re-authentication');
assert.match(commandPolicy, /return true;/, 'command-center navigation must remain unlocked');
assert.equal(/freshBiometric|passwordReauthenticated|REAUTH_REQUIRED/.test(commandPolicy), false, 'navigation policy must not require re-authentication');
assert.equal(/Fingerprint|اثر انگشت\/بیومتریک/.test(accountCenter), false, 'account UI must not advertise biometric authentication');
console.log('STARTUP_NO_BIOMETRIC_GATE_PASS');
