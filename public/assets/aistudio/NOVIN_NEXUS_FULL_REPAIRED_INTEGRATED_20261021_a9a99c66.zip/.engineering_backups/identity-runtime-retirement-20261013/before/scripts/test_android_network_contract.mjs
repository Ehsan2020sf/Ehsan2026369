import fs from 'node:fs';
const api = fs.readFileSync('src/lib/apiClient.ts','utf8');
const account = fs.readFileSync('src/core/security/creatorAccountApi.ts','utf8');
const server = fs.readFileSync('server.ts','utf8');
const checks = [
  ['API_RUNTIME_BASE_OVERRIDE', api.includes('__NOVIN_API_BASE_URL__')],
  ['API_HTTPS_VALIDATION', api.includes("url.protocol === 'https:'") && api.includes('new URL(base)')],
  ['HEALTH_NO_CACHE', api.includes("cache: 'no-store'")],
  ['ACCOUNT_USES_RESOLVER', account.includes('getApiUrl(path)')],
  ['ACCOUNT_CREDENTIALS', account.includes("credentials: 'include'")],
  ['CORS_ORIGIN', server.includes('Access-Control-Allow-Origin')],
  ['CORS_CREDENTIALS', server.includes('Access-Control-Allow-Credentials')],
  ['CORS_OPTIONS', server.includes("req.method === 'OPTIONS'")],
  ['PROD_COOKIE_CROSS_ORIGIN', server.includes("'None' : 'Lax'")],
  ['NO_WILDCARD_CREDENTIALS', !server.includes("Access-Control-Allow-Origin', '*")],
];
const failed = checks.filter(([,ok])=>!ok);
if (failed.length) { console.error('ANDROID_NETWORK_CONTRACT_FAIL', failed.map(([id])=>id).join(',')); process.exit(1); }
console.log(`ANDROID_NETWORK_CONTRACT_PASS checks=${checks.length}`);
