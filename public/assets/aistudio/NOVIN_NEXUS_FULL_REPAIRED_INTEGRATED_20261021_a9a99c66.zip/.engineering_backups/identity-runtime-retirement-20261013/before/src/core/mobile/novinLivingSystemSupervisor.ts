/**
 * NOVIN Living System Supervisor, Android-first.
 *
 * Reconciles the live phone state with NOVIN's brain, workforce and repair
 * policy. It is intentionally stateful and idempotent: the same unresolved
 * condition produces one issue, not an endless stream of repeated repairs.
 */
import { agentRegistry } from '../agent/agentRegistry.ts';
import { decideLivingBootstrap, type LivingBootstrapObservation, type LivingBootstrapDecision } from './novinLivingBootstrapBrain.ts';

export interface LivingRuntimeObservation extends LivingBootstrapObservation {
  nativeVerified: boolean;
  ttsVerified?: boolean;
  memoryPressure?: 'LOW'|'MEDIUM'|'HIGH'|'CRITICAL'|'UNKNOWN';
  thermal?: 'NOMINAL'|'WARM'|'HOT'|'CRITICAL'|'UNKNOWN';
  gateway?: 'ONLINE'|'OFFLINE'|'UNKNOWN';
  provider?: 'READY'|'DEGRADED'|'UNKNOWN';
}

export interface LivingSystemIssue {
  fingerprint: string;
  title: string;
  severity: 'INFO'|'WARNING'|'BLOCKER';
  count: number;
  status: 'OPEN'|'RESOLVED'|'QUARANTINED';
  firstSeen: string;
  lastSeen: string;
}

export interface LivingSystemSnapshot {
  cycle: number;
  health: 'ALIVE'|'DEGRADED'|'BLOCKED';
  decision: LivingBootstrapDecision;
  readyAgents: number;
  totalAgents: number;
  workforceReady: boolean;
  gateway: LivingRuntimeObservation['gateway'];
  provider: LivingRuntimeObservation['provider'];
  issues: LivingSystemIssue[];
  nextActions: string[];
  generatedAt: string;
}

const hash = (value: string) => { let h = 2166136261; for (let i = 0; i < value.length; i += 1) h = Math.imul(h ^ value.charCodeAt(i), 16777619); return (h >>> 0).toString(16).padStart(8, '0'); };

export class NovinLivingSystemSupervisor {
  private cycle = 0;
  private issues = new Map<string, LivingSystemIssue>();
  private last?: LivingSystemSnapshot;

  reconcile(observation: LivingRuntimeObservation): LivingSystemSnapshot {
    this.cycle += 1;
    const now = new Date().toISOString();
    const decision = decideLivingBootstrap(observation);
    const signals = [...decision.reasons];
    if (observation.gateway === 'OFFLINE') signals.push('AI_GATEWAY_OFFLINE');
    if (observation.provider === 'DEGRADED') signals.push('AI_PROVIDER_DEGRADED');
    if (observation.memoryPressure === 'CRITICAL') signals.push('MEMORY_CRITICAL');
    if (observation.thermal === 'CRITICAL') signals.push('THERMAL_CRITICAL');
    const activeSignals = new Set(signals);

    for (const signal of activeSignals) {
      const fingerprint = hash(signal);
      const existing = this.issues.get(fingerprint);
      if (existing) {
        existing.count += 1;
        existing.lastSeen = now;
        // A previously RESOLVED incident is a live regression when the same
        // signal is observed again. Re-open it with the existing fingerprint.
        // QUARANTINED incidents remain closed until a distinct evidence path
        // creates a new fingerprint, preventing repair storms.
        if (existing.status === 'RESOLVED') existing.status = 'OPEN';
        if (existing.count > 3 && existing.status === 'OPEN') existing.status = 'QUARANTINED';
      } else {
        this.issues.set(fingerprint, {
          fingerprint,
          title: signal,
          severity: /SECURITY|GATEWAY_OFFLINE|THERMAL|MEMORY/.test(signal) ? 'BLOCKER' : 'WARNING',
          count: 1,
          status: 'OPEN',
          firstSeen: now,
          lastSeen: now,
        });
      }
    }

    // Keep the incident history, but reconcile the live state independently.
    // A resolved signal must stop degrading the current runtime while remaining
    // available for learning/audit. Quarantined incidents are intentionally not
    // auto-reopened without a new fingerprint/evidence path.
    for (const issue of this.issues.values()) {
      if (issue.status === 'OPEN' && !activeSignals.has(this.signalFromIssue(issue))) {
        issue.status = 'RESOLVED';
      }
    }

    const active = [...this.issues.values()].filter(i => i.status === 'OPEN');
    const readyAgents = agentRegistry.countReady();
    const totalAgents = agentRegistry.all().length;
    const workforceReady = totalAgents > 0 && readyAgents === totalAgents;
    const blockers = active.some(i => i.severity === 'BLOCKER');
    const warnings = active.some(i => i.severity === 'WARNING');
    const health = blockers || decision.health === 'BLOCKED' ? 'BLOCKED' : warnings || decision.health === 'DEGRADED' ? 'DEGRADED' : 'ALIVE';

    const nextActions = [...new Set([
      ...decision.reasons.map(reason => this.actionFor(reason)),
      ...(observation.gateway === 'OFFLINE' ? ['WAIT_FOR_NETWORK', 'REPROBE_GATEWAY'] : []),
      ...(observation.provider === 'DEGRADED' ? ['REPROBE_PROVIDER', 'USE_GOVERNED_FAILOVER'] : []),
      ...(!workforceReady ? ['RECONCILE_AGENT_WORKFORCE'] : []),
      ...(observation.memoryPressure === 'CRITICAL' ? ['REDUCE_RENDER_LOAD', 'RECHECK_MEMORY'] : []),
      ...(observation.thermal === 'CRITICAL' ? ['REDUCE_RENDER_LOAD', 'RECHECK_THERMAL'] : []),
    ])];

    const snapshot: LivingSystemSnapshot = {
      cycle: this.cycle,
      health,
      decision,
      readyAgents,
      totalAgents,
      workforceReady,
      gateway: observation.gateway,
      provider: observation.provider,
      issues: active,
      nextActions,
      generatedAt: now,
    };
    this.last = snapshot;
    return snapshot;
  }

  snapshot() { return this.last; }
  reset() { this.cycle = 0; this.issues.clear(); this.last = undefined; }
  clearResolvedIssue(signal: string) { this.issues.delete(hash(signal)); }

  private signalFromIssue(issue: LivingSystemIssue): string {
    return issue.title;
  }

  private actionFor(reason: string): string {
    if (reason.includes('TTS')) return 'REPAIR_TTS';
    if (reason.includes('MICROPHONE')) return 'REQUEST_MIC_PERMISSION';
    if (reason.includes('CAMERA')) return 'REQUEST_CAMERA_PERMISSION';
    if (reason.includes('NETWORK')) return 'WAIT_FOR_NETWORK';
    if (reason.includes('MEMORY')) return 'REDUCE_RENDER_LOAD';
    if (reason.includes('ANDROID_NATIVE')) return 'REPAIR_ANDROID_RUNTIME';
    return 'VERIFY_AND_REPLAN';
  }
}

export const novinLivingSystemSupervisor = new NovinLivingSystemSupervisor();
