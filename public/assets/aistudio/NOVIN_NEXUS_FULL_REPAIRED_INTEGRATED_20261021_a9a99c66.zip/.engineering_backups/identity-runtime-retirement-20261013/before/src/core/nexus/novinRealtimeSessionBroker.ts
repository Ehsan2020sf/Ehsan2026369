/**
 * NOVIN Realtime Session Broker.
 *
 * The standard OpenAI API key remains server-side. This broker issues only an
 * ephemeral Realtime client secret after a verified owner session has been
 * established by the caller. It deliberately refuses unauthenticated issue
 * requests and never stores or returns the standard API key.
 */
import { createHash, randomUUID } from 'node:crypto';
import { verifyOwnerIdentity, type OwnerIdentityProfile, type OwnerVerification } from '../security/ownerIdentityBoundary.ts';
import { resolveProviderCredential } from '../security/providerCredentialBoundary.ts';
import { NetworkEgressGovernor } from '../security/runtime/networkEgressGovernor.ts';
import { governedFetch } from '../security/runtime/governedFetch.ts';

export type RealtimeBrokerStatus = 'ISSUED'|'BLOCKED'|'NOT_VERIFIED'|'FAILED';

export interface RealtimeSessionIssueRequest {
  ownerId: string;
  ownerSessionVerified: boolean;
  ownerProfile?: OwnerIdentityProfile;
  ownerVerification?: OwnerVerification;
  model?: string;
  voice?: string;
}

export interface RealtimeSessionIssueResult {
  status: RealtimeBrokerStatus;
  provider: 'OPENAI_REALTIME'|'NONE';
  model: string;
  sessionId: string|null;
  clientSecret: string|null;
  expiresAt: string|null;
  safetyIdentifier: string|null;
  evidence: string[];
  messageFa: string;
}

function safetyIdentifier(ownerId: string): string {
  return createHash('sha256').update(`novin-owner:${ownerId}`).digest('hex');
}

export class NovinRealtimeSessionBroker {
  async issue(request: RealtimeSessionIssueRequest): Promise<RealtimeSessionIssueResult> {
    const model = request.model || 'gpt-realtime-2.1';
    const identityVerified = request.ownerSessionVerified && Boolean(request.ownerProfile && request.ownerVerification && verifyOwnerIdentity(request.ownerVerification, request.ownerProfile));
    if (!request.ownerId || !identityVerified) {
      return {
        status: 'BLOCKED', provider: 'NONE', model, sessionId: null,
        clientSecret: null, expiresAt: null, safetyIdentifier: null,
        evidence: ['OWNER_SESSION_REQUIRED'],
        messageFa: 'صدور Session زنده فقط پس از احراز هویت مالک مجاز است.',
      };
    }

    const credential = resolveProviderCredential('openai');
    const apiKey = credential.credential;
    if (!credential.configured || !apiKey) {
      return {
        status: 'NOT_VERIFIED', provider: 'NONE', model, sessionId: null,
        clientSecret: null, expiresAt: null, safetyIdentifier: safetyIdentifier(request.ownerId),
        evidence: ['OPENAI_API_KEY_NOT_CONFIGURED'],
        messageFa: 'کلید OpenAI روی Broker تنظیم نشده است؛ اتصال زنده قابل تأیید نیست.',
      };
    }

    const sessionConfig = {
      session: {
        type: 'realtime',
        model,
        ...(request.voice ? { audio: { output: { voice: request.voice } } } : {}),
      },
    };

    try {
      const endpoint = NetworkEgressGovernor.assert('https://api.openai.com/v1/realtime/client_secrets', 'openai');
      const response = await governedFetch(endpoint, 'openai', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'OpenAI-Safety-Identifier': safetyIdentifier(request.ownerId),
        },
        body: JSON.stringify(sessionConfig),
      });
      const data = await response.json().catch(() => ({} as any));
      if (!response.ok || typeof data?.value !== 'string') {
        return {
          status: 'FAILED', provider: 'OPENAI_REALTIME', model, sessionId: null,
          clientSecret: null, expiresAt: null, safetyIdentifier: safetyIdentifier(request.ownerId),
          evidence: [`OPENAI_CLIENT_SECRET_HTTP_${response.status}`],
          messageFa: `صدور Session زنده ناموفق بود (${response.status}).`,
        };
      }

      return {
        status: 'ISSUED', provider: 'OPENAI_REALTIME', model,
        sessionId: typeof data.id === 'string' ? data.id : randomUUID(),
        clientSecret: data.value,
        expiresAt: typeof data.expires_at === 'string' ? data.expires_at : null,
        safetyIdentifier: safetyIdentifier(request.ownerId),
        evidence: ['OPENAI_REALTIME_CLIENT_SECRET_ISSUED'],
        messageFa: 'Session زنده کوتاه‌عمر صادر شد.',
      };
    } catch (error) {
      return {
        status: 'FAILED', provider: 'OPENAI_REALTIME', model, sessionId: null,
        clientSecret: null, expiresAt: null, safetyIdentifier: safetyIdentifier(request.ownerId),
        evidence: ['OPENAI_CLIENT_SECRET_REQUEST_FAILED'],
        messageFa: `ارتباط با سرویس Realtime ناموفق بود: ${error instanceof Error ? error.message : 'UNKNOWN_ERROR'}`,
      };
    }
  }
}

export const novinRealtimeSessionBroker = new NovinRealtimeSessionBroker();
