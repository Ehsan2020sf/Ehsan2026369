import assert from 'node:assert/strict';
import { NovinRealtimeAndroidRuntime } from './novinRealtimeAndroidRuntime.ts';

const previousFetch = globalThis.fetch;
(globalThis as any).fetch = async () => new Response(JSON.stringify({ status: 'BLOCKED', evidence: ['OWNER_SESSION_REQUIRED'] }), { status: 403, headers: { 'Content-Type': 'application/json' } });
try {
  const runtime = new NovinRealtimeAndroidRuntime({
    endpoint: 'http://127.0.0.1:8787/api/voice/realtime/session',
    requestBody: { ownerId: 'TEST', ownerSessionVerified: false },
  });
  assert.equal(runtime.state, 'DISCONNECTED');
  const status = await runtime.connect();
  assert.equal(runtime.state, 'BLOCKED');
  assert.equal(status.reality, 'BLOCKED');
  console.log('NOVIN PHASE8 REALTIME ANDROID RUNTIME CONTRACT PASS');
} finally {
  globalThis.fetch = previousFetch;
}
