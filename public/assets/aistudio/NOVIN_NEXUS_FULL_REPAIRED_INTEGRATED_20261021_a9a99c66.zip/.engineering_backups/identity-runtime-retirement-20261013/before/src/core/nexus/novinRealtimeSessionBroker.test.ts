import { novinRealtimeSessionBroker } from './novinRealtimeSessionBroker.ts';
import type { OwnerIdentityProfile } from '../security/ownerIdentityBoundary.ts';

const blocked = await novinRealtimeSessionBroker.issue({ ownerId: '', ownerSessionVerified: false });
if (blocked.status !== 'BLOCKED' || blocked.evidence[0] !== 'OWNER_SESSION_REQUIRED') throw new Error('owner gate failed');

const profile: OwnerIdentityProfile = { ownerId: 'test-owner', enrolledFactors: ['DEVICE_BIOMETRIC'], consent: true, version: 1 };
const verification = { ownerId: 'test-owner', factor: 'DEVICE_BIOMETRIC' as const, verified: true, timestamp: new Date().toISOString() };
const missingKey = await novinRealtimeSessionBroker.issue({ ownerId: 'test-owner', ownerSessionVerified: true, ownerProfile: profile, ownerVerification: verification });
if (!process.env.OPENAI_API_KEY && missingKey.status !== 'NOT_VERIFIED') throw new Error('missing-key reality gate failed');
if (missingKey.clientSecret !== null) throw new Error('broker leaked credential');

console.log(`NOVIN_REALTIME_SESSION_BROKER_PASS unauth=${blocked.status} configured=${missingKey.status}`);
