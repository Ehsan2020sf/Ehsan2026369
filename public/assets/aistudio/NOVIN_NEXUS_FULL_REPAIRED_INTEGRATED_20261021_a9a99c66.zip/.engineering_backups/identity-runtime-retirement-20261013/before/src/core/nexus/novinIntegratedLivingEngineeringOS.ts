import { providerCredentialConfigured } from '../security/providerCredentialBoundary.ts';
import type { AndroidBuildRequest, AndroidBuildEvidence } from './novinAndroidBuildDeployAgent.ts';
/**
 * NOVIN Integrated Living Engineering OS
 * One coordination surface for voice, memory, avatar, vision, world, tools and engineering.
 * It composes existing subsystems and never upgrades UNKNOWN/UNVERIFIED into success.
 */
import { converseMultilingual, getConversation } from '../mobile/novinMultilingualConversationRuntime.ts';
import { memoryFabric } from '../memory/memoryFabric.ts';
import { memoryIntelligence } from '../memory/memoryIntelligence.ts';
import { novinAvatarNervousSystem } from '../nexusAutonomy/novinAvatarNervousSystem.ts';
import { novinAvatarOperatingSystem } from '../nexusAutonomy/novinAvatarOperatingSystem.ts';
import { buildLivingMissionPlan } from '../environment/novinLivingMissionPlanner.ts';
import { worldRegistry } from '../world/worldRegistry.ts';
import { toolRegistry } from '../tools/toolRegistry.ts';
import { novinSeniorEngineeringAvatarBrain } from '../environment/novinSeniorEngineeringAvatarBrain.ts';
import { novinEngineeringAgentRuntime } from './novinEngineeringAgentRuntime.ts';
import { novinLivingAvatarBehaviorEngine } from './novinLivingAvatarBehaviorEngine.ts';
import { novinHearingRuntime } from './novinHearingRuntime.ts';
import { novinVisionRealityAdapter } from './novinVisionRealityAdapter.ts';
import { novinCodeExecutionCoordinator } from './novinCodeExecutionCoordinator.ts';
import { novinAutomaticEnvironmentBuilder } from '../development/novinAutomaticEnvironmentBuilder.ts';
import { novinProjectVerificationCoordinator } from '../development/novinProjectVerificationCoordinator.ts';
import { novinProjectUnderstandingEngine } from '../development/novinProjectUnderstandingEngine.ts';
import { novinRealProjectGenerator } from '../development/novinRealProjectGenerator.ts';
import { novinProjectDeliveryPipeline } from '../development/novinProjectDeliveryPipeline.ts';
import { verifyAndroidArtifact, type AndroidRuntimeVerificationRequest, type AndroidRuntimeVerificationEvidence } from './novinAndroidRuntimeVerifier.ts';
import { novinAvatarAgentSession } from './novinAvatarAgentSession.ts';
import { novinRealtimeVoiceAgent } from '../mobile/novinRealtimeVoiceAgent.ts';
import { novinRealtimeSessionBroker, type RealtimeSessionIssueRequest } from './novinRealtimeSessionBroker.ts';
import { novinWorldInteractionEngine } from './novinWorldInteractionEngine.ts';
import { novinCapabilityRealityCenter } from './novinCapabilityRealityCenter.ts';

export type IntegratedStatus = 'PASS'|'FAIL'|'BLOCKED'|'NOT_VERIFIED'|'NOT_IMPLEMENTED';
export interface IntegratedCapability { id: string; group: string; status: IntegratedStatus; evidence: string[]; noteFa: string; }
export interface IntegratedCommandResult { status: IntegratedStatus; messageFa: string; route: 'CONVERSATION'|'AVATAR_MISSION'|'ENGINEERING'|'AUTONOMOUS'|'UNKNOWN'; reality: string; evidenceRefs: string[]; }

const engineeringPattern = /کد|برنامه|برنامه‌نویسی|پروژه|فایل|باگ|خطا|تست|build|build|dependency|پکیج|مهندسی|بساز|بسازش|توسعه|تعمیر|پیاده.?سازی/i;
const missionPattern = /برو|بردار|بگیر|بگذار|قرار بده|لمس|بررسی|نزدیک شو|pick up|place|inspect|walk/i;
const autonomousPattern = /خودت انجام بده|خودکار|اتوماسیون|چرخه کامل|یکپارچه|همه کار|repair|self.?engineering/i;
const environmentBuildPattern = /محیط|پروژه|workspace|world|شبیه.?سازی|simulation|سه.?بعدی|3d/;
const explicitBuildPattern = /بساز|ایجاد کن|ساخت.*شروع|create|generate/i;

export class NovinIntegratedLivingEngineeringOS {
  capabilities(): IntegratedCapability[] {
    const tools = toolRegistry.all();
    const vision = novinVisionRealityAdapter.status();
    const reality = novinCapabilityRealityCenter.snapshot();
    const statusFor = (id: string, fallback: IntegratedStatus = 'NOT_VERIFIED'): IntegratedStatus => {
      const item = reality.find(entry => entry.id === id);
      if (!item) return fallback;
      if (item.reality === 'AVAILABLE') return 'PASS';
      if (item.reality === 'BLOCKED') return 'BLOCKED';
      if (item.reality === 'SIMULATED') return 'NOT_VERIFIED';
      return 'NOT_VERIFIED';
    };
    return [
      { id: 'conversation.fa', group: 'HUMAN', status: statusFor('conversation.local'), evidence: ['converseMultilingual', 'fa-STT', 'fa-TTS'], noteFa: 'مکالمه فارسی با تشخیص زبان، STT و TTS بومی Android.' },
      { id: 'conversation.en', group: 'HUMAN', status: statusFor('conversation.local'), evidence: ['converseMultilingual', 'en-STT', 'en-TTS'], noteFa: 'مکالمه انگلیسی با همان مسیر شناختی و صدای انگلیسی.' },
      { id: 'hearing.runtime', group: 'HUMAN', status: statusFor('hearing.stt'), evidence: [], noteFa: 'لایه شنیدن به Adapter واقعی WebView نیاز دارد.' },
      { id: 'memory.fabric', group: 'MEMORY', status: statusFor('memory.local'), evidence: ['MemoryFabric', 'MemoryIntelligence'], noteFa: 'حافظه چندلایه و بازیابی شواهد موجود است.' },
      { id: 'avatar.nervous-system', group: 'AVATAR', status: 'PASS', evidence: ['NovinAvatarNervousSystem'], noteFa: 'سیستم عصبی دیجیتال موجود است.' },
      { id: 'avatar.behavior', group: 'AVATAR', status: 'PASS', evidence: ['NovinLivingAvatarBehaviorEngine'], noteFa: 'حالت، نگاه، پلک، تنفس و گفتار به‌صورت دیجیتال مدل می‌شوند.' },
      { id: 'vision', group: 'PERCEPTION', status: statusFor('vision.understanding'), evidence: ['OwnerCameraRuntime', 'VisionBridge'], noteFa: vision.noteFa },
      { id: 'world', group: 'WORLD', status: 'PASS', evidence: ['WorldRegistry', 'LivingMissionPlanner', 'NovinWorldInteractionEngine', 'RealityGate'], noteFa: 'محیط سه‌بعدی و چرخه تعامل دیجیتال با Reality Gate موجود است.' },
      { id: 'tools', group: 'ENGINEERING', status: statusFor('tools.governed'), evidence: [`toolCount=${tools.length}`], noteFa: 'Tool Registry موجود و Governance شده است.' },
      { id: 'android.engineering-workspace', group: 'ENGINEERING', status: 'NOT_VERIFIED', evidence: ['NovinAndroidEngineeringWorkspace'], noteFa: 'محیط مهندسی Native اندروید به Workspace داخلی Sandbox شده وصل است؛ اجرای واقعی روی APK هنوز باید Verify شود.' },
      { id: 'code-execution', group: 'EXECUTION', status: statusFor('code.execution'), evidence: ['NovinCodeExecutionCoordinator', 'SecureCodeExecutionEngine'], noteFa: 'سیاست اجرا و Approval واقعی است؛ تا اتصال Executor معتبر، اجرای کد NOT_VERIFIED باقی می‌ماند.' },
      { id: 'environment-builder', group: 'ENGINEERING', status: 'PASS', evidence: ['NovinAutomaticEnvironmentBuilder', 'file-hash-verification', 'workspace-boundary'], noteFa: 'سازنده محیط می‌تواند پس از Approval فایل‌ها و ساختار واقعی را داخل Workspace ایجاد کند؛ Build/Execution هنوز جداگانه Verify می‌شوند.' },
      { id: 'project-generator', group: 'ENGINEERING', status: 'PASS', evidence: ['NovinRealProjectGenerator', 'file-hash-verification', 'blueprint-contract'], noteFa: 'Blueprint آماده را پس از Approval به اسکلت واقعی پروژه تبدیل می‌کند؛ Build و Execution را موفق فرض نمی‌کند.' },
      { id: 'project-verification', group: 'ENGINEERING', status: 'PASS', evidence: ['NovinProjectVerificationCoordinator', 'DependencyEnvironmentAuditor', 'TestOrchestrator', 'RealBuildPipeline'], noteFa: 'ساخت، تحلیل Dependency، تست و Build در یک زنجیره شواهد‌محور هماهنگ شده‌اند؛ وضعیت نهایی فقط از اجرای واقعی می‌آید.' },
      { id: 'project-delivery-pipeline', group: 'ENGINEERING', status: 'PASS', evidence: ['NovinProjectDeliveryPipeline', 'Blueprint', 'DependencyRecovery', 'TestIntelligence'], noteFa: 'Blueprint، تولید، Dependency Reality، کشف تست و آمادگی Build در یک Pipeline واحد هماهنگ شده‌اند.' },
      { id: 'engineering-agent', group: 'ENGINEERING', status: 'PASS', evidence: ['NovinEngineeringAgentRuntime', 'UnifiedEngineeringController'], noteFa: 'عامل مهندسی از موتورهای موجود و کنترل‌شده استفاده می‌کند.' },
      { id: 'self-engineering', group: 'SELF_ENGINEERING', status: 'PASS', evidence: ['PatchExecutor', 'RepairLoop', 'Snapshot/Recovery'], noteFa: 'چرخه مهندسی خودکار با Approval و Rollback موجود است.' },
      { id: 'android-build-deploy', group: 'ENGINEERING', status: 'PASS', evidence: ['NovinAndroidBuildDeployAgent', 'GradleWrapper', 'ArtifactVerification'], noteFa: 'عامل Build اندروید با Gradle Wrapper و Artifact Evidence به‌صورت fail-closed متصل است.' },
      { id: 'android-runtime-verification', group: 'ENGINEERING', status: 'PASS', evidence: ['NovinAndroidRuntimeVerifier', 'APK-container-integrity', 'ADB-gate'], noteFa: 'Artifact APK از نظر فایل و Hash بررسی می‌شود و نصب فقط با ADB واقعی و Approval صریح Verify می‌شود.' },
      { id: 'governance', group: 'GOVERNANCE', status: 'PASS', evidence: ['ToolRegistry', 'IdentityAccessPlane', 'SecurityCommandPlane'], noteFa: 'اجرای ابزارها پشت کنترل دسترسی و امنیت قرار دارد.' },
      { id: 'reality', group: 'VERIFICATION', status: 'PASS', evidence: ['RealityGate', 'MemoryRealityAdmissionGovernor'], noteFa: 'وضعیت ناشناخته به‌صورت جعلی موفق اعلام نمی‌شود.' },
      { id: 'realtime-session-broker', group: 'VOICE_AGENT', status: providerCredentialConfigured('openai') ? 'NOT_VERIFIED' : 'NOT_VERIFIED', evidence: ['NovinRealtimeSessionBroker', 'OwnerIdentityBoundary', 'ephemeral-client-secret'], noteFa: 'Broker فقط پس از احراز مالک Session کوتاه‌عمر صادر می‌کند؛ کلید دائمی داخل Android قرار نمی‌گیرد.' },
    ];
  }

  async command(command: string, options: { projectRoot?: string; approvalGranted?: boolean } = {}): Promise<IntegratedCommandResult> {
    const clean = command.trim();
    if (!clean) return { status: 'BLOCKED', messageFa: 'فرمان خالی است.', route: 'UNKNOWN', reality: 'UNKNOWN', evidenceRefs: [] };

    if (/پروژه.*واقعی|اسکلت پروژه|generate.*project|project.*generate|از روی blueprint|بر اساس blueprint/i.test(clean) && explicitBuildPattern.test(clean)) {
      const root = options.projectRoot ?? process.cwd();
      const blueprint = novinProjectUnderstandingEngine.understand(clean);
      if (options.approvalGranted !== true) {
        const plan = novinRealProjectGenerator.plan(blueprint, root);
        return { status: 'BLOCKED', messageFa: `Blueprint ${blueprint.status} است و برای تولید فایل‌های واقعی Approval صریح لازم است. ${plan.files.length} فایل برنامه‌ریزی شده است.`, route: 'ENGINEERING', reality: 'OBSERVED', evidenceRefs: plan.evidenceRefs };
      }
      const generated = await novinRealProjectGenerator.generate(blueprint, root, true);
      return { status: generated.status === 'PASS' ? 'PASS' : generated.status === 'BLOCKED' ? 'BLOCKED' : generated.status === 'FAIL' ? 'FAIL' : 'NOT_VERIFIED', messageFa: generated.reasonFa, route: 'ENGINEERING', reality: generated.status === 'PASS' ? 'VERIFIED_REAL' : 'UNKNOWN', evidenceRefs: generated.evidenceRefs };
    }

    if (environmentBuildPattern.test(clean) && explicitBuildPattern.test(clean)) {
      const root = options.projectRoot ?? process.cwd();
      const plan = novinAutomaticEnvironmentBuilder.plan(clean, root);
      if (options.approvalGranted !== true) {
        return {
          status: 'BLOCKED',
          messageFa: `طرح ساخت آماده است اما برای ایجاد واقعی فایل‌ها Approval صریح لازم است. ${plan.files.length} فایل برنامه‌ریزی شده است.`,
          route: 'ENGINEERING',
          reality: 'OBSERVED',
          evidenceRefs: plan.evidenceRefs
        };
      }
      const built = await novinAutomaticEnvironmentBuilder.build(clean, root, true);
      return {
        status: built.status === 'PASS' ? 'PASS' : built.status === 'BLOCKED' ? 'BLOCKED' : built.status === 'FAIL' ? 'FAIL' : 'NOT_VERIFIED',
        messageFa: built.reason,
        route: 'ENGINEERING',
        reality: built.status === 'PASS' ? 'VERIFIED_REAL' : 'UNKNOWN',
        evidenceRefs: built.evidenceRefs
      };
    }

    if (/بررسی.*Build|Build.*بررسی|اعتبارسنجی پروژه|verify.*project|validate.*project/i.test(clean)) {
      const root = options.projectRoot ?? process.cwd();
      const report = novinProjectVerificationCoordinator.plan(root, clean);
      if (options.approvalGranted !== true) {
        return { status: 'BLOCKED', messageFa: report.reasonFa, route: 'ENGINEERING', reality: 'OBSERVED', evidenceRefs: report.evidenceRefs };
      }
      const executed = await novinProjectVerificationCoordinator.execute(report, true);
      return { status: executed.status === 'PASS' ? 'PASS' : executed.status === 'FAIL' ? 'FAIL' : executed.status === 'BLOCKED' ? 'BLOCKED' : 'NOT_VERIFIED', messageFa: executed.reasonFa, route: 'ENGINEERING', reality: executed.status === 'PASS' ? 'VERIFIED_REAL' : 'UNKNOWN', evidenceRefs: executed.evidenceRefs };
    }

    const worldInteractionMatch = clean.match(/(?:بردار|بگیر|pick up|grab|گرفتن|بگذار|قرار بده|place|put|نزدیک شو|برو سمت|approach|walk to)\s+(.+)/i);
    if (worldInteractionMatch && missionPattern.test(clean)) {
      const targetId = worldInteractionMatch[1].trim().replace(/[.؟?!]+$/, '');
      const action = /بردار|بگیر|pick up|grab|گرفتن/i.test(clean) ? 'GRAB' : /بگذار|قرار بده|place|put/i.test(clean) ? 'PLACE' : 'APPROACH';
      const state = novinWorldInteractionEngine.command({ action, targetId, source: 'USER', reality: 'RECONSTRUCTED_SIMULATION' });
      novinAvatarNervousSystem.sense('TEXT', clean, 'IntegratedLivingEngineeringOS');
      novinLivingAvatarBehaviorEngine.setState('WORKING', action === 'APPROACH' ? 'WALK' : action === 'GRAB' ? 'REACH' : 'PLACE');
      return { status: state.phase === 'BLOCKED' ? 'BLOCKED' : 'PASS', messageFa: state.phase === 'BLOCKED' ? `تعامل با «${targetId}» متوقف شد: ${state.lastEvent}.` : `تعامل دیجیتال با «${targetId}» در مرحله ${state.phase} ثبت شد.`, route: 'AVATAR_MISSION', reality: 'RECONSTRUCTED_SIMULATION', evidenceRefs: ['NovinWorldInteractionEngine', 'RealityGate'] };
    }

    if (engineeringPattern.test(clean)) {
      if (autonomousPattern.test(clean) && options.approvalGranted !== true) {
        return { status: 'BLOCKED', messageFa: 'برای اجرای مهندسی خودکار، Approval صریح مالک لازم است.', route: 'ENGINEERING', reality: 'OBSERVED', evidenceRefs: ['OWNER_APPROVAL_REQUIRED_FOR_AUTONOMOUS_ENGINEERING'] };
      }
      const assessment = novinEngineeringAgentRuntime.assess(clean, options.projectRoot ?? process.cwd());
      memoryFabric.remember({ kind: 'OBSERVATION', layer: 'WORKING', key: 'last.engineering.assessment', content: `فرمان مهندسی تحلیل شد: ${clean}`, reality: 'OBSERVED', confidence: 0.9, evidenceRefs: ['NovinEngineeringAgentRuntime'], tags: ['engineering'] });
      if (autonomousPattern.test(clean)) {
        const execution = await novinEngineeringAgentRuntime.requestExecution(assessment.unifiedPlan, options.approvalGranted === true);
        return { status: execution.status === 'PASS' ? 'PASS' : execution.status === 'BLOCKED' ? 'BLOCKED' : 'NOT_VERIFIED', messageFa: execution.reason, route: 'ENGINEERING', reality: execution.status === 'PASS' ? 'VERIFIED_REAL' : 'UNKNOWN', evidenceRefs: execution.evidenceRefs };
      }
      return { status: 'PASS', messageFa: `فرمان مهندسی تحلیل شد. وضعیت پیش‌بررسی: ${assessment.unifiedPlan.status}. قبل از هر تغییر واقعی باید Approval صریح داده شود.`, route: 'ENGINEERING', reality: 'OBSERVED', evidenceRefs: assessment.unifiedPlan.evidenceRefs };
    }

    const world = worldRegistry.getActiveWorld();
    if (missionPattern.test(clean)) {
      const mission = buildLivingMissionPlan(clean, world.objects ?? []);
      if (mission) {
        memoryFabric.remember({ kind: 'GOAL', layer: 'WORKING', key: `mission.${mission.missionId}`, content: clean, reality: 'SIMULATED', confidence: 0.7, evidenceRefs: [], tags: ['living-mission'] });
        novinAvatarNervousSystem.sense('TEXT', clean, 'IntegratedLivingEngineeringOS');
        novinLivingAvatarBehaviorEngine.setState('WORKING', 'WALK');
        return { status: 'PASS', messageFa: mission.noteFa, route: 'AVATAR_MISSION', reality: 'SIMULATED', evidenceRefs: [] };
      }
    }

    const conversation = await converseMultilingual(clean);
    memoryFabric.remember({ kind: 'OBSERVATION', layer: 'SHORT_TERM', key: 'conversation.latest.user', content: clean, reality: 'OBSERVED', confidence: 0.95, evidenceRefs: ['speech-or-text-input'], tags: ['conversation', conversation.language] });
    memoryFabric.remember({ kind: 'FACT', layer: 'SHORT_TERM', key: 'conversation.latest.novin', content: conversation.reply, reality: conversation.reality === 'OBSERVED' ? 'OBSERVED' : 'INFERRED', confidence: conversation.confidence, evidenceRefs: ['converseMultilingual'], tags: ['conversation', conversation.language] });
    novinAvatarNervousSystem.sense('TEXT', clean, 'IntegratedLivingEngineeringOS');
    novinLivingAvatarBehaviorEngine.setState('SPEAKING', 'SPEAK');
    return { status: conversation.status === 'BLOCKED' ? 'BLOCKED' : 'PASS', messageFa: conversation.reply, route: 'CONVERSATION', reality: conversation.reality, evidenceRefs: ['converseMultilingual', `language=${conversation.language}`] };
  }

  capabilityReality() { return novinCapabilityRealityCenter.snapshot(); }
  capabilityGaps() { return novinCapabilityRealityCenter.gaps(); }

  memoryRecall(query: string) { return memoryIntelligence.recall(query); }
  conversation() { return getPersianConversation(); }
  avatarAgentSession() { return novinAvatarAgentSession.snapshot(); }
  async avatarAgentSend(text: string, approvalGranted = false, projectRoot?: string) { return novinAvatarAgentSession.send(text, { approvalGranted, projectRoot }); }
  avatarAgentInterrupt(reason?: string) { novinAvatarAgentSession.interrupt(reason); return novinAvatarAgentSession.snapshot(); }
  realtimeVoiceStatus() { return novinRealtimeVoiceAgent.status(); }
  async realtimeVoiceConnect(sessionCredential?: string) { return novinRealtimeVoiceAgent.connect(sessionCredential); }
  async realtimeVoiceInterrupt() { return novinRealtimeVoiceAgent.interrupt(); }
  async issueRealtimeSession(request: RealtimeSessionIssueRequest) { return novinRealtimeSessionBroker.issue(request); }
  avatarFrame() { return novinLivingAvatarBehaviorEngine.snapshot(); }
  visionStatus() { return novinVisionRealityAdapter.status(); }
  hearingStatus() { return novinHearingRuntime.snapshot(); }
  async androidEngineeringWorkspaceStatus() {
    try {
      const mod = await import('../mobile/novinAndroidEngineeringWorkspace.ts');
      return await mod.inspectAndroidEngineeringWorkspace();
    } catch (error) {
      return { status: 'NOT_AVAILABLE' as const, runtime: 'NON_ANDROID_NATIVE', processExecution: false, error: error instanceof Error ? error.message : 'ANDROID_WORKSPACE_ADAPTER_UNAVAILABLE' };
    }
  }
  projectUnderstanding(request: string) { return novinProjectUnderstandingEngine.understand(request); }
  projectGenerationPlan(request: string, projectRoot = process.cwd()) { return novinRealProjectGenerator.plan(request, projectRoot); }
  projectDeliveryPlan(request: string, projectRoot = process.cwd()) { return novinProjectDeliveryPipeline.plan(request, projectRoot); }
  async generateProject(request: string, projectRoot = process.cwd(), approvalGranted = false) { return novinRealProjectGenerator.generate(request, projectRoot, approvalGranted); }
  engineeringAssessment(command: string, projectRoot = process.cwd()) { return novinSeniorEngineeringAvatarBrain.assess(command); }
  codeExecutionStatus() { return novinCodeExecutionCoordinator.executorStatus(); }
  codeExecutionPreflight(request: Parameters<typeof novinCodeExecutionCoordinator.preflight>[0]) { return novinCodeExecutionCoordinator.preflight(request); }
  async executeCode(request: Parameters<typeof novinCodeExecutionCoordinator.execute>[0], approvalGranted = false) { return novinCodeExecutionCoordinator.execute(request, approvalGranted); }

  async inspectAndroidBuild(projectRoot: string) {
    const { inspectAndroidBuildEnvironment } = await import('./novinAndroidBuildDeployAgent.ts');
    return inspectAndroidBuildEnvironment(projectRoot);
  }

  async buildAndroid(request: AndroidBuildRequest): Promise<AndroidBuildEvidence> {
    const { buildAndroid } = await import('./novinAndroidBuildDeployAgent.ts');
    return buildAndroid(request);
  }

  async verifyAndroidRuntime(request: AndroidRuntimeVerificationRequest): Promise<AndroidRuntimeVerificationEvidence> {
    return verifyAndroidArtifact(request);
  }

}

export const novinIntegratedLivingEngineeringOS = new NovinIntegratedLivingEngineeringOS();
