import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const srcRoot = path.join(root, 'src');
const gateway = fs.readFileSync(path.join(srcRoot, 'core/ai/aiGateway.ts'), 'utf8');
const broker = fs.readFileSync(path.join(srcRoot, 'core/nexus/novinRealtimeSessionBroker.ts'), 'utf8');
const android = fs.readFileSync(path.join(srcRoot, 'components/mobile/AndroidAvatarRuntime.tsx'), 'utf8');
const realtimeAdapter = fs.readFileSync(path.join(srcRoot, 'core/mobile/novinOpenAIRealtimeWebRtcAdapter.ts'), 'utf8');

if (!gateway.includes('governedFetch')) throw new Error('AIGATEWAY_PROVIDER_EGRESS_MISSING');
if (!broker.includes('NovinRealtimeSessionBroker')) throw new Error('REALTIME_BROKER_MISSING');
if (!broker.includes('verifyOwnerIdentity')) throw new Error('REALTIME_OWNER_GATE_MISSING');
if (!broker.includes('client_secrets')) throw new Error('REALTIME_EPHEMERAL_ENDPOINT_MISSING');
if (!broker.includes('clientSecret: null')) throw new Error('REALTIME_SECRET_FAIL_CLOSED_MISSING');
if (broker.includes('return apiKey') || broker.includes('clientSecret: apiKey')) throw new Error('PERMANENT_PROVIDER_CREDENTIAL_LEAK');
if (android.includes('converseInPersian(')) throw new Error('ANDROID_DIRECT_CONVERSATION_PROVIDER_BYPASS');
if (!realtimeAdapter.includes('EPHEMERAL_REALTIME_CREDENTIAL_REQUIRED')) throw new Error('REALTIME_EPHEMERAL_CREDENTIAL_GATE_MISSING');
if (realtimeAdapter.includes('process.env.OPENAI_API_KEY') || /Authorization:\s*\x60Bearer \x24\{apiKey\}/.test(realtimeAdapter)) throw new Error('REALTIME_PERMANENT_KEY_PATH');

const approvedProviderDirect = new Set([
  path.join(srcRoot, 'core/ai/aiGateway.ts'),
  path.join(srcRoot, 'core/nexus/novinRealtimeSessionBroker.ts'),
  path.join(srcRoot, 'core/mobile/novinOpenAIRealtimeWebRtcAdapter.ts'),
  path.join(srcRoot, 'core/security/runtime/networkEgressGovernor.ts'),
  path.join(srcRoot, 'core/security/runtime/networkEgressGovernor.test.ts'),
  path.join(srcRoot, 'core/security/runtime/serverEgressBoundary.test.ts'),
]);
const directProviderFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'generated' || entry.name === 'node_modules' || entry.name.startsWith('.')) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (/\.(ts|tsx|js|mjs)$/.test(entry.name)) {
      const text = fs.readFileSync(full, 'utf8');
      if (!approvedProviderDirect.has(full) && /api\.openai\.com|generativelanguage\.googleapis\.com|api\.anthropic\.com|api\.x\.ai/.test(text)) directProviderFiles.push(path.relative(root, full));
    }
  }
}
walk(srcRoot);
if (directProviderFiles.length) throw new Error(`UNAPPROVED_PROVIDER_DIRECT_FILES:${directProviderFiles.join(',')}`);
console.log('NOVIN_PROVIDER_EGRESS_BOUNDARY_PASS completion=AIGateway realtime=approved-broker');
