import React, { lazy, Suspense } from 'react';
const SovereignCommandCenter = lazy(() => import('./components/SovereignCommandCenter.tsx').then((m) => ({ default: m.SovereignCommandCenter })));
import { AndroidAvatarRuntime } from './components/mobile/AndroidAvatarRuntime.tsx';
import { isAndroidNativeRuntime } from './platform/runtimeMode.ts';

export default function App() {
  return isAndroidNativeRuntime() ? <AndroidAvatarRuntime /> : <Suspense fallback={null}><SovereignCommandCenter /></Suspense>;
}
