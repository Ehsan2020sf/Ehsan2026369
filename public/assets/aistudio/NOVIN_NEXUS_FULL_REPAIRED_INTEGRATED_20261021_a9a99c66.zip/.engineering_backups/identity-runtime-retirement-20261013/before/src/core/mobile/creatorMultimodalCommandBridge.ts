/**
 * Multimodal command boundary without creator authentication.
 * Recognition/identity enrollment is intentionally not part of NOVIN runtime.
 * External side effects still require explicit approval.
 */
export interface MultimodalCommandInput {
  text: string;
  confidence: number;
  consent: boolean;
  staleSignal?: boolean;
  externalAction?: boolean;
  explicitApproval?: boolean;
}

export type MultimodalCommandDecision = 'ALLOW_TEXT' | 'REQUIRE_EXPLICIT_APPROVAL' | 'BLOCK';
export interface MultimodalCommandResult {
  decision: MultimodalCommandDecision;
  parsedText: string | null;
  externalActionAuthorized: false;
  reasons: string[];
}

export function routeMultimodalCommand(input: MultimodalCommandInput): MultimodalCommandResult {
  const text = input.text.trim();
  if (!text) return { decision: 'BLOCK', parsedText: null, externalActionAuthorized: false, reasons: ['EMPTY_COMMAND'] };
  if (!Number.isFinite(input.confidence) || input.confidence < 0 || input.confidence > 1) {
    return { decision: 'BLOCK', parsedText: null, externalActionAuthorized: false, reasons: ['INVALID_CONFIDENCE'] };
  }
  if (!input.consent) return { decision: 'BLOCK', parsedText: null, externalActionAuthorized: false, reasons: ['USER_CONSENT_REQUIRED'] };
  if (input.staleSignal) return { decision: 'BLOCK', parsedText: null, externalActionAuthorized: false, reasons: ['STALE_INPUT_SIGNAL'] };
  if (input.externalAction && !input.explicitApproval) {
    return { decision: 'REQUIRE_EXPLICIT_APPROVAL', parsedText: null, externalActionAuthorized: false, reasons: ['EXPLICIT_APPROVAL_REQUIRED_FOR_EXTERNAL_ACTION'] };
  }
  return { decision: 'ALLOW_TEXT', parsedText: text, externalActionAuthorized: false, reasons: ['TEXT_MAY_ENTER_REASONING_PIPELINE', 'EXECUTION_REMAINS_GOVERNED'] };
}
