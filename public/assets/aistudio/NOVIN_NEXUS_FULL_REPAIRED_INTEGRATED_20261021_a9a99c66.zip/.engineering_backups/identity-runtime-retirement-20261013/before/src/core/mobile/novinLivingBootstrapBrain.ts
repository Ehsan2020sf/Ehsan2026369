/**
 * NOVIN Living Bootstrap Brain, Android-first.
 *
 * The brain continuously answers: what is healthy, what is missing, what can be
 * repaired automatically, and what is blocked by Android/user/security boundaries.
 * It may self-heal reversible application/runtime faults, but it can never forge
 * identity enrollment is deliberately outside the runtime startup path.
 */
import { brainDiagnosticEngine, type BrainDiagnosticResult } from '../ai/brainDiagnosticEngine.ts';

export type BootstrapHealth = 'HEALTHY' | 'DEGRADED' | 'BLOCKED' | 'UNKNOWN';
export type BootstrapAction = 'NONE' | 'REPAIR_RUNTIME' | 'REQUEST_PERMISSION' | 'WAIT_FOR_NETWORK';

export interface LivingBootstrapObservation {
  native: 'AVAILABLE' | 'DEGRADED' | 'UNKNOWN';
  network: 'ONLINE' | 'OFFLINE' | 'UNKNOWN';
  microphone: 'GRANTED' | 'DENIED' | 'UNKNOWN';
  camera: 'GRANTED' | 'DENIED' | 'UNKNOWN';
  tts: 'READY' | 'DEGRADED' | 'UNKNOWN';
  memory: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'UNKNOWN';
}

export interface LivingBootstrapDecision {
  health: BootstrapHealth;
  action: BootstrapAction;
  reasons: string[];
  autoRepairAllowed: boolean;
  ownerBoundary: 'READY' | 'REQUIRES_ANDROID';
  brainDiagnostic: BrainDiagnosticResult;
}

export function decideLivingBootstrap(o: LivingBootstrapObservation): LivingBootstrapDecision {
  const reasons: string[] = [];
  const brainDiagnostic = brainDiagnosticEngine.inspect({
    confidence: o.native === 'AVAILABLE' ? 0.9 : 0.3,
    evidenceCoverage: o.native === 'AVAILABLE' ? 0.85 : 0.25,
    contextQuality: 0.85,
    knownFacts: Object.values(o).filter((v) => v !== 'UNKNOWN').length,
    unknowns: Object.values(o).filter((v) => v === 'UNKNOWN').length,
    conflicts: 0,
    reversible: true,
    autonomyBlocked: false,
    memoryAvailable: o.memory !== 'CRITICAL',
    observabilityAvailable: true,
    securityGateAvailable: true,
  });
  if (brainDiagnostic.verdict === 'BLOCKED') reasons.push('BRAIN_DIAGNOSTIC_BLOCKED');
  else if (brainDiagnostic.verdict === 'REVIEW') reasons.push('BRAIN_DIAGNOSTIC_REVIEW');
  if (o.native !== 'AVAILABLE') reasons.push('ANDROID_NATIVE_NOT_READY');
  if (o.network === 'OFFLINE') reasons.push('NETWORK_OFFLINE');
  if (o.microphone !== 'GRANTED') reasons.push('MICROPHONE_PERMISSION_MISSING');
  if (o.camera !== 'GRANTED') reasons.push('CAMERA_PERMISSION_MISSING');
  if (o.tts !== 'READY') reasons.push('TTS_NOT_READY');
  if (o.memory === 'CRITICAL') reasons.push('CRITICAL_MEMORY_PRESSURE');

  if (o.native !== 'AVAILABLE') return { health: 'DEGRADED', action: 'REPAIR_RUNTIME', reasons, autoRepairAllowed: true, ownerBoundary: 'REQUIRES_ANDROID', brainDiagnostic };
  if (o.memory === 'CRITICAL' || o.tts !== 'READY') return { health: 'DEGRADED', action: 'REPAIR_RUNTIME', reasons, autoRepairAllowed: true, ownerBoundary: 'READY', brainDiagnostic };
  if (o.network === 'OFFLINE') return { health: 'DEGRADED', action: 'WAIT_FOR_NETWORK', reasons, autoRepairAllowed: true, ownerBoundary: 'READY', brainDiagnostic };
  if (o.microphone !== 'GRANTED' || o.camera !== 'GRANTED') return { health: 'DEGRADED', action: 'REQUEST_PERMISSION', reasons, autoRepairAllowed: true, ownerBoundary: 'READY', brainDiagnostic };
  return { health: 'HEALTHY', action: 'NONE', reasons, autoRepairAllowed: true, ownerBoundary: 'READY', brainDiagnostic };
}
