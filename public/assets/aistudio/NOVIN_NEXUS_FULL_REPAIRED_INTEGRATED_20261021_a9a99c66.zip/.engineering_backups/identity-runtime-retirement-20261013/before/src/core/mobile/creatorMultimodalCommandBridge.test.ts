import assert from 'node:assert/strict';
import { routeMultimodalCommand } from './creatorMultimodalCommandBridge.ts';

const normal = routeMultimodalCommand({ text: 'دستور آزمایشی', confidence: 0.95, consent: true });
assert.equal(normal.decision, 'ALLOW_TEXT', 'ordinary text must not require creator authentication');
assert.equal(normal.parsedText, 'دستور آزمایشی');

const noConsent = routeMultimodalCommand({ text: 'دستور آزمایشی', confidence: 0.99, consent: false });
assert.equal(noConsent.decision, 'BLOCK', 'consent is separate from identity verification');

const external = routeMultimodalCommand({ text: 'ارسال پیام', confidence: 0.99, consent: true, externalAction: true });
assert.equal(external.decision, 'REQUIRE_EXPLICIT_APPROVAL');
const approvedExternal = routeMultimodalCommand({ text: 'ارسال پیام', confidence: 0.99, consent: true, externalAction: true, explicitApproval: true });
assert.equal(approvedExternal.decision, 'ALLOW_TEXT');
assert.equal(approvedExternal.externalActionAuthorized, false, 'text routing never authorizes external execution by itself');
console.log('MULTIMODAL_COMMAND_NO_IDENTITY_GATE_PASS');
