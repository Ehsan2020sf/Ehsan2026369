import React, { useEffect, useState } from 'react';
import { Accessibility, AppWindow, Camera, Contact, Globe, LockKeyhole, Mic, Music, ShieldCheck, Sparkles, Bell, Battery, Activity } from 'lucide-react';
import { AndroidAssistantControl, type AndroidAssistantCapabilities } from '../../core/mobile/androidAssistantControl.ts';
import { getBackendBaseUrl, isBackendConfigured, setBackendBaseUrl, checkBackendHealth } from '../../lib/apiClient.ts';

export const AndroidAssistantSettings: React.FC = () => {
  const [caps, setCaps] = useState<AndroidAssistantCapabilities | null>(null);
  const [message, setMessage] = useState('در حال خواندن وضعیت واقعی Android...');
  const [overlayState, setOverlayState] = useState<'OFF'|'ON'|'BLOCKED'>('OFF');
  const [backendUrl, setBackendUrl] = useState('');
  const [backendStatus, setBackendStatus] = useState('BACKEND_NOT_CONFIGURED');
  const refresh = async () => {
    try { const value = await AndroidAssistantControl.getAssistantCapabilities(); setCaps(value); setMessage('وضعیت از Android خوانده شد.'); }
    catch { setMessage('وضعیت قابلیت‌ها در این محیط قابل خواندن نیست.'); }
  };
  useEffect(() => { void refresh(); setBackendUrl(getBackendBaseUrl()); }, []);
  const saveBackend = async () => {
    const result = setBackendBaseUrl(backendUrl);
    if (!result.ok) { setBackendStatus(result.error || 'BACKEND_URL_INVALID'); return; }
    const healthy = await checkBackendHealth(5000);
    setBackendStatus(healthy ? 'BACKEND_HEALTHY' : (isBackendConfigured() ? 'BACKEND_UNREACHABLE' : 'BACKEND_NOT_CONFIGURED'));
  };
  const open = async (action: 'accessibility'|'overlay'|'contacts'|'media'|'app'|'notifications'|'battery'|'usage') => {
    if (action === 'accessibility') await AndroidAssistantControl.openAccessibilitySettings();
    if (action === 'overlay') await AndroidAssistantControl.openOverlaySettings();
    if (action === 'contacts') await AndroidAssistantControl.requestContactsPermission();
    if (action === 'media') await AndroidAssistantControl.requestMediaPermissions();
    if (action === 'app') await AndroidAssistantControl.openAppDetailsSettings();
    if (action === 'notifications') await AndroidAssistantControl.openNotificationSettings();
    if (action === 'battery') { const r = await AndroidAssistantControl.requestBatteryOptimizationExemption(); setMessage(r.evidence ?? 'وضعیت باتری از Android دریافت شد.'); if (r.status === 'BLOCKED') await AndroidAssistantControl.openBatteryOptimizationSettings(); }
    if (action === 'usage') await AndroidAssistantControl.openUsageAccessSettings();
    window.setTimeout(() => void refresh(), 700);
  };
  const toggleOverlay = async () => { if (!caps?.overlay) { await open('overlay'); return; } const r = overlayState === 'ON' ? await AndroidAssistantControl.stopAvatarOverlay() : await AndroidAssistantControl.startAvatarOverlay(); setOverlayState(r.status === 'PASS' ? (overlayState === 'ON' ? 'OFF' : 'ON') : 'BLOCKED'); setMessage(r.evidence); };
  const Row = ({icon: Icon, title, detail, enabled, action, button}: any) => (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 flex items-center gap-3">
      <div className="rounded-xl bg-slate-800 p-2"><Icon className="w-5 h-5" /></div>
      <div className="min-w-0 flex-1"><div className="font-bold">{title}</div><div className="text-xs text-slate-500 mt-1">{detail}</div></div>
      <div className={`text-xs font-black ${enabled ? 'text-emerald-400' : 'text-amber-400'}`}>{enabled ? 'فعال' : 'نیازمند مجوز'}</div>
      {!enabled && action ? <button onClick={() => void open(action)} className="rounded-xl bg-indigo-600 px-3 py-2 text-xs font-bold">{button}</button> : null}
    </div>
  );
  return <section dir="rtl" className="h-full overflow-auto p-4 max-w-3xl w-full mx-auto space-y-4">
    <div className="rounded-3xl border border-indigo-500/20 bg-gradient-to-br from-slate-900 to-slate-950 p-5">
      <div className="flex items-center gap-3"><Sparkles className="w-6 h-6 text-indigo-400" /><div><div className="text-xl font-black">تنظیمات حرفه‌ای دستیار نوین</div><div className="text-xs text-slate-500 mt-1">اتصال هوش مصنوعی، آواتار، مجوزها و اجرای Android</div></div></div>
      <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-xl bg-slate-800/70 p-3"><b>فرمان صوتی</b><br/><span className="text-slate-500">گفتگو و اجرای فرمان</span></div>
        <div className="rounded-xl bg-slate-800/70 p-3"><b>تشخیص هدف</b><br/><span className="text-slate-500">برنامه، تماس، پیام، وب، رسانه</span></div>
        <div className="rounded-xl bg-slate-800/70 p-3"><b>تأیید حساس</b><br/><span className="text-slate-500">تماس/پیام و اقدامات پرریسک</span></div>
        <div className="rounded-xl bg-slate-800/70 p-3"><b>Reality Gate</b><br/><span className="text-slate-500">ادعا فقط بر اساس وضعیت واقعی Android</span></div>
      </div>
    </div>
    <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/5 p-4 space-y-3">
      <div className="flex items-center gap-2 font-black"><Globe className="w-5 h-5 text-cyan-400" /> اتصال اینترنت و Backend واقعی NOVIN</div>
      <div className="text-xs text-slate-500 leading-6">Android به‌صورت خودکار به localhost متصل نمی‌شود. آدرس HTTPS سرور واقعی NOVIN را یک‌بار وارد کن؛ در صورت پیکربندی، درخواست‌های هوش مصنوعی و API از همین مسیر استفاده می‌کنند.</div>
      <input value={backendUrl} onChange={e=>setBackendUrl(e.target.value)} placeholder="https://your-novin-backend.example" inputMode="url" className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-3 text-sm" dir="ltr" />
      <div className="flex gap-2"><button onClick={() => void saveBackend()} className="flex-1 rounded-xl bg-cyan-600 px-4 py-3 text-sm font-black">ذخیره و تست اتصال</button><button onClick={() => { setBackendUrl(''); setBackendBaseUrl(''); setBackendStatus('BACKEND_NOT_CONFIGURED'); }} className="rounded-xl bg-slate-800 px-4 py-3 text-xs font-bold">پاک‌کردن آدرس</button></div>
      <div className={`text-xs font-black ${backendStatus === 'BACKEND_HEALTHY' ? 'text-emerald-400' : 'text-amber-400'}`}>{backendStatus}</div>
    </div>
    <Row icon={Accessibility} title="کنترل بین برنامه‌ها" detail="برای Home / Back / اجرای تعاملات UI، Accessibility باید توسط خود کاربر فعال شود." enabled={!!caps?.accessibility} action="accessibility" button="فعال‌سازی" />
    <div className="rounded-2xl border border-indigo-500/30 bg-indigo-500/5 p-4 flex items-center gap-3"><div className="rounded-xl bg-slate-800 p-2"><AppWindow className="w-5 h-5" /></div><div className="flex-1"><div className="font-bold">آواتار روی صحنه گوشی</div><div className="text-xs text-slate-500 mt-1">آواتار شناور واقعی روی برنامه‌های دیگر. Android باید Overlay را اجازه دهد.</div></div><button onClick={() => void toggleOverlay()} className="rounded-xl bg-indigo-600 px-3 py-2 text-xs font-bold">{!caps?.overlay ? 'فعال‌سازی مجوز' : overlayState === 'ON' ? 'خاموش' : 'نمایش آواتار'}</button></div>
    <Row icon={Contact} title="مخاطبین" detail="برای تشخیص چند «احسان» و انتخاب مخاطب، دسترسی مخاطبین لازم است." enabled={!!caps?.contacts} action="contacts" button="اجازه دسترسی" />
    <Row icon={Mic} title="میکروفون" detail="برای دریافت فرمان صوتی واقعی Android." enabled={!!caps?.microphone} action="media" button="اجازه دسترسی" />
    <Row icon={Bell} title="اعلان‌ها" detail="برای وضعیت و اعلان‌های دستیار در Android 13+، مجوز باید توسط کاربر تأیید شود." enabled={!!caps?.notifications} action="notifications" button="تنظیم اعلان" />
    <Row icon={Activity} title="Usage Access" detail="برای یادگیری استفاده از برنامه‌ها؛ فقط در صورت اعطای مجوز Android." enabled={!!caps?.usageAccess} action="usage" button="فعال‌سازی" />
    <Row icon={Battery} title="استثنای بهینه‌سازی باتری" detail="برای پایداری سرویس‌های پس‌زمینه؛ Android ممکن است اجازه ندهد." enabled={!!caps?.batteryOptimizationIgnored} action="battery" button="بررسی" />
    <Row icon={Camera} title="دوربین" detail="اجرای دوربین فقط وقتی Android مجوز CAMERA را گزارش کند." enabled={!!caps?.canOpenCamera && !!caps?.microphone} action="media" button="اجازه دسترسی" />
    <Row icon={Music} title="موسیقی" detail="بازکردن برنامه/مسیر رسانه؛ پخش خودکار وابسته به برنامه مقصد و مجوزهای خودش است." enabled={!!caps?.canOpenMusic} />
    <Row icon={Globe} title="وب و جستجو" detail="بازکردن جستجوی وب با Intent واقعی Android." enabled={!!caps?.canOpenBrowser} />
    <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4 text-xs text-amber-200 leading-6"><LockKeyhole className="inline w-4 h-4 ml-1" />نوین قرار نیست برای «کنترل کامل گوشی» امنیت Android را دور بزند. هر قابلیت حساس باید توسط خود Android گزارش شود و اقدامات ارتباطی حساس می‌توانند نیازمند تأیید کاربر باقی بمانند.</div>
    <div className="text-[11px] text-slate-600">{message}</div>
  </section>;
};
