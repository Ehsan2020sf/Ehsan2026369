import { NovinMultimodalContextRuntime } from './novinMultimodalContextRuntime.ts';

const runtime = new NovinMultimodalContextRuntime('TEST-MULTIMODAL');
const observed = runtime.beginTurn('این تصویر را بررسی کن', true);
if (observed.reality !== 'CAMERA_OBSERVED' || !observed.cameraAttached) throw new Error('MULTIMODAL_OBSERVATION_FAILED');
const generated = runtime.acceptGeneratedResponse('نتیجه تولیدشده');
if (generated.reality !== 'GENERATED') throw new Error('MULTIMODAL_GENERATION_FAILED');
const blocked = runtime.block('REALTIME_PROVIDER_UNAVAILABLE');
if (blocked.reality !== 'BLOCKED') throw new Error('MULTIMODAL_BLOCK_FAILED');
console.log('NOVIN MULTIMODAL CONTEXT RUNTIME PASS');
