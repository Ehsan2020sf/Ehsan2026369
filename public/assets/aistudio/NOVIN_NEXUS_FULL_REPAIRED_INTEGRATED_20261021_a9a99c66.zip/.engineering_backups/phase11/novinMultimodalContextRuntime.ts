/** NOVIN Phase 9: unified Voice + Vision context boundary. */
export type MultimodalContextReality = 'CAMERA_OBSERVED'|'VOICE_OBSERVED'|'GENERATED'|'BLOCKED'|'UNKNOWN';

export interface MultimodalContextSnapshot {
  sessionId: string;
  turn: number;
  userText: string | null;
  cameraAttached: boolean;
  reality: MultimodalContextReality;
  evidence: string[];
}

export class NovinMultimodalContextRuntime {
  private turn = 0;
  private userText: string | null = null;
  private cameraAttached = false;
  private evidence: string[] = [];

  private readonly sessionId: string;

  constructor(sessionId = `MULTIMODAL-${Date.now()}`) {
    this.sessionId = sessionId;
  }

  beginTurn(userText: string, cameraAttached: boolean): MultimodalContextSnapshot {
    const clean = userText.trim();
    this.turn += 1;
    this.userText = clean || null;
    this.cameraAttached = cameraAttached;
    this.evidence = [];
    if (clean) this.evidence.push('VOICE_OR_TEXT_INPUT_OBSERVED');
    if (cameraAttached) this.evidence.push('CAMERA_FRAME_ATTACHED_IN_MEMORY');
    if (!clean && !cameraAttached) {
      this.evidence.push('MULTIMODAL_INPUT_EMPTY');
      return this.snapshot('BLOCKED');
    }
    return this.snapshot(cameraAttached ? 'CAMERA_OBSERVED' : 'VOICE_OBSERVED');
  }

  acceptGeneratedResponse(response: string): MultimodalContextSnapshot {
    if (!response.trim()) {
      this.evidence.push('MULTIMODAL_RESPONSE_EMPTY');
      return this.snapshot('UNKNOWN');
    }
    this.evidence.push('MULTIMODAL_RESPONSE_GENERATED');
    return this.snapshot('GENERATED');
  }

  block(reason: string): MultimodalContextSnapshot {
    this.evidence.push(reason);
    return this.snapshot('BLOCKED');
  }

  snapshot(reality: MultimodalContextReality): MultimodalContextSnapshot {
    return { sessionId: this.sessionId, turn: this.turn, userText: this.userText, cameraAttached: this.cameraAttached, reality, evidence: [...this.evidence] };
  }
}
