import fs from 'node:fs';
const avatar = fs.readFileSync('src/components/avatar/NovinAvatarVisual.tsx','utf8');
const scene = fs.readFileSync('src/components/living3d/NovinLiving3DScene.tsx','utf8');
if (avatar.includes('WEBGL_lose_context') || avatar.includes('loseContext()')) throw new Error('WebGL probe must not force-loss its context');
for (const token of ['document.visibilityState','webglcontextlost','webglcontextrestored','targetFrameInterval']) {
  if (!scene.includes(token)) throw new Error(`missing graphics resilience token: ${token}`);
}
console.log('NOVIN_ANDROID_GRAPHICS_RUNTIME_SAFETY_PASS');
