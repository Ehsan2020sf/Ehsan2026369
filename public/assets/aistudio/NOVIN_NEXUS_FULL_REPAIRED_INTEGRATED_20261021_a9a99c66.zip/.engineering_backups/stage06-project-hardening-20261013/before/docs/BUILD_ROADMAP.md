# Build Roadmap

## Phase 0 — Foundation
- [x] Clean directory tree
- [x] Core contracts
- [x] Evidence model
- [x] Governance boundary
- [x] Brain boundary
- [x] Memory port
- [x] Agent port
- [x] Nervous-system ports
- [x] Tool registry
- [x] Execution lifecycle
- [x] Avatar state boundary
- [x] Android device profile

## Phase 1 — Real Brain
- [x] Provider boundary and exception containment
- [x] Model routing boundary
- [x] Persian conversation engine
- [x] Context assembly
- [x] Deterministic local fallback
- [x] Brain/runtime integration tests
- [ ] Real external provider adapters with runtime credentials/evidence

## Phase 2 — Real Body
- Android TTS
- Android STT
- Camera
- Vision pipeline
- Network adapter
- storage adapter

## Phase 3 — Agent Runtime
- planner
- delegation
- queue
- retries
- cancellation
- verification
- recovery

## Phase 4 — Professional Mobile UI
- command-first home
- 3D avatar runtime
- conversation surface
- camera surface
- diagnostics hidden behind developer mode
- Redmi Note 11 performance governor

## Phase 5 — Integration
- Android build
- static checks
- unit tests
- integration tests
- runtime evidence
- final packaging

### Phase 2A — Android Runtime Boundary (completed)
- [x] Platform-neutral Android runtime shell
- [x] Text → Brain/Runtime → Avatar state path
- [x] STT/TTS ports with fail-closed UNKNOWN state
- [x] Camera port boundary with fail-closed UNKNOWN state
- [x] Android shell integration test
- [x] Core remains independent of Android/UI framework

### Next
- Complete provider policy/configuration boundary without embedding credentials.
- Implement real Android TTS/STT callbacks behind the ports.
- Implement camera capture callback and evidence-bearing vision input.
- Add network/storage ports without leaking platform APIs into core.


## Native Android Runtime Gate
- Native Android application shell and Web runtime bridge are implemented.
- Physical build/install remains a hard evidence gate.
- No APK PASS is allowed until Gradle + Android SDK build and Redmi device execution are observed.
