import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import type { WorldDefinition, WorldObject } from '../../core/world/contracts.ts';
import { DEFAULT_3D_DESIGN_STATE, type Novin3DDesignState } from '../../core/environment/novin3DDesignState.ts';
import { buildLayeredDepthSimulation, buildMultiFrameSpatialTwin, type SpatialFrameSignature } from '../../core/environment/novinSpatialTwinReconstruction.ts';
import { buildSpatialSceneGraph } from '../../core/environment/novinSpatialSceneGraph.ts';
import { buildSpatialAvatarPathPlan } from '../../core/environment/novinSpatialAvatarPathPlanning.ts';
import { correlateVisionEvidence, type VisionEvidenceCorrelationState } from '../../core/environment/novinVisionEvidenceCorrelation.ts';
import { attachPersistentSpatialIdentities, buildPersistentSpatialIdentities, type PersistentSpatialIdentityState } from '../../core/environment/novinPersistentSpatialIdentity.ts';
import { buildPersistentSpatialPositions } from '../../core/environment/novinPersistentSpatialPosition.ts';
import { buildSpatialWorldState, setSpatialWorldRelation, updateSpatialWorldObjectState, type SpatialWorldState } from '../../core/environment/novinSpatialWorldState.ts';
import { buildLivingMissionPlan, type LivingMissionPlan } from '../../core/environment/novinLivingMissionPlanner.ts';
import { applySpatialCausalAction, createSpatialCausalMemory, type SpatialCausalMemory } from '../../core/environment/novinSpatialCausalMemory.ts';
import { reasonNextLivingMissionStep } from '../../core/environment/novinSpatialMissionReasoner.ts';
import { attachVisionObservationsToSpatialGraph, type VisionObservationBatch } from '../../core/environment/novinVisionObservationBridge.ts';
import { NovinMultimodalStudio } from './NovinMultimodalStudio.tsx';
import { detectNovinMobileGraphicsProfile } from '../../core/mobile/novinMobileGraphicsProfile.ts';
import { novinWorldInteractionEngine } from '../../core/nexus/novinWorldInteractionEngine.ts';
import { resolveLivingWorldCommand } from '../../core/environment/novinLivingWorldCommand.ts';
import { subscribeLivingWorldCommands } from '../../core/environment/novinLivingWorldCommandBus.ts';
import { novinWorldCameraController } from '../../core/environment/novinWorldCameraController.ts';
import { ensureDefaultWorldBuilding } from '../../core/environment/novinWorldBuildingRuntime.ts';
import { NovinWorldInteractionRuntime } from '../../core/environment/novinWorldInteractionRuntime.ts';

interface NovinLiving3DSceneProps { activeWorld: WorldDefinition; }

export const NovinLiving3DScene: React.FC<NovinLiving3DSceneProps> = ({ activeWorld }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const selectedObjectIdRef = useRef<string | null>(null);
  const spatialMemoryRef = useRef<PersistentSpatialIdentityState | null>(null);
  const visionCorrelationRef = useRef<VisionEvidenceCorrelationState | null>(null);
  const livingMissionRef = useRef<LivingMissionPlan | null>(null);
  const spatialWorldStateRef = useRef<SpatialWorldState | null>(null);
  const spatialCausalMemoryRef = useRef<SpatialCausalMemory>(createSpatialCausalMemory());
  const [rendererError, setRendererError] = useState<string | null>(null);
  const [worldCameraLabel, setWorldCameraLabel] = useState('دنبال‌کردن آواتار');
  const [worldRuntimeStatus, setWorldRuntimeStatus] = useState('WORLD_READY');
  const graphicsProfile = useMemo(() => detectNovinMobileGraphicsProfile(), []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    setRendererError(null);
    const scene = new THREE.Scene();
    const design = (activeWorld as WorldDefinition & { environmentDesign?: Novin3DDesignState }).environmentDesign ?? DEFAULT_3D_DESIGN_STATE;
    const graphics = graphicsProfile;
    scene.background = new THREE.Color(0x020617);
    scene.fog = new THREE.FogExp2(0x020617, 0.018);
    const camera = new THREE.PerspectiveCamera(55, container.clientWidth / Math.max(container.clientHeight, 1), 0.1, 1000);
    if (design.camera === 'TOP') camera.position.set(0, 14, 0.01);
    else if (design.camera === 'ARCHITECTURAL') camera.position.set(10, 8, 12);
    else if (design.camera === 'CINEMATIC') camera.position.set(12, 5, 9);
    else camera.position.set(8, 7, 10);
    camera.lookAt(0, 0, 0);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: graphics.antialias, alpha: false, powerPreference: 'high-performance' });
    } catch (error) {
      console.error('[NOVIN-3D] WEBGL_UNAVAILABLE', error);
      setRendererError('WEBGL_UNAVAILABLE');
      return;
    }
    renderer.setPixelRatio(graphics.pixelRatio);
    renderer.shadowMap.enabled = graphics.shadows;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    const ambientIntensity = design.lighting === 'DRAMATIC' ? 0.7 : design.lighting === 'DAYLIGHT' ? 2.4 : 1.8;
    scene.add(new THREE.HemisphereLight(0x9cc7ff, 0x111827, design.lighting === 'DRAMATIC' ? 0.55 : 0.9));
    scene.add(new THREE.AmbientLight(0xffffff, ambientIntensity));
    const key = new THREE.DirectionalLight(0xffffff, design.lighting === 'DRAMATIC' ? 3 : 2.2);
    key.position.set(5, 10, 7);
    key.castShadow = graphics.shadows;
    if (graphics.shadows) { key.shadow.mapSize.set(graphics.shadowMapSize, graphics.shadowMapSize); key.shadow.camera.near = 0.5; key.shadow.camera.far = 60; }
    scene.add(key);
    if (design.lighting === 'STUDIO') { const fill = new THREE.DirectionalLight(0x93c5fd, 1.2); fill.position.set(-6, 5, 4); scene.add(fill); }

    if (design.floor !== 'NONE') {
      const grid = new THREE.GridHelper(30, 30, 0x334155, 0x1e293b);
      if (design.floor === 'STUDIO') grid.scale.set(1.2, 1.2, 1.2);
      scene.add(grid);
    }
    scene.add(new THREE.AxesHelper(3));
    const objectGroup = new THREE.Group(); scene.add(objectGroup);
    const buildingPlan = ensureDefaultWorldBuilding(activeWorld.objects);
    const interactionRuntime = new NovinWorldInteractionRuntime();
    interactionRuntime.setWorldObjects(activeWorld.objects);
    scene.userData.worldInteractionRuntime = interactionRuntime;
    scene.userData.buildingPlan = buildingPlan;
    const spatialTwinGroup = new THREE.Group(); spatialTwinGroup.name = 'NOVIN-SPATIAL-TWIN'; scene.add(spatialTwinGroup);
    const avatarSpeechState = { speaking: false };
    const speechHandler = (event: Event) => { avatarSpeechState.speaking = Boolean((event as CustomEvent).detail?.speaking); };
    window.addEventListener('novin:avatar-speech', speechHandler);
    const spatialCaptureHandler = (event: Event) => {
      const detail = (event as CustomEvent).detail as {
        id?: string; dataUrl?: string; source?: string; signatures?: SpatialFrameSignature[]; frameCount?: number;
        visionObservations?: Array<{ id: string; label: string; confidence: number; position?: { x: number; y: number; z: number }; source: 'DEVICE_CAMERA' | 'IMAGE_FILE' | 'VISION_PROVIDER' | 'SIMULATION'; observedAt?: string }>;
        visionSourceEvidence?: 'RUNTIME_OBSERVED' | 'PROVIDER_RESULT' | 'SIMULATED' | 'UNVERIFIED';
      } | undefined;
      if (!detail?.dataUrl) return;
      const loader = new THREE.TextureLoader();
      loader.load(detail.dataUrl, (texture) => {
        spatialTwinGroup.clear();
        const image = texture.image as HTMLImageElement;
        const reconstruction = detail.signatures && detail.signatures.length >= 2 ? buildMultiFrameSpatialTwin(image.width, image.height, detail.signatures) : buildLayeredDepthSimulation(image.width, image.height);
        const aspect = image.width / Math.max(image.height, 1);
        spatialTwinGroup.clear();
        reconstruction.layers.forEach((layer) => {
          const width = Math.min(14, 7 * Math.max(0.7, aspect) * layer.widthFactor);
          const height = 7 * layer.heightFactor;
          const plane = new THREE.Mesh(
            new THREE.PlaneGeometry(width, height, graphics.tier === 'ULTRA' ? 8 : 2, graphics.tier === 'ULTRA' ? 8 : 2),
            new THREE.MeshBasicMaterial({ map: texture, transparent: true, opacity: layer.opacity, side: THREE.DoubleSide, depthWrite: false })
          );
          const multiFrame = reconstruction.mode === 'MULTI_FRAME_DEPTH_SIMULATION' ? reconstruction : null;
          const parallaxX = multiFrame ? multiFrame.motion.dx * layer.depth * 0.55 : 0;
          const parallaxY = multiFrame ? multiFrame.motion.dy * layer.depth * 0.35 : 0;
          plane.position.set(parallaxX, (layer.role === 'FLOOR' ? 0.35 : layer.role === 'CEILING' ? 6.5 : 3.5) + parallaxY, layer.depth);
          if (layer.role === 'FLOOR') plane.rotation.x = -Math.PI / 2;
          if (layer.role === 'CEILING') plane.rotation.x = Math.PI / 2;
          plane.name = `SPATIAL-TWIN-${layer.role}`;
          plane.userData.captureId = detail.id;
          plane.userData.reality = 'RECONSTRUCTED_SIMULATION';
          plane.userData.reconstructionMode = reconstruction.mode;
          plane.userData.confidence = reconstruction.confidence;
          plane.userData.frameCount = detail.frameCount ?? detail.signatures?.length ?? 1;
          plane.userData.motion = multiFrame?.motion ?? null;
          spatialTwinGroup.add(plane);
        });
        spatialTwinGroup.userData.reconstruction = reconstruction;
        const baseSceneGraph = buildSpatialSceneGraph(image.width, image.height, detail.frameCount ?? detail.signatures?.length ?? 1, reconstruction.confidence);
        const visionBatch: VisionObservationBatch | undefined = detail.visionObservations ? {
          frameId: detail.id ?? `capture-${Date.now()}`,
          observations: detail.visionObservations,
          sourceEvidence: detail.visionSourceEvidence ?? 'UNVERIFIED',
        } : undefined;
        let sceneGraph = visionBatch ? attachVisionObservationsToSpatialGraph(baseSceneGraph, visionBatch) : baseSceneGraph;
        if (visionBatch) {
          visionCorrelationRef.current = correlateVisionEvidence([visionBatch], visionCorrelationRef.current);
          spatialMemoryRef.current = buildPersistentSpatialIdentities(visionCorrelationRef.current.tracks, spatialMemoryRef.current);
          const persistentPositions = buildPersistentSpatialPositions(spatialMemoryRef.current, visionCorrelationRef.current.tracks);
          sceneGraph = attachPersistentSpatialIdentities(sceneGraph, spatialMemoryRef.current);
          spatialWorldStateRef.current = buildSpatialWorldState(activeWorld.objects, spatialMemoryRef.current, persistentPositions, spatialWorldStateRef.current);
          spatialWorldStateRef.current = { ...spatialWorldStateRef.current, worldId: activeWorld.worldId };
          spatialTwinGroup.userData.spatialMemory = spatialMemoryRef.current;
          spatialTwinGroup.userData.visionCorrelation = visionCorrelationRef.current;
          spatialTwinGroup.userData.spatialWorldState = spatialWorldStateRef.current;
          spatialTwinGroup.userData.spatialCausalMemory = spatialCausalMemoryRef.current;
        }
        spatialTwinGroup.userData.sceneGraph = sceneGraph;
        sceneGraph.nodes.filter((node) => node.kind !== 'ROOM' && node.kind !== 'REFERENCE').forEach((node) => {
          const geometry = node.kind === 'FLOOR' || node.kind === 'CEILING'
            ? new THREE.BoxGeometry(1, 0.08, 1)
            : new THREE.BoxGeometry(1, 1, 0.12);
          const material = new THREE.MeshStandardMaterial({ color: node.kind === 'FLOOR' ? 0x475569 : node.kind === 'CEILING' ? 0x64748b : 0x334155, transparent: true, opacity: 0.16, wireframe: true });
          const mesh = new THREE.Mesh(geometry, material);
          mesh.name = `SPATIAL-GRAPH-${node.kind}-${node.id}`;
          mesh.position.set(node.position.x, node.position.y, node.position.z);
          mesh.rotation.y = node.rotationY;
          mesh.scale.set(node.scale.x, node.scale.y, node.scale.z);
          mesh.userData.worldObjectId = node.id;
          mesh.userData.worldObjectName = node.nameFa;
          mesh.userData.reality = node.reality;
          mesh.userData.confidence = node.confidence;
          mesh.userData.sourceFrameCount = node.sourceFrameCount;
          mesh.userData.spatialSceneNode = true;
          spatialTwinGroup.add(mesh);
        });
      });
    };
    let runtimeBuildObject: ((objectKind: string) => WorldObject | null) | null = null;
    let avatarGroupRef: THREE.Group | undefined;

    const ownerCommandHandler = (event: Event) => {
      const command = String((event as CustomEvent).detail?.commandFa ?? '').trim();
      if (scene.userData.lastBusCommand === command) { scene.userData.lastBusCommand = null; return; }
      scene.userData.lastOwnerCommand = command;
      const livingCommand = resolveLivingWorldCommand(command);
      if (livingCommand.kind === 'AVATAR_WAVE' && avatarGroupRef) {
        window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: true, text: 'سلام', runtime: 'LIVING_WORLD' } }));
        window.setTimeout(() => window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: false } })), 800);
        window.dispatchEvent(new CustomEvent('novin:world-runtime-status', { detail: { status: 'AVATAR_WAVE', messageFa: 'آواتار در جهان زنده دست تکان داد (شبیه‌سازی).' } }));
      }
      if (livingCommand.kind === 'AVATAR_LOOK' && avatarGroupRef) {
        const yaw = livingCommand.direction === 'LEFT' ? 0.4 : livingCommand.direction === 'RIGHT' ? -0.4 : 0;
        avatarGroupRef.rotation.y += yaw;
        window.dispatchEvent(new CustomEvent('novin:world-runtime-status', { detail: { status: 'AVATAR_LOOK', messageFa: 'آواتار نگاه کرد (شبیه‌سازی).' } }));
      }
      if (livingCommand.kind === 'AVATAR_GOTO_EXTERIOR' && design.avatarBody) {
        const exterior = { x: 0, y: 0, z: -14 };
        design.avatarBody = { ...design.avatarBody, enabled: true, pose: 'WALKING', motionMode: 'WALK', position: design.avatarBody.position, destinationObjectId: '__NOVIN_EXTERIOR__', gazeTargetObjectId: '__NOVIN_EXTERIOR__', navigationWaypoints: [exterior], navigationWaypointIndex: 0 };
        scene.userData.avatarDestination = { ...exterior, id: '__NOVIN_EXTERIOR__', reality: 'RECONSTRUCTED_SIMULATION' };
        novinWorldCameraController.setPreset('FOLLOW_AVATAR');
        window.dispatchEvent(new CustomEvent('novin:world-runtime-status', { detail: { status: 'AVATAR_MOVING_TO_EXTERIOR', messageFa: 'آواتار در حال حرکت به بیرون ساختمان است.' } }));
      }
      if (livingCommand.kind === 'BUILD_STRUCTURE') {
        const structureMap = { BUILDING: 'ساختمان جدید', ROOM: 'اتاق جدید', DOOR: 'در جدید', WINDOW: 'پنجره جدید' } as const;
        const primitiveMap = { BUILDING: 'WALL', ROOM: 'WALL', DOOR: 'DOOR', WINDOW: 'WINDOW' } as const;
        const id = `OBJ-NOVIN-${livingCommand.structure}-${Date.now()}`;
        const created: WorldObject = { id, name: livingCommand.structure, nameFa: structureMap[livingCommand.structure], category: 'GENERATED_STRUCTURE', realityLayer: 'GENERATED', confidence: 1, properties: { primitive: primitiveMap[livingCommand.structure], generatedBy: 'NOVIN_OWNER_COMMAND', physicalWorldEffect: false, size: livingCommand.structure === 'BUILDING' ? { x: 8, y: 3.2, z: 6 } : livingCommand.structure === 'ROOM' ? { x: 5, y: 3.2, z: 5 } : livingCommand.structure === 'DOOR' ? { x: 1.5, y: 2.5, z: 0.12 } : { x: 2.2, y: 1.5, z: 0.08 } }, coordinates: { x: 2, y: livingCommand.structure === 'DOOR' || livingCommand.structure === 'WINDOW' ? 1.25 : livingCommand.structure === 'BUILDING' || livingCommand.structure === 'ROOM' ? 1.6 : 0.5, z: -2 }, status: 'ACTIVE', lastObserved: new Date().toISOString() };
        activeWorld.objects.push(created);
        createWorldObject(created);
        scene.userData.lastBuiltObjectId = created.id;
        setWorldRuntimeStatus(`${created.nameFa} در جهان شبیه‌سازی ساخته شد.`);
      }
      if (livingCommand.kind === 'BUILD_OBJECT' && runtimeBuildObject) {
        const created = runtimeBuildObject(livingCommand.objectKind);
        if (created) {
          novinWorldCameraController.setPreset('BEHIND_TARGET', created.id);
          scene.userData.lastBuiltObjectId = created.id;
          scene.userData.lastBuiltObjectReality = 'GENERATED_SIMULATION';
          window.dispatchEvent(new CustomEvent('novin:world-runtime-status', { detail: { status: 'OBJECT_BUILT', messageFa: `${created.nameFa} در جهان شبیه‌سازی ساخته شد.` } }));
        }
      }
      if (livingCommand.kind === 'INTERACT_APPROACH') {
        const result = interactionRuntime.approachObject(livingCommand.targetHint);
        scene.userData.worldInteractionRuntimeState = result;
        setWorldRuntimeStatus(result.status === 'BLOCKED' ? `حرکت متوقف شد: ${result.lastEvent}` : 'آواتار به شیء نزدیک می‌شود.');
        window.dispatchEvent(new CustomEvent('novin:world-interaction-state', { detail: result }));
      }
      if (livingCommand.kind === 'INTERACT_GRAB') {
        const result = interactionRuntime.grabObject(livingCommand.targetHint);
        scene.userData.worldInteractionRuntimeState = result;
        setWorldRuntimeStatus(result.status === 'BLOCKED' ? `گرفتن مسدود شد: ${result.lastEvent}` : 'شیء در دست آواتار قرار گرفت.');
        window.dispatchEvent(new CustomEvent('novin:world-interaction-state', { detail: result }));
      }
      if (livingCommand.kind === 'INTERACT_PLACE') {
        const result = interactionRuntime.moveHeldObjectTo(livingCommand.targetHint);
        scene.userData.worldInteractionRuntimeState = result;
        setWorldRuntimeStatus(result.status === 'BLOCKED' ? `جای‌گذاری مسدود شد: ${result.lastEvent}` : 'شیء در جهان شبیه‌سازی جای‌گذاری شد.');
        window.dispatchEvent(new CustomEvent('novin:world-interaction-state', { detail: result }));
      }
      if (livingCommand.kind === 'DOOR_OPEN') {
        const result = interactionRuntime.openDoor(livingCommand.targetHint);
        scene.userData.worldInteractionRuntimeState = result;
        setWorldRuntimeStatus(result.status === 'BLOCKED' ? `بازکردن در مسدود شد: ${result.lastEvent}` : 'در باز شد.');
        window.dispatchEvent(new CustomEvent('novin:world-interaction-state', { detail: result }));
      }
      if (livingCommand.kind === 'DOOR_PASS') {
        const result = interactionRuntime.passThroughDoor(livingCommand.targetHint);
        scene.userData.worldInteractionRuntimeState = result;
        setWorldRuntimeStatus(result.status === 'BLOCKED' ? `عبور مسدود شد: ${result.lastEvent}` : 'آواتار از در عبور کرد.');
        window.dispatchEvent(new CustomEvent('novin:world-interaction-state', { detail: result }));
      }
      if (livingCommand.kind === 'DOOR_CLOSE') {
        const result = interactionRuntime.closeDoor(livingCommand.targetHint);
        scene.userData.worldInteractionRuntimeState = result;
        setWorldRuntimeStatus(result.status === 'BLOCKED' ? `بستن در مسدود شد: ${result.lastEvent}` : 'در بسته شد.');
        window.dispatchEvent(new CustomEvent('novin:world-interaction-state', { detail: result }));
      }
      if (livingCommand.kind === 'CAMERA_PRESET') {
        const target = livingCommand.preset === 'BEHIND_TARGET' || livingCommand.preset === 'CLOSE_TARGET' ? (scene.userData.lastBuiltObjectId as string | undefined) ?? null : null;
        novinWorldCameraController.setPreset(livingCommand.preset, target);
        if (livingCommand.preset === 'FRONT_AVATAR' && avatarGroupRef) novinWorldCameraController.setYaw(avatarGroupRef.rotation.y + Math.PI);
        scene.userData.worldCamera = novinWorldCameraController.snapshot();
        window.dispatchEvent(new CustomEvent('novin:world-camera-state', { detail: scene.userData.worldCamera }));
      }
      if (livingCommand.kind === 'CAMERA_ORBIT') {
        novinWorldCameraController.orbit(livingCommand.direction, livingCommand.degrees);
        scene.userData.worldCamera = novinWorldCameraController.snapshot();
        window.dispatchEvent(new CustomEvent('novin:world-camera-state', { detail: scene.userData.worldCamera }));
      }
      if (livingCommand.kind === 'CAMERA_ZOOM') {
        novinWorldCameraController.zoom(livingCommand.direction);
        scene.userData.worldCamera = novinWorldCameraController.snapshot();
        window.dispatchEvent(new CustomEvent('novin:world-camera-state', { detail: scene.userData.worldCamera }));
      }
      const plan = buildLivingMissionPlan(command, activeWorld.objects);
      spatialWorldStateRef.current = spatialWorldStateRef.current ?? buildSpatialWorldState(activeWorld.objects, spatialMemoryRef.current, [], null);
      const reasoning = reasonNextLivingMissionStep(plan, spatialWorldStateRef.current, spatialCausalMemoryRef.current);
      if (plan?.steps[0] && reasoning.decision === 'BLOCKED') plan.steps[0].status = 'BLOCKED';
      livingMissionRef.current = reasoning.decision === 'BLOCKED' ? null : plan;
      scene.userData.livingMission = reasoning.decision === 'BLOCKED' ? null : plan;
      scene.userData.livingMissionReasoning = reasoning;
      if (plan?.steps[0]) {
        spatialWorldStateRef.current = setSpatialWorldRelation(spatialWorldStateRef.current, {
          fromIdentityId: `world-object-${plan.steps[0].targetObjectId}`,
          relation: 'SELECTED',
          toIdentityId: 'avatar',
          confidence: 0.8,
          reality: 'RECONSTRUCTED_SIMULATION',
        });
        scene.userData.spatialWorldState = spatialWorldStateRef.current;
      }
      if (plan?.steps[0]) {
        const step = plan.steps[0];
        const interactionAction = step.action === 'PICK_UP' ? 'GRAB' : step.action === 'PLACE' ? 'PLACE' : step.action === 'APPROACH' ? 'APPROACH' : step.action === 'INSPECT' ? 'GAZE' : step.action === 'TOUCH' ? 'REACH' : 'REACH';
        novinWorldInteractionEngine.command({ action: interactionAction, targetId: step.targetObjectId, source: 'USER', reality: 'RECONSTRUCTED_SIMULATION' });
        scene.userData.worldInteraction = novinWorldInteractionEngine.snapshot();
        design.interactionState = {
          ...(design.interactionState ?? { interaction: 'NONE' }),
          interaction: step.action, targetObjectId: step.targetObjectId, targetObjectNameFa: step.targetObjectNameFa,
          selectedObjectId: step.targetObjectId, phase: step.action === 'APPROACH' ? 'APPROACHING' : 'REACHING',
          hand: step.action === 'PLACE' ? 'BOTH' : 'RIGHT', lastInteractionCommand: command,
        };
        design.avatarBody = { ...(design.avatarBody ?? DEFAULT_3D_DESIGN_STATE.avatarBody!), enabled: true, rig: 'HUMANOID', height: design.avatarBody?.height ?? 1.78, position: design.avatarBody?.position ?? { x: 0, y: 0, z: 0 }, rotationY: design.avatarBody?.rotationY ?? 0, pose: step.action === 'APPROACH' ? 'WALKING' : 'INTERACTING', destinationObjectId: step.targetObjectId, gazeTargetObjectId: step.targetObjectId, activeHand: step.action === 'PLACE' ? 'BOTH' : 'RIGHT', motionMode: step.action === 'APPROACH' ? 'WALK' : step.action === 'PICK_UP' ? 'HOLD' : step.action === 'PLACE' ? 'PLACE' : 'REACH' };
      }
    };
    const livingWorldUnsubscribe = subscribeLivingWorldCommands((envelope) => {
      // The command bus is the canonical route. The legacy DOM event remains for backwards compatibility with older surfaces.
      scene.userData.lastOwnerCommand = envelope.commandFa;
      scene.userData.lastBusCommand = envelope.commandFa;
      const livingCommand = envelope.command;
      if (livingCommand.kind === 'AVATAR_GOTO_EXTERIOR' && design.avatarBody) {
        design.avatarBody = { ...design.avatarBody, enabled: true, pose: 'WALKING', motionMode: 'WALK', destinationObjectId: '__NOVIN_EXTERIOR__', gazeTargetObjectId: '__NOVIN_EXTERIOR__', navigationWaypoints: [{ x: 0, y: 0, z: -14 }], navigationWaypointIndex: 0 };
        novinWorldCameraController.setPreset('FOLLOW_AVATAR');
        setWorldRuntimeStatus('آواتار در حال حرکت به بیرون ساختمان است.');
      } else if (livingCommand.kind === 'BUILD_STRUCTURE') {
        const structureMap = { BUILDING: 'ساختمان جدید', ROOM: 'اتاق جدید', DOOR: 'در جدید', WINDOW: 'پنجره جدید' } as const;
        const primitiveMap = { BUILDING: 'WALL', ROOM: 'WALL', DOOR: 'DOOR', WINDOW: 'WINDOW' } as const;
        const id = `OBJ-NOVIN-${livingCommand.structure}-${Date.now()}`;
        const created: WorldObject = { id, name: livingCommand.structure, nameFa: structureMap[livingCommand.structure], category: 'GENERATED_STRUCTURE', realityLayer: 'GENERATED', confidence: 1, properties: { primitive: primitiveMap[livingCommand.structure], generatedBy: 'NOVIN_OWNER_COMMAND', physicalWorldEffect: false }, coordinates: { x: 2, y: 1.25, z: -2 }, status: 'ACTIVE', lastObserved: new Date().toISOString() };
        activeWorld.objects.push(created);
        createWorldObject(created);
        scene.userData.lastBuiltObjectId = created.id;
        setWorldRuntimeStatus(`${created.nameFa} در جهان شبیه‌سازی ساخته شد.`);
      } else if (livingCommand.kind === 'BUILD_OBJECT' && runtimeBuildObject) {
        const created = runtimeBuildObject(livingCommand.objectKind);
        if (created) {
          novinWorldCameraController.setPreset('BEHIND_TARGET', created.id);
          setWorldRuntimeStatus(`${created.nameFa} در جهان شبیه‌سازی ساخته شد.`);
        }
      } else if (livingCommand.kind === 'CAMERA_PRESET') {
        const target = livingCommand.preset === 'BEHIND_TARGET' || livingCommand.preset === 'CLOSE_TARGET' ? (scene.userData.lastBuiltObjectId as string | undefined) ?? null : null;
        novinWorldCameraController.setPreset(livingCommand.preset, target);
        if (livingCommand.preset === 'FRONT_AVATAR' && avatarGroupRef) novinWorldCameraController.setYaw(avatarGroupRef.rotation.y + Math.PI);
        setWorldCameraLabel(livingCommand.preset);
      } else if (livingCommand.kind === 'CAMERA_ORBIT') {
        novinWorldCameraController.orbit(livingCommand.direction, livingCommand.degrees);
      } else if (livingCommand.kind === 'CAMERA_ZOOM') {
        novinWorldCameraController.zoom(livingCommand.direction);
      }
      scene.userData.worldCamera = novinWorldCameraController.snapshot();
    });
    window.addEventListener('novin:spatial-capture', spatialCaptureHandler);
    window.addEventListener('novin:owner-command', ownerCommandHandler);

    const materialFor = (status: string, kind?: string) => {
      const color = kind === 'MARBLE_WHITE' || kind === 'WHITE_MARBLE' ? 0xf8fafc : kind === 'MIRROR' ? 0xcbd5e1 : kind === 'GOLD' ? 0xd4af37 : status === 'CRITICAL' ? 0xef4444 : status === 'WARNING' ? 0xf59e0b : 0x38bdf8;
      return new THREE.MeshStandardMaterial({ color, metalness: kind === 'MIRROR' || kind === 'GOLD' || design.material === 'METAL' ? 0.85 : 0.15, roughness: kind === 'MIRROR' ? 0.12 : design.material === 'MATTE' ? 1 : 0.45, transparent: kind === 'MIRROR' || design.material === 'GLASS', opacity: kind === 'MIRROR' || design.material === 'GLASS' ? 0.72 : 1 });
    };
    const createHumanoid = () => {
      const body = design.avatarBody;
      if (!body?.enabled) return;
      const group = new THREE.Group();
      group.name = 'NOVIN-SENIOR-ENGINEERING-HUMANOID';
      const scale = body.height / 1.78;
      const skin = new THREE.MeshStandardMaterial({ color: 0xd7a77d, roughness: 0.7 });
      const suit = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.25, roughness: 0.5 });
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 20, 16), skin); head.position.y = 1.58; head.name = 'HEAD'; group.add(head);
      const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.035, 12, 8), new THREE.MeshStandardMaterial({ color: 0x3f172a, roughness: 0.6 })); mouth.position.set(0, 1.53, 0.17); mouth.scale.set(1.35, 0.55, 0.35); mouth.name = 'MOUTH'; head.add(mouth);
      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.68, 0.28), suit); torso.position.y = 1.15; torso.name = 'TORSO'; group.add(torso);
      const limb = (x:number, y:number, z:number, sx:number, sy:number, sz:number) => { const m=new THREE.Mesh(new THREE.CapsuleGeometry(0.07, Math.max(0.1, sy-0.14), 8, 12), suit); m.position.set(x,y,z); return m; };
      const leftArm=limb(-0.31,1.16,0,0.1,0.58,0.1), rightArm=limb(0.31,1.16,0,0.1,0.58,0.1);
      leftArm.name='LEFT_ARM'; rightArm.name='RIGHT_ARM';
      const leftLeg=limb(-0.13,0.55,0,0.1,0.78,0.1), rightLeg=limb(0.13,0.55,0,0.1,0.78,0.1);
      const hand=(x:number)=>{const h=new THREE.Mesh(new THREE.SphereGeometry(0.085,12,8),skin);h.position.set(x,0.84,0);return h;};
      const leftHand=hand(-0.31), rightHand=hand(0.31); leftHand.name='LEFT_HAND'; rightHand.name='RIGHT_HAND';
      leftLeg.name='LEFT_LEG'; rightLeg.name='RIGHT_LEG';
      group.add(leftArm,rightArm,leftLeg,rightLeg,leftHand,rightHand);
      group.userData.joints = { head, torso, leftArm, rightArm, leftLeg, rightLeg, leftHand, rightHand, mouth };
      group.position.set(body.position.x, body.position.y, body.position.z); group.rotation.y=body.rotationY*Math.PI/180; group.scale.setScalar(scale);
      group.userData.avatarPose = body.pose;
      objectGroup.add(group);
      return group;
    };
    const createWorldObject = (worldObject: WorldObject) => {
      const objectDesign = design.objectDesigns?.[worldObject.id];
      if (objectDesign?.visible === false || worldObject.status === 'OFFLINE') return;
      const primitive = objectDesign?.primitive ?? (worldObject.properties?.primitive as string) ?? 'BOX';
      if (primitive === 'HUMANOID') return;
      const role = objectDesign?.role ?? (worldObject.properties?.role as string) ?? '';
      const size = (worldObject.properties?.size as { x?: number; y?: number; z?: number } | undefined);
      const geometry = primitive === 'SPHERE'
        ? new THREE.SphereGeometry(0.65, 20, 14)
        : primitive === 'CYLINDER'
          ? new THREE.CylinderGeometry(0.55, 0.55, 1.2, 20)
          : primitive === 'PLANE'
            ? new THREE.PlaneGeometry(1.4, 1.4)
            : primitive === 'TABLE' || role === 'COMMAND_DESK'
              ? new THREE.BoxGeometry(2.2, 0.65, 1.1)
              : primitive === 'CHAIR'
                ? new THREE.BoxGeometry(0.8, 1.1, 0.8)
                : primitive === 'DOOR'
                  ? new THREE.BoxGeometry(Number(size?.x ?? 1.5), Number(size?.y ?? 2.5), Number(size?.z ?? 0.12))
                  : primitive === 'WINDOW'
                    ? new THREE.BoxGeometry(Number(size?.x ?? 2.2), Number(size?.y ?? 1.5), Number(size?.z ?? 0.08))
                    : primitive === 'FLOOR'
                      ? new THREE.BoxGeometry(Number(size?.x ?? 18), Number(size?.y ?? 0.12), Number(size?.z ?? 8))
                      : primitive === 'CEILING'
                        ? new THREE.BoxGeometry(Number(size?.x ?? 18), Number(size?.y ?? 0.12), Number(size?.z ?? 8))
                        : primitive === 'WALL' || role === 'WALL'
                          ? new THREE.BoxGeometry(Number(size?.x ?? 12), Number(size?.y ?? 3.2), Number(size?.z ?? 0.18))
                          : new THREE.BoxGeometry(1, 1, 1);
      const materialKind = objectDesign?.material ?? (worldObject.properties?.material as string) ?? (primitive === 'WINDOW' ? 'GLASS' : primitive === 'DOOR' ? 'METAL' : undefined);
      const mesh = new THREE.Mesh(geometry, materialFor(worldObject.status, materialKind));
      const scale = (objectDesign?.scale ?? 1) * design.objectScale;
      mesh.scale.setScalar(scale);
      mesh.position.set(objectDesign?.position.x ?? worldObject.coordinates?.x ?? 0, objectDesign?.position.y ?? worldObject.coordinates?.y ?? 0.5, objectDesign?.position.z ?? worldObject.coordinates?.z ?? 0);
      if (primitive === 'PLANE') mesh.rotation.x = -Math.PI / 2;
      mesh.userData.worldObjectId = worldObject.id; mesh.userData.worldObjectName = worldObject.nameFa; mesh.userData.engineeringPrimitive = primitive;
      objectGroup.add(mesh);
    };
    buildingPlan.objects.forEach((worldObject) => createWorldObject(worldObject));

    runtimeBuildObject = (objectKind) => {
      const base = avatarGroupRef?.position ?? new THREE.Vector3(0, 0, 0);
      const id = `OBJ-NOVIN-${objectKind}-${Date.now()}`;
      const nameMap: Record<string, string> = { TABLE: 'میز ساخته‌شده برای آواتار', CHAIR: 'صندلی ساخته‌شده برای آواتار', WALL: 'دیوار ساخته‌شده', BOX: 'جعبه ساخته‌شده', SPHERE: 'کره ساخته‌شده', LAMP: 'چراغ ساخته‌شده', BED: 'تخت ساخته‌شده', TREE: 'درخت ساخته‌شده', BOOK: 'کتاب ساخته‌شده', CAR: 'ماشین ساخته‌شده', CLOCK: 'ساعت ساخته‌شده', PHONE: 'گوشی ساخته‌شده', COMPUTER: 'کامپیوتر ساخته‌شده', GARDEN: 'باغ ساخته‌شده' };
      const primitiveMap: Record<string, string> = { TABLE: 'TABLE', CHAIR: 'CHAIR', WALL: 'WALL', BOX: 'BOX', SPHERE: 'SPHERE', LAMP: 'BOX', BED: 'BOX', TREE: 'SPHERE', BOOK: 'BOX', CAR: 'BOX', CLOCK: 'BOX', PHONE: 'BOX', COMPUTER: 'BOX', GARDEN: 'SPHERE' };
      const created: WorldObject = { id, name: objectKind, nameFa: nameMap[objectKind] || objectKind, category: 'GENERATED_WORLD_OBJECT', realityLayer: 'GENERATED', confidence: 1, properties: { primitive: primitiveMap[objectKind] || 'BOX', generatedBy: 'NOVIN_OWNER_COMMAND', source: 'USER_COMMAND', physicalWorldEffect: false }, coordinates: { x: base.x + 2, y: 0.5, z: base.z - 1.5 }, status: 'ACTIVE', lastObserved: new Date().toISOString() };
      activeWorld.objects.push(created);
      createWorldObject(created);
      return created;
    };
    const avatarGroup = createHumanoid();
    avatarGroupRef = avatarGroup;

    // تعامل زنده داخل همان Living 3D: انتخاب با لمس/ماوس و هدف‌گیری آواتار.
    // این لایه فقط وضعیت صحنه را کنترل می‌کند و ادعای تعامل با دنیای فیزیکی ندارد.
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const selectedTargetRef = { current: null as THREE.Object3D | null };
    const selectedMaterial = new THREE.MeshStandardMaterial({ color: 0xfacc15, emissive: 0x7c5d00, emissiveIntensity: 0.35, metalness: 0.35, roughness: 0.3 });
    const originalMaterials = new Map<THREE.Mesh, THREE.Material | THREE.Material[]>();
    const selectMesh = (mesh: THREE.Mesh | null) => {
      for (const [item, material] of originalMaterials) item.material = material;
      originalMaterials.clear();
      selectedObjectIdRef.current = null;
      selectedTargetRef.current = null;
      if (!mesh) return;
      originalMaterials.set(mesh, mesh.material);
      mesh.material = selectedMaterial;
      selectedObjectIdRef.current = String(mesh.userData.worldObjectId ?? '');
      selectedTargetRef.current = mesh;
    };
    const findTargetMesh = (targetId: string) => {
      const groups = [objectGroup, spatialTwinGroup];
      for (const group of groups) {
        let found: THREE.Mesh | null = null;
        group.traverse((object) => {
          if (!found && object instanceof THREE.Mesh && String(object.userData.worldObjectId ?? '') === targetId) found = object;
        });
        if (found) return found;
      }
      return null;
    };
    const visionTargetHandler = (event: Event) => {
      const detail = (event as CustomEvent).detail as { targetId?: string; mode?: 'GAZE' | 'APPROACH' | 'INTERACT' } | undefined;
      if (!detail?.targetId) return;
      const mesh = findTargetMesh(detail.targetId);
      if (mesh) selectMesh(mesh);
      scene.userData.visionAvatarTarget = { targetId: detail.targetId, mode: detail.mode ?? 'GAZE' };
    };
    const handlePointer = (event: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects([objectGroup, spatialTwinGroup], true);
      const hit = hits.find((entry) => entry.object.userData.worldObjectId) ?? null;
      selectMesh(hit ? hit.object as THREE.Mesh : null);
    };
    renderer.domElement.addEventListener('pointerdown', handlePointer);
    window.addEventListener('novin:vision-avatar-target', visionTargetHandler);

    const distanceToTarget = (group: THREE.Object3D, target: WorldObject) => {
      const x = target.coordinates?.x ?? 0;
      const z = target.coordinates?.z ?? 0;
      return Math.hypot(x - group.position.x, z - group.position.z);
    };
    const handSideOffset = (side: 'LEFT' | 'RIGHT') => side === 'LEFT' ? -1 : 1;
    let animationFrame = 0;
    let lastRenderAt = 0;
    let runtimeVisible = typeof document === 'undefined' || document.visibilityState === 'visible';
    let runtimeGraphics = { tier: graphics.tier, dprMultiplier: 1, shadows: graphics.shadows, postProcessing: graphics.postProcessing, targetFps: graphics.targetFps };
    const clock = new THREE.Clock();
    let avatarVelocity = 0;
    const avatarTarget = design.avatarBody?.destinationObjectId ? activeWorld.objects.find((o) => o.id === design.avatarBody?.destinationObjectId)?.coordinates : undefined;
    // ادراک/تصمیم مسیر: وقتی فرمان تعامل هدف مشخص دارد، مسیر از Scene Graph موجود محاسبه می‌شود.
    const spatialGraph = buildSpatialSceneGraph(12, 8, 1, 0.8);
    const plannedPath = (() => {
      const targetId = design.interactionState?.targetObjectId ?? design.avatarBody?.destinationObjectId;
      const target = targetId ? activeWorld.objects.find((o) => o.id === targetId)?.coordinates : undefined;
      if (!targetId || !target) return null;
      return buildSpatialAvatarPathPlan(design, spatialGraph, targetId, { x: target.x ?? 0, y: target.y ?? 0, z: target.z ?? 0 });
    })();
    if (plannedPath && design.avatarBody && !plannedPath.blocked) {
      design.avatarBody.navigationWaypoints = plannedPath.waypoints;
      design.avatarBody.navigationWaypointIndex = 0;
    }
    const poseIsMoving = (group: THREE.Object3D, velocity: number) => velocity > 0.01 || group.userData.avatarPose === 'WALKING';
    const targetFrameInterval = () => 1000 / Math.max(30, runtimeGraphics.targetFps);
    const animate = (now = performance.now()) => {
      animationFrame = requestAnimationFrame(animate);
      if (!runtimeVisible) return;
      const interval = targetFrameInterval();
      if (lastRenderAt > 0 && now - lastRenderAt < interval) return;
      lastRenderAt = now;
      const delta = Math.min(clock.getDelta(), 0.05);
      objectGroup.rotation.y += design.rotationSpeed;
      // حرکت آواتار بر پایه زمان واقعی، نه تعداد فریم، تا سرعت روی دستگاه‌های مختلف پایدار بماند.
      const locomotionSpeed = 1.35;
      const acceleration = 5.5;
      const deceleration = 7.5;
      if (avatarGroup && design.avatarBody) {
        const selectedTarget = selectedTargetRef.current;
        const selectedTargetPosition = selectedTarget ? new THREE.Vector3() : null;
        if (selectedTarget && selectedTargetPosition) selectedTarget.getWorldPosition(selectedTargetPosition);
        const governedTarget = activeWorld.objects.find((o) => o.id === design.interactionState?.targetObjectId)?.coordinates;
        const avatarDestination = design.avatarBody?.destinationObjectId === '__NOVIN_EXTERIOR__' ? { x: 0, y: 0, z: -14 } : undefined;
        const governedDistance = governedTarget ? Math.hypot(governedTarget.x - avatarGroup.position.x, governedTarget.z - avatarGroup.position.z) : Infinity;
        const needsApproach = Boolean(governedTarget && design.interactionState?.interaction !== 'NONE' && governedDistance > 0.85);
        const pose = selectedTargetPosition || needsApproach ? 'WALKING' : design.avatarBody.pose;
        const plannedWaypoint = design.avatarBody?.navigationWaypoints?.[design.avatarBody.navigationWaypointIndex ?? 0];
        const target = selectedTargetPosition
          ? { x: selectedTargetPosition.x, y: selectedTargetPosition.y, z: selectedTargetPosition.z }
          : plannedWaypoint ?? governedTarget ?? avatarDestination ?? avatarTarget;
        const joints = avatarGroup.userData.joints as { head: THREE.Object3D; torso: THREE.Object3D; leftArm: THREE.Object3D; rightArm: THREE.Object3D; leftLeg: THREE.Object3D; rightLeg: THREE.Object3D; leftHand: THREE.Object3D; rightHand: THREE.Object3D; mouth: THREE.Object3D } | undefined;
        const t = performance.now() / 1000;
        const interaction = design.interactionState?.interaction ?? 'NONE';
        const interactionTargetId = design.interactionState?.targetObjectId;
        const activeInteractionTarget = interactionTargetId ? activeWorld.objects.find((o) => o.id === interactionTargetId) : undefined;
        const interactionPhase = design.interactionState?.phase ?? 'COMPLETED';
        if (pose === 'WALKING' && target) {
          const dx = target.x - avatarGroup.position.x, dz = target.z - avatarGroup.position.z;
          const distance = Math.hypot(dx, dz);
          if (distance > 0.85) {
            // حرکت شتاب‌دار و محدود به محیط شبیه حرکت عامل داخل شبیه‌ساز است.
            avatarVelocity = Math.min(locomotionSpeed, avatarVelocity + acceleration * delta);
            const step = Math.min(avatarVelocity * delta, distance - 0.85);
            const obstacleDistance = 0.72;
            const nextX = avatarGroup.position.x + (dx / distance) * step;
            const nextZ = avatarGroup.position.z + (dz / distance) * step;
            const blocked = activeWorld.objects.some((worldObject) => {
              if (worldObject.status === 'OFFLINE' || worldObject.id === design.avatarBody?.destinationObjectId) return false;
              const ox = worldObject.coordinates?.x ?? 0;
              const oz = worldObject.coordinates?.z ?? 0;
              return Math.hypot(nextX - ox, nextZ - oz) < obstacleDistance;
            });
            if (!blocked) {
              avatarGroup.position.x = nextX;
              avatarGroup.position.z = nextZ;
              const waypointIndex = design.avatarBody?.navigationWaypointIndex ?? 0;
              const waypoints = design.avatarBody?.navigationWaypoints ?? [];
              if (waypoints[waypointIndex]) {
                const remaining = Math.hypot(waypoints[waypointIndex].x - avatarGroup.position.x, waypoints[waypointIndex].z - avatarGroup.position.z);
                if (remaining <= 0.2) design.avatarBody.navigationWaypointIndex = Math.min(waypointIndex + 1, Math.max(waypoints.length - 1, 0));
              }
            } else {
              // برخورد: سرعت صفر می‌شود و آواتار در شیء فرو نمی‌رود.
              avatarVelocity = 0;
              scene.userData.navigationBlocked = true;
            }
            avatarGroup.rotation.y = Math.atan2(dx, dz);
          } else if (selectedTarget) {
            // رسیدن به هدف انتخاب‌شده: چرخه تعامل داخلی فعال می‌شود.
            avatarGroup.userData.interactionTargetId = selectedTarget.userData.worldObjectId;
          } else {
            avatarVelocity = Math.max(0, avatarVelocity - deceleration * delta);
          }
        } else {
          avatarVelocity = Math.max(0, avatarVelocity - deceleration * delta);
        }
        if (activeInteractionTarget && interaction !== 'NONE' && pose !== 'WALKING') {
          const interactionMesh = objectGroup.children.find((child) => child.userData.worldObjectId === activeInteractionTarget.id) as THREE.Mesh | undefined;
          const handSide = design.interactionState?.hand ?? 'RIGHT';
          const activeHand = handSide === 'LEFT' ? joints?.leftHand : handSide === 'BOTH' ? joints?.rightHand : joints?.rightHand;
          if (interactionMesh && activeHand && (interaction === 'PICK_UP' || interaction === 'PLACE' || interaction === 'TOUCH')) {
            const handWorld = new THREE.Vector3();
            activeHand.getWorldPosition(handWorld);
            const closeEnough = distanceToTarget(avatarGroup, activeInteractionTarget) <= 1.15;
            if (closeEnough && interaction === 'PICK_UP') {
              interactionMesh.position.copy(objectGroup.worldToLocal(handWorld));
              interactionMesh.userData.heldByAvatar = true;
              avatarGroup.userData.heldObjectId = activeInteractionTarget.id;
              novinWorldInteractionEngine.grab(activeInteractionTarget.id);
              scene.userData.worldInteraction = novinWorldInteractionEngine.snapshot();
              if (spatialWorldStateRef.current) {
                const causal = applySpatialCausalAction(spatialWorldStateRef.current, spatialCausalMemoryRef.current, 'PICK_UP', activeInteractionTarget.id);
                spatialWorldStateRef.current = causal.state;
                spatialCausalMemoryRef.current = causal.memory;
                scene.userData.spatialWorldState = spatialWorldStateRef.current;
                scene.userData.spatialCausalMemory = spatialCausalMemoryRef.current;
                scene.userData.lastSpatialCause = causal.event;
              }
            } else if (closeEnough && interaction === 'PLACE') {
              const heldObjectId = String(avatarGroup.userData.heldObjectId ?? activeInteractionTarget.id);
              interactionMesh.userData.heldByAvatar = false;
              avatarGroup.userData.heldObjectId = undefined;
              interactionMesh.position.set(activeInteractionTarget.coordinates?.x ?? 0, (activeInteractionTarget.coordinates?.y ?? 0.5) + 0.5, activeInteractionTarget.coordinates?.z ?? 0);
              novinWorldInteractionEngine.place(activeInteractionTarget.id);
              novinWorldInteractionEngine.complete();
              scene.userData.worldInteraction = novinWorldInteractionEngine.snapshot();
              if (spatialWorldStateRef.current) {
                const causal = applySpatialCausalAction(spatialWorldStateRef.current, spatialCausalMemoryRef.current, 'PLACE', heldObjectId ?? null, activeInteractionTarget.id);
                spatialWorldStateRef.current = causal.state;
                spatialCausalMemoryRef.current = causal.memory;
                scene.userData.spatialWorldState = spatialWorldStateRef.current;
                scene.userData.spatialCausalMemory = spatialCausalMemoryRef.current;
                scene.userData.lastSpatialCause = causal.event;
              }
            }
            if (closeEnough && interaction === 'TOUCH') avatarGroup.userData.lastTouchAt = performance.now();
          } else {
            avatarVelocity = Math.max(0, avatarVelocity - deceleration * delta);
          }
        } else {
          avatarVelocity = Math.max(0, avatarVelocity - deceleration * delta);
        }
        if (activeInteractionTarget && interaction !== 'NONE' && pose !== 'WALKING') {
          avatarGroup.userData.interactionTargetId = activeInteractionTarget.id;
        }
        const livingMission = livingMissionRef.current;
        if (livingMission) {
          const currentStep = livingMission.steps.find(step => step.status === 'RUNNING');
          if (currentStep && activeInteractionTarget?.id === currentStep.targetObjectId && interaction !== 'NONE') {
            const reached = distanceToTarget(avatarGroup, activeInteractionTarget) <= 1.15;
            const completedInteraction = reached && (currentStep.action === 'APPROACH' || currentStep.action === 'INSPECT' || currentStep.action === 'TOUCH' || (currentStep.action === 'PICK_UP' && Boolean(avatarGroup.userData.heldObjectId)) || (currentStep.action === 'PLACE' && !avatarGroup.userData.heldObjectId));
            if (completedInteraction) {
              currentStep.status = 'COMPLETED';
              const nextStep = livingMission.steps[livingMission.steps.indexOf(currentStep) + 1];
              if (nextStep) {
                const nextReasoning = reasonNextLivingMissionStep(livingMission, spatialWorldStateRef.current, spatialCausalMemoryRef.current);
                scene.userData.livingMissionReasoning = nextReasoning;
                if (nextReasoning.decision === 'BLOCKED') {
                  nextStep.status = 'BLOCKED';
                  scene.userData.livingMissionStatus = 'BLOCKED';
                  livingMissionRef.current = null;
                } else {
                nextStep.status = 'RUNNING';
                design.interactionState = { ...(design.interactionState ?? { interaction: 'NONE' }), interaction: nextStep.action, targetObjectId: nextStep.targetObjectId, targetObjectNameFa: nextStep.targetObjectNameFa, selectedObjectId: nextStep.targetObjectId, phase: nextStep.action === 'APPROACH' ? 'APPROACHING' : 'REACHING', hand: nextStep.action === 'PLACE' ? 'BOTH' : 'RIGHT', lastInteractionCommand: livingMission.command };
                design.avatarBody = { ...(design.avatarBody ?? DEFAULT_3D_DESIGN_STATE.avatarBody!), pose: nextStep.action === 'APPROACH' ? 'WALKING' : 'INTERACTING', destinationObjectId: nextStep.targetObjectId, gazeTargetObjectId: nextStep.targetObjectId, activeHand: nextStep.action === 'PLACE' ? 'BOTH' : 'RIGHT', motionMode: nextStep.action === 'APPROACH' ? 'WALK' : nextStep.action === 'PICK_UP' ? 'HOLD' : nextStep.action === 'PLACE' ? 'PLACE' : 'REACH' };
                }
              } else {
                scene.userData.livingMissionStatus = 'COMPLETED';
                livingMissionRef.current = null;
              }
            }
          }
        }
        // جسم برداشته‌شده باید در تمام فریم‌ها همراه دست حرکت کند، نه فقط هنگام شروع تعامل.
        const heldId = avatarGroup.userData.heldObjectId as string | undefined;
        if (heldId && joints?.rightHand) {
          novinWorldInteractionEngine.move(heldId);
          scene.userData.worldInteraction = novinWorldInteractionEngine.snapshot();
          const heldMesh = findTargetMesh(heldId);
          if (heldMesh) {
            const handWorld = new THREE.Vector3();
            joints.rightHand.getWorldPosition(handWorld);
            heldMesh.position.copy(objectGroup.worldToLocal(handWorld));
            heldMesh.userData.heldByAvatar = true;
          }
        }
        avatarGroup.position.y = pose === 'SITTING' ? 0.15 : design.avatarBody.position.y;
        const gait = pose === 'WALKING' ? Math.sin(t * 8) : 0;
        const reaching = interaction === 'TOUCH' || interaction === 'PICK_UP' || interaction === 'PLACE' || interaction === 'INSPECT';
        const reachAmount = reaching ? (0.5 + Math.sin(t * 4) * 0.08) : 0;
        const gesture = pose === 'COMMANDING' ? Math.sin(t * 2) * 0.08 : pose === 'INTERACTING' ? Math.sin(t * 3) * 0.18 : 0;
        if (joints) {
          joints.leftArm.rotation.z = pose === 'SITTING' ? -0.18 : pose === 'COMMANDING' ? -0.75 + gesture : reaching ? -1.15 + reachAmount * 0.35 : pose === 'INTERACTING' ? -0.95 + gesture : gait * 0.45;
          joints.rightArm.rotation.z = pose === 'SITTING' ? 0.18 : pose === 'COMMANDING' ? 0.75 - gesture : reaching ? 1.15 - reachAmount * 0.35 : pose === 'INTERACTING' ? 0.95 - gesture : -gait * 0.45;
          joints.leftLeg.rotation.x = pose === 'SITTING' ? -0.95 : -gait * 0.35;
          joints.rightLeg.rotation.x = pose === 'SITTING' ? -0.95 : gait * 0.35;
          joints.torso.rotation.z = pose === 'WALKING' ? gait * 0.025 : 0;
          if (target) {
            const dx = target.x - avatarGroup.position.x;
            const dz = target.z - avatarGroup.position.z;
            joints.head.rotation.y = Math.max(-0.65, Math.min(0.65, Math.atan2(dx, dz) - avatarGroup.rotation.y));
          } else {
            joints.head.rotation.y = pose === 'COMMANDING' ? Math.sin(t * 0.8) * 0.18 : 0;
          }
          const handReach = reaching ? Math.min(0.28, 0.16 + Math.abs(Math.sin(t * 3)) * 0.12) : 0;
          if (joints.mouth) joints.mouth.scale.y = avatarSpeechState.speaking ? 0.45 + Math.abs(Math.sin(t * 14)) * 0.65 : 0.55;
          joints.leftHand.position.z = handSideOffset('LEFT') * handReach;
          joints.rightHand.position.z = handSideOffset('RIGHT') * handReach;
          joints.leftHand.position.y = 0.84 + (pose === 'COMMANDING' ? Math.sin(t * 2) * 0.05 : 0);
          joints.rightHand.position.y = 0.84 + (pose === 'COMMANDING' ? -Math.sin(t * 2) * 0.05 : 0);
        }
        const bob = pose === 'WALKING' ? Math.sin(t * 8) * 0.035 : 0;
        avatarGroup.position.y += bob;
      }
      if (avatarGroup) {
        const cameraState = novinWorldCameraController.snapshot();
        let cameraTarget = avatarGroup.getWorldPosition(new THREE.Vector3());
        if (cameraState.targetId) {
          const targetMesh = objectGroup.children.find((child) => child.userData.worldObjectId === cameraState.targetId);
          if (targetMesh) cameraTarget = targetMesh.getWorldPosition(new THREE.Vector3());
        }
        if (cameraState.preset === 'ABOVE_WORLD' || cameraState.preset === 'WIDE_WORLD') cameraTarget = new THREE.Vector3(0, 0, 0);
        novinWorldCameraController.apply(camera, cameraTarget, delta);
        scene.userData.worldCamera = cameraState;
      }

      renderer.render(scene, camera);
    };
    const handleGraphicsGovernor = (event: Event) => {
      const adjustment = (event as CustomEvent<{ adjustment?: { tier: string; dprMultiplier: number; shadows: boolean; postProcessing: boolean; targetFps: 30 | 60 } }>).detail?.adjustment;
      if (!adjustment) return;
      runtimeGraphics = { ...runtimeGraphics, ...adjustment, tier: adjustment.tier as typeof runtimeGraphics.tier };
      renderer.setPixelRatio(Math.max(0.7, Math.min(graphics.maxDpr, graphics.maxDpr * adjustment.dprMultiplier)));
      renderer.shadowMap.enabled = adjustment.shadows;
      lastRenderAt = 0;
    };
    const handleResize = () => { const width = container.clientWidth; const height = Math.max(container.clientHeight, 1); camera.aspect = width / height; camera.updateProjectionMatrix(); renderer.setSize(width, height); };
    const handleVisibility = () => {
      runtimeVisible = document.visibilityState === 'visible';
      if (runtimeVisible) {
        clock.getDelta();
        lastRenderAt = 0;
        window.dispatchEvent(new CustomEvent('novin:world-runtime-status', { detail: { status: 'WORLD_VISIBLE', messageFa: 'محیط سه‌بعدی دوباره فعال شد.' } }));
      }
    };
    const handleContextLost = (event: Event) => {
      event.preventDefault();
      setRendererError('WEBGL_CONTEXT_LOST');
      window.dispatchEvent(new CustomEvent('novin:world-runtime-status', { detail: { status: 'WEBGL_CONTEXT_LOST', messageFa: 'شتاب‌دهنده گرافیکی موقتاً قطع شد؛ بازیابی محیط در حال انجام است.' } }));
    };
    const handleContextRestored = () => {
      setRendererError(null);
      lastRenderAt = 0;
      window.dispatchEvent(new CustomEvent('novin:world-runtime-status', { detail: { status: 'WEBGL_CONTEXT_RESTORED', messageFa: 'شتاب‌دهنده گرافیکی دوباره در دسترس است.' } }));
      window.dispatchEvent(new CustomEvent('novin:avatar-webgl-ready'));
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored, false);
    window.addEventListener('resize', handleResize);
    window.addEventListener('novin:graphics-governor', handleGraphicsGovernor);
    document.addEventListener('visibilitychange', handleVisibility);
    animate();
    return () => {
      cancelAnimationFrame(animationFrame);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('novin:graphics-governor', handleGraphicsGovernor);
      document.removeEventListener('visibilitychange', handleVisibility);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);
      window.removeEventListener('novin:avatar-speech', speechHandler);
      window.removeEventListener('novin:spatial-capture', spatialCaptureHandler);
      window.removeEventListener('novin:owner-command', ownerCommandHandler);
      livingWorldUnsubscribe();
      window.removeEventListener('novin:vision-avatar-target', visionTargetHandler);
      renderer.domElement.removeEventListener('pointerdown', handlePointer);
      objectGroup.traverse((object) => { if (object instanceof THREE.Mesh) { object.geometry.dispose(); Array.isArray(object.material) ? object.material.forEach((m) => m.dispose()) : object.material.dispose(); } });
      renderer.dispose();
      if (renderer.domElement.parentElement === container) container.removeChild(renderer.domElement);
    };
  }, [activeWorld, graphicsProfile]);

  const design = (activeWorld as WorldDefinition & { environmentDesign?: Novin3DDesignState }).environmentDesign ?? DEFAULT_3D_DESIGN_STATE;
  useEffect(() => {
    const cameraLabels: Record<string, string> = { FOLLOW_AVATAR: 'دنبال‌کردن آواتار', BEHIND_TARGET: 'پشت هدف', ABOVE_WORLD: 'نمای بالا', WIDE_WORLD: 'نمای باز جهان', CLOSE_TARGET: 'نمای نزدیک هدف', FRONT_AVATAR: 'نمای روبه‌روی آواتار' };
    const onCamera = (event: Event) => { const preset = String((event as CustomEvent).detail?.preset ?? 'FOLLOW_AVATAR'); setWorldCameraLabel(cameraLabels[preset] ?? preset); };
    const onRuntime = (event: Event) => { setWorldRuntimeStatus(String((event as CustomEvent).detail?.messageFa ?? (event as CustomEvent).detail?.status ?? 'WORLD_READY')); };
    window.addEventListener('novin:world-camera-state', onCamera);
    window.addEventListener('novin:world-runtime-status', onRuntime);
    return () => { window.removeEventListener('novin:world-camera-state', onCamera); window.removeEventListener('novin:world-runtime-status', onRuntime); };
  }, []);
  return <section ref={containerRef} className="relative w-full min-h-[420px] overflow-hidden rounded-2xl border border-slate-800 bg-slate-950" aria-label={`نمای سه‌بعدی جهان ${activeWorld.titleFa}`}>
    <NovinMultimodalStudio />
    {rendererError && (
      <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/95 p-6 text-center">
        <div className="max-w-md rounded-2xl border border-amber-700/50 bg-slate-900 p-5">
          <div className="text-lg font-bold text-amber-300">محیط سه‌بعدی در این دستگاه در دسترس نیست</div>
          <div className="mt-2 text-sm text-slate-300">WebGL در WebView فعال نشد. مسیر فرمان و مغز NOVIN همچنان باید مستقل از این لایه کار کند.</div>
          <div className="mt-3 text-xs font-mono text-amber-400">NOT_VERIFIED: {rendererError}</div>
        </div>
      </div>
    )}
    <div className="absolute left-3 top-3 z-10 max-w-[min(80%,420px)] rounded-xl border border-cyan-500/20 bg-slate-950/85 px-3 py-2 text-[11px] text-slate-200 backdrop-blur">
      <div className="font-black text-cyan-300">دوربین جهان NOVIN</div>
      <div className="mt-1 text-slate-300">حالت: {worldCameraLabel}</div>
      <div className="mt-1 text-emerald-300">{worldRuntimeStatus}</div>
      <div className="mt-1 text-[9px] text-slate-500">این دوربین مجازی صحنه است، نه دوربین واقعی گوشی.</div>
    </div>
    <div className="absolute right-3 top-3 z-10 rounded-lg border border-slate-700 bg-slate-950/80 px-3 py-2 text-xs text-slate-300 backdrop-blur">
      <div className="font-bold text-slate-100">{activeWorld.titleFa}</div>
      <div className="mt-1 text-[10px] text-amber-300">[{activeWorld.realityLayer}]</div>
      <div className="mt-1 text-[10px] text-cyan-300">طراحی: {design.camera} / {design.lighting} / {design.material}</div>
      <div className="mt-1 text-[10px] text-emerald-300">GPU Profile: {graphicsProfile.tier} / {graphicsProfile.targetFps}fps</div>
    </div>
  </section>;
};
