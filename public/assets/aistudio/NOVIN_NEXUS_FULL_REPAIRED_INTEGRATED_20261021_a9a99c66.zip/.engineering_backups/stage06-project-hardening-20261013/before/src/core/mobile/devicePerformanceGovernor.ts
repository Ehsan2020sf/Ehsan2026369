/**
 * Runtime rendering governor. It adapts rendering quality to measured frame time
 * and resource pressure without reducing intelligence, memory, tools, or Agent capability.
 * Unknown native metrics remain UNKNOWN and never become PASS by assumption.
 */
export type GraphicsPressure = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'UNKNOWN';
export interface PerformanceSample {
  frameTimeMs: number | null;
  fps: number | null;
  memoryPressure: GraphicsPressure;
  thermal: 'NOMINAL' | 'WARM' | 'HOT' | 'CRITICAL' | 'UNKNOWN';
  gpuPressure: GraphicsPressure;
  timestamp: string;
}
export interface GraphicsAdjustment {
  tier: 'ULTRA' | 'HIGH' | 'BALANCED' | 'SAFE';
  dprMultiplier: number;
  shadows: boolean;
  postProcessing: boolean;
  targetFps: 30 | 60;
  reason: string;
}

const rank: Record<GraphicsPressure, number> = { LOW: 0, MEDIUM: 1, HIGH: 2, CRITICAL: 3, UNKNOWN: 0 };

export function sampleFramePressure(
  frameTimeMs: number | null,
  memoryPressure: GraphicsPressure = 'UNKNOWN',
  thermal: PerformanceSample['thermal'] = 'UNKNOWN',
  targetFps: 30 | 60 = 60,
): PerformanceSample {
  const fps = frameTimeMs !== null && frameTimeMs > 0 ? Math.min(240, 1000 / frameTimeMs) : null;
  // Judge frame pacing against the selected target, not an assumed 60 FPS. A
  // healthy 30 FPS Android profile is ~33.3 ms/frame and must not be labelled CRITICAL.
  const targetFrameMs = 1000 / targetFps;
  const ratio = frameTimeMs !== null && frameTimeMs > 0 ? frameTimeMs / targetFrameMs : null;
  const gpuPressure: GraphicsPressure = ratio === null ? 'UNKNOWN' : ratio > 1.75 ? 'CRITICAL' : ratio > 1.35 ? 'HIGH' : ratio > 1.15 ? 'MEDIUM' : 'LOW';
  return { frameTimeMs, fps, memoryPressure, thermal, gpuPressure, timestamp: new Date().toISOString() };
}

export function chooseGraphicsAdjustment(current: GraphicsAdjustment['tier'], sample: PerformanceSample): GraphicsAdjustment {
  const pressure = Math.max(rank[sample.gpuPressure], rank[sample.memoryPressure], sample.thermal === 'CRITICAL' ? 3 : sample.thermal === 'HOT' ? 2 : sample.thermal === 'WARM' ? 1 : 0);
  if (pressure >= 3) return { tier: 'SAFE', dprMultiplier: 0.70, shadows: false, postProcessing: false, targetFps: 30, reason: 'critical_runtime_pressure' };
  if (pressure >= 2) return { tier: current === 'ULTRA' ? 'HIGH' : 'SAFE', dprMultiplier: 0.82, shadows: current !== 'SAFE', postProcessing: false, targetFps: 60, reason: 'high_runtime_pressure' };
  if (pressure >= 1) return { tier: current === 'ULTRA' ? 'HIGH' : current, dprMultiplier: 0.92, shadows: current !== 'SAFE', postProcessing: false, targetFps: current === 'SAFE' ? 30 : 60, reason: 'medium_runtime_pressure' };
  return { tier: current, dprMultiplier: current === 'SAFE' ? 0.82 : 1, shadows: current !== 'SAFE', postProcessing: current === 'ULTRA' || current === 'HIGH', targetFps: current === 'SAFE' ? 30 : 60, reason: 'runtime_pressure_within_target' };
}
