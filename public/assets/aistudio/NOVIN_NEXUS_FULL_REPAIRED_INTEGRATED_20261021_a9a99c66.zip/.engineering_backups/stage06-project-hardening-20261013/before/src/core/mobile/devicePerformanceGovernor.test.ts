import { chooseGraphicsAdjustment, sampleFramePressure } from './devicePerformanceGovernor.ts';

const critical = chooseGraphicsAdjustment('ULTRA', sampleFramePressure(40, 'LOW', 'NOMINAL'));
if (critical.tier !== 'SAFE' || critical.targetFps !== 30) throw new Error('critical pressure was not reduced');
const medium = chooseGraphicsAdjustment('ULTRA', sampleFramePressure(24, 'LOW', 'NOMINAL'));
if (medium.postProcessing) throw new Error('medium pressure retained post-processing');
const nominal = chooseGraphicsAdjustment('HIGH', sampleFramePressure(12, 'LOW', 'NOMINAL'));
if (nominal.tier !== 'HIGH' || nominal.dprMultiplier !== 1) throw new Error('nominal pressure degraded graphics');
const unknown = sampleFramePressure(null);
if (unknown.fps !== null || unknown.gpuPressure !== 'UNKNOWN') throw new Error('unknown metrics were fabricated');
console.log('NOVIN_DEVICE_PERFORMANCE_GOVERNOR_PASS');

const healthyThirty = sampleFramePressure(1000 / 30, 'UNKNOWN', 'UNKNOWN', 30);
if (healthyThirty.gpuPressure !== 'LOW') throw new Error('a healthy 30 FPS target was incorrectly classified as pressure');
const safeNominal = chooseGraphicsAdjustment('SAFE', sampleFramePressure(16, 'LOW', 'NOMINAL', 60));
if (safeNominal.shadows || safeNominal.postProcessing || safeNominal.dprMultiplier >= 1 || safeNominal.targetFps !== 30) throw new Error('SAFE profile re-enabled expensive graphics settings');
console.log('NOVIN_DEVICE_PERFORMANCE_GOVERNOR_TARGET_AWARE_PASS');
