import React, { Component, type ErrorInfo, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { Mic, Radio, Shield, Sparkles, Brain, Cpu, Volume2, CheckCircle2 } from 'lucide-react';
import { EnvironmentDefinition } from '../../core/environment/contracts.ts';
import { WorldDefinition } from '../../core/world/contracts.ts';
import type { Novin3DDesignState } from '../../core/environment/novin3DDesignState.ts';
import { evaluateWorldHealth, WorldHealthStatus } from '../../core/world/worldHealth.ts';
import { detectNovinMobileGraphicsProfile } from '../../core/mobile/novinMobileGraphicsProfile.ts';
import { buildTextTimedVisemeFrame, normalizeRealtimeViseme, type NovinViseme } from '../../core/nexus/novinVisemeEngine.ts';
import { deriveAvatarExpression } from '../../core/nexus/novinAvatarExpressionEngine.ts';
import { novinAvatarIKEngine } from '../../core/nexus/novinAvatarIKEngine.ts';

export type AvatarState =
  | 'IDLE'
  | 'LISTENING'
  | 'THINKING'
  | 'EXECUTING'
  | 'WAITING_FOR_APPROVAL'
  | 'VALIDATING'
  | 'SPEAKING'
  | 'SUCCESS'
  | 'ERROR'
  | 'DEGRADED';

interface NovinAvatarVisualProps {
  avatarState: AvatarState;
  activeEnv: EnvironmentDefinition;
  activeWorld: WorldDefinition;
  isListening: boolean;
  onToggleVoice: () => void;
  lastMessageFa?: string;
  officerRoleFa?: string;
  operationalMode?: 'AUTONOMOUS_GOVERNED' | 'WAITING_APPROVAL' | 'EMERGENCY_HOLD' | 'DIAGNOSTIC';
  activeApprovals?: number;
  realityEvidenceCount?: number;
  worldHealthStatus?: WorldHealthStatus;
  worldHealthScore?: number;
  androidMode?: boolean;
  /** WebGL starts only after the Android runtime boot gate is READY. */
  render3D?: boolean;
}

const AvatarVisualFallback: React.FC<{ reason?: string }> = ({ reason }) => (
  <div className="novin-avatar-fallback" role="img" aria-label="آواتار نوین">
    <div className="novin-avatar-fallback-grid" />
    <div className="novin-avatar-fallback-radar radar-one" />
    <div className="novin-avatar-fallback-radar radar-two" />
    <div className="novin-avatar-fallback-core">
      <div className="novin-avatar-fallback-head">
        <div className="novin-avatar-fallback-eye left" />
        <div className="novin-avatar-fallback-eye right" />
        <div className="novin-avatar-fallback-mouth" />
      </div>
      <div className="novin-avatar-fallback-body">
        <span className="novin-avatar-fallback-node left" />
        <span className="novin-avatar-fallback-node right" />
      </div>
    </div>
    <div className="novin-avatar-fallback-label">
      <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
      <span>هسته تصویری نوین فعال است</span>
    </div>
    {reason && <div className="novin-avatar-fallback-reason">{reason}</div>}
  </div>
);

/** Schedules actual WebGL frames at a controlled rate instead of rendering at display refresh. */
const AvatarRenderScheduler: React.FC<{ fps: number; active: boolean }> = ({ fps, active }) => {
  const invalidate = useThree((state) => state.invalidate);
  useEffect(() => {
    if (!active) return;
    const safeFps = Math.max(15, Math.min(60, Math.floor(fps)));
    const timer = window.setInterval(() => invalidate(), Math.round(1000 / safeFps));
    invalidate();
    return () => window.clearInterval(timer);
  }, [active, fps, invalidate]);
  return null;
};

class AvatarWebGLBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.warn('[NOVIN-AVATAR-WEBGL]', error, info);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('novin:avatar-webgl-failure', { detail: { message: error.message } }));
    }
  }
  render() {
    if (this.state.failed) {
      return <AvatarVisualFallback reason="WebGL روی این دستگاه در دسترس نیست؛ مسیر تصویری ایمن فعال است." />;
    }
    return this.props.children;
  }
}

const STATE_COLORS: Record<AvatarState, string> = {
  IDLE: '#38bdf8',
  LISTENING: '#fb7185',
  THINKING: '#a78bfa',
  EXECUTING: '#22d3ee',
  WAITING_FOR_APPROVAL: '#f59e0b',
  VALIDATING: '#34d399',
  SPEAKING: '#c084fc',
  SUCCESS: '#4ade80',
  ERROR: '#f43f5e',
  DEGRADED: '#94a3b8',
};

interface LivingHumanoidProps {
  avatarState: AvatarState;
  isListening: boolean;
  speaking?: boolean;
  speechText?: string;
}

const LivingHumanoid: React.FC<LivingHumanoidProps> = ({ avatarState, isListening, speaking = false, speechText = '' }) => {
  const group = useRef<THREE.Group>(null);
  const head = useRef<THREE.Group>(null);
  const chest = useRef<THREE.Group>(null);
  const leftArm = useRef<THREE.Group>(null);
  const rightArm = useRef<THREE.Group>(null);
  const leftForearm = useRef<THREE.Group>(null);
  const rightForearm = useRef<THREE.Group>(null);
  const leftHand = useRef<THREE.Group>(null);
  const rightHand = useRef<THREE.Group>(null);
  const leftBrow = useRef<THREE.Mesh>(null);
  const rightBrow = useRef<THREE.Mesh>(null);
  const leftEye = useRef<THREE.Mesh>(null);
  const rightEye = useRef<THREE.Mesh>(null);
  const leftLid = useRef<THREE.Mesh>(null);
  const rightLid = useRef<THREE.Mesh>(null);
  const mouth = useRef<THREE.Mesh>(null);
  const pulse = useRef(0);
  const speechStartedAt = useRef(0);
  const ikTarget = useRef<{ x: number; y: number; z?: number; hand?: 'LEFT' | 'RIGHT' } | null>(null);
  const realtimeViseme = useRef<{ viseme: NovinViseme; weight: number } | null>(null);
  const blinkUntil = useRef(0);
  const color = STATE_COLORS[avatarState];

  useEffect(() => {
    const handleReach = (event: Event) => {
      const detail = (event as CustomEvent<{ x?: number; y?: number; z?: number; hand?: 'LEFT' | 'RIGHT' }>).detail;
      if (typeof detail?.x !== 'number' || typeof detail?.y !== 'number') return;
      const hand = detail.hand ?? 'RIGHT';
      ikTarget.current = { x: detail.x, y: detail.y, z: detail.z ?? 0, hand };
      novinAvatarIKEngine.setTarget({ x: detail.x, y: detail.y, z: detail.z ?? 0, hand, enabled: true });
    };
    const handleRelease = () => {
      ikTarget.current = null;
      novinAvatarIKEngine.release('RIGHT');
      novinAvatarIKEngine.release('LEFT');
    };
    window.addEventListener('novin:avatar-reach-target', handleReach);
    window.addEventListener('novin:avatar-release-target', handleRelease);
    return () => {
      window.removeEventListener('novin:avatar-reach-target', handleReach);
      window.removeEventListener('novin:avatar-release-target', handleRelease);
    };
  }, []);

  useEffect(() => {
    const handleViseme = (event: Event) => {
      const detail = (event as CustomEvent<{ viseme?: string; weight?: number }>).detail;
      if (detail?.viseme) {
        const frame = normalizeRealtimeViseme(detail);
        realtimeViseme.current = { viseme: frame.viseme, weight: frame.weight };
      }
    };
    window.addEventListener('novin:avatar-viseme-frame', handleViseme);
    return () => window.removeEventListener('novin:avatar-viseme-frame', handleViseme);
  }, []);

  useFrame((state, delta) => {
    const t = state.clock.elapsedTime;
    pulse.current += delta;
    if (!group.current || !head.current || !chest.current || !leftArm.current || !rightArm.current) return;

    const active = avatarState !== 'IDLE';
    if (speaking && speechStartedAt.current === 0) speechStartedAt.current = performance.now();
    if (!speaking) { speechStartedAt.current = 0; realtimeViseme.current = null; }
    const elapsedSpeech = speechStartedAt.current ? performance.now() - speechStartedAt.current : 0;
    const timedViseme = speechText ? buildTextTimedVisemeFrame(speechText, elapsedSpeech) : null;
    const thinking = avatarState === 'THINKING';
    const executing = avatarState === 'EXECUTING';

    // A procedural breathing cycle gives the digital body a persistent living rhythm.
    const breath = Math.sin(t * 1.55) * 0.018 + Math.sin(t * 0.77) * 0.008;
    chest.current.scale.set(1 + breath * 0.7, 1 + breath, 1 + breath * 0.35);
    group.current.position.y = Math.sin(t * 1.7) * (active ? 0.038 : 0.015) + breath * 0.35;
    group.current.rotation.y = THREE.MathUtils.lerp(
      group.current.rotation.y,
      Math.sin(t * (isListening ? 1.7 : 0.32)) * (isListening ? 0.08 : 0.022),
      0.08,
    );

    // Natural gaze: listening looks toward the owner, thinking drifts toward the world target.
    const gazeX = isListening ? Math.sin(t * 0.9) * 0.045 : thinking ? Math.sin(t * 0.38) * 0.11 : Math.sin(t * 0.24) * 0.035;
    const gazeY = thinking ? 0.025 + Math.sin(t * 0.31) * 0.025 : Math.sin(t * 0.52) * 0.012;
    const expression = deriveAvatarExpression({ state: avatarState, isListening, speaking, success: avatarState === 'SUCCESS', error: avatarState === 'ERROR', gazeX, gazeY });
    head.current.rotation.y = THREE.MathUtils.lerp(head.current.rotation.y, gazeX, 0.07);
    head.current.rotation.x = THREE.MathUtils.lerp(head.current.rotation.x, gazeY, 0.07);
    head.current.rotation.z = THREE.MathUtils.lerp(head.current.rotation.z, expression.headTilt + Math.sin(t * 0.47) * 0.008, 0.06);

    // Shoulder/elbow motion is procedural until an explicit reach target exists.
    const armEnergy = executing ? 0.55 : thinking ? 0.18 : isListening ? 0.28 : 0.07;
    const ik = ikTarget.current ? novinAvatarIKEngine.solve() : null;
    if (ik && ikTarget.current?.hand === 'RIGHT') {
      rightArm.current.rotation.z = THREE.MathUtils.lerp(rightArm.current.rotation.z, -ik.shoulderAngle, 0.16);
      if (rightForearm.current) {
        rightForearm.current.rotation.z = THREE.MathUtils.lerp(rightForearm.current.rotation.z, ik.elbowAngle - Math.PI, 0.16);
      }
    } else if (ik && ikTarget.current?.hand === 'LEFT') {
      leftArm.current.rotation.z = THREE.MathUtils.lerp(leftArm.current.rotation.z, Math.PI + ik.shoulderAngle, 0.16);
      if (leftForearm.current) {
        leftForearm.current.rotation.z = THREE.MathUtils.lerp(leftForearm.current.rotation.z, Math.PI - ik.elbowAngle, 0.16);
      }
    } else {
      leftArm.current.rotation.z = -0.12 - Math.sin(t * 2.1) * armEnergy;
      rightArm.current.rotation.z = 0.12 + Math.sin(t * 2.1 + 1.2) * armEnergy;
      if (leftForearm.current && rightForearm.current) {
        leftForearm.current.rotation.z = -0.08 + Math.sin(t * 2.1 + 0.5) * armEnergy * 0.45;
        rightForearm.current.rotation.z = 0.08 - Math.sin(t * 2.1 + 1.7) * armEnergy * 0.45;
      }
    }

    // Periodic blink with a small state-aware blink-rate variation.
    if (blinkUntil.current < t && Math.sin(t * (0.62 + (active ? 0.08 : 0))) > 0.995) blinkUntil.current = t + 0.105;
    const blink = blinkUntil.current > t;
    const lidScale = blink ? 0.08 : 1;
    if (leftLid.current && rightLid.current) {
      leftLid.current.scale.y = THREE.MathUtils.lerp(leftLid.current.scale.y, lidScale, 0.65);
      rightLid.current.scale.y = THREE.MathUtils.lerp(rightLid.current.scale.y, lidScale, 0.65);
    }
    if (leftEye.current && rightEye.current) {
      const eyePulse = 1 + Math.sin(t * 4.2) * (active ? 0.08 : 0.035);
      leftEye.current.scale.set(eyePulse, (blink ? 0.08 : eyePulse) * expression.eyeOpen, 1);
      rightEye.current.scale.set(eyePulse, (blink ? 0.08 : eyePulse) * expression.eyeOpen, 1);
      if (leftBrow.current && rightBrow.current) {
        leftBrow.current.rotation.z = -0.06 + expression.browTilt;
        rightBrow.current.rotation.z = 0.06 - expression.browTilt;
        leftBrow.current.position.y = 0.16 + expression.browLift;
        rightBrow.current.position.y = 0.16 + expression.browLift;
      }
    }

    // Procedural mouth/viseme proxy. Real phoneme data can later drive the same blend shape.
    if (mouth.current) {
      const activeViseme = realtimeViseme.current ?? timedViseme;
      const voiceWave = speaking
        ? activeViseme ? activeViseme.weight : 0.45 + Math.abs(Math.sin(t * 9.5)) * 0.35
        : avatarState === 'LISTENING' ? 0.18 : 0;
      const width = activeViseme?.viseme === 'MBP' ? 0.62 : activeViseme?.viseme === 'OO' ? 0.54 : activeViseme?.viseme === 'EE' ? 0.95 : 0.72;
      mouth.current.scale.y = THREE.MathUtils.lerp(mouth.current.scale.y, 0.22 + voiceWave * 1.05 + expression.mouthOpen * 0.08, 0.32);
      mouth.current.scale.x = THREE.MathUtils.lerp(mouth.current.scale.x, width + voiceWave * 0.12 + expression.mouthSmile * 0.08, 0.32);
      mouth.current.rotation.z = THREE.MathUtils.lerp(mouth.current.rotation.z, expression.mouthSmile * 0.025, 0.18);
    }

    pulse.current += delta;
  });

  return (
    <group ref={group}>
      <pointLight position={[0, 1.8, 1.2]} intensity={1.8} distance={4} color={color} />
      <mesh ref={chest} position={[0, 0.05, 0]} castShadow>
        <capsuleGeometry args={[0.48, 0.95, 10, 24]} />
        <meshStandardMaterial color="#20283a" metalness={0.65} roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.62, 0]} castShadow>
        <capsuleGeometry args={[0.22, 0.24, 10, 20]} />
        <meshStandardMaterial color="#39465e" metalness={0.4} roughness={0.35} />
      </mesh>

      <group ref={head} position={[0, 1.25, 0]}>
        <mesh castShadow>
          <sphereGeometry args={[0.58, 40, 28]} />
          <meshStandardMaterial color="#303a50" metalness={0.45} roughness={0.26} />
        </mesh>
        <mesh position={[0, 0.26, -0.05]}>
          <sphereGeometry args={[0.62, 40, 24, 0, Math.PI * 2, 0, Math.PI * 0.38]} />
          <meshStandardMaterial color="#111827" metalness={0.15} roughness={0.7} />
        </mesh>
        <mesh position={[-0.43, 0.02, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.09, 0.018, 10, 24]} />
          <meshStandardMaterial color="#303a50" metalness={0.45} roughness={0.3} />
        </mesh>
        <mesh position={[0.43, 0.02, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.09, 0.018, 10, 24]} />
          <meshStandardMaterial color="#303a50" metalness={0.45} roughness={0.3} />
        </mesh>

        <mesh ref={leftBrow} position={[-0.2, 0.16, 0.51]} rotation={[0, 0, -0.06]}>
          <capsuleGeometry args={[0.022, 0.15, 5, 10]} />
          <meshStandardMaterial color="#0b1020" roughness={0.6} />
        </mesh>
        <mesh ref={rightBrow} position={[0.2, 0.16, 0.51]} rotation={[0, 0, 0.06]}>
          <capsuleGeometry args={[0.022, 0.15, 5, 10]} />
          <meshStandardMaterial color="#0b1020" roughness={0.6} />
        </mesh>
        <mesh ref={leftLid} position={[-0.2, 0.035, 0.525]}>
          <sphereGeometry args={[0.105, 20, 14]} />
          <meshStandardMaterial color="#182033" roughness={0.5} />
        </mesh>
        <mesh ref={rightLid} position={[0.2, 0.035, 0.525]}>
          <sphereGeometry args={[0.105, 20, 14]} />
          <meshStandardMaterial color="#182033" roughness={0.5} />
        </mesh>
        <mesh ref={leftEye} position={[-0.2, 0.03, 0.56]}>
          <sphereGeometry args={[0.075, 20, 14]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={3.2} />
        </mesh>
        <mesh ref={rightEye} position={[0.2, 0.03, 0.56]}>
          <sphereGeometry args={[0.075, 20, 14]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={3.2} />
        </mesh>
        <mesh position={[-0.02, 0.055, 0.62]}>
          <sphereGeometry args={[0.018, 10, 8]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={1.4} />
        </mesh>
        <mesh position={[0.38, 0.17, 0.42]} rotation={[0, 0, -0.18]}>
          <capsuleGeometry args={[0.025, 0.16, 5, 10]} />
          <meshStandardMaterial color="#1e293b" roughness={0.55} />
        </mesh>
        <mesh ref={mouth} position={[0, -0.2, 0.535]} scale={[0.75, 0.45, 0.8]}>
          <sphereGeometry args={[0.13, 24, 14]} />
          <meshStandardMaterial color="#111827" emissive={color} emissiveIntensity={0.7} />
        </mesh>
      </group>

      <group ref={leftArm} position={[-0.58, 0.35, 0]}>
        <mesh position={[0, -0.32, 0]} castShadow>
          <capsuleGeometry args={[0.12, 0.62, 8, 16]} />
          <meshStandardMaterial color="#283248" metalness={0.55} roughness={0.35} />
        </mesh>
        <group ref={leftForearm} position={[0, -0.64, 0]}>
          <mesh position={[0, -0.18, 0]} castShadow>
            <capsuleGeometry args={[0.105, 0.42, 8, 14]} />
            <meshStandardMaterial color="#263148" metalness={0.52} roughness={0.36} />
          </mesh>
          <mesh position={[0, -0.46, 0]}>
            <sphereGeometry args={[0.15, 18, 14]} />
            <meshStandardMaterial color={color} emissive={color} emissiveIntensity={1.2} />
          </mesh>
        </group>
      </group>
      <group ref={rightArm} position={[0.58, 0.35, 0]}>
        <mesh position={[0, -0.32, 0]} castShadow>
          <capsuleGeometry args={[0.12, 0.62, 8, 16]} />
          <meshStandardMaterial color="#283248" metalness={0.55} roughness={0.35} />
        </mesh>
        <group ref={rightForearm} position={[0, -0.64, 0]}>
          <mesh position={[0, -0.18, 0]} castShadow>
            <capsuleGeometry args={[0.105, 0.42, 8, 14]} />
            <meshStandardMaterial color="#263148" metalness={0.52} roughness={0.36} />
          </mesh>
          <mesh position={[0, -0.46, 0]}>
            <sphereGeometry args={[0.15, 18, 14]} />
            <meshStandardMaterial color={color} emissive={color} emissiveIntensity={1.2} />
          </mesh>
        </group>
      </group>

      <mesh position={[-0.2, -0.83, 0]} castShadow>
        <capsuleGeometry args={[0.15, 0.62, 8, 16]} />
        <meshStandardMaterial color="#242d42" metalness={0.55} roughness={0.35} />
      </mesh>
      <mesh position={[0.2, -0.83, 0]} castShadow>
        <capsuleGeometry args={[0.15, 0.62, 8, 16]} />
        <meshStandardMaterial color="#242d42" metalness={0.55} roughness={0.35} />
      </mesh>
    </group>
  );
};


const NovinSpatialCore: React.FC<{ avatarState: AvatarState; reduced?: boolean }> = ({ avatarState, reduced = false }) => {
  const group = useRef<THREE.Group>(null);
  const accent = STATE_COLORS[avatarState];
  useFrame((state) => {
    if (!group.current) return;
    const t = state.clock.elapsedTime;
    group.current.rotation.y = t * 0.18;
    group.current.rotation.x = Math.sin(t * 0.22) * 0.025;
  });
  return (
    <group ref={group} position={[0, 0.22, 0.35]}>
      <mesh>
        <sphereGeometry args={[0.16, reduced ? 12 : 24, reduced ? 8 : 16]} />
        <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={3.5} metalness={0.2} roughness={0.18} />
      </mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.58, 0.012, 6, reduced ? 32 : 64]} />
        <meshBasicMaterial color={accent} transparent opacity={0.55} />
      </mesh>
      {!reduced && <>
        <mesh rotation={[0.62, 0.18, 0.2]}>
          <torusGeometry args={[0.78, 0.009, 6, 64]} />
          <meshBasicMaterial color="#a78bfa" transparent opacity={0.34} />
        </mesh>
        <mesh rotation={[-0.48, 0.35, 0.4]}>
          <torusGeometry args={[0.96, 0.008, 6, 64]} />
          <meshBasicMaterial color="#60a5fa" transparent opacity={0.24} />
        </mesh>
      </>}
      <pointLight position={[0, 0.15, 0.2]} intensity={reduced ? 0.35 : 0.75} distance={2.4} color={accent} />
    </group>
  );
};

const NovinHolographicPillars: React.FC<{ avatarState: AvatarState; reduced?: boolean }> = ({ avatarState, reduced = false }) => {
  const accent = STATE_COLORS[avatarState];
  const pillars = reduced ? 2 : 4;
  return <group>
    {Array.from({ length: pillars }, (_, index) => {
      const angle = (index / pillars) * Math.PI * 2 + Math.PI / 4;
      const radius = reduced ? 2.8 : 3.15;
      return <group key={index} position={[Math.cos(angle) * radius, 1.35, Math.sin(angle) * radius - 0.8]}>
        <mesh>
          <boxGeometry args={[0.035, 2.25, 0.035]} />
          <meshBasicMaterial color={accent} transparent opacity={0.36} />
        </mesh>
        <mesh position={[0, 0.72, 0]}>
          <sphereGeometry args={[0.075, reduced ? 8 : 14, reduced ? 8 : 12]} />
          <meshBasicMaterial color={accent} transparent opacity={0.8} />
        </mesh>
      </group>;
    })}
  </group>;
};

const FloatingWorldParticles: React.FC<{ avatarState: AvatarState }> = ({ avatarState }) => {
  const group = useRef<THREE.Group>(null);
  const accent = STATE_COLORS[avatarState];
  const nodes = useMemo(() => Array.from({ length: 34 }, (_, index) => {
    const a = (index / 34) * Math.PI * 2;
    const radius = 2.4 + (index % 5) * 0.34;
    return { x: Math.cos(a) * radius, y: 0.2 + ((index * 17) % 29) / 10, z: -1.8 + Math.sin(a) * 1.5, s: 0.018 + (index % 3) * 0.009 };
  }), []);
  useFrame((state) => {
    if (!group.current) return;
    group.current.rotation.y = state.clock.elapsedTime * 0.035;
    group.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.21) * 0.018;
  });
  return <group ref={group}>
    {nodes.map((node, index) => <mesh key={index} position={[node.x, node.y, node.z]}>
      <sphereGeometry args={[node.s, 8, 8]} />
      <meshBasicMaterial color={accent} transparent opacity={0.22 + (index % 4) * 0.1} />
    </mesh>)}
  </group>;
};

interface LivingEnvironmentSceneProps {
  design?: Novin3DDesignState;
  avatarState: AvatarState;
  reduced?: boolean;
}

const LivingEnvironmentScene: React.FC<LivingEnvironmentSceneProps> = ({ design, avatarState, reduced = false }) => {
  const group = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (!group.current) return;
    const t = state.clock.elapsedTime;
    group.current.rotation.y = design?.rotationSpeed ? Math.sin(t * 0.12) * Math.min(0.035, design.rotationSpeed * 10) : 0;
  });

  const floor = design?.floor ?? 'GRID';
  const wall = design?.wall ?? 'DEFAULT';
  const atmosphere = design?.atmosphere ?? 'DEFAULT';
  const wallColor = wall === 'GOLD' ? '#8b6b28' : wall === 'GLASS' ? '#24445f' : wall === 'MARBLE_BLACK' ? '#151923' : wall === 'WOOD' ? '#4b3020' : '#182234';
  const floorColor = floor === 'WOOD' ? '#503626' : floor === 'STONE' ? '#343a46' : '#0b1220';
  const accent = atmosphere === 'FUTURISTIC' ? '#22d3ee' : atmosphere === 'LUXURY' ? '#f59e0b' : '#60a5fa';

  const designs = Object.entries(design?.objectDesigns ?? {}).filter(([, item]) => item.visible);
  return (
    <group ref={group} position={[0, -1.2, -0.4]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[12, 10]} />
        <meshStandardMaterial color={floorColor} metalness={floor === 'GRID' ? 0.45 : 0.18} roughness={0.72} />
      </mesh>
      {floor === 'GRID' && <gridHelper args={[12, 24, accent, '#172033']} position={[0, 0.012, 0]} />}
      <mesh position={[0, 2.0, -5]} receiveShadow>
        <boxGeometry args={[12, 4, 0.12]} />
        <meshStandardMaterial color={wallColor} metalness={wall === 'GLASS' ? 0.45 : 0.2} roughness={0.62} />
      </mesh>
      <mesh position={[0, 0.045, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[2.25, 2.5, 0.09, 64]} />
        <meshStandardMaterial color="#111a2c" metalness={0.72} roughness={0.28} emissive={accent} emissiveIntensity={0.05} />
      </mesh>
      <mesh position={[0, 0.11, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.12, 0.025, 8, 96]} />
        <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={2.2} />
      </mesh>
      <mesh position={[0, 2.15, -3.9]} rotation={[0, 0, 0]}>
        <planeGeometry args={[5.4, 2.0]} />
        <meshBasicMaterial color="#0b1220" transparent opacity={0.72} />
      </mesh>
      <mesh position={[0, 2.15, -3.84]}>
        <torusGeometry args={[1.7, 0.018, 8, 64]} />
        <meshBasicMaterial color={accent} transparent opacity={0.42} />
      </mesh>
      <mesh position={[-6, 2.0, 0]} rotation={[0, Math.PI / 2, 0]} receiveShadow>
        <boxGeometry args={[10, 4, 0.12]} />
        <meshStandardMaterial color={wallColor} metalness={0.2} roughness={0.62} />
      </mesh>
      {design?.ceiling !== 'DEFAULT' && (
        <mesh position={[0, 4, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <planeGeometry args={[12, 10]} />
          <meshStandardMaterial color={design.ceiling === 'GOLD' ? '#6d5525' : '#263247'} transparent opacity={0.32} />
        </mesh>
      )}
      <pointLight position={[0, 3.4, -1]} intensity={design?.lighting === 'DRAMATIC' ? 2.8 : 1.6} color={accent} distance={12} />
      {designs.map(([id, item]) => (
        <group key={id} position={[item.position.x, item.position.y, item.position.z - 1.1]} scale={item.scale}>
          {item.primitive === 'SPHERE' ? (
            <mesh castShadow><sphereGeometry args={[0.32, 20, 16]} /><meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={1.4} /></mesh>
          ) : item.primitive === 'CYLINDER' ? (
            <mesh castShadow><cylinderGeometry args={[0.3, 0.36, 0.8, 20]} /><meshStandardMaterial color="#475569" metalness={0.55} roughness={0.35} /></mesh>
          ) : (
            <mesh castShadow><boxGeometry args={[1, 0.55, 0.8]} /><meshStandardMaterial color="#334155" metalness={0.45} roughness={0.38} /></mesh>
          )}
          <pointLight position={[0, 0.7, 0]} intensity={item.primitive === 'SPHERE' ? 1.1 : 0.15} color={accent} distance={2.5} />
        </group>
      ))}
      <NovinSpatialCore avatarState={avatarState} reduced={reduced} />
      <NovinHolographicPillars avatarState={avatarState} reduced={reduced} />
      {avatarState === 'EXECUTING' && (
        <mesh position={[0, 0.03, 0]}>
          <torusGeometry args={[1.7, 0.018, 8, 64]} />
          <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={2} />
        </mesh>
      )}
    </group>
  );
};

export const NovinAvatarVisual: React.FC<NovinAvatarVisualProps> = ({
  avatarState,
  activeEnv,
  activeWorld,
  isListening,
  onToggleVoice,
  lastMessageFa,
  officerRoleFa = 'افسر ارشد هوش مصنوعی / فرمانده عملیات',
  operationalMode = 'AUTONOMOUS_GOVERNED',
  activeApprovals = 0,
  realityEvidenceCount = 0,
  worldHealthStatus,
  worldHealthScore,
  androidMode = false,
  render3D = true,
}) => {
  const evaluatedHealth = evaluateWorldHealth(activeWorld);
  const graphicsProfile = useMemo(() => detectNovinMobileGraphicsProfile(), []);
  const [graphicsAdjustment, setGraphicsAdjustment] = useState(() => ({
    tier: graphicsProfile.tier,
    dprMultiplier: 1,
    shadows: graphicsProfile.shadows,
    postProcessing: graphicsProfile.postProcessing,
    targetFps: graphicsProfile.targetFps,
    reason: 'initial_device_profile',
  }));
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const canvasContextLossHandlerRef = useRef<((event: Event) => void) | null>(null);
  const [avatarSpeaking, setAvatarSpeaking] = useState(false);
  const [avatarSpeechText, setAvatarSpeechText] = useState('');
  const speechGenerationRef = useRef(0);
  const activeUtteranceRef = useRef<string | null>(null);
  const [visualStage, setVisualStage] = useState<'BOOTING' | 'READY' | 'DEGRADED'>('BOOTING');
  const [documentVisible, setDocumentVisible] = useState(() => typeof document === 'undefined' || document.visibilityState === 'visible');
  const [webglCapability, setWebglCapability] = useState<'UNKNOWN' | 'SUPPORTED' | 'UNSUPPORTED'>('UNKNOWN');
  const webglCapabilityRef = useRef<'UNKNOWN' | 'SUPPORTED' | 'UNSUPPORTED'>('UNKNOWN');
  const [visualGeneration, setVisualGeneration] = useState(0);
  const visualRetryRef = useRef(0);

  // Stop the GPU render loop when NOVIN is backgrounded. On resume, React Three
  // Fiber restarts the same scene instead of leaving an invisible 3D loop running.
  useEffect(() => {
    const updateVisibility = () => setDocumentVisible(document.visibilityState === 'visible');
    document.addEventListener('visibilitychange', updateVisibility);
    updateVisibility();
    return () => document.removeEventListener('visibilitychange', updateVisibility);
  }, []);

  useEffect(() => {
    if (typeof document === 'undefined') return;
    let cancelled = false;
    let retryTimer: number | null = null;
    let attempt = 0;

    const probeWebGL = () => {
      if (cancelled || document.visibilityState === 'hidden') return;
      attempt += 1;
      try {
        const probe = document.createElement('canvas');
        const context = probe.getContext('webgl2') || probe.getContext('webgl') || probe.getContext('experimental-webgl');
        const supported = Boolean(context);
        if (supported) {
          webglCapabilityRef.current = 'SUPPORTED';
          setWebglCapability('SUPPORTED');
          setVisualStage('BOOTING');
        } else if (attempt >= 4) {
          webglCapabilityRef.current = 'UNSUPPORTED';
          setWebglCapability('UNSUPPORTED');
          setVisualStage('DEGRADED');
        }
        // Android WebView/GPU initialization can lag behind React mount, especially
        // under power/resource pressure. Retry transient failure before declaring WebGL unavailable.
        // IMPORTANT: never force-loss the probe context. On some Android WebView/GPU stacks,
        // destroying a fresh probe can temporarily starve the real renderer that follows it.
        probe.width = 1;
        probe.height = 1;
      } catch {
        if (attempt >= 4) {
          webglCapabilityRef.current = 'UNSUPPORTED';
          setWebglCapability('UNSUPPORTED');
          setVisualStage('DEGRADED');
        }
      }
      if (!cancelled && attempt < 4 && webglCapabilityRef.current !== 'SUPPORTED') {
        retryTimer = window.setTimeout(probeWebGL, 300);
      }
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible' && webglCapabilityRef.current !== 'SUPPORTED') {
        attempt = 0;
        if (retryTimer !== null) window.clearTimeout(retryTimer);
        retryTimer = window.setTimeout(probeWebGL, 120);
      }
    };

    probeWebGL();
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      cancelled = true;
      if (retryTimer !== null) window.clearTimeout(retryTimer);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  // Capability is intentionally probed once per mount/session; state reads here
  // are only used to avoid unnecessary retries and must not restart the effect.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (webglCapability !== 'UNSUPPORTED') return;
    window.dispatchEvent(new CustomEvent('novin:avatar-webgl-failure', { detail: { message: 'WEBGL_CAPABILITY_UNAVAILABLE' } }));
  }, [webglCapability]);

  useEffect(() => {
    const handleVisualFailure = () => setVisualStage('DEGRADED');
    const handleVisualReady = () => setVisualStage('READY');
    window.addEventListener('novin:avatar-webgl-failure', handleVisualFailure);
    window.addEventListener('novin:avatar-webgl-ready', handleVisualReady);
    return () => {
      window.removeEventListener('novin:avatar-webgl-failure', handleVisualFailure);
      window.removeEventListener('novin:avatar-webgl-ready', handleVisualReady);
    };
  }, []);

  useEffect(() => {
    setVisualStage('BOOTING');
    visualRetryRef.current = 0;
  }, [activeWorld.worldId, activeEnv.envId]);

  useEffect(() => {
    if (visualStage !== 'DEGRADED' || visualRetryRef.current >= 1) return;
    const timer = window.setTimeout(() => {
      visualRetryRef.current += 1;
      setVisualStage('BOOTING');
      setVisualGeneration((value) => value + 1);
    }, 1400);
    return () => window.clearTimeout(timer);
  }, [visualStage]);

  useEffect(() => {
    const handleGraphicsGovernor = (event: Event) => {
      const detail = (event as CustomEvent<{ adjustment?: typeof graphicsAdjustment }>).detail;
      if (!detail?.adjustment) return;
      setGraphicsAdjustment((current) => {
        const next = detail.adjustment!;
        if (current.tier === next.tier && current.dprMultiplier === next.dprMultiplier && current.shadows === next.shadows && current.postProcessing === next.postProcessing && current.targetFps === next.targetFps) return current;
        return next;
      });
    };
    window.addEventListener('novin:graphics-governor', handleGraphicsGovernor);
    return () => window.removeEventListener('novin:graphics-governor', handleGraphicsGovernor);
  }, []);

  useEffect(() => {
    return () => {
      const canvas = canvasRef.current;
      const handler = canvasContextLossHandlerRef.current;
      if (canvas && handler) {
        canvas.removeEventListener('webglcontextlost', handler);
        canvas.removeEventListener('webglcontextrestored', handler);
      }
      canvasContextLossHandlerRef.current = null;
      canvasRef.current = null;
    };
  }, []);

  useEffect(() => {
    const handleSpeech = (event: Event) => {
      const detail = (event as CustomEvent<{ speaking?: boolean; text?: string; viseme?: string; weight?: number; timestampMs?: number; utteranceId?: string; generation?: number; source?: 'REAL_AUDIO' | 'PHONEME' }>).detail;
      if (typeof detail?.generation === 'number' && detail.generation !== speechGenerationRef.current) return;
      if (detail?.speaking === true) {
        speechGenerationRef.current += 1;
        activeUtteranceRef.current = detail.utteranceId ?? null;
        setAvatarSpeaking(true);
      } else if (detail?.speaking === false) {
        if (detail.utteranceId && activeUtteranceRef.current && detail.utteranceId !== activeUtteranceRef.current) return;
        setAvatarSpeaking(false);
        activeUtteranceRef.current = null;
      }
      if (typeof detail?.text === 'string') setAvatarSpeechText(detail.text);
      if (detail?.viseme) {
        const frame = normalizeRealtimeViseme({ ...detail, source: detail.source ?? 'PHONEME' });
        window.dispatchEvent(new CustomEvent('novin:avatar-viseme-frame', { detail: frame }));
      }
    };
    window.addEventListener('novin:avatar-speech', handleSpeech);
    return () => window.removeEventListener('novin:avatar-speech', handleSpeech);
  }, []);
  const effectiveHealthStatus = worldHealthStatus ?? evaluatedHealth.status;
  const effectiveHealthScore = worldHealthScore ?? evaluatedHealth.score;
  const environmentDesign = activeEnv.stateSnapshot.customData?.novin3DDesign as Novin3DDesignState | undefined;
  const stateLabel = ({
    LISTENING: 'در حال شنیدن صدای شما...', THINKING: 'در حال فکر و برنامه‌ریزی...',
    EXECUTING: 'در حال ساخت و اجرا...', WAITING_FOR_APPROVAL: 'در انتظار تأیید انسانی...',
    VALIDATING: 'در حال بررسی نتیجه واقعی...', SPEAKING: 'در حال بیان پاسخ...',
    SUCCESS: 'عملیات با موفقیت ثبت شد.', ERROR: 'خطا تشخیص داده شد؛ مسیر بازیابی فعال است.',
    DEGRADED: 'حالت محدود؛ قابلیت‌ها کامل نیستند.', IDLE: 'آماده دریافت فرمان متنی یا صوتی.',
  } as Record<AvatarState, string>)[avatarState];

  return (
    <section className={`relative flex h-full min-h-0 flex-col overflow-hidden rounded-3xl border border-slate-800 bg-slate-950/95 shadow-2xl ${androidMode ? 'novin-avatar-android-shell' : ''}`}>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,rgba(59,130,246,.16),transparent_45%)]" />
      <div className={`novin-living-stage relative w-full ${androidMode ? 'min-h-0 flex-1' : 'h-[min(68vh,620px)] min-h-[430px]'}`} onDoubleClick={onToggleVoice} aria-label="محیط زنده سه بعدی نوین">
        {render3D && webglCapability !== 'UNSUPPORTED' ? (
        <AvatarWebGLBoundary key={visualGeneration}>
          <Canvas
            camera={{ position: [0, 0.55, 5.8], fov: 40 }}
            shadows={graphicsAdjustment.shadows}
            dpr={Math.max(0.7, Math.min(graphicsProfile.maxDpr, graphicsProfile.maxDpr * graphicsAdjustment.dprMultiplier))}
            frameloop="demand"
            gl={{
              antialias: graphicsProfile.antialias && graphicsAdjustment.tier !== 'SAFE',
              powerPreference: graphicsAdjustment.tier === 'SAFE' ? 'low-power' : 'high-performance',
              alpha: false,
              preserveDrawingBuffer: false,
            }}
            onCreated={({ gl }) => {
              const previousCanvas = canvasRef.current;
              const previousHandler = canvasContextLossHandlerRef.current;
              if (previousCanvas && previousHandler) {
                previousCanvas.removeEventListener('webglcontextlost', previousHandler);
                previousCanvas.removeEventListener('webglcontextrestored', previousHandler);
              }
              const canvas = gl.domElement;
              const handleContext = (event: Event) => {
                if (event.type === 'webglcontextlost') {
                  event.preventDefault();
                  setVisualStage('DEGRADED');
                  window.dispatchEvent(new CustomEvent('novin:avatar-webgl-failure', { detail: { message: 'WEBGL_CONTEXT_LOST' } }));
                  return;
                }
                // Reuse the restored renderer instead of leaving the HUD in a
                // permanent degraded state after Android resumes the GPU context.
                setVisualStage('READY');
                window.dispatchEvent(new CustomEvent('novin:avatar-webgl-ready'));
              };
              canvasRef.current = canvas;
              canvasContextLossHandlerRef.current = handleContext;
              canvas.addEventListener('webglcontextlost', handleContext, false);
              canvas.addEventListener('webglcontextrestored', handleContext, false);
              setVisualStage('READY');
              window.dispatchEvent(new CustomEvent('novin:avatar-webgl-ready'));
            }}
          >
            <AvatarRenderScheduler fps={androidMode ? Math.min(30, graphicsAdjustment.targetFps) : graphicsAdjustment.targetFps} active={documentVisible} />
            <color attach="background" args={['#070b14']} />
            <ambientLight intensity={1.15} />
            <directionalLight position={[2, 4, 3]} intensity={graphicsAdjustment.shadows ? 2.2 : 1.7} castShadow={graphicsAdjustment.shadows} />
            <pointLight position={[0, 2.2, 2.2]} intensity={1.25} distance={6} color="#7dd3fc" />
            <directionalLight position={[-3, 1, 2]} intensity={1.0} color={STATE_COLORS[avatarState]} />
            <LivingEnvironmentScene design={environmentDesign} avatarState={avatarState} reduced={graphicsAdjustment.tier === 'SAFE'} />
            {graphicsAdjustment.tier !== 'SAFE' && <FloatingWorldParticles avatarState={avatarState} />}
            <group scale={androidMode ? 1.08 : 1}><LivingHumanoid avatarState={avatarState} isListening={isListening} speaking={avatarSpeaking} speechText={avatarSpeechText} /></group>
          </Canvas>
        </AvatarWebGLBoundary>
        ) : (
          <AvatarVisualFallback reason={webglCapability === 'UNSUPPORTED' ? 'شتاب‌دهی WebGL در WebView در دسترس نیست؛ محیط تصویری ایمن فعال شد.' : 'در حال آماده‌سازی موتور تصویری...'} />
        )}
        <div className="absolute inset-x-4 top-4 z-10 flex items-start justify-between gap-3 pointer-events-none">
          <div className="novin-stage-hud rounded-2xl border border-white/10 bg-slate-950/55 px-3 py-2 backdrop-blur-xl">
            <div className="text-[9px] uppercase tracking-[0.24em] text-cyan-300/80">NOVIN LIVING CORE</div>
            <div className="mt-1 text-xs font-bold text-slate-100">{activeEnv.titleFa}</div>
            <div className="text-[9px] text-slate-500">{activeWorld.titleFa}</div>
            <div className="mt-1 flex items-center gap-1 text-[8px] font-bold tracking-[.12em] text-cyan-300/70"><span className={`h-1.5 w-1.5 rounded-full ${visualStage === 'READY' ? 'bg-emerald-400' : visualStage === 'DEGRADED' ? 'bg-amber-400' : 'bg-cyan-400 animate-pulse'}`} />{visualStage === 'READY' ? `3D RUNTIME READY · ${graphicsAdjustment.tier}` : visualStage === 'DEGRADED' ? 'VISUAL FALLBACK ACTIVE' : '3D RUNTIME BOOTING'}</div>
          </div>
          <div className="novin-stage-hud rounded-2xl border border-white/10 bg-slate-950/55 px-3 py-2 text-left backdrop-blur-xl">
            <div className="flex items-center justify-end gap-2 text-[9px] text-slate-400">
              <span className={`h-2 w-2 rounded-full ${isListening ? 'bg-rose-400 animate-pulse' : avatarState === 'ERROR' ? 'bg-rose-400' : 'bg-emerald-400 animate-pulse'}`} />
              {stateLabel}
            </div>
            <div className="mt-2 grid grid-cols-3 gap-1.5 text-[8px] font-bold tracking-[.12em]">
              <span className="rounded-lg border border-violet-400/15 bg-violet-400/5 px-2 py-1 text-violet-200">BRAIN {avatarState === 'THINKING' ? 'THINKING' : avatarState === 'EXECUTING' ? 'EXECUTING' : 'IDLE'}</span>
              <span className={`rounded-lg border px-2 py-1 ${isListening ? 'border-rose-400/20 bg-rose-400/5 text-rose-200' : 'border-cyan-400/15 bg-cyan-400/5 text-cyan-200'}`}>VOICE {isListening ? 'LISTENING' : avatarSpeaking ? 'SPEAKING' : 'STANDBY'}</span>
              <span className="rounded-lg border border-amber-400/15 bg-amber-400/5 px-2 py-1 text-amber-200">REALITY {effectiveHealthStatus}</span>
            </div>
            <div className="mt-1 text-[9px] text-slate-500">Reality {effectiveHealthStatus} · {effectiveHealthScore}</div>
          </div>
        </div>
        <div className="absolute bottom-4 left-4 z-10 max-w-[85%] rounded-2xl border border-cyan-400/15 bg-slate-950/80 px-3 py-2.5 backdrop-blur-xl pointer-events-none">
          <div className="flex items-center gap-2 text-[10px] text-cyan-300"><span className="h-1.5 w-1.5 rounded-full bg-cyan-300 animate-pulse" /> محیط زنده نوین</div>
          <div className="mt-1 line-clamp-3 text-xs leading-5 text-slate-100">{lastMessageFa || 'هسته آماده دریافت فرمان است.'}</div>
        </div>
      </div>
      {!androidMode && (
        <div className="relative flex flex-col gap-3 border-t border-slate-800 p-4 md:flex-row md:items-center md:justify-between">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-black text-xl text-slate-100">نوین</span>
              <span className="rounded-full border border-indigo-500/30 bg-indigo-500/15 px-2 py-0.5 text-[10px] text-indigo-300">آواتار مهندس</span>
            </div>
            <p className="mt-1 text-xs text-slate-400">{officerRoleFa}</p>
            {lastMessageFa && <p className="mt-2 line-clamp-2 text-sm text-slate-200">{lastMessageFa}</p>}
          </div>
          <button onClick={onToggleVoice} className={`rounded-xl px-4 py-2 text-sm font-bold text-white shadow-lg transition ${isListening ? 'bg-rose-600' : 'bg-indigo-600 hover:bg-indigo-500'}`}>
            {isListening ? 'توقف شنیدن' : 'فرمان صوتی'}
          </button>
        </div>
      )}
      {!androidMode && (
        <div className="flex flex-wrap gap-2 border-t border-slate-800 p-3 text-[10px] text-slate-400">
          <span>سلامت: {effectiveHealthScore}</span><span>تأییدها: {activeApprovals}</span><span>شواهد: {realityEvidenceCount}</span>
          <span>جهان: {activeWorld.titleFa}</span><span>محیط: {activeEnv.titleFa}</span><span>حالت: {operationalMode}</span>
        </div>
      )}
    </section>
  );
};
