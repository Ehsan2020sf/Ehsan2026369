import React, { Suspense, lazy, useEffect, useMemo, useRef, useState } from 'react';
import { Camera, Mic, Send, Settings, ShieldCheck } from 'lucide-react';
import { NovinAvatarVisual, type AvatarState } from '../avatar/NovinAvatarVisual.tsx';
import { environmentRegistry } from '../../core/environment/environmentRegistry.ts';
import { worldRegistry } from '../../core/world/worldRegistry.ts';
import { HumanSovereigntyGate } from '../../core/governance/humanSovereigntyGate.ts';
import { novinAvatarCommandAuthority } from '../../core/mobile/novinAvatarCommandAuthority.ts';
import { RealityGate } from '../../core/evidence/realityGate.ts';
import { novinAvatarOperatingSystem } from '../../core/nexusAutonomy/novinAvatarOperatingSystem.ts';
import { brainCoordinator } from '../../core/ai/brainCoordinator.ts';
import { novinEngineeringAvatarController } from '../../core/environment/novinEngineeringAvatarController.ts';
import { openOwnerFrontCamera, closeOwnerFrontCamera } from '../../core/mobile/ownerCameraRuntime.ts';
import { captureAndPrepareOwnerVisionExecution } from '../../core/mobile/ownerVisionExecutionBridge.ts';
import { NovinNativeExecution } from '../../core/mobile/novinNativeExecution.ts';
import { checkBackendHealth, getApiUrl } from '../../lib/apiClient.ts';
import { decideLivingBootstrap } from '../../core/mobile/novinLivingBootstrapBrain.ts';
import { novinLivingSystemSupervisor } from '../../core/mobile/novinLivingSystemSupervisor.ts';
import { nextLivingPulseMs } from '../../core/mobile/livingSystemPulsePolicy.ts';
import { verifyAndroidRuntimeReality } from '../../core/mobile/androidRuntimeRealityVerifier.ts';
import { novinLivingAvatarBehaviorEngine } from '../../core/nexus/novinLivingAvatarBehaviorEngine.ts';
import { chooseGraphicsAdjustment, sampleFramePressure, type GraphicsAdjustment } from '../../core/mobile/devicePerformanceGovernor.ts';
import { detectNovinMobileGraphicsProfile } from '../../core/mobile/novinMobileGraphicsProfile.ts';
import type { EnvironmentDefinition } from '../../core/environment/contracts.ts';
import type { WorldDefinition } from '../../core/world/contracts.ts';
import { AndroidAssistantSettings } from './AndroidAssistantSettings.tsx';
import { NovinCommandCenterPanel } from './NovinCommandCenterPanel.tsx';
import { EnvironmentCommandEngine } from '../../core/kernel/environmentCommandEngine.ts';
import { novinEnvironmentKernel } from '../../core/environment/novinEnvironmentKernel.ts';
import { novinCapabilityRegistry } from '../../core/kernel/novinCapabilityRegistry.ts';
const NovinNeuralEngineering = lazy(() => import('./NovinNeuralEngineering.tsx').then((m) => ({ default: m.NovinNeuralEngineering })));
import { NovinVoiceConversationRuntime } from '../../core/mobile/novinVoiceConversationRuntime.ts';
import { detectConversationLanguage } from '../../core/mobile/novinMultilingualConversationRuntime.ts';

export const AndroidAvatarRuntime: React.FC = () => {
  const [avatarState, setAvatarState] = useState<AvatarState>('IDLE');
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastMessageFa, setLastMessageFa] = useState('نوین آماده است. فرمان خود را بگو یا بنویس.');
  const [activeEnv, setActiveEnv] = useState<EnvironmentDefinition>(() => environmentRegistry.getActiveEnvironment());
  const [activeWorld, setActiveWorld] = useState<WorldDefinition>(() => worldRegistry.getActiveWorld());
  const [cameraOpen, setCameraOpen] = useState(false);
  const [activePage, setActivePage] = useState<'AVATAR' | 'COMMAND' | 'CAMERA' | 'SETTINGS' | 'ENGINEERING'>('AVATAR');
  const [visionState, setVisionState] = useState<'IDLE'|'CAPTURING'|'BLOCKED'|'READY'>('IDLE');
  const [bootStage, setBootStage] = useState<'BOOTING'|'NATIVE'|'READY'|'DEGRADED'>('BOOTING');
  const nativeCapabilityRef = useRef<'VERIFIED' | 'DEGRADED'>('DEGRADED');
  const [contactChoices, setContactChoices] = useState<Array<{id:string;name:string;phones:string[]}>>([]);
  const [contactAction, setContactAction] = useState<'CALL'|'MESSAGE'|null>(null);
  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const nativeListeningRef = useRef(false);
  const speechStopRequestedRef = useRef(false);
  const conversationModeRef = useRef(false);
  const processingRef = useRef(false);
  const voiceQueueRef = useRef<Promise<void>>(Promise.resolve());
  const executeRef = useRef<(command: string, modality: 'VOICE' | 'TEXT' | 'CAMERA') => Promise<void>>(async () => undefined);
  const startContinuousListeningRef = useRef<() => void>(() => undefined);
  const speechSequenceRef = useRef(0);
  const mountedRef = useRef(true);
  const listenRestartTimerRef = useRef<number | null>(null);
  const listenSessionRef = useRef(0);
  const activeNativeTtsIdRef = useRef<string | null>(null);
  const activeNativeTtsTextRef = useRef<string | null>(null);
  const voiceConversationRef = useRef(new NovinVoiceConversationRuntime());
  const activeSpeechSessionRef = useRef<number | null>(null);
  const graphicsProfile = useMemo(() => detectNovinMobileGraphicsProfile(), []);
  const interactionReady = bootStage === 'READY' || bootStage === 'DEGRADED';
  const graphicsAdjustmentRef = useRef<GraphicsAdjustment>({ tier: graphicsProfile.tier, dprMultiplier: 1, shadows: graphicsProfile.shadows, postProcessing: graphicsProfile.postProcessing, targetFps: graphicsProfile.targetFps, reason: 'initial_device_profile' });
  const speakResponse = (text: string) => {
    const clean = text.trim();
    const speechSequence = ++speechSequenceRef.current;
    if (!clean || typeof window === 'undefined') return false;
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    nativeListeningRef.current = false;
    speechStopRequestedRef.current = true;
    // Text result already shown via setLastMessageFa; SPEAKING is presentation-only.
    setAvatarState('SPEAKING');

    const speakNativeWhenReady = async () => {
      // Stop recognition/speech in sequence. The previous implementation fired
      // stopSpeaking() and speakText() concurrently, allowing the stop command
      // to race with and cancel a newly accepted utterance.
      await NovinNativeExecution.stopSpeechRecognition().catch(() => undefined);
      await NovinNativeExecution.stopSpeaking().catch(() => undefined);

      for (let attempt = 0; attempt < 12; attempt += 1) {
        if (speechSequence !== speechSequenceRef.current) return;
        const detected = detectConversationLanguage(clean);
        const nativeLanguage = detected.language === 'en' ? 'en-US' : detected.language === 'fa' ? 'fa-IR' : 'AUTO';
        const native = await NovinNativeExecution.speakText(clean, nativeLanguage).catch(() => null);
        if (speechSequence !== speechSequenceRef.current) return;
        if (native?.status === 'PASS') {
          activeNativeTtsIdRef.current = typeof native.utteranceId === 'string' ? native.utteranceId : null;
          activeNativeTtsTextRef.current = clean;
          window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: true, text: clean, runtime: 'ANDROID_NATIVE_TTS', utteranceId: activeNativeTtsIdRef.current } }));
          return;
        }
        if (native?.evidence !== 'ANDROID_TTS_NOT_READY') {
          speakResponseFallback(clean);
          return;
        }
        await new Promise<void>((resolve) => window.setTimeout(resolve, 150));
      }
      if (speechSequence === speechSequenceRef.current) speakResponseFallback(clean);
    };

    void speakNativeWhenReady();
    return true;
  };

  const speakResponseFallback = (clean: string) => {
    if (!('speechSynthesis' in window)) {
      (window as Window).dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: false, runtime: 'NONE', text: clean } }));
      return false;
    }
    nativeListeningRef.current = false;
    void NovinNativeExecution.stopSpeechRecognition().catch(() => undefined);
    window.speechSynthesis.cancel();
    const voices = window.speechSynthesis.getVoices();
    const detected = detectConversationLanguage(clean);
    const targetLang = detected.language === 'en' ? 'en' : 'fa';
    const targetVoice = targetLang === 'en'
      ? (voices.find((voice) => /^en(-|_)/i.test(voice.lang)) || voices.find((voice) => /english/i.test(voice.name)))
      : (voices.find((voice) => /^fa(-|_)/i.test(voice.lang)) || voices.find((voice) => /persian|farsi|فارسی/i.test(voice.name)));
    const chunks = clean.match(/[^.!؟?]+[.!؟?]?/g)?.map((part) => part.trim()).filter(Boolean) ?? [clean];
    let index = 0;
    const speakNext = () => {
      const part = chunks[index++];
      if (!part) {
        window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: false } }));
        if (conversationModeRef.current && !processingRef.current) {
          voiceConversationRef.current.finishSpeaking();
          scheduleListenRestart(180);
        }
        return;
      }
      const partDetected = detectConversationLanguage(part);
      const partLang = partDetected.language === 'en' ? 'en' : 'fa';
      const partVoice = partLang === 'en'
        ? (voices.find((voice) => /^en(-|_)/i.test(voice.lang)) || voices.find((voice) => /english/i.test(voice.name)))
        : (voices.find((voice) => /^fa(-|_)/i.test(voice.lang)) || voices.find((voice) => /persian|farsi|فارسی/i.test(voice.name)));
      const utterance = new SpeechSynthesisUtterance(part);
      utterance.lang = partVoice?.lang || (partLang === 'en' ? 'en-US' : 'fa-IR');
      if (partVoice) utterance.voice = partVoice;
      utterance.rate = 0.94;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;
      utterance.onstart = () => {
        recognitionRef.current?.stop();
        recognitionRef.current = null;
        setIsListening(false);
        window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: true, text: clean } }));
      };
      utterance.onend = speakNext;
      utterance.onerror = () => window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: false } }));
      window.speechSynthesis.speak(utterance);
    };
    speakNext();
    return true;
  };


  useEffect(() => {
    if (!interactionReady) return;
    let cancelled = false;
    let raf = 0;
    let previous = performance.now();
    let frameCount = 0;
    let lastNative = 0;
    const tick = async (now: number) => {
      if (cancelled) return;
      const frameTime = now - previous;
      previous = now;
      frameCount += 1;
      if (frameCount % 30 === 0) {
        let native: Awaited<ReturnType<typeof NovinNativeExecution.getPerformanceSnapshot>> = { memoryPressure: 'UNKNOWN', thermal: 'UNKNOWN', gpuPressure: 'UNKNOWN' };
        if (now - lastNative > 1500 && NovinNativeExecution.getPerformanceSnapshot) {
          lastNative = now;
          try { native = await NovinNativeExecution.getPerformanceSnapshot(); } catch { /* unknown remains unknown */ }
        }
        const sample = sampleFramePressure(frameTime, native.memoryPressure, native.thermal);
        graphicsAdjustmentRef.current = chooseGraphicsAdjustment(graphicsAdjustmentRef.current.tier, sample);
        window.dispatchEvent(new CustomEvent('novin:graphics-governor', { detail: { sample, adjustment: graphicsAdjustmentRef.current } }));
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelled = true; cancelAnimationFrame(raf); };
  }, [bootStage, interactionReady]);

  useEffect(() => {
    const unsubEnv = environmentRegistry.subscribe((env) => setActiveEnv({ ...env }));
    const unsubWorld = worldRegistry.subscribe((world) => setActiveWorld({ ...world }));
    return () => { unsubEnv(); unsubWorld(); };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const performanceSnapshotRef: { current?: { memoryPressure?: 'LOW'|'MEDIUM'|'HIGH'|'CRITICAL'|'UNKNOWN'; thermal?: 'NOMINAL'|'WARM'|'HOT'|'CRITICAL'|'UNKNOWN'; batteryPct?: number; charging?: boolean; powerSave?: boolean } } = {};
    const reconcileLiveState = async () => {
      if (cancelled || nativeCapabilityRef.current !== 'VERIFIED') return;
      const online = typeof navigator === 'undefined' ? 'UNKNOWN' as const : navigator.onLine ? 'ONLINE' as const : 'OFFLINE' as const;
      let gateway: 'ONLINE'|'OFFLINE'|'UNKNOWN' = online;
      if (online === 'ONLINE') {
        try {
          gateway = (await checkBackendHealth(3500)) ? 'ONLINE' : 'OFFLINE';
        } catch {
          gateway = 'OFFLINE';
        }
      }
      const media = await NovinNativeExecution.getMediaPermissionState().catch(() => ({ camera: 'DENIED' as const, microphone: 'DENIED' as const, status: 'PASS' as const, runtime: 'UNKNOWN' }));
      const tts = await NovinNativeExecution.getTtsStatus?.().catch(() => undefined);
      const performance = await NovinNativeExecution.getPerformanceSnapshot?.().catch(() => undefined);
      performanceSnapshotRef.current = performance;
      const living = novinLivingSystemSupervisor.reconcile({
        native: 'AVAILABLE', nativeVerified: true, network: online,
        microphone: media.microphone, camera: media.camera,
        tts: tts?.ttsReady ? 'READY' : 'DEGRADED',
        memory: performance?.memoryPressure ?? 'UNKNOWN', memoryPressure: performance?.memoryPressure,
        thermal: performance?.thermal, gateway, provider: 'UNKNOWN', ttsVerified: Boolean(tts?.verified),
      });
      novinCapabilityRegistry.set('living.supervisor', living.health === 'ALIVE' ? 'AVAILABLE' : 'DEGRADED', `cycle=${living.cycle};issues=${living.issues.length};agents=${living.readyAgents}/${living.totalAgents};gateway=${gateway}`);
      novinCapabilityRegistry.set('internet.gateway', gateway === 'ONLINE' ? 'AVAILABLE' : gateway === 'OFFLINE' ? 'DEGRADED' : 'UNKNOWN', `health=${getApiUrl('/api/health')}`);
      novinCapabilityRegistry.set('voice.tts', tts?.ttsReady ? 'AVAILABLE' : 'DEGRADED', tts?.evidence ?? 'TTS status unknown');
      return living.health;
    };
    let timer: number | undefined;
    const schedule = (delayMs: number) => {
      if (cancelled) return;
      timer = window.setTimeout(async () => {
        if (cancelled) return;
        const living = await reconcileLiveState();
        schedule(nextLivingPulseMs({
          health: living,
          batteryPct: performanceSnapshotRef.current?.batteryPct,
          charging: performanceSnapshotRef.current?.charging,
          powerSave: performanceSnapshotRef.current?.powerSave,
          memoryPressure: performanceSnapshotRef.current?.memoryPressure,
          thermal: performanceSnapshotRef.current?.thermal,
        }));
      }, delayMs);
    };
    void reconcileLiveState().then((living) => {
      if (living) schedule(nextLivingPulseMs({
        health: living,
        batteryPct: performanceSnapshotRef.current?.batteryPct,
        charging: performanceSnapshotRef.current?.charging,
        powerSave: performanceSnapshotRef.current?.powerSave,
        memoryPressure: performanceSnapshotRef.current?.memoryPressure,
        thermal: performanceSnapshotRef.current?.thermal,
      }));
    });
    return () => { cancelled = true; if (timer !== undefined) window.clearTimeout(timer); };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const boot = async () => {
      setBootStage('BOOTING');
      novinEnvironmentKernel.reportBootStage('BOOTING', 'avatar runtime mount');
      setLastMessageFa('در حال راه‌اندازی نوین...');
      try {
        setBootStage('NATIVE');
        novinEnvironmentKernel.reportBootStage('NATIVE', 'native probe');
        const probe = await NovinNativeExecution.probe();
        const reality = verifyAndroidRuntimeReality(probe);
        if (cancelled) return;
        if (reality.status !== 'PASS') {
          nativeCapabilityRef.current = 'DEGRADED';
          setBootStage('DEGRADED');
          novinEnvironmentKernel.reportBootStage('DEGRADED', reality.status);
          novinCapabilityRegistry.set('android.native', 'DEGRADED', reality.status);
          novinEnvironmentKernel.setCapability('android', 'DEGRADED');
          setAvatarState('DEGRADED');
          novinCapabilityRegistry.set('voice.tts', 'UNKNOWN', 'Android TTS probe unavailable because native runtime is degraded');
          setLastMessageFa('محیط نوین آماده است؛ بعضی قابلیت‌های بومی Android فعلاً در حالت محدود هستند.');
          return;
        }
        nativeCapabilityRef.current = 'VERIFIED';
        const media = await NovinNativeExecution.getMediaPermissionState();
        const online = typeof navigator === 'undefined' ? 'UNKNOWN' as const : navigator.onLine ? 'ONLINE' as const : 'OFFLINE' as const;
        const decision = decideLivingBootstrap({
          native: 'AVAILABLE',
          network: online,
          microphone: media.microphone,
          camera: media.camera,
          tts: 'UNKNOWN',
          memory: 'UNKNOWN',
        });
        const performance = await NovinNativeExecution.getPerformanceSnapshot?.().catch(() => undefined);
        const living = novinLivingSystemSupervisor.reconcile({
          native: 'AVAILABLE',
          nativeVerified: true,
          network: online,
          microphone: media.microphone,
          camera: media.camera,
          tts: 'UNKNOWN',
          memory: performance?.memoryPressure ?? 'UNKNOWN',
          memoryPressure: performance?.memoryPressure,
          thermal: performance?.thermal,
          gateway: 'UNKNOWN',
          provider: 'UNKNOWN',
        });
        novinCapabilityRegistry.set('living.supervisor', living.health === 'ALIVE' ? 'AVAILABLE' : 'DEGRADED', `cycle=${living.cycle};issues=${living.issues.length};agents=${living.readyAgents}/${living.totalAgents}`);
        if (cancelled) return;
        novinCapabilityRegistry.set('bootstrap.brain', decision.health === 'HEALTHY' ? 'AVAILABLE' : 'DEGRADED', decision.reasons.join('|') || 'living bootstrap healthy');
        if (decision.health === 'BLOCKED') setBootStage('DEGRADED'); else setBootStage('READY');
        novinEnvironmentKernel.reportBootStage(decision.health === 'BLOCKED' ? 'DEGRADED' : 'READY', `native verified; bootstrap=${decision.health}`);
        novinCapabilityRegistry.set('android.native', 'AVAILABLE', 'NovinNativeExecution.probe PASS');
        novinEnvironmentKernel.setCapability('android', 'AVAILABLE');
        novinCapabilityRegistry.set('voice.stt', media.microphone === 'GRANTED' ? 'AVAILABLE' : 'DEGRADED', `mic=${media.microphone}`);
        novinCapabilityRegistry.set('voice.tts', 'DEGRADED', 'TTS is lazy and will be verified/initialized on first speech request');
        novinCapabilityRegistry.set('camera', media.camera === 'GRANTED' ? 'AVAILABLE' : 'DEGRADED', `camera=${media.camera}`);
        if (media.camera !== 'GRANTED' || media.microphone !== 'GRANTED') {
          setLastMessageFa('نوین آماده است. برای فرمان صوتی یا دوربین، مجوز مربوطه را فعال کن.');
        } else {
          setLastMessageFa('نوین آماده است. فرمان خود را بگو یا بنویس.');
        }
      } catch {
        if (!cancelled) {
          nativeCapabilityRef.current = 'DEGRADED';
          setBootStage('DEGRADED');
          novinEnvironmentKernel.reportBootStage('DEGRADED', 'boot exception');
          novinCapabilityRegistry.set('android.native', 'DEGRADED', 'boot exception');
          setAvatarState('DEGRADED');
          setLastMessageFa('محیط نوین آماده است؛ لایه Android در حالت محدود اجرا می‌شود.');
        }
      }
    };
    void boot();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    const clearListenRestart = () => {
      if (listenRestartTimerRef.current !== null) {
        window.clearTimeout(listenRestartTimerRef.current);
        listenRestartTimerRef.current = null;
      }
    };
    const scheduleListenRestart = (delayMs: number) => {
      clearListenRestart();
      if (!conversationModeRef.current || processingRef.current) return;
      listenRestartTimerRef.current = window.setTimeout(() => {
        listenRestartTimerRef.current = null;
        if (mountedRef.current && conversationModeRef.current && !processingRef.current) startContinuousListeningRef.current();
      }, delayMs);
    };
    const handleHidden = () => {
      if (document.visibilityState !== 'visible') {
        conversationModeRef.current = false;
        ++listenSessionRef.current;
        activeNativeTtsIdRef.current = null;
        clearListenRestart();
        recognitionRef.current?.stop();
        recognitionRef.current = null;
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: false } }));
        setIsListening(false);
        setCameraOpen(false);
        setAvatarState('IDLE');
      }
    };
    document.addEventListener('visibilitychange', handleHidden);
    return () => {
      mountedRef.current = false;
      clearListenRestart();
      document.removeEventListener('visibilitychange', handleHidden);
    };
  }, []);

  useEffect(() => {
    if (!cameraOpen || activePage !== 'CAMERA') return;
    let cancelled = false;
    const activate = async () => {
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
      const video = cameraVideoRef.current;
      if (!video || cancelled) return;
      const result = await openOwnerFrontCamera(video);
      if (!cancelled) {
        setLastMessageFa(result.active ? 'دوربین واقعی فعال شد. برای تحلیل تصویر، دکمه تحلیل را بزن.' : `دوربین فعال نشد: ${result.evidence[0]}`);
        setVisionState(result.active ? 'IDLE' : 'BLOCKED');
      }
    };
    void activate();
    return () => { cancelled = true; if (cameraVideoRef.current) closeOwnerFrontCamera(cameraVideoRef.current); };
  }, [cameraOpen, activePage]);


  // Watchdog: never leave UI permanently locked if a command hangs
  useEffect(() => {
    if (!isProcessing) return;
    const t = window.setTimeout(() => {
      if (processingRef.current) {
        console.warn('[NOVIN_PROCESSING_WATCHDOG] force-reset after 45s');
        processingRef.current = false;
        setIsProcessing(false);
        setAvatarState('DEGRADED');
        setLastMessageFa('اجرای فرمان بیش از حد طول کشید و بازنشانی شد. دوباره تلاش کنید.');
      }
    }, 45000);
    return () => window.clearTimeout(t);
  }, [isProcessing]);

  const execute = async (command: string, modality: 'VOICE' | 'TEXT' | 'CAMERA' = 'TEXT') => {
    const raw = command.trim();
    // Controlled diagnostic: enable with localStorage.NOVIN_DEBUG=1 or window.__NOVIN_DEBUG__=true
    const cmdDebug = true;
    const cmdLog = (tag: string, data?: Record<string, unknown>) => {
      if (cmdDebug && typeof console !== 'undefined') console.info('[NOVIN_CMD]', tag, data ?? {});
    };
    cmdLog('ENTER', { modality, len: raw.length, interactionReady, processing: processingRef.current, bootStage });
    if (!raw || processingRef.current || !interactionReady) {
      cmdLog('EARLY_EXIT', { empty: !raw, processing: processingRef.current, interactionReady, bootStage });
      return;
    }
    processingRef.current = true;
    nativeListeningRef.current = false;
    void NovinNativeExecution.stopSpeechRecognition().catch(() => undefined);
    setIsProcessing(true);
    setAvatarState('THINKING');
    novinLivingAvatarBehaviorEngine.setState('THINKING', 'THINK');
    try {
      setAvatarState('EXECUTING');
      const normalized = raw.toLowerCase();
      // SINGLE AVATAR COMMAND SPINE: device, engineering, autonomy and conversation
      // commands are admitted by one authority. The UI only presents the result.
      const authority = await novinAvatarCommandAuthority.execute(raw, modality);
      if (authority.route !== 'MIND' || authority.success || authority.needsApproval) {
        setLastMessageFa(authority.messageFa);
        if (modality === 'VOICE') speakResponse(authority.messageFa);
        setAvatarState(authority.needsApproval ? 'VALIDATING' : authority.success ? 'SUCCESS' : 'ERROR');
        return;
      }

      novinLivingAvatarBehaviorEngine.setState('WORKING', 'NONE');
      // NORMAL CHAT PATH: authority has already admitted all other command classes.
        // NORMAL CHAT PATH:
        // Every Android command, including natural conversation, enters the
        // canonical Mind Core command spine. UI must never call the provider
        // conversation adapter directly.
        const result = await EnvironmentCommandEngine.executeCommand(raw, {
          sourceModality: modality,
        });
        const blocked = !result.success || result.needsApproval === true;
        const generated = result.messageFa.startsWith('[GENERATED]');

        cmdLog('CONVERSATION_RESULT', {
          status: blocked ? 'BLOCKED' : 'PASS',
          reality: generated ? 'GENERATED' : blocked ? 'UNKNOWN' : 'OBSERVED',
          providerUsed: generated,
          confidence: blocked ? 0 : 1,
          evidenceId: result.evidenceId,
          msgLen: result.messageFa.length,
        });

        setLastMessageFa(result.messageFa);
        if (modality === 'VOICE') {
          voiceConversationRef.current.acceptResponse(result.messageFa, generated ? 'GENERATED' : blocked ? 'BLOCKED' : 'UNKNOWN');
          speakResponse(result.messageFa);
        }

        if (blocked) {
          novinEnvironmentKernel.reportCommandPhase('VALIDATING');
          setAvatarState('VALIDATING');
        } else {
          novinEnvironmentKernel.reportCommandPhase('SUCCESS');
          setAvatarState('SUCCESS');
        }
      if (modality === 'CAMERA') setCameraOpen(false);
      window.setTimeout(() => { if (!conversationModeRef.current) setAvatarState('IDLE'); }, 1800);
    } catch (error) {
      cmdLog('EXCEPTION', { error: error instanceof Error ? error.message : String(error) });
      novinEnvironmentKernel.reportCommandPhase('ERROR');
      const errorMessage = error instanceof Error ? error.message : String(error);
      const errorStack = error instanceof Error ? error.stack : undefined;
      cmdLog('EXCEPTION_DETAIL', { error: errorMessage, stack: errorStack });
      setLastMessageFa(`اجرای فرمان ناموفق بود: ${errorMessage || 'UNKNOWN_ERROR'}`);
      setAvatarState('ERROR');
    } finally {
      processingRef.current = false;
      setIsProcessing(false);
      cmdLog('FINALLY', { processing: processingRef.current, isProcessing: false });
      novinLivingAvatarBehaviorEngine.setState(conversationModeRef.current ? 'LISTENING' : 'IDLE', conversationModeRef.current ? 'LOOK_AT_USER' : 'NONE');
    }
  };

  executeRef.current = execute;

  const scheduleListenRestart = (delayMs: number) => {
    if (typeof window === 'undefined' || !conversationModeRef.current || processingRef.current) return;
    if (listenRestartTimerRef.current !== null) window.clearTimeout(listenRestartTimerRef.current);
    const session = listenSessionRef.current;
    listenRestartTimerRef.current = window.setTimeout(() => {
      listenRestartTimerRef.current = null;
      if (session !== listenSessionRef.current || !conversationModeRef.current || processingRef.current) return;
      startContinuousListeningRef.current();
    }, delayMs);
  };

  useEffect(() => {
    const add = NovinNativeExecution.addListener;
    if (!add) return;
    let active = true;
    let remove: (() => Promise<void>) | null = null;
    const removers: Array<() => Promise<void>> = [];
    const register = (eventName: 'speechResult' | 'speechError' | 'speechReady' | 'speechStarted' | 'speechEnded' | 'ttsStarted' | 'ttsFinished' | 'ttsError', handler: (event: { text?: string; error?: string; runtime?: string; utteranceId?: string; speechSessionId?: number }) => void) => {
      void add(eventName, handler).then((handle) => {
        if (active) removers.push(handle.remove); else void handle.remove();
      }).catch(() => undefined);
    };
    register('speechResult', (event) => {
      if (event.speechSessionId != null && activeSpeechSessionRef.current != null && event.speechSessionId !== activeSpeechSessionRef.current) return;
      const transcript = event.text?.trim() ?? '';
      nativeListeningRef.current = false;
      if (transcript) voiceConversationRef.current.acceptTranscript(transcript);
      if (!active || !transcript || !conversationModeRef.current) return;
      setIsListening(false);
      voiceQueueRef.current = voiceQueueRef.current.then(() => executeRef.current(transcript, 'VOICE')).catch(() => undefined);
    });
    register('speechError', (event) => {
      if (event.speechSessionId != null && activeSpeechSessionRef.current != null && event.speechSessionId !== activeSpeechSessionRef.current) return;
      nativeListeningRef.current = false;
      if (speechStopRequestedRef.current) { speechStopRequestedRef.current = false; return; }
      if (!active || !conversationModeRef.current) return;
      setIsListening(false);
      if (event.error) setLastMessageFa(`خطای تشخیص گفتار Android: ${event.error}`);
      if (!processingRef.current) scheduleListenRestart(350);
    });
    register('speechEnded', (event) => {
      if (event.speechSessionId != null && activeSpeechSessionRef.current != null && event.speechSessionId !== activeSpeechSessionRef.current) return;
      nativeListeningRef.current = false;
      if (!active || !conversationModeRef.current || processingRef.current) return;
      scheduleListenRestart(180);
    });
    register('ttsStarted', () => {
      if (!active) return;
      setIsListening(false);
      setAvatarState('SPEAKING');
      window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: true, runtime: 'ANDROID_NATIVE_TTS' } }));
    });
    register('ttsFinished', (event) => {
      if (!active) return;
      const eventId = event.utteranceId;
      if (activeNativeTtsIdRef.current && eventId && eventId !== activeNativeTtsIdRef.current) return;
      activeNativeTtsIdRef.current = null;
      activeNativeTtsTextRef.current = null;
      window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: false, runtime: 'ANDROID_NATIVE_TTS' } }));
      // Text result remains visible; avatar returns to IDLE unless still processing.
      if (!processingRef.current) {
        setAvatarState(conversationModeRef.current ? 'LISTENING' : 'SUCCESS');
        window.setTimeout(() => {
          if (!processingRef.current && !conversationModeRef.current) setAvatarState('IDLE');
        }, 1200);
      }
      if (conversationModeRef.current && !processingRef.current) scheduleListenRestart(180);
    });
    register('ttsError', (event) => {
      if (!active) return;
      const eventId = event.utteranceId;
      if (activeNativeTtsIdRef.current && eventId && eventId !== activeNativeTtsIdRef.current) return;
      const failedText = activeNativeTtsTextRef.current;
      activeNativeTtsIdRef.current = null;
      activeNativeTtsTextRef.current = null;
      window.dispatchEvent(new CustomEvent('novin:avatar-speech', { detail: { speaking: false, runtime: 'ANDROID_NATIVE_TTS' } }));
      // Keep text result; mark degraded speech only — do not wipe message.
      if (!processingRef.current) setAvatarState('DEGRADED');
      if (failedText) {
        window.setTimeout(() => {
          if (active && !processingRef.current) speakResponseFallback(failedText);
        }, 0);
      } else if (conversationModeRef.current && !processingRef.current) {
        scheduleListenRestart(180);
      }
    });
    return () => {
      active = false;
      for (const removeListener of removers) void removeListener();
    };
  }, []);

  const startContinuousListening = () => {
    if (!interactionReady || !conversationModeRef.current || recognitionRef.current || nativeListeningRef.current || typeof window === 'undefined') return;
    const session = ++listenSessionRef.current;
    activeSpeechSessionRef.current = null;
    // Android Native SpeechRecognizer is the canonical path. Browser Web Speech is fallback only.
    speechStopRequestedRef.current = false;
    void NovinNativeExecution.startSpeechRecognition('AUTO').then((native) => {
      if (session !== listenSessionRef.current || !conversationModeRef.current) {
        if (native.status === 'PASS') void NovinNativeExecution.stopSpeechRecognition().catch(() => undefined);
        return;
      }
      if (native.status === 'PASS') {
        activeSpeechSessionRef.current = native.speechSessionId ?? activeSpeechSessionRef.current;
        nativeListeningRef.current = true;
        voiceConversationRef.current.beginListening();
        setIsListening(true);
        setAvatarState('LISTENING');
        setLastMessageFa('نوین با تشخیص گفتار Android گوش می‌دهد...');
        return;
      }
      const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!Ctor) {
        nativeListeningRef.current = false;
        conversationModeRef.current = false;
        setIsListening(false);
        setAvatarState('ERROR');
        setLastMessageFa('تشخیص گفتار Android در این دستگاه در دسترس نیست.');
        return;
      }
      startWebSpeechRecognition(Ctor);
    }).catch(() => {
      const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (Ctor) startWebSpeechRecognition(Ctor);
      else {
        nativeListeningRef.current = false;
        conversationModeRef.current = false;
        setIsListening(false);
        setAvatarState('ERROR');
        setLastMessageFa('تشخیص گفتار در دسترس نیست.');
      }
    });
  };

  const startWebSpeechRecognition = (Ctor: SpeechRecognitionConstructor) => {
    const recognition = new Ctor();
    recognition.lang = 'fa-IR';
    recognition.interimResults = false;
    recognition.continuous = true;
    recognition.onresult = (event: SpeechRecognitionEvent & { resultIndex: number; results: ArrayLike<{ isFinal?: boolean; 0?: { transcript?: string } }> }) => {
      const finalParts: string[] = [];
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        if (event.results[i]?.isFinal) finalParts.push(event.results[i][0]?.transcript || '');
      }
      const transcript = finalParts.join(' ').trim();
      if (!transcript) return;
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      voiceQueueRef.current = voiceQueueRef.current.then(() => executeRef.current(transcript, 'VOICE')).catch(() => undefined);
    };
    recognition.onerror = (event) => {
      recognitionRef.current = null;
      setIsListening(false);
      if (conversationModeRef.current && event.error !== 'aborted' && event.error !== 'no-speech') {
        setLastMessageFa(`خطای گفتار: ${event.error || 'UNKNOWN'}`);
        scheduleListenRestart(350);
      }
    };
    recognition.onend = () => {
      if (recognitionRef.current === recognition) recognitionRef.current = null;
      setIsListening(false);
      if (conversationModeRef.current && !processingRef.current) scheduleListenRestart(180);
    };
    recognitionRef.current = recognition;
    try { recognition.start(); setIsListening(true); setAvatarState('LISTENING'); setLastMessageFa('نوین گوش می‌دهد... صحبت کن.'); }
    catch { recognitionRef.current = null; setIsListening(false); setAvatarState('ERROR'); setLastMessageFa('شروع گفت‌وگوی صوتی پیوسته انجام نشد.'); }
  };

  startContinuousListeningRef.current = startContinuousListening;

  const toggleVoice = () => {
    if (conversationModeRef.current) {
      conversationModeRef.current = false;
      voiceConversationRef.current.interrupt();
      ++listenSessionRef.current;
      activeNativeTtsIdRef.current = null;
      if (listenRestartTimerRef.current !== null) { window.clearTimeout(listenRestartTimerRef.current); listenRestartTimerRef.current = null; }
      recognitionRef.current?.stop();
      recognitionRef.current = null;
      nativeListeningRef.current = false;
      activeSpeechSessionRef.current = null;
      speechStopRequestedRef.current = true;
      void NovinNativeExecution.stopSpeechRecognition().catch(() => undefined);
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      setIsListening(false);
      setAvatarState('IDLE');
      setLastMessageFa('گفت‌وگوی صوتی پیوسته متوقف شد.');
      return;
    }
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    conversationModeRef.current = true;
    startContinuousListening();
  };

  return (
    <div className="novin-note11-shell min-h-[100dvh] h-[100dvh] w-full overflow-hidden bg-[#030712] text-slate-100 flex flex-col" dir="rtl">
      <header className="relative z-20 flex shrink-0 items-center justify-between border-b border-white/5 bg-slate-950/80 px-4 py-3 backdrop-blur-xl">
        <div className="flex min-w-0 items-center gap-3">
          <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-cyan-400/25 bg-cyan-400/10 shadow-[0_0_24px_rgba(34,211,238,.12)]">
            <ShieldCheck className="h-5 w-5 text-cyan-300" />
            <span className={`absolute -bottom-0.5 -left-0.5 h-2.5 w-2.5 rounded-full border-2 border-slate-950 ${bootStage === 'READY' ? 'bg-emerald-400' : bootStage === 'DEGRADED' ? 'bg-cyan-400' : 'bg-amber-400'}`} />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2"><span className="font-black tracking-tight text-slate-100">NOVIN NEXUS</span><span className="rounded-full border border-indigo-400/20 bg-indigo-400/10 px-2 py-0.5 text-[9px] text-indigo-300">LIVING RUNTIME</span></div>
            <div className="truncate text-[10px] text-slate-500">نوین هوشمند دید برتر · هسته تحت حاکمیت مالک</div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[9px] text-slate-400">
          <span className="hidden rounded-full border border-white/5 bg-white/[.03] px-2 py-1 sm:inline">{activeEnv.titleFa}</span>
          <span className={`rounded-full border px-2 py-1 ${bootStage === 'READY' ? 'border-emerald-400/20 bg-emerald-400/10 text-emerald-300' : 'border-amber-400/20 bg-amber-400/10 text-amber-300'}`}>{bootStage === 'READY' ? 'سیستم زنده' : bootStage === 'DEGRADED' ? 'سیستم زنده · حالت محدود' : 'در حال بیدارسازی'}</span>
        </div>
      </header>
      <main className="flex-1 min-h-0 w-full overflow-hidden">
        {activePage === 'AVATAR' ? (
          <section className="mx-auto flex h-full min-h-0 w-full max-w-6xl flex-col gap-2 p-2 sm:p-3">
            <div className="min-h-0 flex-1">
              <NovinAvatarVisual avatarState={avatarState} activeEnv={activeEnv} activeWorld={activeWorld} isListening={isListening} onToggleVoice={toggleVoice} lastMessageFa={lastMessageFa} androidMode render3D={true} activeApprovals={HumanSovereigntyGate.getPending().length} realityEvidenceCount={RealityGate.getLogs().length} />
            </div>
            {/* Always-visible Android response strip — independent of AvatarVisual androidMode panels */}
            <div
              className="relative z-30 shrink-0 rounded-2xl border border-cyan-400/20 bg-slate-900/95 px-3 py-2.5 shadow-lg shadow-black/30 backdrop-blur-xl"
              data-novin-cmd-result="1"
              role="status"
              aria-live="polite"
            >
              <div className="flex items-center gap-2 text-[10px] text-cyan-300/90">
                <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${isProcessing ? 'animate-pulse bg-amber-400' : avatarState === 'ERROR' ? 'bg-rose-400' : avatarState === 'SUCCESS' ? 'bg-emerald-400' : 'bg-cyan-300'}`} />
                <span className="font-medium">{isProcessing ? 'در حال اجرا' : avatarState === 'ERROR' ? 'خطا' : avatarState === 'SUCCESS' ? 'انجام شد' : avatarState === 'VALIDATING' ? 'نیازمند تایید' : 'پاسخ نوین'}</span>
                {!interactionReady ? <span className="text-amber-300/80">· ورودی هنوز فعال نیست</span> : null}
              </div>
              <p className="mt-1 max-h-20 overflow-y-auto text-sm leading-5 text-slate-100 whitespace-pre-wrap break-words">
                {lastMessageFa || 'هسته آماده دریافت فرمان است.'}
              </p>
            </div>
            <form className="relative flex shrink-0 items-center gap-2 rounded-2xl border border-white/10 bg-slate-900/85 p-2 shadow-2xl shadow-black/20 backdrop-blur-xl" onSubmit={(event) => { event.preventDefault(); const input = event.currentTarget.elements.namedItem('command') as HTMLInputElement | null; if (input?.value.trim()) { const value = input.value; input.value = ''; if (typeof window !== 'undefined' && ((window as unknown as { __NOVIN_DEBUG__?: boolean }).__NOVIN_DEBUG__ === true || (typeof localStorage !== 'undefined' && localStorage.getItem('NOVIN_DEBUG') === '1')) && typeof console !== 'undefined') console.info('[NOVIN_CMD]', 'FORM_SUBMIT', { len: value.trim().length }); void execute(value, 'TEXT'); } }}>
              <input name="command" disabled={isProcessing || !interactionReady} dir="rtl" placeholder={isListening ? 'نوین در حال شنیدن است...' : 'با نوین صحبت کن یا فرمانت را بنویس...'} className="min-w-0 flex-1 rounded-xl border border-white/5 bg-slate-950/80 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-cyan-400/40 disabled:opacity-50" />
              <button type="button" onClick={toggleVoice} disabled={isProcessing || !interactionReady} className={`rounded-xl p-3 transition ${isListening ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/20' : 'bg-cyan-400/10 text-cyan-200 hover:bg-cyan-400/20'}`} title="گفت‌وگوی صوتی پیوسته"><Mic className="h-4 w-4" /></button>
              <button type="submit" disabled={isProcessing || !interactionReady} className="rounded-xl bg-indigo-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-indigo-600/20 transition hover:bg-indigo-500 disabled:opacity-40"><Send className="h-4 w-4" /></button>
            </form>
            {contactChoices.length > 0 ? <div className="rounded-2xl border border-amber-500/30 bg-slate-900 p-3 space-y-2"><div className="text-sm font-bold">انتخاب مخاطب برای {contactAction === 'CALL' ? 'تماس' : 'پیام'}</div>{contactChoices.map((contact) => <button key={contact.id} onClick={async () => { const actionCommand = contactAction === 'CALL' ? `به ${contact.name} زنگ بزن` : `به ${contact.name} پیام بده`; const result = await novinAvatarCommandAuthority.execute(actionCommand, 'TEXT'); setLastMessageFa(result.messageFa); setContactChoices([]); setContactAction(null); setAvatarState(result.needsApproval ? 'VALIDATING' : result.success ? 'SUCCESS' : 'ERROR'); }} className="w-full text-right rounded-xl bg-slate-800 px-3 py-3"><b>{contact.name}</b><span className="block text-xs text-slate-500 mt-1">{contact.phones.join(' ، ')}</span></button>)}</div> : null}
          </section>
        ) : activePage === 'SETTINGS' ? (
          <AndroidAssistantSettings />
        ) : activePage === 'ENGINEERING' ? (
                            <Suspense fallback={<div className="p-4 text-sm text-slate-400">محیط مهندسی در حال بارگذاری است...</div>}><NovinNeuralEngineering /></Suspense>
                        ) : activePage === 'COMMAND' ? (
                            <NovinCommandCenterPanel
                                onExecute={(cmd) => { void execute(cmd, 'TEXT'); }}
                                bootStage={bootStage}
                                avatarState={avatarState}
                                lastMessageFa={lastMessageFa}
                                isProcessing={isProcessing}
                            />
                        ) : (
          <section className="h-full flex flex-col p-4 max-w-3xl w-full mx-auto gap-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4">
              <div className="flex items-center justify-between mb-3">
                <div><div className="font-black">دوربین</div><div className="text-xs text-slate-500">صفحه مستقل ورودی تصویر، جدا از آواتار</div></div>
                <Camera className="w-5 h-5 text-slate-300" />
              </div>
              <video ref={cameraVideoRef} className="w-full aspect-video rounded-xl bg-black object-cover" playsInline muted autoPlay />
              <div className="mt-3 flex gap-2">
                {!cameraOpen ? <button className="flex-1 rounded-xl bg-indigo-600 px-4 py-3 text-sm font-bold" onClick={() => { setCameraOpen(true); setAvatarState('IDLE'); }}>فعال‌کردن دوربین</button> : null}
                {cameraOpen ? <button className="flex-1 rounded-xl bg-indigo-600 px-4 py-3 text-sm font-bold disabled:opacity-50" disabled={visionState === 'CAPTURING'} onClick={async () => {
                  const video = cameraVideoRef.current;
                  if (!video) return;
                  setVisionState('CAPTURING');
                  const executionId = `ANDROID-VISION-${Date.now()}`;
                  try {
                    const prepared = await captureAndPrepareOwnerVisionExecution(video, { executionId, payloadRef: 'pending', requireRealExecution: true });
                    prepared.release();
                    if (!prepared.captured) {
                      setVisionState('BLOCKED');
                      setLastMessageFa(`فریم دوربین آماده نشد: ${prepared.reason}`);
                    } else {
                      const vision = await executeOwnerVisionAgainstGateway(video);
                      if (vision.status === 'SUCCESS') {
                        setVisionState('READY');
                        setLastMessageFa(`تحلیل Vision (${vision.provider || 'provider'} / ${vision.modelUsed || 'model'}): ${vision.replyFa}`);
                        setAvatarState('SUCCESS');
                      } else {
                        setVisionState('BLOCKED');
                        setLastMessageFa(`Vision متوقف شد: ${vision.reason || 'NOT_VERIFIED'}`);
                        setAvatarState('VALIDATING');
                      }
                    }
                  } catch (error) {
                    setVisionState('BLOCKED');
                    setLastMessageFa(`تحلیل تصویر انجام نشد: ${error instanceof Error ? error.message : 'UNKNOWN_ERROR'}`);
                  }
                }}>تحلیل تصویر</button> : null}
                {cameraOpen ? <button className="rounded-xl bg-rose-600 px-4 py-3 text-sm font-bold" onClick={() => setCameraOpen(false)}>بستن</button> : null}
              </div>
              <div className="mt-3 text-xs text-slate-400">وضعیت: {visionState}</div>
            </div>
          </section>
        )}
      </main>
      <nav className="novin-bottom-nav relative z-20 shrink-0 border-t border-cyan-400/10 bg-slate-950/95 p-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-xl">
        <div className="mx-auto grid max-w-5xl grid-cols-5 gap-1.5">
          <button type="button" onClick={() => { setActivePage('AVATAR'); setCameraOpen(false); }} className={`rounded-xl px-2 py-3 text-[11px] font-bold ${activePage === 'AVATAR' ? 'bg-cyan-600 text-white shadow-[0_0_16px_rgba(34,211,238,.25)]' : 'bg-slate-900 text-slate-400'}`}>آواتار</button>
          <button type="button" onClick={() => { setActivePage('COMMAND'); setCameraOpen(false); }} className={`rounded-xl px-2 py-3 text-[11px] font-bold ${activePage === 'COMMAND' ? 'bg-cyan-600 text-white shadow-[0_0_16px_rgba(34,211,238,.25)]' : 'bg-slate-900 text-slate-400'}`}>فرماندهی</button>
          <button type="button" onClick={() => setActivePage('CAMERA')} className={`rounded-xl px-2 py-3 text-[11px] font-bold ${activePage === 'CAMERA' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400'}`}><Camera className="inline w-3.5 h-3.5 ml-0.5" />دوربین</button>
          <button type="button" onClick={() => { setActivePage('ENGINEERING'); setCameraOpen(false); }} className={`rounded-xl px-2 py-3 text-[11px] font-bold ${activePage === 'ENGINEERING' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400'}`}>
            مهندسی عصبی
          </button>
          <button type="button" onClick={() => setActivePage('SETTINGS')} className={`rounded-xl px-2 py-3 text-[11px] font-bold ${activePage === 'SETTINGS' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400'}`}><Settings className="inline w-3.5 h-3.5 ml-0.5" />تنظیمات</button>
        </div>
      </nav>
    </div>
  );
};
