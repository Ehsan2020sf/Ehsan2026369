# Rollback record: NOVIN REA integration

This snapshot records the pre-REA contents of the two existing files modified by this integration. Their exact original bytes are stored in `before/package.json.before` and `before/NOVIN_MASTER_STATE.md.before`.

To roll back this integration:

1. Restore `before/package.json.before` to repository root as `package.json`.
2. Restore `before/NOVIN_MASTER_STATE.md.before` to repository root as `NOVIN_MASTER_STATE.md`.
3. Remove the newly added `.agents/skills/novin-rea-static-audit/`, `tools/third_party/rea/`, `scripts/novin_rea_bridge.mjs`, `scripts/novin_rea_bridge.test.mjs`, `scripts/verify_novin_rea_vendor.mjs`, `docs/engineering/NOVIN_REA_INTEGRATION.md`, `NOVIN_REA_INTEGRATION_STATE_20261013.md`, and `artifacts/rea/`.
4. Re-run the existing NOVIN checks before using the restored archive.

No Android source, Android manifest, runtime code, or root dependency/lockfile entries were modified by the REA integration.
