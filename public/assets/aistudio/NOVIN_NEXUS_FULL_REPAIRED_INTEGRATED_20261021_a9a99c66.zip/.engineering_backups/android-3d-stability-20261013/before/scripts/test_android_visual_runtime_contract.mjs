import fs from 'node:fs';

const runtime = fs.readFileSync('src/components/mobile/AndroidAvatarRuntime.tsx', 'utf8');
const avatar = fs.readFileSync('src/components/avatar/NovinAvatarVisual.tsx', 'utf8');
const css = fs.readFileSync('src/index.css', 'utf8');

const checks = [
  ['visual_mount_not_blocked_by_native_probe', /render3D=\{true\}/.test(runtime) && !/render3D=\{bootStage/.test(runtime)],
  ['webgl_boundary_exists', /class AvatarWebGLBoundary/.test(avatar)],
  ['visual_fallback_exists', /AvatarVisualFallback/.test(avatar)],
  ['fallback_is_animated', /novin-avatar-fallback-core/.test(css) && /novin-fallback-float/.test(css)],
  ['fallback_has_status_label', /هسته تصویری نوین فعال است/.test(avatar)],
  ['legacy_webgl_diagnostic_removed', !/NOVIN WEBGL DIAGNOSTIC|NOVIN HTML OK|ROOT CHILDREN/.test(runtime + avatar + css)],
  ['living_hud_present', /LIVING RUNTIME/.test(runtime) && /BRAIN/.test(avatar) && /REALITY/.test(avatar)],
  ['degraded_mode_keeps_interaction_alive', /'DEGRADED'/.test(runtime) && /const interactionReady = bootStage === 'READY' \|\| bootStage === 'DEGRADED'/.test(runtime)],
  ['immersive_stage_present', /novin-living-stage/.test(avatar) && /androidMode \? 'min-h-0 flex-1'/.test(avatar)],
  ['world_particles_present', /FloatingWorldParticles/.test(avatar)],
  ['webgl_ready_state_reported', /novin:avatar-webgl-ready/.test(avatar) && /3D RUNTIME READY/.test(avatar)],
  ['webgl_context_loss_recovery', /webglcontextlost/.test(avatar) && /setVisualGeneration/.test(avatar)],
  ['visual_retry_is_bounded', /visualRetryRef.current >= 1/.test(avatar)],
  ['webview_root_contract', /html, body, #root/.test(css) && /#root \{ min-height: 100dvh; \}/.test(css)],
  ['canvas_fills_visual_stage', /\.novin-living-stage canvas/.test(css) && /height: 100% !important/.test(css)],
  ['immersive_world_platform', /cylinderGeometry args=\{\[2\.25, 2\.5/.test(avatar) && /torusGeometry args=\{\[2\.12/.test(avatar)],
  ['android_dynamic_viewport_contract', /100dvh/.test(runtime) && /novin-bottom-nav/.test(runtime)],
  ['android_avatar_shell_uses_full_stage', /novin-avatar-android-shell/.test(avatar) && /min-h-0 flex-1/.test(avatar)],
  ['android_safe_area_nav', /safe-area-inset-bottom/.test(css)],
];

const failed = checks.filter(([, ok]) => !ok);
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
if (failed.length) process.exit(1);
console.log(`ANDROID_VISUAL_RUNTIME_CONTRACT PASS checks=${checks.length}`);
