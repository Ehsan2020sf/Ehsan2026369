import { detectNovinMobileGraphicsProfile } from './novinMobileGraphicsProfile.ts';
const p = detectNovinMobileGraphicsProfile();
if (!['ULTRA','HIGH','BALANCED','SAFE'].includes(p.tier)) throw new Error('invalid tier');
if (!(p.pixelRatio >= 1 && p.pixelRatio <= p.maxDpr)) throw new Error('invalid pixel ratio');
if (p.targetFps !== 30 && p.targetFps !== 60) throw new Error('invalid target fps');
console.log(`NOVIN_MOBILE_GRAPHICS_PROFILE_PASS tier=${p.tier} webgl2=${p.webgl2}`);
