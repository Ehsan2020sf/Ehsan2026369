export type NovinGraphicsTier = 'ULTRA' | 'HIGH' | 'BALANCED' | 'SAFE';

export interface NovinMobileGraphicsProfile {
  tier: NovinGraphicsTier;
  pixelRatio: number;
  antialias: boolean;
  shadows: boolean;
  shadowMapSize: 512 | 1024 | 2048;
  postProcessing: boolean;
  maxDpr: number;
  targetFps: 30 | 60;
  hardwareConcurrency: number;
  deviceMemoryGb: number | null;
  webgl2: boolean;
  rendererHint: string;
}


let cachedProfile: NovinMobileGraphicsProfile | null = null;

function computeNovinMobileGraphicsProfile(): NovinMobileGraphicsProfile {
  if (typeof window === 'undefined') {
    return {
      tier: 'SAFE', pixelRatio: 1, antialias: false, shadows: false, shadowMapSize: 512,
      postProcessing: false, maxDpr: 1, targetFps: 30, hardwareConcurrency: 2,
      deviceMemoryGb: null, webgl2: false, rendererHint: 'SSR',
    };
  }

  const hardwareConcurrency = Math.max(1, Number(navigator.hardwareConcurrency || 4));
  const deviceMemoryGb = typeof (navigator as Navigator & { deviceMemory?: number }).deviceMemory === 'number'
    ? Number((navigator as Navigator & { deviceMemory?: number }).deviceMemory)
    : null;
  const canvas = document.createElement('canvas');
  const gl2 = canvas.getContext('webgl2');
  const gl1 = gl2 ? null : canvas.getContext('webgl');
  const activeGl = gl2 ?? gl1;
  const debug = activeGl?.getExtension('WEBGL_debug_renderer_info');
  const rendererHint = debug ? String(activeGl?.getParameter(debug.UNMASKED_RENDERER_WEBGL) ?? 'UNKNOWN') : 'UNKNOWN';
  const webgl2 = Boolean(gl2);
  // Do not force-loss the probe context on Android WebView. Explicitly losing a
  // freshly-created context can transiently starve the next renderer creation,
  // especially under power/resource pressure. Let the tiny probe canvas become
  // unreachable naturally instead.
  const dpr = Math.max(1, window.devicePixelRatio || 1);
  const memoryScore = deviceMemoryGb === null ? 2 : deviceMemoryGb >= 8 ? 4 : deviceMemoryGb >= 6 ? 3 : deviceMemoryGb >= 4 ? 2 : 1;
  const cpuScore = hardwareConcurrency >= 8 ? 4 : hardwareConcurrency >= 6 ? 3 : hardwareConcurrency >= 4 ? 2 : 1;
  const gpuScore = webgl2 ? 3 : 1;
  let score = memoryScore + cpuScore + gpuScore;

  // Redmi Note 11 / Xiaomi mid-range: keep a real 3D living avatar (not a flat shell).
  // WebGL2 floor → at least BALANCED (shadows + antialias). Thermal governor may still
  // lower DPR under pressure without turning off the 3D pipeline.
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : '';
  const isXiaomiFamily = /Xiaomi|Redmi|POCO|MIUI|HyperOS/i.test(ua) || /Adreno \(TM\) 61|Mali-G57/i.test(rendererHint);
  if (webgl2 && (isXiaomiFamily || score < 6)) {
    score = Math.max(score, 6);
  }

  if (score >= 10) {
    return { tier: 'ULTRA', pixelRatio: Math.min(dpr, 2), antialias: true, shadows: true, shadowMapSize: 2048, postProcessing: true, maxDpr: 2, targetFps: 60, hardwareConcurrency, deviceMemoryGb, webgl2, rendererHint };
  }
  if (score >= 8) {
    return { tier: 'HIGH', pixelRatio: Math.min(dpr, 1.75), antialias: true, shadows: true, shadowMapSize: 1024, postProcessing: true, maxDpr: 1.75, targetFps: 60, hardwareConcurrency, deviceMemoryGb, webgl2, rendererHint };
  }
  if (score >= 6) {
    return { tier: 'BALANCED', pixelRatio: Math.min(dpr, 1.5), antialias: true, shadows: true, shadowMapSize: 1024, postProcessing: false, maxDpr: 1.5, targetFps: 60, hardwareConcurrency, deviceMemoryGb, webgl2, rendererHint };
  }
  // SAFE still uses WebGL 3D when available — quality only, not feature removal.
  return { tier: 'SAFE', pixelRatio: Math.min(dpr, 1.35), antialias: webgl2, shadows: false, shadowMapSize: 512, postProcessing: false, maxDpr: 1.35, targetFps: 30, hardwareConcurrency, deviceMemoryGb, webgl2, rendererHint };
}

/**
 * Graphics capability is device-session state, not render state. Cache it so
 * React re-renders and sibling 3D surfaces never create repeated WebGL probes.
 */
export function detectNovinMobileGraphicsProfile(): NovinMobileGraphicsProfile {
  if (cachedProfile) return cachedProfile;
  cachedProfile = computeNovinMobileGraphicsProfile();
  return cachedProfile;
}

/** Test/dev hook. Never called by production UI paths. */
export function resetNovinMobileGraphicsProfileCache(): void {
  cachedProfile = null;
}
