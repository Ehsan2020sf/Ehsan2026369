# NOVIN Stage 121: Provider timeout classification and bounded deadlines

Date: 2026-10-17

## Finding
The OpenAI adapter bounded configured timeouts, while the Gemini adapter passed `provider.timeoutMs` directly to `setTimeout`. The two adapters also converted an aborted fetch into its runtime-specific generic error message, which made timeout failures harder to diagnose reliably.

## Changes
- Added `boundedProviderTimeout()` with a finite default of 45,000 ms and bounds of 1,000 to 120,000 ms.
- Applied the same timeout bounds to Gemini and OpenAI provider calls.
- When the adapter's own timeout aborts the fetch, return a bounded, provider-specific `PROVIDER_TIMEOUT:<provider>` error marked retryable.
- Timeout failures continue through the gateway's existing failure path, which produces an empty `UNKNOWN` response with zero estimated cost rather than fabricating generated content.
- Added `scripts/test_ai_gateway_provider_timeout_classification.ts` using a controlled fetch mock.

## Verification performed
- `node --experimental-strip-types scripts/test_ai_gateway_provider_timeout_classification.ts` — PASS; one Gemini attempt, timeout classified, reality `UNKNOWN`, cost 0, no content.
- `node --experimental-strip-types scripts/test_ai_idempotency_inflight_ttl.ts` — PASS; one provider call for concurrent duplicate requests after simulated TTL passage.
- `node --experimental-strip-types scripts/test_ai_gateway_transient_http_retry.ts` — PASS; controlled HTTP 503 retry behavior.
- `node --experimental-strip-types scripts/test_ai_gateway_request_trace_provenance.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_gateway_blocked_request_trace.ts` — PASS.

All provider behavior tests used controlled local mocks, not live external model services.

## Scope and limits
This stage standardizes and classifies provider-owned timeouts. `AIRequest` does not yet expose a caller-owned cancellation signal, so user-initiated cancellation propagation is NOT IMPLEMENTED / NOT TESTED in this stage. Full `test:all`, full TypeScript compilation, APK build, and physical-device tests were not run. No dependencies were installed.

## Archive
Updated the single canonical archive in place: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`. No parallel archive was created. Archive integrity, duplicate entry count, changed-file parity, and SHA-256 are recorded in the stage completion message.
