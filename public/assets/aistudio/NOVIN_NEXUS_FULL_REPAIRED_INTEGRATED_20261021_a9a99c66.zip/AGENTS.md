# NOVIN NEXUS: Agent Engineering Contract

## Mission
Build NOVIN as a dependable Android-native personal assistant, not a mockup. Prioritize a real end-to-end user path: Persian input → governed conversation/decision → evidence-backed response → Persian audio output, with camera/vision and avatar capabilities only when their runtime paths are real and testable.

## Non-negotiable truth rules
- Evidence first. Never report PASS without naming the exact command/test and its result.
- UNKNOWN is not SUCCESS. A mocked contract test does not prove a live provider, device runtime, or production deployment.
- Distinguish source correctness, build success, APK creation, device installation, and live-provider operation.
- Never claim sentient/self-aware behavior. Describe capabilities in observable engineering terms.
- Never print, commit, or log secrets, API keys, personal data, or full environment values.
- Fail closed for missing authorization, invalid provider configuration, budget exhaustion, and uncertain side effects.

## Architecture boundaries
- Reuse the existing architecture and canonical namespace. No architecture reset, mass rewrite, duplicate service, raw bypass, or parallel source of truth.
- Keep Mind/Core, governance/AEGIS, evidence/memory, agent orchestration, provider gateway, Android lifecycle, UI, avatar, STT, TTS, and camera/vision as distinct responsibilities.
- UI status must be derived from actual runtime evidence. A glowing orb, animation, avatar, or microphone icon is not proof of intelligence, listening, speech, or vision.
- Route external AI calls through the existing governed gateway and budget controls. Do not introduce direct provider calls from UI components.
- Preserve Android application identity and version alignment unless a tested, intentional migration requires changing them.

## Low-quota / low-token workflow
1. Read this file, `NOVIN_START_HERE.md`, `NOVIN_MASTER_STATE.md` if present, the latest continuation state, and the latest stage report. Do not read every historical report unless a concrete conflict requires it.
2. Inspect `package.json`, the exact target module, its direct tests, and git/status or a before/after file inventory before editing.
3. State a one-paragraph plan and choose the smallest coherent change with the highest user-visible value.
4. Reuse existing scripts and utilities. Do not repeat tests that have valid fresh evidence unless the change affects them.
5. Make the smallest patch. Avoid unrelated formatting, generated-file churn, dependency upgrades, lockfile rewrites, and broad refactors.
6. Run focused tests first, then `npm run test:all` when feasible. Run build/typecheck only when dependencies are present; do not repeatedly retry npm installs while registry DNS/network is known blocked.
7. Report exact changed files, commands, outcomes, blockers, and next single best action. Do not hide failures or turn timeouts into PASS.

## Definition of done
- A reproducible change exists in the source tree.
- Relevant tests pass, or the failure/blocker is precisely recorded.
- Security, authorization, cost/budget, cancellation, timeout, and cleanup behavior are considered where relevant.
- No secret or unrelated file is introduced.
- Documentation and evidence match the actual code state.
- If archive is updated, verify ZIP integrity and SHA-256 sidecar, and test from a fresh extraction where practical.
- Do not claim an APK/device/live-provider PASS without the corresponding real artifact or device/provider evidence.

## Agent coordination
Codex is the primary implementation agent when available. Cursor/Windsurf may review or implement a narrowly scoped follow-up, but must not independently duplicate the same work. Replit is for reproducible web preview/build workflows, not proof of Android-native behavior. Use one shared task brief and one owner per patch; other agents review diffs rather than redoing the task.
