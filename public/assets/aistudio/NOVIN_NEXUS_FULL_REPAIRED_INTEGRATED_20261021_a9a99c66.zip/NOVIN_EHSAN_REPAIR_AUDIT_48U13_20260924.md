# NOVIN EHSAN Repair Audit 48U13

## Actual repair
A persisted-evidence boundary was found where successful software callbacks from DeviceActionBridge were classified as OBSERVED. Although the records contained DEVICE_RUNTIME_PROOF_REQUIRED, OBSERVED could still be misread as physical-device observation.

## Repair
- DeviceActionBridge callback execution is now classified UNKNOWN unless independent physical-device evidence exists.
- Existing six affected persisted records were downgraded to UNKNOWN, not deleted.
- Checksums were rebuilt.
- A regression test now rejects OBSERVED records whose source/notes indicate mock/callback/device-runtime-proof-required execution.

## Verification
- Device Action Reality Boundary: PASS
- Device Evidence UNKNOWN Boundary: PASS
- Persisted Evidence Truth Boundary: PASS, 408 records checked, invalid VERIFIED_REAL=0, invalid REAL_EXECUTED=0, checksum failures=0
- Current Evidence Isolation: PASS
- Reality Claims: PASS
- Runtime Wiring: PASS, 9/9
- Unified Integrity: PASS, 1584 files, errors=0, warnings=0

## Reality limits
No physical-device proof was created. APK build, physical Redmi device E2E, and live AI remain NOT VERIFIED/BLOCKED.
