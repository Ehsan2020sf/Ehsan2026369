# NOVIN NSCO Tenant Isolation / Agent Runtime Hardening — 2026-09-23

## Scope
Only the NSCO ↔ Agent Runtime tenant-isolation boundary was inspected and hardened in this cycle.

## Finding
`AgentRuntime.run()` previously treated `tenantId` as optional. When omitted, the runtime skipped `AgentAuthorizationBoundary` entirely and could continue into AI/runtime processing. This violated fail-closed tenant authorization because the execution boundary could proceed without an explicit tenant context.

## Fix
- `AgentExecutionInput.tenantId` is now required.
- `AgentRuntime.run()` fails closed with `AGENT_TENANT_REQUIRED` before authorization or provider execution when tenant context is missing.
- Existing callers were wired to pass their explicit mission tenant/world context.
- Memory recording no longer relies on an optional tenant branch because successful runtime execution now always has a tenant context.
- No new executor, authority, or bypass path was introduced.

## Evidence
- `AGENT_RUNTIME_TENANT_REALITY_GATE_PASS`
- `ALL_AGENT_AI_RUNTIME_TESTS_PASS`
- `R103_AGENT_AUTHORIZATION_BOUNDARY_PASS`
- `NSCO_CHIEF_OPERATIONS_PLANE` test: `PASS`

## Reality status
- Tenant isolation at Agent Runtime boundary: **PASS**
- Missing tenant fail-closed behavior: **PASS**
- Wrong-tenant authorization path: **BLOCKED** as expected
- External AI provider registration: **NOT VERIFIED**
- Physical Android APK/device execution: **NOT VERIFIED**
- Full project build: **NOT VERIFIED / BLOCKED**

This PASS is limited to the focused source-level hardening and regression tests for this section. It is not evidence of APK/device execution.

## Change boundary
No Build/Deploy, Recovery, Memory, Security Command Plane, Avatar Worker, Brain/Body, or other completed section was intentionally modified in this cycle except the minimum Agent Runtime callers required to preserve the tenant boundary.
