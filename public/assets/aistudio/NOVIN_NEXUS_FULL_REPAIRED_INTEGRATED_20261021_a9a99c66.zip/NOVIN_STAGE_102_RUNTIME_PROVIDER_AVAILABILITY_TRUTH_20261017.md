# NOVIN Stage 102 — Runtime Provider Availability Truth Boundary

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding

`AIGateway.execute()` refreshed provider availability at request time through `refreshRuntimeProviderAvailability()`, updating the model router from current runtime environment/credential state. However, the separate `anyConfiguredLiveProvider` check still consulted `candidate.enabled`, a value captured in `DEFAULT_PROVIDERS` at module initialization. In workers where the live permission and credentials become available after import, the router and universal provider security policy could therefore disagree.

## Change

- `refreshRuntimeProviderAvailability()` now returns the exact set of providers enabled under the current runtime gate.
- `execute()` uses that set when determining whether any live provider is configured, instead of trusting stale import-time `provider.enabled` values.
- The live gate remains fail-closed: without `NOVIN_ALLOW_LIVE_AI=1` and a configured credential, the controlled test observes zero outbound fetch calls.
- Added `scripts/test_ai_gateway_runtime_provider_refresh.ts` using a mocked `fetch` response and a dummy test credential. It proves a provider that becomes configured after module import can pass the runtime gate, while no real provider network is contacted.
- Registered `test:ai-gateway-runtime-provider-refresh` in `package.json` and the `test:all` chain.

## Verification performed

- `node --experimental-strip-types scripts/test_ai_gateway_runtime_provider_refresh.ts` — PASS. No-permission case made zero network calls; after runtime permission/credential injection, exactly one mocked OpenAI endpoint call returned `GENERATED`.
- `node --experimental-strip-types scripts/test_ai_gateway_router_integration.ts` — PASS; response remained explicitly `SIMULATED` for the local simulation path and over-budget forced model was rejected.
- `node --experimental-strip-types scripts/test_ai_provider_failure_fallback.ts` — PASS; explicitly permitted simulation fallback remained `SIMULATED`.
- `node --experimental-strip-types scripts/test_ai_idempotency_concurrency.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_failure_recovery.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_gateway_router_contract.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_retry_budget.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_edge_matrix.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_lifecycle_boundary.ts` — PASS.
- `node --experimental-strip-types scripts/test_ai_idempotency_canonicalization.ts` — PASS.
- `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts` — PASS; local responses reported `SIMULATED/FALLBACK`, not live AI.
- `package.json` parsed as valid JSON.

## Limits

No live provider call was made. The apparent `GENERATED` response in the new test came from a locally mocked HTTP response, not an actual model. No full `test:all`, full TypeScript build, dependency installation, APK build, or Android device test was performed. This fixes a runtime availability/governance mismatch; it does not establish production credential availability or live model reliability.
