# NOVIN Stage 120: In-flight Idempotency TTL Race

Date: 2026-10-17

## Finding
The gateway's idempotency cache purged entries solely by expiry timestamp. A second check also treated an expired in-flight entry as absent. If provider work lasted longer than the five-minute cache TTL, a repeated request could start duplicate provider work under the same request ID. In addition, response publication was keyed only by request ID, allowing an old execution to mutate whichever cache entry currently used that key.

## Changes
- `src/core/ai/aiGateway.ts`
  - In-flight reservations remain eligible for joining after the cache TTL; TTL expiry applies only to completed cache entries.
  - Purge skips in-flight entries.
  - Completion publishes a result only if both the request fingerprint and the exact execution promise still own the reservation.
  - Rejected execution removes an entry only when that same execution still owns it.
  - Removed early cache writes from the execution path; the owner publishes the terminal result once it resolves.
- `scripts/test_ai_idempotency_inflight_ttl.ts`
  - Advances the wall clock beyond the five-minute TTL while a mocked provider call is deliberately held in flight.
  - Confirms a duplicate caller joins the existing execution and exactly one provider call occurs.

## Focused validation
Executed with the already available Node runtime, without installing dependencies:
- `node --experimental-strip-types scripts/test_ai_idempotency_inflight_ttl.ts` — PASS
- `node --experimental-strip-types scripts/test_ai_idempotency_fallback_interaction.ts` — PASS
- `node --experimental-strip-types scripts/test_ai_gateway_marks_fallback_failure.ts` — PASS
- `node --experimental-strip-types scripts/test_ai_gateway_request_trace_provenance.ts` — PASS
- `node --experimental-strip-types scripts/test_ai_gateway_blocked_request_trace.ts` — PASS

The TTL regression test advances mocked wall-clock time by six minutes while the first provider call is pending and observes exactly one provider call and consistent results for both callers. All provider responses are local mocks; no live model endpoint is used.

## Limits
- Full `test:all` was not run.
- Full TypeScript compilation was not verified.
- No dependencies were installed, no APK was built, and no Android device installation or runtime test was performed.

## Archive
The canonical archive was updated in place. Integrity, duplicate-path, changed-file parity, size, and SHA-256 results are recorded in the stage completion message.
