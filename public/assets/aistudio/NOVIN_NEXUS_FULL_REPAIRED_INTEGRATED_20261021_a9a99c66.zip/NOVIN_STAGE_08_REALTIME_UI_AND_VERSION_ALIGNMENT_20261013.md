# NOVIN NEXUS Stage 08: Realtime UI integration and release version alignment

Date: 2026-10-13
Previous version: `0.9.26-unified`
Updated source version: `0.9.27-unified`
Android versionName/versionCode: `0.9.27` / `92700`
Canonical archive path: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip` (path retained).

## Implemented

- Connected `NovinRealtimeAndroidRuntime` to the canonical Android avatar UI through an explicit user-initiated control.
- Added a visible realtime lifecycle state, surfaced text/transcript events and errors, and retained the existing standard voice path as an independent option.
- Realtime capture is stopped when the document becomes hidden or the component unmounts.
- Before realtime capture, native speech recognition is stopped to avoid competing microphone consumers. Toggling back to the standard voice path first releases realtime resources.
- Added a static UI integration contract with 10 checks and included it in `test:all`.
- Aligned package, lockfile, Android Gradle, system manifest, mobile build adapter, release manifest, and real-world readiness version metadata.
- Regenerated the neural engineering source index after source changes.

## Verification

- `npm run test:all`: PASS, exit 0.
- `npm run test:rebuild-integrity`: PASS, exit 0.
- Realtime UI integration contract: PASS, 10 checks.
- WebRTC cleanup contract: PASS, mocked SDP failure confirms microphone tracks stopped, peer closed, channel closed, audio removed, and idempotent disconnect.
- Release version alignment contract: added and included in full suite; run result recorded in continuation state.
- `npm run preflight:platform-deps`: BLOCKED_ENVIRONMENT. `node_modules` is absent, including `@esbuild/linux-x64` and `@rollup/rollup-linux-x64-gnu`; lockfile is present.
- `npm run build:web`: BLOCKED at the dependency preflight, before Vite build.
- APK build/install and physical Redmi Note 11 runtime: NOT TESTED.

## Boundaries

The realtime path is now connected at source/UI level, but provider-backed end-to-end audio is not verified. It requires a configured server-side provider key, reachable broker/provider, WebView microphone permission, and a real device/browser session. This change does not claim a successful live AI session. Web assets are not regenerated because native build dependencies cannot be restored in the current environment.

## Next actions

1. Restore dependencies using `npm ci --include=optional` on a network-enabled compatible Linux x64 build host; do not copy `node_modules` across architectures.
2. Pass TypeScript/lint and `build:web`, then write and verify the source-digest asset manifest.
3. Run Capacitor sync and pass the Gradle asset freshness gate.
4. Build APK; verify application ID, version, signing certificate, file size, and SHA-256.
5. Test on Redmi Note 11 Android 13: WebGL, lifecycle, microphone permission, realtime audio in/out, disconnect/reconnect, STT/TTS, camera/vision, thermal and memory pressure.
