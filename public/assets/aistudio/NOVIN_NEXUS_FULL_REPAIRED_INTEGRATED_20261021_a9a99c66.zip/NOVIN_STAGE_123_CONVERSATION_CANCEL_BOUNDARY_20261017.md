# NOVIN Stage 123: Conversation cancellation boundary
Date: 2026-10-17

## Scope
Connect caller cancellation from multilingual/Persian conversation APIs into the AI gateway and ensure cancellation is not converted into a simulated answer or stale accepted reply.

## Changes
- `src/core/mobile/novinMultilingualConversationRuntime.ts`
  - Added optional `AbortSignal` to the multilingual conversation entry point and passed it into `aiGateway.complete`.
  - A signal already aborted before the queued turn starts returns `BLOCKED`/`UNKNOWN` with empty reply and does not mutate conversation history.
  - Re-checks cancellation after provider completion before accepting the response, preventing a late result from being stored after cancellation.
  - If cancellation occurs during provider work, it does not append a simulated NOVIN fallback turn.
- `src/core/mobile/novinPersianConversationRuntime.ts`
  - Added optional signal parameter and forwards it to the multilingual runtime.
- Added regression assertions for pre-cancelled requests in multilingual and Persian conversation tests.

## Focused test evidence
Executed successfully with Node's built-in TypeScript stripping; no dependency installation:
1. `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
2. `node --experimental-strip-types src/core/mobile/novinPersianConversationRuntime.test.ts`
3. `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`
4. `node --experimental-strip-types scripts/test_ai_gateway_caller_cancellation.ts`
5. `node --experimental-strip-types src/core/mobile/novinVoiceConversationRuntime.test.ts`

All five passed. The gateway cancellation test uses controlled provider mocks, not a live provider.

## Boundary and limitations
- The cancellation signal is now supported at the multilingual/Persian conversation API boundary and propagated to the gateway.
- This stage does **not** prove that a visible Android UI stop button or native voice screen passes an AbortSignal; that wiring must be audited separately.
- The post-provider cancellation check prevents accepting a result if cancellation is observable before the continuation accepts it. It cannot undo provider work already completed remotely.
- Full `test:all`, full TypeScript compilation, APK build, live network validation, and device installation were not run.
- No dependencies installed; no phone commands or installation performed.

## Status
- Focused tests: PASS
- UI stop-button wiring: UNKNOWN / NOT VERIFIED
- Full project build and release readiness: NOT VERIFIED
