# NOVIN NSCO Recovery Hardening — 2026-09-23

## دامنه این چرخه
فقط هماهنگی **NSCO ↔ Recovery** بررسی و اصلاح شد. بخش‌های Change Engine و Build/Deploy در این چرخه تغییر داده نشدند.

## یافته
NSCO در متد `recover()` یک **Recovery Plan** صرفاً تصمیم‌گیری را با رویداد `JOB_STARTED` و وضعیت `ACTIVE` در Audit Ledger ثبت می‌کرد. این از نظر معنایی بیش از واقعیت اجرا را نشان می‌داد، چون `planAutonomousRecovery()` فقط برنامه‌ریزی می‌کند و هیچ side effect یا recovery execution انجام نمی‌دهد.

## اصلاح
- رویداد مستقل `RECOVERY_PLANNED` به Audit Ledger اضافه شد.
- Recovery Plan غیر اجرایی اکنون با وضعیت `PLANNED` ثبت می‌شود.
- برای `HUMAN_REVIEW`، `STOP` یا هر plan دارای `requiresOwnerApproval=true` همچنان `APPROVAL_REQUIRED/BLOCKED` ثبت می‌شود.
- متن Audit صریحاً اعلام می‌کند که Planning به معنی Execution نیست و هیچ side effect بازیابی‌شده‌ای ادعا نمی‌شود.
- منطق fail-closed موجود حفظ شد و هیچ مسیر Owner Sovereignty ضعیف نشد.

## Evidence
- `AUTONOMOUS_RECOVERY_PLANNER_PASS`: 6 سناریوی موجود PASS
- `R122_RECOVERY_SOVEREIGNTY_GATE_PASS`: PASS
- `NSCO_RECOVERY_REALITY_GATE`: PASS
  - RETRY → `RECOVERY_PLANNED / PLANNED`
  - UNKNOWN → `APPROVAL_REQUIRED / BLOCKED`
- `NSCO_CHIEF_OPERATIONS_PLANE`: PASS
  - Owner Sovereignty = LOCKED
  - generatedOutputIsProof = false
  - Build Readiness = BLOCKED
  - Deployment Readiness = MANUAL_STEP_REQUIRED
  - AI Provider Registered = false

## وضعیت واقعی
**PASS** برای اصلاح و هماهنگی منطق Recovery و Reality/Audit Gate.

**NOT VERIFIED** برای اجرای Recovery واقعی روی دستگاه/محیط عملیاتی؛ این چرخه هیچ ادعایی درباره اجرای فیزیکی Recovery ندارد.
