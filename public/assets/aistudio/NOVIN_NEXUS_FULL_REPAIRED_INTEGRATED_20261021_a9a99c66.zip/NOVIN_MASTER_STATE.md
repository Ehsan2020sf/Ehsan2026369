# NOVIN MASTER STATE

مرجع مادر قفل‌شده NOVIN:

`docs/master/NOVIN_MASTER_STATE_LOCKED_20260922.md`

برای معماری:
`docs/architecture/NOVIN_UNIFIED_ARCHITECTURE_BLUEPRINT_20260922.md`

برای قوانین:
`docs/governance/NOVIN_GOVERNANCE_LOCK_20260922.md`

برای ذخیره‌سازی و حاکمیت اطلاعات:
`docs/operations/NOVIN_INFORMATION_SOVEREIGNTY_AND_STORAGE_20260922.md`

برای مسیر ادامه:
`docs/master/NOVIN_CONTINUATION_PLAN_20260922.md`

این فایل فقط ورودی کوتاه است؛ محتوای Canonical در سند قفل‌شده نگهداری می‌شود.
## ابزار مهندسی اختیاری REA

وضعیت ادغام ابزار تحلیل ایستای REA (بدون وابستگی به اجرای عادی اندروید):
`NOVIN_REA_INTEGRATION_STATE_20261013.md`
راهنمای معماری و محدودیت‌ها: `docs/engineering/NOVIN_REA_INTEGRATION.md`


## کاتالوگ مهندسی Build with Claude

وضعیت: رجیستری محلی آماده است؛ کاتالوگ بیرونی به‌صورت کامل دانلود یا mirror نشده و هیچ افزونهٔ ثالثی خودکار نصب/اجرا نشده است.
- رجیستری و راهنما: `tools/buildwithclaude/registry.json`, `tools/buildwithclaude/README.fa.md`
- گزارش ادغام: `NOVIN_BUILDWITHCLAUDE_INTEGRATION_20261013.md`
- مهارت انتخاب و بازبینی امن: `.agents/skills/novin-buildwithclaude-engineering/SKILL.md`
- آزمون: `npm run test:buildwithclaude-integration`
- فرمان‌های جست‌وجو: `npm run bwc:status`, `npm run bwc:verify`, `npm run bwc:packs`, `npm run bwc:search -- <term>`
- مرز معماری: ابزار توسعه‌ای اختیاری، بدون وابستگی به Android runtime یا startup؛ هر افزودن واقعی از کاتالوگ نیازمند بررسی مجوز، منشأ، امنیت و آزمون جداگانه است.

## مرحلهٔ مهندسی 2026-10-13: حذف وابستگی اجرای نوین به احراز خالق

گزارش: `docs/engineering/NOVIN_IDENTITY_RUNTIME_RETIREMENT_20261013.md`
- ورود Android مستقیم به `AndroidAvatarRuntime` متصل است.
- UI حساب/ثبت خالق از تنظیمات فعال جدا شده است.
- مسیرهای account/cloud identity از `server.ts` حذف شده‌اند؛ health/readiness به secrets/OTP وابسته نیستند.
- Broker صدای بلادرنگ دیگر احراز خالق نمی‌خواهد؛ کلید دائمی سمت سرور می‌ماند و endpoint محدودیت نرخ دارد.
- آزمون‌های `test:identity-retirement`, `test:all`, `test:rebuild-integrity` موفق‌اند.
- مانع باقی‌مانده: npm dependencies در محیط موجود نیستند، Gradle download مسدود است و Android WebView bundle قدیمی است. ساخت/نصب/اجرای APK هنوز تأیید نشده.
- فایل‌های legacy احراز هویت به‌عنوان کد آرشیوی غیرفعال باقی مانده‌اند تا ارجاع‌های رجیستری 1200 مرحله‌ای در چرخه‌ای جداگانه مهاجرت کنند.

## مرحلهٔ ۲: حذف مسیرهای هویت فعال و دروازهٔ تازگی Bundle اندروید

گزارش: `NOVIN_STAGE_02_IDENTITY_AND_ASSET_FRESHNESS_20261013.md`
- مسیرهای فعال حساب/OTP/Cloud Identity از سرور حذف شدند؛ health/readiness به آن‌ها وابسته نیست.
- Broker صوت بلادرنگ بدون احراز خالق کار می‌کند، با محدودیت نرخ و کلید دائمی فقط سمت سرور.
- `build:web` اکنون manifest هش و source digest تولید می‌کند؛ Gradle در نبود manifest یا در صورت drift بسته‌بندی را متوقف می‌کند.
- آزمون‌های `test:all`، `test:rebuild-integrity`، `test:archive-cleanliness` و `test:archive-permissions` موفق‌اند؛ مجوزهای 1,376 پوشه نیز اصلاح و آزموده شدند.
- Bundle فعلی manifest ندارد و ساخت واقعی هنوز BLOCKED است؛ نصب APK انجام نشده. مسیر Realtime broker آزمون واحد دارد اما هنوز از `AndroidAvatarRuntime` فراخوانی نمی‌شود؛ اتصال end-to-end مرحلهٔ بعد است.


## نقشه‌راه راهبردی ابرسامانهٔ هوش مصنوعی — 2026-10-14

مرجع برنامه‌ریزی و دروازه‌های پذیرش:
- `docs/strategy/NOVIN_SUPERINTELLIGENCE_ROADMAP_20261014.md`
- `config/novin-superintelligence-roadmap.json`
- اعتبارسنجی ساختاری: `npm run novin:roadmap`
- آزمون قرارداد نقشه‌راه: `npm run test:superintelligence-roadmap`

این نقشه‌راه برنامه است، نه ادعای تحقق AGI یا تأیید قابلیت‌های زنده. وضعیت‌های مسدود ساخت، وابستگی، ارائه‌دهنده و دستگاه فقط با شواهد تازه تغییر می‌کنند.


## ادامهٔ مهندسی جاری — 2026-10-16 / Stage 77
- گزارش آخرین بررسی: `NOVIN_STAGE_77_LOCKFILE_METADATA_BLOCKER_20261016.md`.
- فایل کاری همچنان همین آرشیو canonical است؛ ZIP موازی، APK و نصب ایجاد نشده‌اند.
- ممیزی تازهٔ lockfile: 520 ورودی؛ 335 مورد بدون `resolved` و 335 مورد بدون `integrity`؛ 30 وابستگی مستقیم تحت‌تأثیر inventory. وضعیت `BLOCKED`.
- رجیستری npm روی میزبان بررسی Linux/x64 با `EAI_AGAIN` مسدود است. این نتیجه درباره شبکه Termux مالک ادعایی نمی‌کند.
- recovery pipeline در حالت validate-only مسدود شد و `package-lock.json` را تغییر نداد؛ SHA-256 آن همچنان `ea065278aaacc539dcd93f11a83ebae303b7a70aa642a10e48aa02165dd27949` است.
- تست‌های متمرکز تشخیصی و قرارداد بازیابی PASS؛ نصب وابستگی، typecheck، build، APK، امضا و اجرای دستگاه تأیید نشده‌اند.
- اقدام بعدی: اجرای تشخیص فقط‌خواندنی روی Termux مالک؛ فقط در صورت دسترسی رجیستری، ساخت candidate و ممیزی آن در حالت validate-only. هرگونه تغییر lockfile نیازمند شواهد و تأیید صریح است.


## ادامهٔ مهندسی جاری — Stage 79 / 2026-10-16
- گزارش: `NOVIN_STAGE_79_REALTIME_DATA_CHANNEL_READINESS_GATE_20261016.md`.
- نقص منبع: WebRTC adapter می‌توانست پس از SDP negotiation و پیش از بازشدن `RTCDataChannel` اتصال را موفق اعلام کند.
- اصلاح: readiness gate محدودزمان اضافه شد؛ خطا/بسته‌شدن پیش از بازشدن fail-closed است و listener/timer پاک‌سازی می‌شوند.
- تست متمرکز جدید به `test:all` اضافه شد. تست readiness، cleanup، UI contract، runtime broker، adapter credential gate و agent contract همگی در میزبان بررسی PASS شدند.
- این شواهد source/contract-only هستند؛ اتصال واقعی provider، build، Android WebView و دستگاه همچنان `UNKNOWN / NOT TESTED` هستند.
- طبق دستور مالک: در دوره توسعه چندماهه هیچ نصب Termux، نصب وابستگی، ساخت APK یا نصب دستگاه انجام نشود.
