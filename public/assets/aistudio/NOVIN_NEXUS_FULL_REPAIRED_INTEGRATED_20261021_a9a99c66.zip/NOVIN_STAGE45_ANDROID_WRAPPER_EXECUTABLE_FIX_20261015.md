# NOVIN Stage 45 — Android Wrapper Executable Fix

- Date: 2026-10-15
- Scope: Android-only; no website deployment work.
- Input archive SHA-256: `75dd240b494a04f3487475a4b054d140b293af564ecdda27961ed08fd0f22287`
- Source archive integrity before changes: `unzip -t` PASS (11,892 entries).

## Change applied

The archive stored `android/gradlew` without executable permission. This caused `scripts/test_android_wrapper_boundary.mjs` to fail with `GRADLEW_NOT_EXECUTABLE`, despite the wrapper being part of the Android build path. The ZIP entry's Unix mode is corrected to executable (`0755`). Script contents are unchanged.

## Verification

- `node --test scripts/test_android_only_product_scope.mjs`: PASS, 3/3 tests.
- `node --test scripts/test_release_version_alignment.mjs`: PASS, 12 checks.
- `node scripts/test_novin_lockfile_repair_pipeline.mjs`: PASS.
- `node scripts/test_android_build_entrypoint.mjs`: PASS.
- `node scripts/test_android_wrapper_boundary.mjs`: PASS after permission correction.
- `node scripts/novin_lockfile_integrity_audit.mjs`: BLOCKED, exit 2; 520 package records, 335 missing `resolved` URLs and 335 missing `integrity` fields.
- Full APK build: NOT RUN / BLOCKED. Extracted workspace has no `node_modules`, no `dist`, and no fresh `novin-web-build-manifest.json`; dependency lockfile gate fails. No APK or device installation is claimed.

## Next release blocker

Recover the exact locked package artifacts and SRI metadata from a trusted networked environment without changing dependency versions. Then run the Android build pipeline and verify the generated APK's identity, version, signature and SHA-256. Installation remains gated until release checks pass.
