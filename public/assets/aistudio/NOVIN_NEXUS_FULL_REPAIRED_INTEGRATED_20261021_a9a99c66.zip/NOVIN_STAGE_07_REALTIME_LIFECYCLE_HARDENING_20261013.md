# NOVIN NEXUS Stage 07: Realtime WebRTC lifecycle hardening

Date: 2026-10-13
Previous source version: `0.9.25-unified`
Updated source version: `0.9.26-unified`
Android version: `0.9.26` / versionCode `92600`
Canonical archive path unchanged: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`.

## Why this stage

The realtime WebRTC adapter was implemented but its failure cleanup was incomplete. If SDP negotiation failed after microphone permission had been granted, local audio tracks, the peer connection, data channel, or detached audio element could survive the failed attempt. This can leave microphone capture active and make retry behavior unreliable.

## Changes

- Wrapped WebRTC setup/negotiation in failure-safe cleanup.
- Added one idempotent resource-release path for data channel, microphone tracks, peer connection, audio playback element, and session identifiers.
- A failed SDP exchange now releases local resources before rethrowing the original failure.
- Public disconnect reuses the same cleanup path and tolerates repeated calls.
- Added `scripts/test_realtime_webrtc_cleanup.mjs`, exercising a mocked HTTP 401 after microphone acquisition and asserting track stop, peer close, data channel close, audio element removal, and repeated-disconnect safety.
- Added the cleanup test to `test:all`.
- Aligned package.json, package-lock root metadata, and Android Gradle metadata to version `0.9.26-unified` / `0.9.26` / code `92600`.
- Updated the graphics-runtime safety contract to verify the current aligned version rather than hard-coding the prior release.

## Verification

- `npm run test:realtime-webrtc-cleanup`: PASS.
- `npm run test:all`: PASS, exit 0 after version-contract correction.
- `npm run test:rebuild-integrity`: PASS, exit 0.
- Platform dependency preflight: BLOCKED_ENVIRONMENT; `@esbuild/linux-x64` and `@rollup/rollup-linux-x64-gnu` are absent.
- `npm run build:web`: BLOCKED at platform dependency preflight, exit 2.
- `npm run lint`: BLOCKED because installed type definitions `@types/node`, `@types/react`, and `@types/react-dom` are absent.

## Explicitly not verified

- This stage does not connect the realtime runtime into `AndroidAvatarRuntime`; source search still finds no production instantiation of `NovinRealtimeAndroidRuntime` in that UI component.
- Real provider, microphone, WebRTC network, backend broker, and Android WebView end-to-end behavior remain NOT VERIFIED.
- The Android packaged `assets/public` output has not been regenerated because the web build is blocked. It may contain an older web bundle/version and must not be treated as the current source build.
- APK build/install and Redmi Note 11 physical runtime remain NOT TESTED.

## Decision

Stage 07 closes a concrete resource-leak/retry defect at source-contract level. It does not make realtime voice production-ready. Continue with exact dependency restoration, web build and source-digest manifest generation; then wire and test realtime UI integration behind an explicit user action and verify it end-to-end before claiming success.
