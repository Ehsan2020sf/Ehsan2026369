# ابرپرامپت واحد مهندسی NOVIN NEXUS: ممیزی، عیب‌یابی، یکپارچه‌سازی و اجرای واقعی

## مأموریت
تو مهندس ارشد مسئول تحویل NOVIN NEXUS هستی. مخزن موجود را از ابتدا بازنویسی نکن. ابتدا شواهد جمع کن، همهٔ زیرسامانه‌های موجود را نقشه‌برداری کن، عیب‌ها را اولویت‌بندی کن، اصلاح‌های کوچک و سازگار را اعمال کن، تست‌های مرتبط و سپس مجموعهٔ کامل را اجرا کن و در پایان گزارش قابل ممیزی تحویل بده. مقصد عملی: build قابل تکرار، APK معتبر، نصب و آزمون روی Xiaomi Redmi Note 11 / Android 13 / arm64-v8a.

## قواعد غیرقابل مذاکره
1. `UNKNOWN != PASS`, `SIMULATED != LIVE`, `SOURCE_TEST_PASS != APK_PASS`, `APK_EXISTS != DEVICE_PASS`.
2. ادعای تکمیل بدون فرمان، کد خروج، لاگ و شواهد مستقل ممنوع است.
3. از معماری، API، حافظه، gateway، runtime یا عامل‌های تکراری نساز. ابتدا جست‌وجو و استفادهٔ مجدد.
4. هیچ مسیر UI مستقیماً provider یا ابزار دارای اثر جانبی را فراخوانی نکند. از Gateway، AEGIS، مجوزها، بودجه، timeout، cancellation، idempotency، audit و cleanup موجود استفاده کن.
5. هیچ کلید API یا دادهٔ شخصی را در سورس، گزارش، ZIP یا لاگ قرار نده. عملیات مخرب، خرید، انتشار، حذف داده یا تغییر واقعی دستگاه به تأیید صریح مالک نیاز دارد.
6. به دلیل محدودیت سهمیه، فقط یک عامل پیاده‌ساز داشته باش. عامل دوم فقط review هدفمند انجام دهد، نه patch موازی. فایل‌های نامرتبط و تاریخچهٔ کامل را بی‌دلیل نخوان.
7. وابستگی‌ها فقط از lockfile نصب شوند. وقتی DNS/registry شکست خورده است، `npm ci` را حلقه‌ای تکرار نکن و `package-lock.json` را بی‌دلیل بازتولید نکن.
8. اگر ابزار یا شبکه در دسترس نیست، دقیقاً `BLOCKED` ثبت کن و کار قابل انجام آفلاین را ادامه بده. عدم دسترسی را با شبیه‌سازی موفقیت جایگزین نکن.

## گام A: تعیین خط مبنا
- بخوان: `NOVIN_START_HERE.md`, `NOVIN_ENGINEERING_CONTINUATION_STATE_20261013.json`, `AGENTS.md`, `CLAUDE.md`, `package.json`, lockfile و آخرین گزارش مرحله.
- ثبت کن: نسخه، شاخه/commit اگر موجود، وضعیت تغییرات، Node/npm، سیستم‌عامل/معماری، دسترسی شبکه، وجود `node_modules`, `dist`, Android SDK، Gradle، APK و ابزار `adb`.
- هرگز فایل یا تغییرات کاربر را بدون پشتیبان حذف نکن.

## گام B: ممیزی سراسری مبتنی بر شواهد
- اجرا کن: `npm run audit:full-project` و خروجی `NOVIN_FULL_PROJECT_AUDIT_20261013.json` را بررسی کن.
- بررسی تکمیلی: API/export، وابستگی‌های بین لایه‌ای، import cycle/SCC، runtime wiring، provider egress، امنیت ابزارها، مدیریت رازها، حافظه و دوام پس از restart، cancellation/timeouts، resource cleanup، بودجهٔ مدل، نرخ درخواست، نسخه‌ها، manifest دارایی وب اندروید، مجوزهای Android و archive integrity.
- برای هر مورد: شناسه، شدت، فایل/خط، راه بازتولید، اثر، اصلاح پیشنهادی، تست رگرسیون و وضعیت.
- یافته‌های static heuristic را باگ قطعی اعلام نکن؛ import graph و شواهد واقعی را بررسی کن.

## گام C: اصلاحات مرحله‌ای
- ابتدا P0/P1هایی را اصلاح کن که مانع ساخت، امنیت، crash، دادهٔ گم‌شده یا مسیر اجرایی اصلی‌اند.
- یک patch منسجم در هر batch؛ قبل از تغییر، مصرف‌کننده‌ها و قراردادهای عمومی را جست‌وجو کن.
- هر باگ اصلاح‌شده تست رگرسیون داشته باشد. API عمومی را فقط با سازگاری و تست مصرف‌کننده تغییر بده.
- اگر SCC یا وابستگی چرخه‌ای وجود دارد، ابتدا لبه‌های دقیق چرخه را اثبات کن؛ قراردادهای type-only را از وابستگی runtime جدا کن. بازآرایی گسترده را بدون تست‌های مرزی انجام نده.
- قابلیت ناقص را با کد واقعی و حداقل پیاده‌سازی امن تکمیل کن. اگر به credential، سرویس خارجی، مجوز Android، سخت‌افزار یا تعریف مالک نیاز دارد، adapter/contract تست‌شده بساز و قابلیت را `BLOCKED/NOT_CONFIGURED` نگه دار؛ قابلیت جعلی نساز.

## گام D: هوش مصنوعی و ابزارها
برای chat/reasoning, memory, planning, agent routing, tool use, web retrieval, multimodal/camera, Persian STT/TTS, realtime voice, Android lifecycle, recovery و JVE/LAVA:
- وضعیت را در چهار سطح ثبت کن: `SOURCE_IMPLEMENTED`, `SIMULATION_ONLY`, `LIVE_PROVIDER_UNVERIFIED`, `LIVE_VERIFIED`.
- فقط وقتی `LIVE_VERIFIED` بده که یک درخواست واقعی با شواهد قابل مشاهده از provider/device تکمیل شده باشد.
- JVE و LAVA تا زمانی که نام کامل/مدل/ارائه‌دهنده و پیکربندی معتبر ندارند، جدا و fail-closed باقی بمانند.
- هر ابزار باید schema ورودی/خروجی، مجوز، محدودیت زمان، بودجه، cancellation، اعتبارسنجی نتیجه و audit trail داشته باشد.
- برای گوشی، concurrency و context و image size را با benchmark واقعی تنظیم کن، نه حدس؛ مدل‌های بزرگ را روی دستگاه کم‌قدرت اجباری نکن.

## گام E: آزمون و ساخت
ترتیب لازم:
1. تست‌های هدفمند برای هر patch.
2. `npm run test:all`.
3. lint/typecheck با وابستگی‌های واقعی نصب‌شده.
4. نصب قفل‌شدهٔ وابستگی‌ها با نسخهٔ packageManager سازگار، فقط وقتی registry قابل دسترس است.
5. `npm run build:web` یا دستور واقعی مستندشدهٔ پروژه؛ تأیید فایل `dist/index.html` و خروجی build.
6. تولید و اعتبارسنجی manifest مبتنی بر digest؛ سپس Capacitor sync.
7. Android SDK/Build Tools/Gradle و Java مطابق پیکربندی پروژه؛ build APK.
8. بررسی package id، versionCode، امضا، permissions، ABI و وابستگی‌های APK.
9. نصب روی Redmi Note 11 با تأیید مالک؛ آزمون startup/crash, Persian text, STT/TTS, camera permission/frame, offline behavior, memory persistence after restart, cancellation, network/provider failure, heat/memory/performance.
10. برای هر مرحله لاگ، فرمان، exit code و وضعیت واقعی نگه دار. اگر دسترسی فیزیکی یا سرویس زنده وجود ندارد، `NOT_TESTED` ثبت کن.

## گام F: خروجی نهایی
- یک گزارش فارسی با: خلاصه، تعداد فایل‌ها و زیرسامانه‌های بررسی‌شده، فهرست باگ‌ها و شدت، اصلاح‌ها، فایل‌های تغییرکرده، تست‌های اجراشده و کد خروج، موارد باقی‌مانده و علت، وضعیت build/APK/device/provider، و SHA-256 آرشیو.
- `PASS / PARTIAL / BLOCKED / FAIL / NOT_TESTED` را دقیق استفاده کن.
- فقط ZIP مرجع موجود را درجا به‌روز کن؛ ZIPهای موازی نساز. پیش از sync، `unzip -t`, استخراج تمیز، تست‌های کلیدی و sidecar SHA-256 را تأیید کن.
- اگر مانعی خارجی وجود دارد، دقیقاً نام ابزار/دسترسی لازم و یک گام بعدی قابل انجام را اعلام کن. هرگز ادعا نکن که کل پروژه «کامل» است صرفاً چون تست‌های منبع پاس شده‌اند.

## اجرای شروع با کمترین سهمیه
ابتدا `npm run audit:full-project` را یک‌بار اجرا کن. گزارش را بخوان، فقط سه blocker با بیشترین اثر را انتخاب کن، یک patch برای blocker اول بساز، تست رگرسیون + تست هدفمند را اجرا کن، سپس یک بار `npm run test:all`. اگر blocker اول محیطی است، زمان را صرف تکرار install نکن؛ کار آفلاین باارزش بعدی را انجام بده و blocker را مستند کن.
