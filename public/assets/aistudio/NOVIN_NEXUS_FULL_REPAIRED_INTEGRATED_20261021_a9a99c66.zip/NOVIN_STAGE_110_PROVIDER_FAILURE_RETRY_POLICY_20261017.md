# NOVIN Stage 110: Provider failure and retry policy
Date: 2026-10-17

## Change
- Added `src/core/ai/providerFailurePolicy.ts` as a shared, deterministic HTTP retry classification boundary.
- Retryable statuses: 408, 409, 425, 429, and 5xx. Invalid status values and permanent client failures such as 400, 401, 403, 404, and 422 are not retryable.
- Added bounded extraction of provider error messages. A malformed/non-JSON error body now returns a safe generic message and cannot override the HTTP status's retry classification.
- Updated both Gemini and OpenAI provider adapters to inspect `response.ok` before parsing a success payload. Failed responses are parsed through the shared safe error-message function.

## Evidence
- `node --experimental-strip-types src/core/ai/providerFailurePolicy.test.ts`: PASS.
- Unit cases cover retryable statuses, permanent auth/configuration failures, invalid status values, valid JSON errors, malformed HTML bodies, and wrong-shaped JSON.

## Limits
No live provider request was made. Tests use local values and synthetic `Response` objects. No dependency installation, APK build, or device installation occurred.
