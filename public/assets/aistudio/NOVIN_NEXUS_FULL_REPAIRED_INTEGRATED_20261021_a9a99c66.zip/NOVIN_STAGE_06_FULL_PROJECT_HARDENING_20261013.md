# NOVIN NEXUS Stage 06: Whole-project hardening and release-map update

Date: 2026-10-13
Previous source version: `0.9.24-unified`
Updated source version: `0.9.25-unified`
Android version: `0.9.25` / versionCode `92500`
Baseline archive path remains `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip` to honor the single-live-ZIP workflow.

## Scope and defects addressed

1. **Incorrect performance signal:** the previous governor measured a host `requestAnimationFrame` loop rather than the actual React Three Fiber render cadence. That could report smooth display timing while the WebGL scene was slow. Frame samples now originate in `AvatarRenderScheduler` via `useFrame` and include the selected target FPS.
2. **False 30 FPS pressure:** frame-time thresholds previously assumed a 60 FPS target. A healthy 30 FPS Android render interval (~33.3 ms) could be marked critical. Pressure is now computed relative to the active target FPS.
3. **Governor blocking:** native performance reads are no longer awaited inside an animation-frame callback. They run asynchronously on a visibility-aware timer.
4. **Single-frame sensitivity:** the renderer reports averaged windows rather than using one isolated frame to make a quality decision.
5. **SAFE-tier contradiction:** the governor no longer turns shadows back on while it still labels the graphics tier SAFE. SAFE keeps a reduced DPR multiplier and 30 FPS target.
6. **Recovery dead-end:** after 10 consecutive healthy render windows without known high memory or thermal warnings, the governor can return to the original device profile. This is a source-level policy; physical recovery still needs device verification.
7. **WebGL recovery path:** retry attempts now remount the error boundary itself, not only its Canvas child. Context-restored events update runtime state, and old canvas listeners are removed before a canvas is replaced.
8. **Misleading HUD claims:** idle state no longer reports `BRAIN READY` or `VOICE READY`; it reports `BRAIN IDLE` and `VOICE STANDBY` until an observed active state exists.
9. **Version alignment:** package.json, package-lock root metadata and Android Gradle metadata now agree on 0.9.25.

## Verification results

- `npm run test:device-performance-governor`: PASS.
- `npm run test:android-graphics-runtime-safety`: PASS.
- `npm run test:android-visual-runtime`: PASS, 22 checks.
- `npm run test:android-visual-resilience`: PASS, 5 checks.
- `npm run test:android-visual-quality-governor`: PASS, 5 checks.
- `npm run test:android-avatar-runtime-contract`: PASS, 13 checks.
- `npm run test:all`: PASS, exit code 0 after Stage 06 changes.
- `npm run test:rebuild-integrity`: PASS, exit code 0 after Stage 06 changes.
- `npm run build:web`: BLOCKED, exit code 2; platform preflight reports missing `@esbuild/linux-x64` and `@rollup/rollup-linux-x64-gnu`.
- `npm run lint`: BLOCKED, exit code 2; `@types/node`, `@types/react`, and `@types/react-dom` are absent because dependencies could not be restored.

## Still blocked / not tested

- `npm ci --include=optional --no-audit --no-fund` was previously blocked by npm registry DNS `EAI_AGAIN`; the environment still has no installed `node_modules`.
- Web build, generated web asset manifest and Capacitor sync remain blocked until exact dependencies are restored.
- APK has not been built from this version.
- Redmi Note 11 / Android 13 runtime, real WebGL frame timing, thermal behavior and recovery have not been tested on the physical device.
- End-to-end realtime voice broker to Android avatar integration remains unverified; a mocked provider unit test is not production integration evidence.

## Decision

The project is advanced at source and contract level, with a more truthful graphics governor and a version-aligned build map. It is not a release-ready APK. Keep the Android asset freshness gate fail-closed; do not install or report device success until build and device gates pass.
