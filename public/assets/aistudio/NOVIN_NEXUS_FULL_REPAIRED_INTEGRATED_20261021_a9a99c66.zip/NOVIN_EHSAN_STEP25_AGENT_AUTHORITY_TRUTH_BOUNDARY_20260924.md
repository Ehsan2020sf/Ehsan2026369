# NOVIN EHSAN STEP 25 — R191 Agent Authority Truth Boundary

R191 reality now only accepts OBSERVED/VERIFIED_REAL and requires consent/trusted/fresh exactly true. Missing or weak signals BLOCK. Tests cover allow, evidence, high-risk review, weak reality and missing signals.

STATUS: PASS
