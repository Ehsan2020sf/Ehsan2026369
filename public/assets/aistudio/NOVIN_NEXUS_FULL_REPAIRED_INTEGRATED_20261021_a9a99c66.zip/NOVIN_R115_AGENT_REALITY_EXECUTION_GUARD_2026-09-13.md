# NOVIN R115 Agent Reality Execution Guard

Status: IMPLEMENTED

Purpose: place an AEGIS Reality admission boundary immediately before Agent -> Tool execution.

Rules:
- canonical Project Passport and Human Owner authority are required;
- agent/mission/task/selection context must match;
- generated output can never be treated as proof;
- a request for VERIFIED_REAL requires existing VERIFIED_REAL evidence;
- the guard admits execution but never executes tools or upgrades evidence.

Verification:
- Dedicated R115 test: PASS
- Existing Agent Tool Execution Boundary remains the execution point.
- APK: NOT VERIFIED
- Full TypeScript build: NOT VERIFIED when dependencies are unavailable.
