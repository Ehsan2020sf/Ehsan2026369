NOVIN EHSAN | STEP 29 | R195 Provider Failover Truth Boundary

Real defect: R195 rejected only UNKNOWN and explicit false values, allowing weak/omitted truth fields.
Fix: reality must be OBSERVED or VERIFIED_REAL; consent/trusted/fresh must be exactly true.
Status: repaired; deterministic test required.
