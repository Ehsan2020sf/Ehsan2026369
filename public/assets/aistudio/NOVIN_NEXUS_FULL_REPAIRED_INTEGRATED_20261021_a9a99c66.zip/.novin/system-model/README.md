# NOVIN System Model Runtime

این پوشه حافظه معماری عملیاتی NOVIN است.

- `NOVIN_SYSTEM_MODEL.json`: مدل ماشین‌خوان و source-of-truth معماری.
- `CHANGE_MEMORY.jsonl`: حافظه‌ی تغییرات و root-causeها برای جلوگیری از تکرار.
- `../.. /docs/architecture/NOVIN_SYSTEM_MIND_MODEL_20261006.md`: نسخه انسانی/مهندسی نقشه.

## قانون اجرا

قبل از هر تغییر معماری یا bug-fix:

```bash
npm run gate:system-model
```

اگر boundary قبلاً VERIFIED/FIXED است، تغییر دوباره فقط با Evidence جدید regression مجاز است.
