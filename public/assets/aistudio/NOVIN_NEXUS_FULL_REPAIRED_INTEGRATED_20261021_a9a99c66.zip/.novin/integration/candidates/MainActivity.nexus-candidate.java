package com.novin.nexus;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Log;
import java.util.ArrayList;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQ_AUDIO = 7001;
    private WebView web;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean pageReady = false;
    private boolean ttsReady = false;
    private final java.util.ArrayDeque<String> pendingJs = new java.util.ArrayDeque<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.runtime);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                while (!pendingJs.isEmpty()) view.evaluateJavascript(pendingJs.removeFirst(), null);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e("NOVIN_WEB", "WebView error " + errorCode + ": " + description + " @ " + failingUrl);
            }
        });
        web.addJavascriptInterface(new NativeVoiceBridge(), "NovinAndroid");
        web.loadUrl("file:///android_asset/runtime/index.html");
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) {
            int languageStatus = tts.setLanguage(new Locale("fa", "IR"));
            if (languageStatus == TextToSpeech.LANG_MISSING_DATA || languageStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsReady = false;
                send("window.NOVIN && window.NOVIN.ttsError(\"LANGUAGE_UNAVAILABLE\")");
                return;
            }
            ttsReady = true;
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                public void onStart(String id) { send("window.NOVIN && window.NOVIN.ttsStart("+js(id)+")"); }
                public void onDone(String id) { send("window.NOVIN && window.NOVIN.ttsDone("+js(id)+")"); }
                public void onError(String id) { send("window.NOVIN && window.NOVIN.ttsError("+js(id)+")"); }
            });
        } });
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
    }

    private void ensureRecognizer() {
        if (recognizer != null) return;
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onResults(Bundle b){ ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); String text=(r==null||r.isEmpty())?"":r.get(0); send("window.NOVIN && window.NOVIN.sttResult("+js(text)+")"); }
            public void onError(int e){ send("window.NOVIN && window.NOVIN.sttError("+e+")"); }
            public void onReadyForSpeech(Bundle p){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){} public void onPartialResults(Bundle b){} public void onEvent(int a, Bundle b){}
        });
    }

    private void send(String js){
        runOnUiThread(() -> {
            if (web == null) return;
            if (!pageReady) { pendingJs.addLast(js); return; }
            web.evaluateJavascript(js, null);
        });
    }
    private static String js(String s){ return org.json.JSONObject.quote(s); }

    private final class NativeVoiceBridge {
        @JavascriptInterface public void speak(String text){ runOnUiThread(() -> { if(tts==null || !ttsReady){ send("window.NOVIN && window.NOVIN.ttsError(\"NOT_READY\")"); return; } tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "novin-tts"); }); }
        @JavascriptInterface public void stopSpeaking(){ runOnUiThread(() -> { if(tts!=null) tts.stop(); }); }
        @JavascriptInterface public void listen(){ runOnUiThread(() -> { if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); send("window.NOVIN && window.NOVIN.sttError(\"PERMISSION_REQUIRED\")"); return; } if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) { send("window.NOVIN && window.NOVIN.sttError(\"UNAVAILABLE\")"); return; } ensureRecognizer(); Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false); recognizer.startListening(i); }); }
        @JavascriptInterface public void stopListening(){ runOnUiThread(() -> { if(recognizer!=null) recognizer.stopListening(); }); }
    }

    @Override protected void onDestroy(){ if(recognizer!=null){ recognizer.destroy(); recognizer=null; } if(tts!=null){ ttsReady=false; tts.stop(); tts.shutdown(); tts=null; } if(web!=null){ web.removeJavascriptInterface("NovinAndroid"); web.destroy(); web=null; } super.onDestroy(); }
}
