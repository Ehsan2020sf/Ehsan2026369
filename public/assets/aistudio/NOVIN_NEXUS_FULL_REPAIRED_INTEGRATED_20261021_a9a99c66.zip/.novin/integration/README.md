# NOVIN Canonical Integration Boundary

Only `/mnt/data/NOVIN_ACTIVE_CURRENT/NOVIN_FINAL_MERGED_20261004` is the active NOVIN working tree.

Historical/alternate trees are not execution roots. Candidate source that was not safely mergeable is retained here for forensic comparison only and is not imported into the active runtime.

Rules:
- `src/`, `server/`, `android/`, `app/`, `packages/`, `runtime/`, `scripts/`, `docs/`, `prompts/`, `config/` in this root are canonical.
- `dist/`, `artifacts/`, `.engineering_backups/`, `.baseline_snapshot/`, and `.novin-data/` are generated/evidence/history boundaries, not alternate source roots.
- Native candidate code with a different Android package namespace is not copied into the active Android runtime without a package/manifest/lifecycle reconciliation.
