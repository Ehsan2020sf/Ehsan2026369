declare module 'react' { export const createElement: any; export const useState: any; export const useEffect: any; export const useMemo: any; export const useRef: any; export const useCallback: any; export const useContext: any; export const createContext: any; export type ReactNode = any; export type FC<T = any> = any; }
declare module 'react/jsx-runtime' { export const jsx: any; export const jsxs: any; export const Fragment: any; }
declare module 'lucide-react' { export const Database:any; export const Info:any; export const Check:any; export const RefreshCw:any; }
declare module 'three' { export const MathUtils:any; export class PerspectiveCamera { position:any; lookAt(...args:any[]):any; } export class Vector3 { x:any; y:any; z:any; constructor(...args:any[]); } export class Object3D {} export class Scene {} export class WebGLRenderer {} }
declare module '@capacitor/core' { export const Capacitor: any; export class WebPlugin { constructor(...args:any[]); } export function registerPlugin<T = any>(...args:any[]): T; }
declare module '@capacitor/network' { export const Network: any; }
