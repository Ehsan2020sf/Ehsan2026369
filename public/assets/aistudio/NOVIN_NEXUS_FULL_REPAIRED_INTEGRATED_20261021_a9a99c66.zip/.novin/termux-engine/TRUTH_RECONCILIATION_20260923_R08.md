# NOVIN Termux Engine Truth Reconciliation R08

## Finding
Historical runs in `journal.ndjson` and `engine.log` contain `DEVICE_E2E=PASS` entries without a device identifier. Those records are historical claims and must not be treated as current device evidence.

## Repair
- Device E2E is now fail-closed: without explicit install opt-in and an actually authorized ADB device, the run is `BLOCKED`.
- The engine no longer converts a successful exit with skipped Device E2E into an unconditional overall PASS.
- Current `state.json` and `last-report.json` were reconciled to `BLOCKED` with `truthLevel=REAL_BUILD_ARTIFACT_ONLY_NO_DEVICE_E2E`.
- Historical journal entries were preserved and are not deleted; they remain historical records, not current evidence.

## Verification
- Shell syntax: PASS
- Current-state reconciliation: PASS
- Historical false-positive detection: PASS
- Device E2E: BLOCKED (no physical ADB evidence in this environment)
