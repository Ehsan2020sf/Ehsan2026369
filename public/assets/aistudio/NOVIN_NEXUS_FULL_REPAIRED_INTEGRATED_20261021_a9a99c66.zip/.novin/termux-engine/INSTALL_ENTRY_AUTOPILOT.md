# NOVIN Termux Entry Autopilot

هدف: با ورود به Termux، NOVIN به‌صورت fail-closed وابستگی/محیط را بررسی کند، APK را بسازد، اعتبارسنجی کند، آن را به `~/storage/downloads/NOVIN/` منتقل کند و صفحه نصب Android را باز کند.

## فعال‌سازی یک‌باره

در Termux:

```bash
termux-setup-storage
mkdir -p ~/.novin-termux
printf '\n# NOVIN ENTRY AUTOPILOT\nif [ -x "$HOME/NOVIN_APK_BUILD/scripts/novin_termux_entry_autopilot.sh" ] && [ "${NOVIN_TERMUX_ENTRY_LOADED:-0}" != "1" ]; then export NOVIN_TERMUX_ENTRY_LOADED=1; "$HOME/NOVIN_APK_BUILD/scripts/novin_termux_entry_autopilot.sh"; fi\n' >> ~/.bashrc
```

اگر مسیر پروژه متفاوت است، فقط `NOVIN_APK_BUILD` را با مسیر واقعی پروژه جایگزین کنید.

## رفتار امنیتی

- بدون `node` یا `npm`: `BLOCKED`
- بدون وابستگی‌ها: `npm ci` با lockfile
- Build/SDK/Java/Gradle نامعتبر: `BLOCKED`
- APK نامعتبر: `BLOCKED`
- APK معتبر: انتقال به Downloads
- نصب مستقیم بدون رضایت کاربر: انجام نمی‌شود
- `termux-open` فقط صفحه نصب رسمی Android را باز می‌کند
- در صورت وجود ADB واقعی و مجاز، مسیر ADB مستقل پروژه همچنان می‌تواند نصب را انجام دهد

## خاموش کردن موقت

```bash
export NOVIN_TERMUX_AUTOPILOT=0
```

## وضعیت

`PASS_WITH_OWNER_INSTALL_HANDOFF` یعنی ساخت و انتقال موفق بوده و تصمیم نهایی نصب هنوز با مالک دستگاه است.
