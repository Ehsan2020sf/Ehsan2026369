# NOVIN Multi-Agent Council Integration

Date: 2026-10-05

## Decision
NOVIN uses a governed multi-agent council. External providers are integration targets only until independently verified.

## Admission gates
1. Provider identity evidence.
2. Capability evidence.
3. Security evidence.
4. Test evidence.
5. Reality evidence references.
6. Owner approval before execution.
7. Fail-closed on missing evidence.

## Initial provider targets
OpenAI, Google Gemini, Anthropic Claude, xAI, OpenRouter, Ollama, and custom provider.

## Roles
ARCHITECT, CODER, REVIEWER, SECURITY, TESTER, REALITY_AUDITOR, INTEGRATOR.

## Operating rule
Agents may propose, review, test, and provide evidence. No agent may silently mutate canonical NOVIN or promote simulated output to REAL. Integration execution remains behind NOVIN governance and the owner gate.

## Current reality
The registry is implemented and tested. External provider credentials/connections are NOT VERIFIED in this environment. Therefore all external agents remain BLOCKED until real connection evidence exists.

## Required collaboration loop
Task -> independent proposals -> adversarial review -> tests -> reality audit -> integration candidate -> owner gate -> atomic change -> regression suite -> evidence record.
