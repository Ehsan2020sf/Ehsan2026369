import React, { useState, useEffect, useRef, useMemo, lazy, Suspense } from 'react';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';

// Core & Types
import { CallAnalysis, SpeakerType } from './types.ts';
import {
  CallRecord,
  TenantContext,
  MultiCallAggregationResult,
} from './core/intelligence/types.ts';
import { runMultiCallAggregation } from './core/intelligence/aggregationEngine.ts';
import { INITIAL_CALL_RECORDS, DEFAULT_TENANT } from './data/initialCallRecords.ts';
import { SAMPLE_CALLS } from './data/sampleCalls.ts';

// Navigation & Layout
import { AppHeader } from './components/navigation/AppHeader.tsx';
import { BottomNavBar, MainTabType } from './components/navigation/BottomNavBar.tsx';

// Views
import { HomeView } from './components/views/HomeView.tsx';
import { CommandStudioView } from './components/views/CommandStudioView.tsx';
import { CallsListView } from './components/views/CallsListView.tsx';
import { SingleCallDeepDiveView } from './components/views/SingleCallDeepDiveView.tsx';
import { IntelligenceHubView } from './components/views/IntelligenceHubView.tsx';
import { RoleplayStudioView } from './components/views/RoleplayStudioView.tsx';
import { BusinessBIView } from './components/views/BusinessBIView.tsx';
import { BusinessOSView } from './components/views/BusinessOSView.tsx';
import { SovereignAgentOSView } from './components/views/SovereignAgentOSView.tsx';
const WebEngineeringView = lazy(() => import('./components/views/WebEngineeringView.tsx'));
import { globalBusinessStore } from './core/business/businessStore.ts';

// Modals & Floating Components
import { AudioPlayerBar } from './components/AudioPlayerBar.tsx';
import { UploadModal } from './components/UploadModal.tsx';
const DiagnosticsModal = lazy(() => import('./components/modals/DiagnosticsModal.browser.tsx'));
import { DatasetMode } from './components/common/DataModeIndicator.tsx';
import { NovinWebsiteView } from './components/views/NovinWebsiteView.tsx';

export default function App() {
  // Navigation & Dataset State
  const [showPublicWebsite, setShowPublicWebsite] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<MainTabType>('home');
  const [datasetMode, setDatasetMode] = useState<DatasetMode>('TEST_DATA');
  const [tenant, setTenant] = useState<TenantContext>(DEFAULT_TENANT);
  const [allCallRecords, setAllCallRecords] = useState<CallRecord[]>(INITIAL_CALL_RECORDS);
  const [selectedSellerId, setSelectedSellerId] = useState<string>('rep-alex-rivera');

  // Single Call Analysis & Audio Player State (P63 Core)
  const [currentCall, setCurrentCall] = useState<CallAnalysis>(SAMPLE_CALLS[0]);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);

  // Modals & UI State
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [uploadModalTab, setUploadModalTab] = useState<'upload' | 'record' | 'text'>('upload');
  const [isDiagnosticsModalOpen, setIsDiagnosticsModalOpen] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const playIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Active dataset filtering based on DatasetMode
  const activeCalls: CallRecord[] = useMemo(() => {
    switch (datasetMode) {
      case 'REAL_DATA':
        // Real processed / uploaded calls
        return allCallRecords.filter((c) => c.status === 'PROCESSED').slice(0, 3);
      case 'TEST_DATA':
        // Full benchmark dataset
        return allCallRecords;
      case 'NO_DATA':
        // Empty / Zero state testing
        return [];
    }
  }, [datasetMode, allCallRecords]);

  // Reactive Multi-Call Intelligence Aggregation (P66 Engine Pipeline)
  const aggregationResult: MultiCallAggregationResult | null = useMemo(() => {
    if (activeCalls.length === 0) return null;
    try {
      return runMultiCallAggregation({ tenant, calls: activeCalls });
    } catch (err) {
      console.error('Aggregation error:', err);
      return null;
    }
  }, [tenant, activeCalls]);

  // Android Native Hardware Back Button Handler
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    let backListenerHandle: { remove: () => Promise<void> } | null = null;
    CapApp.addListener('backButton', ({ canGoBack }) => {
      if (isDiagnosticsModalOpen) {
        setIsDiagnosticsModalOpen(false);
      } else if (isUploadModalOpen) {
        setIsUploadModalOpen(false);
      } else if (activeTab !== 'home') {
        setActiveTab('home');
      } else if (!canGoBack) {
        CapApp.exitApp();
      } else {
        window.history.back();
      }
    }).then((handle) => {
      backListenerHandle = handle;
    });

    return () => {
      if (backListenerHandle) {
        backListenerHandle.remove();
      }
    };
  }, [isUploadModalOpen, isDiagnosticsModalOpen, activeTab]);

  // Audio Playback simulation or real audio sync
  useEffect(() => {
    if (isPlaying) {
      if (currentCall.audioUrl && audioElementRef.current) {
        audioElementRef.current.playbackRate = playbackRate;
        audioElementRef.current.play().catch((err) => console.log('Audio autoplay policy:', err));
      }

      // Progress timer (updates every 100ms for smooth scrub)
      playIntervalRef.current = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= currentCall.durationSeconds) {
            setIsPlaying(false);
            return 0;
          }
          return Math.min(currentCall.durationSeconds, prev + 0.1 * playbackRate);
        });
      }, 100);
    } else {
      if (playIntervalRef.current) clearInterval(playIntervalRef.current);
      if (audioElementRef.current) {
        audioElementRef.current.pause();
      }
    }

    return () => {
      if (playIntervalRef.current) clearInterval(playIntervalRef.current);
    };
  }, [isPlaying, playbackRate, currentCall.durationSeconds, currentCall.audioUrl]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (seconds: number) => {
    const boundedTime = Math.max(0, Math.min(currentCall.durationSeconds, seconds));
    setCurrentTime(boundedTime);
    if (audioElementRef.current) {
      audioElementRef.current.currentTime = boundedTime;
    }
  };

  const handleUpdateSpeakerName = (speaker: SpeakerType, newName: string) => {
    setCurrentCall((prev) => {
      const updated = { ...prev };
      if (speaker === 'Speaker A') {
        updated.participants.speakerA.name = newName;
      } else {
        updated.participants.speakerB.name = newName;
      }
      updated.diarizedTranscript = updated.diarizedTranscript.map((seg) => {
        if (seg.speaker === speaker) {
          return { ...seg, speakerLabel: newName };
        }
        return seg;
      });
      return updated;
    });
  };

  const handleOpenUpload = () => {
    setUploadModalTab('upload');
    setIsUploadModalOpen(true);
  };

  const handleOpenRecord = () => {
    setUploadModalTab('record');
    setIsUploadModalOpen(true);
  };

  const handleAnalysisSuccess = (analyzedCall: CallAnalysis) => {
    setCurrentCall(analyzedCall);
    setCurrentTime(0);
    setIsPlaying(false);

    // Also register into multi-call record dataset
    const newRecord: CallRecord = {
      callId: `rec-${Date.now()}`,
      tenantId: tenant.tenantId,
      sellerId: 'rep-alex-rivera',
      sellerName: analyzedCall.participants.speakerA.name || 'Alex Rivera',
      customerId: `cust-${Date.now()}`,
      customerName: analyzedCall.participants.speakerB.name || 'Prospect Client',
      dealStage: analyzedCall.summary.dealStage || 'Discovery',
      timestamp: new Date().toISOString(),
      durationSeconds: analyzedCall.durationSeconds,
      analysis: analyzedCall,
      status: 'PROCESSED',
    };

    setAllCallRecords((prev) => [newRecord, ...prev]);
    setActiveTab('single_call');
  };

  const handleSelectCallFromList = (callRecord: CallRecord) => {
    setCurrentCall(callRecord.analysis);
    setCurrentTime(0);
    setIsPlaying(false);
    setActiveTab('single_call');
  };

  const handleSelectSellerAndNavigate = (sellerId: string) => {
    setSelectedSellerId(sellerId);
    setActiveTab('intelligence');
  };

  if (showPublicWebsite) {
    return <NovinWebsiteView onEnterApp={() => setShowPublicWebsite(false)} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white pb-24 md:pb-12">
      {/* Hidden real audio element if file exists */}
      {currentCall.audioUrl && (
        <audio
          ref={audioElementRef}
          src={currentCall.audioUrl}
          onEnded={() => setIsPlaying(false)}
        />
      )}

      {/* Top Application Header */}
      <AppHeader
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        tenant={tenant}
        datasetMode={datasetMode}
        onSelectDatasetMode={setDatasetMode}
        recordCount={activeCalls.length}
        onOpenUpload={handleOpenUpload}
        onOpenRecord={handleOpenRecord}
        onRunDiagnostics={() => setIsDiagnosticsModalOpen(true)}
        isAnalyzing={isAnalyzing}
        hasActiveSingleCall={Boolean(currentCall)}
        activeCallTitle={currentCall?.title}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* VIEW 1: HOME / OVERVIEW */}
        {activeTab === 'home' && (
          <HomeView
            aggregation={aggregationResult}
            calls={activeCalls}
            datasetMode={datasetMode}
            onNavigateTab={setActiveTab}
            onSelectCall={handleSelectCallFromList}
            onOpenUpload={handleOpenUpload}
            onOpenRecord={handleOpenRecord}
            onSelectSeller={handleSelectSellerAndNavigate}
          />
        )}

        {/* VIEW 1A: SOVEREIGN COMMAND STUDIO (P79) */}
        {activeTab === 'command_studio' && (
          <CommandStudioView
            store={globalBusinessStore}
            tenant={tenant}
            datasetMode={datasetMode}
            onOpenDiagnostics={() => setIsDiagnosticsModalOpen(true)}
          />
        )}

        {/* VIEW 1B: INTEGRATED AGENT OS / LIVING ENVIRONMENT (Phase 8/9) */}
        {activeTab === 'agent_os' && <SovereignAgentOSView />}

        {/* VIEW 1C: NATIVE WEB ENGINE */}
        {activeTab === 'engineering' && <Suspense fallback={null}><WebEngineeringView /></Suspense>}

        {/* VIEW 1B: BUSINESS OPERATING SYSTEM (P70) */}
        {activeTab === 'business_os' && (
          <BusinessOSView
            datasetMode={datasetMode}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* VIEW 2: CALLS DIRECTORY */}
        {activeTab === 'calls' && (
          <CallsListView
            calls={activeCalls}
            onSelectCall={handleSelectCallFromList}
            onOpenUpload={handleOpenUpload}
            onOpenRecord={handleOpenRecord}
          />
        )}

        {/* VIEW 3: SINGLE CALL DEEP DIVE (P63 Core Integrity) */}
        {activeTab === 'single_call' && (
          <SingleCallDeepDiveView
            currentCall={currentCall}
            currentTime={currentTime}
            onSeek={handleSeek}
            onUpdateSpeakerName={handleUpdateSpeakerName}
            onBackToCalls={() => setActiveTab('calls')}
            onOpenUpload={handleOpenUpload}
            onOpenRecord={handleOpenRecord}
          />
        )}

        {/* VIEW 4: INTELLIGENCE HUB */}
        {activeTab === 'intelligence' && (
          <IntelligenceHubView
            aggregation={aggregationResult}
            calls={activeCalls}
            selectedSellerId={selectedSellerId}
            onSelectSellerId={setSelectedSellerId}
            onOpenUpload={handleOpenUpload}
            onOpenRecord={handleOpenRecord}
          />
        )}

        {/* VIEW 5: ROLEPLAY STUDIO */}
        {activeTab === 'roleplay' && (
          <RoleplayStudioView
            aggregation={aggregationResult}
            selectedSellerId={selectedSellerId}
            onSelectSellerId={setSelectedSellerId}
          />
        )}

        {/* VIEW 6: BUSINESS & TEAM BI */}
        {activeTab === 'business' && (
          <BusinessBIView
            aggregation={aggregationResult}
            onSelectSeller={handleSelectSellerAndNavigate}
            onOpenUpload={handleOpenUpload}
          />
        )}
      </main>

      {/* Sticky Bottom Audio Player Bar (when active on single call or audio playing) */}
      {(activeTab === 'single_call' || isPlaying) && (
        <AudioPlayerBar
          call={currentCall}
          currentTime={currentTime}
          isPlaying={isPlaying}
          onPlayPause={handlePlayPause}
          onSeek={handleSeek}
          playbackRate={playbackRate}
          onChangePlaybackRate={setPlaybackRate}
        />
      )}

      {/* Mobile-First Bottom Navigation Bar */}
      <BottomNavBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        hasActiveSingleCall={Boolean(currentCall)}
      />

      {/* Upload / Live Record / Text Modal */}
      <UploadModal
        isOpen={isUploadModalOpen}
        initialTab={uploadModalTab}
        onClose={() => setIsUploadModalOpen(false)}
        onAnalysisSuccess={handleAnalysisSuccess}
        isAnalyzing={isAnalyzing}
        setIsAnalyzing={setIsAnalyzing}
      />

      {/* Forensic Diagnostics Modal */}
      <Suspense fallback={null}>
      <DiagnosticsModal
        isOpen={isDiagnosticsModalOpen}
        onClose={() => setIsDiagnosticsModalOpen(false)}
        calls={activeCalls.length > 0 ? activeCalls : allCallRecords}
        tenant={tenant}
      />
      </Suspense>
    </div>
  );
}
