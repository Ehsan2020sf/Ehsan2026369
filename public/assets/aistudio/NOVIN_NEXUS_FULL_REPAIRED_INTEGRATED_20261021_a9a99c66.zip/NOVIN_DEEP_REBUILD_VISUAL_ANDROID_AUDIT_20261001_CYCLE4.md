# NOVIN Deep Rebuild Visual + Android Audit | 2026-10-01 | Cycle 4

## Scope
Full source-level forensic review of the current live NOVIN reference, with focus on the reported Android symptom: only buttons/windows visible while the intended 3D living environment and avatar are not visible.

## Root-cause findings
1. Android WebView asset integrity was not enforced strongly enough before packaging. A stale or empty Capacitor public asset tree could produce a shell without the intended web runtime.
2. The Android asset synchronizer invoked the full `npm run build`, mixing web and server build concerns. It now uses `npm run build:web` and a dedicated Android web-distribution reality gate.
3. The existing visual runtime had a WebGL error boundary and fallback, but no explicit preflight for WebGL capability. A WebView without usable WebGL could therefore enter a less deterministic renderer path. A capability probe now selects the safe visual fallback immediately when WebGL/WebGL2 is unavailable.
4. Android visual stage sizing was hardened with a mobile dynamic viewport and a bounded minimum stage height so the 3D area cannot silently collapse under flex layout pressure.
5. The Android visual resilience contract was previously represented only by an alias of the visual runtime contract. A dedicated resilience contract now verifies capability preflight, unsupported-WebGL fallback, context-loss recovery, bounded retry, and minimum stage sizing.

## Changes
- `src/components/avatar/NovinAvatarVisual.tsx`
  - Added WebGL/WebGL2 capability preflight.
  - Added explicit unsupported-WebGL visual fallback.
  - Preserved context-loss recovery and bounded retry.
- `src/index.css`
  - Hardened Android living stage minimum height using dynamic viewport units.
- `scripts/verify_android_web_distribution.mjs`
  - New build-output reality gate.
  - Verifies `dist/index.html`, module entry, referenced local assets, localhost leakage, and server-bundle isolation.
- `scripts/sync-android-assets.ts`
  - Uses `build:web` rather than the full server+web build.
  - Runs the Android web-distribution reality gate before copying assets.
- `scripts/novin_android_termux_build.sh`
  - Runs the Android web-distribution reality gate before Capacitor sync.
  - Runs the Android asset boundary after sync.
- `scripts/test_android_visual_resilience_contract.mjs`
  - New dedicated resilience contract.
- `package.json`
  - `test:android-visual-resilience` now points to the dedicated resilience contract.

## Verification
PASS: ZIP integrity (`unzip -t`)
PASS: script registry: 373 scripts / 338 referenced files / 4 required contracts
PASS: Android visual runtime contract: 19/19
PASS: Android visual resilience contract: 5/5
PASS: Android visual quality governor: 5/5
PASS: Android native runtime contract
PASS: Android build entrypoint
PASS: Android build environment portability
PASS: reality claims scan: 1676 files
PASS: npm dependency dry-run: 520 packages resolved from lockfile metadata
PASS: package.json parse
PASS: JavaScript/MJS syntax checks
PASS: referenced project files audit

## Environment limitations
- Full `npm ci` and actual Vite/Gradle execution require target-environment native packages/toolchain and network/cache availability.
- APK/AAB generation is not claimed from this source-only environment.
- Physical Redmi Note 11 rendering remains NOT VERIFIED until the updated project is built and installed on the device.
- Source archive intentionally does not contain generated `dist/` or Capacitor public assets. The Android asset boundary reports NOT_VERIFIED for source-only state and the Gradle gate blocks packaging until `cap sync` provides a real `index.html`.

## Truth policy
No APK, physical-device render, live AI provider, or WebGL hardware success is marked PASS without direct evidence.
