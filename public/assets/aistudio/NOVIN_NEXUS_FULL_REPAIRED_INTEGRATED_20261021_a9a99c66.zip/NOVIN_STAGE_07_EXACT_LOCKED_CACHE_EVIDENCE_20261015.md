# NOVIN NEXUS Stage 07: Exact Locked-Artifact Cache Evidence

Date: 2026-10-15
Baseline archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`
Project version: `0.9.32-unified`

## Change
Extended `scripts/novin_dependency_recovery_audit.mjs` to distinguish a cache listing that merely mentions a missing package name from a listing that contains the exact `resolved` URL recorded for that package in `package-lock.json`.

The audit emits `npmCache.exactLockedArtifactHints` and `exactLockedArtifactHintCount`. Both package-name hits and exact URL hits are explicitly classified as hints, not integrity proof. When exact URLs are listed, the recommended next check is an offline installation in a disposable copy, rather than assuming the existing cache is complete or intact.

## Why
A cache listing for `vite` or an older `vite` tarball does not establish that the exact lockfile-pinned tarball is available. Even an exact URL listing does not prove content integrity or that npm can complete a reproducible offline install. The report now preserves those distinctions.

## Regression coverage
- Missing direct dependencies remain `BLOCKED` even with a consistent lockfile.
- A cache line mentioning a package name and a different tarball version is not counted as an exact lockfile artifact hint.
- A cache line containing the lockfile's exact resolved URL is surfaced as a hint, while `exactUrlHitsAreIntegrityProof` remains `false`.
- Blocked-registry recovery still avoids repeated install attempts.
- Full integration contracts still distinguish passing source tests from APK/device success.

## Verification
- `node --test scripts/test_novin_dependency_recovery_audit.mjs`: PASS.
- `node --test scripts/test_novin_diagnostic_recovery_plan.mjs`: PASS, 3 tests.
- `node --test scripts/test_novin_integrated_os_contract.mjs`: PASS, 2 tests.
- `npm run test:all`: PASS, exit code 0.
- `npm run build:web`: BLOCKED by platform dependency preflight. `@esbuild/linux-x64` and `@rollup/rollup-linux-x64-gnu` are not installed.
- Live dependency audit: 31 direct dependencies declared; 31 missing from `node_modules`; 33 required direct/native/type-support entries missing; registry DNS probe failed; no cache package-name hits and no exact locked-artifact URL hints.
- ZIP integrity: checked after archive update.

## Next safe action
Restore the exact lockfile dependencies on a network-enabled compatible Linux x64 host, or test a trusted cache using `npm ci --offline` in a disposable copy. Then rerun the dependency audit and web build preflight. Do not change lockfile versions, bypass native-package checks, or claim APK/device success based on source tests.

## Truth classification
Source test suite: PASS. Dependency recovery: BLOCKED by environment/network. Web build: BLOCKED at native dependency preflight. APK: NOT BUILT. Physical Android device: NOT TESTED.
