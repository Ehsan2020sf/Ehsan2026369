# NOVIN ARCHITECTURE GOVERNANCE & AUTONOMY MASTER POLICY

**Codename:** NOVIN Sovereign Engineering & Architecture Framework  
**Status:** ACTIVE & ENFORCED  
**Effective Date:** 2026-08-30  

---

## 1. Core Philosophy: Build Forward & Autonomous Lifecycle

1. **Migration Freeze Principle:**  
   The Android toolchain limitation (`DEBT-001`) is frozen as a controlled, non-blocking engineering debt. It must not block the development of new NOVIN Core capabilities, AI intelligence features, or architecture scaling.
2. **Platform-Agnostic Core:**  
   Every new capability must be:  
   `Migration-Friendly + Platform-Agnostic + Modular + Testable + Replaceable`.
3. **No Fake Claims (Evidence-First):**  
   `CLAIM ≠ PROOF`. Every technical milestone requires reproducible evidence. Capabilities are strictly classified into:
   - **`VERIFIED_BUILT`**: Fully implemented, compiled, and verified.
   - **`REQUESTED_NOT_BUILT`**: Backlogged or scoped, awaiting execution.
   - **`EXPERIMENTAL_UNVERIFIED`**: In testing or prototype phase.

---

## 2. Two-Layer Architecture

```
+-------------------------------------------------------------------------+
|                              NOVIN BRAIN                                |
|  +-------------------------------------------------------------------+  |
|  | NOVIN Core Engine | AI Gateway (Gemini 3.7 Flash) | Memory & Logs |  |
|  | Diarization & Audio Analytics | 3x3 Coaching | Policy & Security |  |
|  +-------------------------------------------------------------------+  |
+-------------------------------------------------------------------------+
                                    |
                         Universal Adapter Layer
                                    |
        +---------------------------+---------------------------+
        |                           |                           |
+----------------+          +----------------+          +----------------+
|  Web Runtime   |          | Android Hybrid |          | Desktop / API  |
| (React / Vite) |          | (Capacitor 8)  |          | (Future Nodes) |
+----------------+          +----------------+          +----------------+
```

### Layer A: NOVIN Brain
- **Independence:** The Brain is 100% decoupled from specific UI or operating system bindings.
- **Components:**
  - AI Gateway (`server.ts` with Gemini 3.7 Flash SDK integration)
  - Diarization & Audio Processing pipeline
  - Structured Sentiment & Sales Competency Analyzers
  - Security & Zero Client Secret Guard
  - Migration & Build Autonomy Core

### Layer B: NOVIN Interfaces & Runtimes
- **Rule:** Interfaces do NOT own the Brain; they consume it via structured adapters.
- **Web Runtime:** Primary rich interactive visual dashboard (React 19 + Tailwind).
- **Android Runtime:** Modular mobile container (`/android`) with native hardware listeners (Back Button, Microphone, Safe-Area).
- **Adapter Strategy:** All API calls route through `src/lib/apiClient.ts` resolving relative paths in web mode or `VITE_API_BASE_URL` in mobile standalone mode.

---

## 3. NOVIN Migration & Build Autonomy Core

The Autonomy Core provides progressive automation of engineering tasks across six defined phases:

1. **DISCOVERY:** Project scan, framework detection, dependency graph inspection, environment toolchain probing.
2. **ANALYSIS:** Breaking change analysis, risk classification, platform constraint mapping.
3. **PLANNING:** Generation of formal migration and build plans with explicit rollback checkpoints.
4. **CODE MIGRATION:** Automated patch generation, configuration updates, and adapter generation.
5. **VALIDATION:** Multi-tier verification (`tsc --noEmit`, linter, `npm run build`, `cap sync`, health probe).
6. **SELF-REPAIR:** Error capture, root cause classification, iterative fix application (max attempts governed by policy), and re-testing.

---

## 4. Human Approval Boundary (Sovereignty Matrix)

| Operation | NOVIN Autonomous Action | Human Authority Required |
| :--- | :--- | :--- |
| Code & Dependency Analysis | Full Execution | Optional Review |
| Error Diagnosis & Lint Fixes | Full Execution | Optional Review |
| Web Build & Asset Sync | Full Execution | Optional Review |
| Test Execution & Health Checks | Full Execution | Optional Review |
| Minor Non-Destructive Patches | Full Execution | Policy Governed |
| Core Architecture Redesign | Propose & Prototype | **REQUIRED** |
| Database Schema Destruction | Strictly Blocked | **REQUIRED** |
| Production Release / Publishing | Prepare & Stage | **REQUIRED** |
| Credential & Secret Management | Zero Touch | **REQUIRED** |
| Final APK / AAB Store Signing | Build Scaffolding | **REQUIRED** |

---

## 5. Self-Engineering Loop

```text
OBSERVE ──> UNDERSTAND ──> PLAN ──> IMPLEMENT ──> BUILD ──> TEST ──> VERIFY
   ▲                                                                    │
   │                              [Failure]                             │
   └─────────────── SELF-REPAIR <───────────────────────────────────────┘
                                  [Success]
                                      │
                                      ▼
                        REPORT ──> HUMAN APPROVAL ──> COMMIT
```

---

## 6. Current Capability Classification Status

| Component | Category | Evidence |
| :--- | :--- | :--- |
| Audio Diarization & Analytics | `VERIFIED_BUILT` | `server.ts`, `UploadModal.tsx`, Gemini 3.7 Flash API |
| Sentiment & Engagement Graph | `VERIFIED_BUILT` | `src/components/SentimentGraphView.tsx` |
| 3x3 AI Coaching Cards | `VERIFIED_BUILT` | `src/components/CoachingCardView.tsx` |
| Full-Stack Web Runtime | `VERIFIED_BUILT` | Express + Vite on port 3000 (`HTTP 200 OK`) |
| Android Capacitor Scaffold | `VERIFIED_BUILT` | `/android` project, `npx cap sync android` (Exit 0) |
| Safe API Client & Health Probe | `VERIFIED_BUILT` | `src/lib/apiClient.ts` |
| Autonomy Environment Module | `VERIFIED_BUILT` | `src/core/autonomy/environment.ts` |
| Local In-Container APK Compiler | `REQUESTED_NOT_BUILT` | Blocked by missing JDK in cloud container (`DEBT-001`) |
