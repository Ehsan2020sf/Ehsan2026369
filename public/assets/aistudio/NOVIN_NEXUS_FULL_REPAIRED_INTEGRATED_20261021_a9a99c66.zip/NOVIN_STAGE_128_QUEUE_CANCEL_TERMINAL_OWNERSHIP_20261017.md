# NOVIN Stage 128 — Queue Cancellation Terminal Ownership

Date: 2026-10-17

## Finding
`JobQueue.processNext()` could overwrite a cancellation that arrived while an asynchronous handler was running. The success path continued to assign completion status and emit completion evidence after the handler returned. The error path could also route a cancelled job to dead-letter handling because cancellation only guarded the retry branch, not the final `else`.

## Changes
- `src/core/automation/jobQueue.ts`
  - Before committing success, check whether the job has become `CANCELLED` while awaiting its handler.
  - Preserve `CANCELLED` as the terminal status, record a cancellation-specific summary, persist, and return without success metrics or completion audit.
  - In the error path, detect cancellation before failure metrics/retry/dead-letter logic; persist cancellation and return without retrying or dead-lettering.
- `scripts/test_job_queue_cancel_terminal_ownership.mjs`
  - Static regression checks for late success, cancellation during error, terminal-state persistence, and continued bounded retries for non-cancelled errors.

## Verification
- `node scripts/test_job_queue_cancel_terminal_ownership.mjs`: PASS (4 checks).
- `node scripts/test_cancellation_autonomy_retry_boundary.mjs`: PASS (8 checks).
- ZIP CRC and unique-path checks after archive update: PASS.

## Limits
The queue regression test is a source-structure test, not a live race test with a real asynchronous handler. It establishes that the cancellation guard exists in both success and error paths, but does not prove that all underlying operations are physically interruptible. Full project tests, full TypeScript compilation, APK build, and device testing were not run. No dependencies were installed.
