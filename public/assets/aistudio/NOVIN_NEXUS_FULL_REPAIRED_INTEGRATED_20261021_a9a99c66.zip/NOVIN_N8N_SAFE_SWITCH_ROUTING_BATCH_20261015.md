# NOVIN NEXUS engineering batch: bounded Switch routing

Date: 2026-10-15  
Scope: Android app project only. No public website, server, or full n8n runtime was added.

## Change

Extended `src/core/agent/n8nSafeLocalRuntime.ts` with a deterministic, bounded `n8n-nodes-base.switch` subset. To avoid assuming compatibility with n8n version-specific parameters, it accepts only the explicit `parameters.novinSafeSwitch` schema:

- `field`: one top-level item JSON key
- `cases`: 1 to 10 ordered cases, each using the existing safe condition operators (`equals`, `notEquals`, `greaterThan`, `lessThan`, `isTrue`, `isFalse`, `exists`)
- one connection output per case, followed by a final fallback output
- first matching case wins; unmatched items go to the fallback branch

Case objects may contain only `operator` and, where required, a scalar `value`. They cannot override the configured field or include expressions. Branch counts must exactly match the declared cases plus fallback. Missing or malformed routes are blocked during preflight.

## Safety contract retained

- Whole-graph preflight occurs before any node executes.
- Only allowlisted pure-data nodes are accepted; no network, credentials, shell, arbitrary code, or external side effects.
- Bounded graph, step, item, and serialized payload sizes remain enforced.
- `sideEffects: false` and `executionAllowed: false` remain fixed.
- This is a NOVIN-defined local subset, not full n8n compatibility; imported workflows are not thereby production-executable.

## Test evidence

`src/core/agent/n8nSafeLocalRuntime.test.ts` now covers ordered Switch matching, fallback routing, malformed branch count, rejected attempt to override the configured field, existing IF true/false routing, and fail-closed cases. Full-project tests and archive integrity checks must pass before this batch is considered complete. APK build and physical-device testing are not claimed unless separately performed.
