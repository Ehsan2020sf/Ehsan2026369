# NOVIN × Build with Claude: Integration Record

Date: 2026-10-13
Scope: development-time capability discovery and reviewed capability shortlist.
Upstream: https://buildwithclaude.com/ and https://github.com/davepoon/buildwithclaude

## Design decision
The upstream website indexes independently maintained plugins, skills, agents, commands, hooks, MCP servers, and marketplaces. It is not a single runtime SDK. Copying every indexed item into NOVIN or the Android APK would create an unsafe, oversized, unmaintainable dependency surface. NOVIN therefore gains an isolated discovery registry plus a 16-item engineering shortlist and a reusable adoption skill.

## Added
- `tools/buildwithclaude/registry.json`: catalog source metadata, official HTTPS discovery routes, curated capabilities, adoption guardrails.
- `tools/buildwithclaude/README.fa.md`: Persian operational documentation.
- `scripts/novin_buildwithclaude_registry.mjs`: no-dependency registry status, validation, local search and remote discovery-link CLI.
- `scripts/novin_buildwithclaude_registry.test.mjs`: automated contract tests.
- `.agents/skills/novin-buildwithclaude-engineering/SKILL.md`: NOVIN-specific safe adoption workflow.
- package scripts: `bwc:status`, `bwc:verify`, `bwc:packs`, `bwc:search`, `bwc:url`, `test:buildwithclaude-integration`.

## Safety and dependency boundaries
- No new root runtime dependency.
- No Android startup dependency.
- No automatic third-party install, execution, or MCP connection.
- No arbitrary shell execution through this registry.
- Original per-item licenses and provenance must be reviewed before any import.
- Existing owner-authentication removal and explicit approval for consequential external actions remain policy constraints.

## Validation
Run results are recorded by the implementation session and should be refreshed by running:
`npm run test:buildwithclaude-integration`
`npm run bwc:verify`
`npm run test:all`

The local registry does not mirror or claim to install the entire external catalog. Remote catalog sync and installation of any external plugin were not performed in this integration.
