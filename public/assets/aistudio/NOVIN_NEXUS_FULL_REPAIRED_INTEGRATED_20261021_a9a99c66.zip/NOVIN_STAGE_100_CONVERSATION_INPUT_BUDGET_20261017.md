# NOVIN Stage 100: Bound current conversation input before model routing

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding

The multilingual conversation runtime bounded historical turns before storage, but the current incoming message was language-detected and inserted into the provider prompt before the storage limit could protect it. A very large current message could therefore bypass the intended per-turn storage bound and inflate provider input work.

## Change

- Added `boundConversationInput()` with a 4,000 UTF-16 code-unit budget, trimming outer whitespace and marking truncation.
- Avoided leaving a dangling high surrogate at the truncation boundary.
- Applied the bound before language detection, normalization, history storage, and provider prompt assembly.
- Extended the existing multilingual conversation regression test with oversized-input and truncation-boundary checks. Existing test command already participates in `test:conversation-turn-serialization` and `test:conversation-context-provenance`.

## Evidence

Executed successfully in the extracted source tree, without installing dependencies or building an APK:

- `node --experimental-strip-types src/core/mobile/novinMultilingualConversationRuntime.test.ts`
- `node --experimental-strip-types src/core/mobile/novinPersianConversationRuntime.test.ts`
- `node --experimental-strip-types src/core/mobile/novinVoiceConversationRuntime.test.ts`
- `node --experimental-strip-types src/core/mobile/novinRealtimeAndroidRuntime.backgroundLifecycle.test.ts`
- `node --experimental-strip-types src/core/mobile/novinMultimodalSessionLifecycle.test.ts`
- `node --experimental-strip-types src/core/ai/providerEgressBoundary.test.ts`
- `node --experimental-strip-types src/brain/aiGatewayProvider.test.ts`

All seven commands exited 0. The multilingual runtime test output explicitly reported `fa=SIMULATED/FALLBACK`, `en=SIMULATED/FALLBACK`, and `providerUsed=false`; live-provider behavior was not claimed or tested.

## Limits / status

- PASS: current user input is bounded before language detection and prompt assembly; regression tests above pass.
- NOT TESTED: complete `test:all`, full TypeScript typecheck/build, live provider call with real credentials, and physical Android microphone/speaker behavior.
- No dependencies installed, no APK built, and no device installation performed.
