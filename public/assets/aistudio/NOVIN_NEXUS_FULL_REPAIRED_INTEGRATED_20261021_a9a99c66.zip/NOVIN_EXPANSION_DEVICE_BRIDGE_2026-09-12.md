# Device Action Bridge added
Agent→Risk→HumanSovereignty→Approval(single-use)→Native/Blocked→RealityGate
