# وضعیت فعلی «زیپ احسان» | 2026-09-28

## قانون مرجع
این فایل بخشی از همان نسخه مرجع NOVIN است. تغییرات مهندسی باید در همین درخت انجام شوند و نسخه‌های موازی نباید جایگزین مرجع شوند.

## تقویت انجام‌شده در این دور
- مسیر Bootstrap ترموکس برای JDK 17، Node/npm، Gradle 8.13 و اجزای Android SDK تقویت شد.
- اگر `sdkmanager` در محیط موجود باشد، Bootstrap می‌تواند `platform-tools`، `platforms;android-36` و `build-tools;35.0.0` را نصب/تکمیل کند.
- اگر SDK ناقص باشد و `sdkmanager` موجود نباشد، وضعیت صریحاً `BLOCKED` است و نصب ساختگی گزارش نمی‌شود.
- Gate واحد `android:full-gate` برای Bootstrap → Truth → Preflight → Web Build → Capacitor Sync → Android Build → APK Signer Verification اضافه شد.
- نصب APK از Build جدا شده و فقط با `NOVIN_APPROVE_INSTALL=1` انجام می‌شود.
- Evidence دستگاه فقط پس از اتصال واقعی ADB و وجود package تولید می‌شود.
- Evidence ساخت صراحتاً نصب دستگاه و Runtime دستگاه را `NOT_RUN`/`NOT_VERIFIED` نگه می‌دارد تا جعل نشوند.

## تست‌های محلی این دور
- `novinAndroidBuildDeployAgent.test.ts`: PASS
- `nscoChiefAgentRuntimeIntegration.test.ts`: PASS
- `nscoEngineeringBootstrapIntegration.test.ts`: PASS
- `disasterRecoveryReality.test.ts`: PASS
- `tsc --noEmit`: BLOCKED در محیط فعلی، چون `node_modules` داخل ZIP وجود ندارد؛ اجرای `npm ci` در Termux لازم است.

## واقعیت اجرای دستگاه
ساخت APK، نصب APK و اجرای Runtime روی گوشی در این محیط اثبات نشده‌اند. این سه مرحله فقط با Evidence واقعی دستگاه باید به PASS تبدیل شوند.

## فرمان‌های اصلی Termux
```bash
npm run android:bootstrap
npm run android:truth
npm run android:doctor
npm run android:build
NOVIN_APPROVE_INSTALL=1 npm run android:install
npm run android:device-evidence
```
