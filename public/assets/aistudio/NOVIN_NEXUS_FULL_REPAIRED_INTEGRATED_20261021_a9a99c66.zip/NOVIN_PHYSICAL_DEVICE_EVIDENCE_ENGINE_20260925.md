# NOVIN Physical Device Evidence Engine — 2026-09-25

## هدف
آخرین حلقه زنجیره توسعه NOVIN اکنون یک لایه مستقل برای تبدیل مشاهده واقعی ADB به Evidence دارد:

`Brain → Agent Runtime → NSCO → Development/Programming Engine → Environment Automation → Build/Deploy → Android Reality Validation → Physical Device Evidence`

## پیاده‌سازی
- `src/core/development/physicalDeviceEvidenceEngine.ts`
- `src/core/development/physicalDeviceEvidenceEngine.test.ts`
- `src/core/agent/nscoPhysicalDeviceEvidence.test.ts`
- اتصال خروجی در `src/core/development/index.ts`
- اتصال NSCO در `src/core/agent/nscoChiefOperationsPlane.ts`
- اسکریپت `test:physical-device-evidence`

## Reality Rules
1. `adb devices` به‌تنهایی Physical Hardware را ثابت نمی‌کند.
2. مدل دستگاه و markerهای QEMU باید مشاهده شوند.
3. نبود Evidence واقعی هرگز به PASS ارتقا داده نمی‌شود.
4. نصب APK فقط با `approvedForMutation=true` مجاز است.
5. Launch فقط پس از Installation PASS و با approval صریح انجام می‌شود.
6. خروجی مدل، برنامه یا NSCO به‌تنهایی Evidence محسوب نمی‌شود.
7. Evidence دارای SHA-256 مستقل است.

## وضعیت این دور
- Physical Device Evidence Engine test: PASS
- NSCO integration test: PASS
- نصب/اجرای APK در این مرحله ادعا نشده است.
- Physical Device واقعی تا مشاهده مستقل از محیط اجرا: NOT_VERIFIED

## گام واقعی بعدی
پس از آماده شدن Toolchain و اتصال واقعی Redmi/Android device، مسیر مجاز:
`inspect → verified APK → owner-approved install → launch → runtime checks → persisted evidence`
