---
name: novin-rea-static-audit
description: Use NOVIN's vendored REA tool only for static inspection of NOVIN's own Android web bundle, with evidence-first readiness checks and no device-mutating operations.
---

# NOVIN REA Static Audit Skill

## Required sequence

1. Run `npm run rea:verify-vendor`. If it fails, stop and report `FAIL`.
2. Run `npm run rea:status`. Read the complete JSON. If status is `BLOCKED`, do not attempt to bypass preflight or invoke the upstream CLI directly.
3. Only when status is `READY`, run `npm run rea:audit-android-assets`.
4. Inspect the generated compact report under `artifacts/rea/`; report its status, target, output digest, and failure reason if present.
5. Distinguish static source/bundle evidence from real APK build, installation, Android runtime, microphone, camera, STT/TTS, and live AI provider evidence.

## Boundaries

- Allowed target: fixed `android/app/src/main/assets/public` only.
- Do not pass arbitrary paths or commands to REA through the NOVIN bridge.
- Do not run REA setup, MCP registration, ADB install/uninstall, app launch/stop, file push/pull, Frida, debugger attach, memory/register mutation, browser interaction, or network capture as part of this skill.
- Never auto-install REA dependencies. Dependency installation and the REA Termux build must be explicitly requested as a separate engineering action.
- REA is a development tool. Never import it into Android app code or make normal NOVIN startup depend on it.
- Use `PASS`, `PARTIAL`, `FAIL`, `BLOCKED`, or `UNKNOWN` only when the recorded evidence supports the label. A successful static analysis is not proof that the APK installs or the phone hardware works.
