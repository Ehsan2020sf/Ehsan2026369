# NOVIN EHSAN Repair Ledger R06

## Scope
Truthfulness and integration hardening based on the latest EHSAN R05 source.

## Repairs
- EnvironmentManager now probes actual executables and installed Node packages instead of hard-coded tool readiness.
- Android SDK readiness requires a real SDK root and API 36 platform directory.
- Java readiness requires both `java` and `javac` to execute.
- ADB readiness is separated from physical-device evidence.
- Engineering Build Center no longer displays fake default commit/checksum/build/release PASS values.
- Pipeline UI defaults to BLOCKED/UNVERIFIED until real state evidence exists.
- Software Factory TestFactory no longer labels source-level assertions as REAL_EXECUTION.
- APK existence no longer implies physical-device installation PASS.

## Verification policy
No device E2E, live AI provider call, or native Android build is claimed as PASS without corresponding runtime evidence.
