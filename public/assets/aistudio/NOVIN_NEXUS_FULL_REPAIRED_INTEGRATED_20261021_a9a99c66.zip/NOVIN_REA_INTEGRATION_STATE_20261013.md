# NOVIN REA Integration State

- Date: 2026-10-13
- Engineering ID: `NOVIN-REA-DEVTOOLS-STATIC-AUDIT-20261013`
- NOVIN baseline in this workspace: `0.9.24-unified` (R259 test archive lineage; not the R360 baseline)
- Upstream: `rea-agents` 6.4.0, declared MIT
- Incoming archive SHA-256: `1d1a819cb83f6dd2da6dfff9f83caeafedd0cad1180283f9fc2b4e70f543e4c1`
- Placement: `tools/third_party/rea/`
- App/runtime dependency: none
- Android startup dependency: none
- Root npm dependencies changed: no; only scripts were added
- Allowed operation: static analysis of the fixed `android/app/src/main/assets/public` directory
- Arbitrary command dispatch: disabled in NOVIN bridge
- Upstream source files vendored: 3,359 before NOVIN provenance/manifest files
- Per-file source manifest: `tools/third_party/rea/UPSTREAM_SOURCE_MANIFEST.sha256`

## Current verified facts

- The incoming archive passes ZIP integrity and has no unsafe absolute/parent-traversal paths or symlink entries.
- The vendor source manifest was generated from the extracted upstream snapshot.
- NOVIN bridge has an allowlist, fixed target path, no-shell child process invocation, bounded output (128 MiB), 15-minute timeout, compact evidence summary, and fail-closed readiness checks.
- REA dependencies and compiled `dist/` were absent in the incoming archive; the bridge does not auto-install them.
- Current execution container runs Node `22.16.0`, below REA's declared supported range `^22.19.0 || ^24.11.0 || >=26.0.0`; therefore REA CLI execution is `BLOCKED` here. The status and safety-contract tests can still run on the available Node version.

## Remaining work

1. Install the isolated REA dependencies only in `tools/third_party/rea/` on a compatible network-enabled toolchain.
2. Build its Termux runtime with the upstream `build:termux` script.
3. Run `npm run rea:audit-android-assets` and inspect the actual evidence summary.
4. Use REA's output as additional static evidence only; it does not replace Android build, APK installation, or real-device tests.

## Rollback

Remove `tools/third_party/rea/`, `scripts/novin_rea_bridge.mjs`, `scripts/novin_rea_bridge.test.mjs`, `scripts/verify_novin_rea_vendor.mjs`, `docs/engineering/NOVIN_REA_INTEGRATION.md`, this state record, and the four `rea:*` / `test:rea-integration` script entries from `package.json`. No app runtime files or Android manifest entries were changed by this integration.

## Validation update

- `npm run test:rea-integration`: PASS; 6 bridge tests pass and all 3,359 upstream files match the source SHA-256 manifest.
- `npm run test:all`: PASS; exit code 0, including the REA integration gate.
- `npm run rea:status`: BLOCKED for actual REA execution in this container because Node is 22.16.0 and the isolated dependencies/runtime are not installed/built.
- `npm run rea:audit-android-assets`: correctly returns exit code 2 with explicit `BLOCKED` preflight status; it does not start the REA process when prerequisites are missing.
- APK build, installation, and physical-device runtime tests were not performed as part of this developer-tool integration.
