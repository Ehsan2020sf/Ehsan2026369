# NOVIN NSCO Governance Runtime Sync — 2026-09-23

## Scope
فقط بخش NSCO ↔ Governance Runtime بررسی و اصلاح شد. بخش‌های دیگر در این چرخه تغییر داده نشدند.

## Finding
NSCO execution مسیر مستقیم به ToolGateway داشت، در حالی که `NOVIN-R175-R234-GOVERNANCE-RUNTIME` به‌صورت integration موجود بود اما قبل از اجرای NSCO به‌عنوان admission boundary فراخوانی نمی‌شد. بنابراین وجود 60 Governor به‌تنهایی به معنی اتصال واقعی آنها به مسیر NSCO نبود.

## Fix
- Governance Runtime R175-R234 قبل از ToolGateway در `NovinSeniorChiefOfficer.execute()` متصل شد.
- نبود `governanceEvidenceRefs` با Fail-Closed متوقف می‌شود.
- ریسک مؤثر از بیشینه ریسک درخواست و ریسک مستقل `HumanSovereigntyGate` محاسبه می‌شود؛ caller/model نمی‌تواند ریسک حساس را پایین بیاورد.
- تصمیم `REVIEW/BLOCK` به execution تبدیل نمی‌شود.
- Governance Runtime همچنان خودش مجوز اجرای خارجی صادر نمی‌کند و `externalActionAuthorized=false` و `generatedOutputIsProof=false` باقی می‌ماند.
- برای پیش از اجرا، reality به‌صورت `INFERRED` ثبت می‌شود و به‌عنوان evidence واقعی اجرا معرفی نمی‌شود.

## Evidence
- `NOVIN R175-R234 GOVERNANCE INTEGRATION: PASS`
- `NSCO_SELF_GOVERNANCE_TEST=PASS`
- `NSCO_CHIEF_OPERATIONS_PLANE: PASS`
- `NSCO_GOVERNANCE_RUNTIME_REALITY_GATE_PASS`

## Reality Status
- NSCO ↔ Governance Runtime source-level integration: **PASS**
- Missing governance evidence: **BLOCKED**
- Sensitive action risk downgrade attempt: **BLOCKED**
- External AI provider registration: **NOT VERIFIED**
- Physical Android/APK execution: **NOT VERIFIED**
- Full project build/device E2E: **NOT VERIFIED**

## Rule
PASS above applies only to this focused source-level integration and its executed tests. It does not imply full NOVIN or device-level PASS.
