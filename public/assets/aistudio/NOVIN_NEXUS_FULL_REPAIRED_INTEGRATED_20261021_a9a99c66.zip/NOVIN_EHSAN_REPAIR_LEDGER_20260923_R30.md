# NOVIN EHSAN Repair Ledger R30

- Scope: AI Gateway / Model Router / Provider Health / Fallback
- Model Router now tracks provider runtime health with a bounded cooldown after provider failure.
- Failed providers are excluded from fresh selection and stale fallback chains are re-checked before execution.
- Successful provider execution clears the runtime failure/cooldown state.
- Remote provider failure is never silently converted to simulation unless explicitly requested by caller policy.
- Tests: model-router governance PASS; provider-health PASS; AI gateway router integration PASS; unified integrity PASS.
- Live provider, device E2E, and production readiness remain NOT VERIFIED.
