# NOVIN NSCO Durable Persistence Hardening — 2026-09-23

## Scope
Only the durable persistence boundary was reviewed and hardened in this cycle.

## Findings
1. Node filesystem persistence wrote entity files atomically by rename, but did not fsync the temporary file or parent directory before/after rename.
2. File/index permissions were not explicitly restricted.
3. `.index.json` was treated as the authoritative key list, so index corruption could hide otherwise intact entity files.
4. Index filename handling used a POSIX-style `/` split instead of the platform path API.
5. The persistence layer had no focused reality test for restart recovery, corruption rejection, and index reconstruction together.

## Repairs
- Added file fsync before rename and directory fsync after rename where the runtime supports it.
- Added `0700` directory and `0600` file/index modes.
- Rebuilt the index from persisted entity envelopes instead of trusting a possibly stale/corrupt index.
- Switched filename handling to the runtime path API.
- Added a focused reality test covering atomic persistence, restart recovery, payload corruption rejection, and index reconstruction.

## Evidence
- `NOVIN DURABLE PERSISTENCE REALITY PASS: atomic-write=PASS restart-recovery=PASS corruption-rejection=PASS index-rebuild=PASS`
- Existing local-storage integrity test: `NOVIN LOCAL STORAGE INTEGRITY PASS: envelope=PASS checksum=PASS tamper-detection=PASS`
- Modified durable persistence module load: PASS

## Truth Boundary
This proves source-level persistence behavior in the current Node test environment. It does **not** prove physical Android filesystem durability, SQLite/Keystore durability, or production-device recovery.

## Status
PASS for the reviewed source-level durable persistence hardening.
Physical device persistence: NOT VERIFIED.
