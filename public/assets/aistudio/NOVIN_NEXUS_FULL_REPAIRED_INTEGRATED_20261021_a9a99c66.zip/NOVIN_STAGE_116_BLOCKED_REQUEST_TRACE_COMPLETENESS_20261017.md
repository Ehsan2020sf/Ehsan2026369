# NOVIN Stage 116 — Blocked Request Trace Completeness

Date: 2026-10-17
Canonical archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`

## Finding

Requests blocked before provider selection by the AI circuit breaker or burst/rate limiter returned fail-closed responses, but bypassed the gateway's recent-request log. This made operational traces incomplete precisely for two important failure paths.

## Changes

- Start timing at the beginning of gateway execution so blocked requests receive a real non-negative latency measurement.
- Route circuit-open and rate-limited outcomes through the common failure recorder.
- Route human-approval-required outcomes through the same recorder while preserving `WAITING_FOR_HUMAN_APPROVAL` as the finish reason.
- Preserve fail-closed response semantics: empty content, provider/model `none`, reality `UNKNOWN`, zero cost, explicit error and `ok=false` in the recent log.
- Add `scripts/test_ai_gateway_blocked_request_trace.ts` and wire it into `test:all` as `test:ai-gateway-blocked-request-trace`.

## Executed evidence

PASS:
- `node --experimental-strip-types scripts/test_ai_gateway_blocked_request_trace.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_request_trace_provenance.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_marks_fallback_failure.ts`
- `node --experimental-strip-types scripts/test_ai_gateway_provider_response_integrity.ts`
- `node --experimental-strip-types src/brain/aiGatewayProvider.test.ts`
- `node --experimental-strip-types src/core/mobile/conversationResponseIntegrity.test.ts`

The new test injects deterministic runtime services to force circuit-open and rate-limited paths and verifies both responses appear in recent logs with the expected error, `UNKNOWN` reality, no provider attribution, zero cost, and blocked finish reason. No network calls were made by this test.

## Limitations

- Full `test:all` was not run.
- Full TypeScript compilation remains unverified because project type definitions are not installed; no dependencies were installed.
- No live provider call, APK build, Android device test, or installation was performed.

## Status

- Blocked-request trace coverage: PASS
- Focused adjacent regression checks: PASS
- Full repository validation: UNKNOWN / NOT RUN
- Android runtime validation: NOT TESTED
