# NOVIN Secure Storage Boundary Hardening 2026-09-23

## محدوده این چرخه
فقط مرز Storage / Credential / Short-lived Secret بررسی و سخت‌سازی شد.

## یافته‌های واقعی
- FileStorageAdapter داده را به‌صورت JSON خام ذخیره می‌کرد و checksum نداشت.
- نوشتن فایل durable بود اما fsync فایل و directory برای این adapter تضمین نشده بود.
- SecureTokenStore اندروید یک store حافظه‌ای TTL است و خودش vault رمزنگاری‌شده نیست.
- expiry در SecureTokenStore با `>` بود و در لحظه دقیق expiry توکن هنوز قابل دریافت بود.
- ورودی‌های خالی و TTL نامعتبر در SecureTokenStore صراحتاً رد نمی‌شدند.

## اصلاحات انجام‌شده
1. FileStorageAdapter به envelope نسخه 2 با SHA-256 checksum ارتقا یافت.
2. write به فایل موقت با mode `0600` انجام می‌شود.
3. پس از write، `fsync` روی فایل و پس از rename، تا حد امکان روی directory انجام می‌شود.
4. checksum tampering باعث `corrupted=true` و عدم بازگشت داده می‌شود.
5. fallback به state حافظه‌ای هنگام وجود فایل خراب حفظ نشد، تا داده stale جای واقعیت durable را نگیرد.
6. SecureTokenStore برای key/value خالی، TTL غیرمثبت، زمان منفی و overflow زمان fail-closed می‌شود.
7. انقضای توکن در `nowMs >= expiresAt` اعمال شد.

## Evidence
- `NOVIN FILE STORAGE INTEGRITY PASS`
  - atomic-write = PASS
  - corruption = BLOCKED
  - stale-fallback = BLOCKED
  - checksum tamper = BLOCKED
- `NOVIN ATOMIC STORAGE SPACE PASS`
  - atomic-commit = PASS
  - fsync = PASS
  - checksum = PASS
  - backup-recovery = PASS
  - generation = PASS
  - clear = PASS
- `CREATOR CREDENTIAL VAULT PASS`
  - phone/email verified
  - biometric OS-only
- SecureTokenStore: source-level hardening verified. Android compilation/device execution was not available in this cycle.

## Reality Boundary
این چرخه **به معنی Secure Storage رمزنگاری‌شده واقعی روی دستگاه Android نیست**. `SecureTokenStore` همچنان یک حافظه موقت داخل process است. پیاده‌سازی Android Keystore / encrypted persistent storage و اجرای واقعی روی دستگاه در این چرخه ادعای PASS ندارد.

## وضعیت
SOURCE HARDENING: PASS
ANDROID DEVICE SECURE STORAGE: NOT IMPLEMENTED / NOT VERIFIED
PHYSICAL DEVICE E2E: BLOCKED
