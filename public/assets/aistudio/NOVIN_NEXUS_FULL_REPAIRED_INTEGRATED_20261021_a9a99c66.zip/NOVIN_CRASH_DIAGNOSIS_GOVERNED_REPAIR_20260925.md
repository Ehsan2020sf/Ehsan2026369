# NOVIN Crash Diagnosis & Governed Repair - 2026-09-25

## Status
- Crash diagnosis engine: PASS
- Governed repair planning: PASS
- Explicit approval gate: PASS
- Post-repair verification boundary: PASS
- Automatic root-cause claim: BLOCKED by design

## Flow
Android Runtime Health Evidence -> Crash Diagnosis -> Evidence Correlation -> Governed Repair Plan -> Explicit Approval -> Engineering Recovery -> Post-Repair Verification -> Rebuild/Revalidation.

The diagnosis layer never treats a crash marker as proof of a root cause. It records candidate causes and required evidence. Source mutation remains blocked until explicit approval and a concrete verified patch are supplied.

## Reality rule
A runtime crash, an ANR, missing process, or incomplete log evidence cannot be converted into PASS by inference. The engine uses NOT_VERIFIED / BLOCKED / ESCALATED where evidence is insufficient.

## Verification performed
`node --experimental-strip-types src/core/development/crashDiagnosisGovernedRepairEngine.test.ts`

Result: `CRASH_DIAGNOSIS_GOVERNED_REPAIR: PASS`

The repository integrity audit also reported one pre-existing scanner false-positive for a dynamic import inside `scripts/novin_environment_doctor.mjs`; the referenced TypeScript file exists at `src/core/development/novinEnvironmentDoctor.ts`. This was not introduced by the crash-repair change.
