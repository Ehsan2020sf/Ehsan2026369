# NOVIN Android Runtime Media Repair 2026-09-26

## Change
Android startup now explicitly requests CAMERA and RECORD_AUDIO runtime permissions on Android M+ before NOVIN uses WebView media APIs.

## Scope
- Android runtime only
- No Web UI removal
- No server execution added to APK
- No fake success state added

## Verification
- Manifest CAMERA: PASS
- Manifest RECORD_AUDIO: PASS
- MainActivity runtime permission request source: PASS
- Java compilation: NOT_VERIFIED because the archive does not contain a usable Gradle distribution and this verification environment has no network access to download Gradle 8.13.
- Physical device runtime: NOT_VERIFIED
