# NOVIN EHSAN Repair Ledger R09 — Evidence Admission Guard

## هدف
تقویت مرز `EVIDENCE > CLAIM` در مسیر NSCO Autonomous Operating Plane.

## اصلاح
- نتیجه اجرای NSCO فقط زمانی می‌تواند `PASS` باقی بماند که `evidenceRefs` واقعی/غیرخالی از executor دریافت کرده باشد.
- `PASS` بدون Evidence به `NOT_VERIFIED` تنزل داده می‌شود و اجرای مرحله موفق محسوب نمی‌شود.
- نتیجه verification نیز همین قاعده را دارد.
- تست رگرسیون اختصاصی برای `PASS_WITHOUT_EVIDENCE` اضافه شد.

## تست‌های اجراشده
- Node syntax check: PASS
- NSCO lifecycle test: PASS
- PASS بدون Evidence → NOT_VERIFIED/BLOCKED: PASS
- Phase-0 source preflight: PASS_WITH_REVIEW
- APK/device/live-provider execution: NOT_VERIFIED

## محدودیت
این چرخه ادعای Build کامل، نصب دستگاه، اجرای دوربین واقعی یا اتصال زنده Provider را ایجاد نمی‌کند.
