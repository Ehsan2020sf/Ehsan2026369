# NOVIN EHSAN Repair Audit 48U22

- Baseline: uploaded `NOVIN_NEXUS_EHSAN_20260924_R48.zip` (working copy, no new release sent).
- Finding: 210 persisted records were classified `OBSERVED` without independent evidence references. This is not sufficient for current reality truth.
- Repair: all 210 records were retained and downgraded to `UNKNOWN`; no historical evidence was deleted.
- New regression guard: `scripts/test_persisted_observed_evidence_boundary.mjs` requires explicit evidence references for persisted `OBSERVED`, `VERIFIED_REAL`, and `REAL_EXECUTED` records.
- Current persisted scan: 211 JSON files, malformed JSON=0, OBSERVED without evidence=0, strong reality without evidence=0.
- Current-evidence isolation was also repaired to allow the two new current guard reports without treating their policy text as unquarantined claims.
- Verified tests: persisted evidence boundary PASS; current evidence isolation PASS; reality claims PASS; real execution readiness PASS (`ready=0`, `blocked=7`, `unverified=2`, `live-claim=FALSE`); owner camera runtime PASS with raw persistence BLOCKED; memory lineage PASS; runtime wiring 9/9 PASS; unified integrity PASS with 1593 files, 0 errors, 0 warnings.
- Source-of-truth remains `PHASE_0_BLOCKED`: 31 declared dependencies are not installed and TypeScript is blocked. APK, physical device E2E, live AI, and live channels remain NOT VERIFIED.
