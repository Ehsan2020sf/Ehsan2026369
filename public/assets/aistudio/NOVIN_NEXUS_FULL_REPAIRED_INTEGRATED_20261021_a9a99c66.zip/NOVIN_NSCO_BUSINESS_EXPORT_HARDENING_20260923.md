# NOVIN NSCO Business Export Hardening — 2026-09-23

## Scope
Only Business Store export synchronization was changed in this cycle.

## Finding
`exportTenantData('CSV')` previously returned JSON content while declaring `text/csv`, creating a format-truth mismatch. The export bundle also omitted payment, installation, and marketing-campaign records even though these are first-class business entities in the unified store.

## Fix
- JSON export remains JSON with `application/json` and `.json`.
- CSV export now emits valid CSV with explicit entity type, entity ID, tenant ID, and canonical JSON payload columns.
- Payments, installations, and campaigns are included in the unified export bundle.
- No new business authority, executor, or parallel data store was introduced.

## Evidence
- `NOVIN_BUSINESS_EXPORT_REALITY_PASS`
- `NOVIN_BUSINESS_INTEGRITY_PASS`
- `NOVIN_BUSINESS_TRUTH_HARDENING_PASS`

## Reality status
- Business export synchronization: PASS
- CSV/JSON format truth: PASS
- Payment/Installation/Campaign export coverage: PASS
- Physical database/production connector: NOT VERIFIED
- Android APK/device execution: NOT VERIFIED

PASS here means the focused source-level tests executed successfully. It does not claim production database connectivity or device execution.
