# NOVIN Engineering Recovery Snapshot Standard

هدف: جلوگیری از تغییرات مهندسی بدون نقطه بازگشت قابل‌اثبات.

- قبل از Build اندروید، `novin_engineering_snapshot.mjs --create` اجرا می‌شود.
- Snapshot خارج از ZIP و در `.novin-recovery/snapshots/` محیط اجرا نگهداری می‌شود.
- هر فایل Snapshot با SHA-256 در manifest ثبت می‌شود.
- Verify فقط صحت خود Snapshot را بررسی می‌کند.
- Restore مخرب بدون `NOVIN_APPROVE_RECOVERY=1` عمداً BLOCKED است.
- Restore فقط Snapshot دارای manifest سالم را می‌پذیرد.
- ایجاد Snapshot یا وجود فایل APK به‌تنهایی به معنی موفقیت Runtime نیست.
- Evidence نصب و اجرای واقعی دستگاه باید جداگانه ثبت شود.
