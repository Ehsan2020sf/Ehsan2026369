# NOVIN PHASE 6 — REAL VOICE IMPLEMENTATION REPORT

Date: 2026-10-05

## Scope

Voice vertical slice:

`Android Native STT -> transcript -> NOVIN Brain/Gateway -> generated response -> Android Native TTS -> Avatar`

## VERIFIED IN SOURCE / IN-PROCESS

- Android `NovinNativeExecutionPlugin` owns the canonical native STT/TTS path.
- Persian STT is requested with `fa-IR`.
- Native TTS selects Persian language where the installed Android engine supports it.
- STT and TTS expose lifecycle events to the WebView through Capacitor listeners.
- AndroidAvatarRuntime serializes stop-listening -> stop-speaking -> speak to prevent TTS cancellation races.
- Voice responses use the same governed conversation path as text; a provider response is not fabricated by the voice layer.
- Voice interruption has an explicit state boundary.
- Raw audio is not persisted by the voice conversation layer.
- Obsolete duplicate `com.novin.nexus.MainActivity` voice/WebView bridge was removed. The canonical host is `com.novin.salespulse.MainActivity` with `NovinNativeExecutionPlugin`.

## NEW GOVERNED STATE MACHINE

`src/core/mobile/novinVoiceConversationRuntime.ts`

States:
`IDLE -> LISTENING -> THINKING -> SPEAKING -> IDLE`

Interruption:
`SPEAKING/LISTENING -> INTERRUPTED`

Truth boundary:
- Native STT evidence = `VERIFIED_NATIVE`
- AI response is accepted for speech only when reality = `GENERATED`
- blocked/missing AI response remains `BLOCKED`
- unknown remains `UNKNOWN`

## NOT CLAIMED

- No cloud realtime voice provider is claimed as live without an ephemeral-session backend adapter.
- No external STT provider execution is claimed.
- No physical Android-device execution is claimed by this source/in-process report.
- Browser `SpeechRecognition` remains fallback only, not the canonical Android path.

## TEST

`NOVIN VOICE CONVERSATION RUNTIME PASS: STT=PASS BRAIN_BOUNDARY=PASS TTS=PASS INTERRUPTION=PASS BLOCKED=PASS`

## NEXT REAL GAP

The next production voice upgrade is a real ephemeral-session realtime transport (WebRTC/WebSocket) behind a trusted backend/native broker, followed by physical-device verification of microphone permission, Persian STT, TTS engine/language, interruption and end-to-end AI response.
