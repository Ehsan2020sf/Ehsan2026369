# NOVIN Stage 130: Queue Persistence Fail-Closed

Date: 2026-10-17
Scope: `src/core/automation/jobQueue.ts`, queue persistence boundaries and regression checks.

## Finding
The queue's initial `RUNNING` claim was persisted before the main execution `try/finally`. If this save threw, the local worker counter could remain occupied and execution control could fail before reaching normal cleanup. In addition, completion evidence could be appended before the terminal state had been durably saved, and an unpersisted retry schedule could remain eligible in memory after a final save failure.

## Changes
- Guard the initial `RUNNING` claim save. On failure, do not call the job handler, clear the local lease, release the worker slot, log a bounded error, and throw an explicit `QUEUE_CLAIM_PERSIST_FAILED` error.
- Persist the terminal state before incrementing completion metrics or appending the completion audit event.
- If a durable save fails after handler execution, set the in-memory result to `FAILED` with `UNKNOWN` outcome and `QUEUE_FINAL_PERSIST_FAILED_RECONCILIATION_REQUIRED`; do not schedule an automatic retry.
- If persistence of a queued retry fails during cleanup, convert the in-memory state to a reconciliation-required failure and clear its retry schedule, preventing another local attempt from running on an unpersisted schedule.
- Release the local worker slot before the final cleanup save so a persistence exception cannot leak a worker slot.
- Add `scripts/test_job_queue_persistence_fail_closed.mjs` and npm script `test:job-queue-persistence-fail-closed`.
- Update the cancellation terminal-ownership regression to account for the new durable terminal-write boundary.

## Verification
Passed:
- `npm run test:job-queue-persistence-fail-closed` (3 persistence-boundary assertions)
- `node --experimental-strip-types scripts/test_job_queue_crash_recovery_reconciliation.mjs` (6 checks)
- `node --experimental-strip-types scripts/test_job_queue_cancel_terminal_ownership.mjs` (4 checks)
- `package.json` JSON parse

These are targeted structural/source checks plus the existing controlled crash-recovery test. They do not prove distributed locking across independent processes, do not exercise an injected live filesystem failure end-to-end, and do not establish full TypeScript compilation or full project test success.

## Limits
- Multi-process atomic claim/compare-and-swap is not implemented by the current local/file queue adapter.
- External side effects still require explicit reconciliation after uncertain execution or persistence failure.
- No dependencies were installed; no APK build or device installation was performed.
- Full `test:all` and full TypeScript compilation remain unverified.

## Status
- Targeted tests: PASS
- Full suite: NOT TESTED
- Full TypeScript compile: UNKNOWN / NOT VERIFIED
- APK/device validation: NOT TESTED
