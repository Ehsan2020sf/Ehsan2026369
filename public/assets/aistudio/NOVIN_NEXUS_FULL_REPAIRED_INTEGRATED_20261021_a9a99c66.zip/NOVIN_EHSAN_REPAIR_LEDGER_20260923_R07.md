# NOVIN EHSAN R07 Repair Ledger

## هدف
حذف ادعاهای UI که بدون Evidence اجرایی معتبر، PASS/100%/Verified اعلام می‌کردند.

## اصلاحات
- DiagnosticsModal دیگر در پایان هر اجرای تشخیصی به‌صورت unconditional عبارت `100% GREEN` و status=success ثبت نمی‌کند. وضعیت نهایی بر اساس شواهد BLOCKED/FAIL/NOT_VERIFIED/UNVERIFIED تعیین می‌شود.
- InstallerPack ادعای «۷ تست خودکار ۱۰۰٪ PASS» را به متن حقیقت‌محور تبدیل کرد.
- EngineeringBuildCenter مراحل SOURCE و VALIDATE را دیگر صرفاً از وجود `lastBuild` به PASS تبدیل نمی‌کند.

## محدودیت Evidence
Build واقعی Android، نصب روی دستگاه فیزیکی، E2E دوربین/صدا و Provider زنده فقط با اجرای واقعی و Evidence معتبر قابل PASS هستند.
