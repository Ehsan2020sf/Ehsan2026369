# NOVIN Disaster Recovery Reality Hardening 2026-09-23

## Scope
Crash recovery, checkpoint resume, tenant/cycle isolation, fingerprint binding, and prevention of replay after a durable success.

## Findings
1. A checkpoint could identify a task as EXECUTING while the durable task state had already advanced to SUCCEEDED. Recovery previously could replay it because checkpoint.executingTaskId was treated as sufficient evidence.
2. Checkpoint resume did not explicitly reject tasks from another tenant or cycle.
3. Checkpoint resume did not verify the current task fingerprint against the checkpoint fingerprint before recovery.

## Repairs
- Durable `SUCCEEDED` task state now has precedence over an older checkpoint's in-flight marker.
- Recovery requires checkpoint/task tenant equality.
- Recovery requires checkpoint/task cycle equality.
- When a checkpoint fingerprint exists, the current task fingerprint must match it.
- Mismatches are fail-closed and are not added to the recovery execution set.

## Evidence
- NOVIN DISASTER RECOVERY REALITY PASS
- durableSuccessReplay=BLOCKED
- crossTenantReplay=BLOCKED
- fingerprintMismatch=BLOCKED
- safeInterruptedRecovery=PASS
- NOVIN DURABLE SIDE-EFFECT RECOVERY GATE PASS
- R170 recoveryCheckpoint: PASS
- R221 recoveryRollback: PASS
- R122_RECOVERY_SOVEREIGNTY_GATE_PASS
- AGENT_INCIDENT_RECOVERY_CONTROL_PASS

## Reality Boundary
These tests are source/runtime tests using the available durable persistence abstraction. Physical Android restart/recovery on the Redmi device remains NOT VERIFIED.

## Status
PASS for the hardened source-level recovery gates.
Physical device recovery: NOT VERIFIED.
