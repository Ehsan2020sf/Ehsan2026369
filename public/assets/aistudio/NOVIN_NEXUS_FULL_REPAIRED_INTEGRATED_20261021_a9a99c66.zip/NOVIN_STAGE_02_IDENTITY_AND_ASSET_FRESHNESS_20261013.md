# NOVIN Engineering Stage 02: Identity Runtime Retirement + Android Asset Freshness

Date: 2026-10-13  
Working archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`  
Project version in this archive: `0.9.24-unified`  

## Why this stage was necessary

A deeper source audit found that earlier biometric cleanup did not remove every live dependency: Android settings still mounted creator account/enrollment screens, the server health/readiness endpoints still depended on creator secrets and OTP delivery, and the realtime session broker still required verified owner identity. Separately, the Gradle Web asset gate only checked that `index.html` existed, so a manually invoked Gradle build could package old assets.

## Changes made

1. Android app entry renders `AndroidAvatarRuntime` directly.
2. Android settings no longer mount `CreatorAccountCenter`, `CreatorCommandCenter`, or `CreatorEnrollmentCenter`; backend help text no longer assumes account login.
3. Bootstrap/supervisor no longer expose biometric-enrollment or owner re-authentication actions.
4. Multimodal text routing no longer requires face, voice, fingerprint, or creator verification. Consent and explicit approval for external side effects remain separate.
5. Creator account registration/login/OTP/recovery/logout and creator-cloud identity/device/memory-sync routes were removed from `server.ts`.
6. `/api/health` and `/api/readiness` no longer depend on creator credentials or OTP configuration. Readiness explicitly describes HTTP bootstrap scope and reports provider configuration separately.
7. `/api/voice/realtime/session` was added with a per-source rate limit. The broker no longer checks creator identity, never returns the permanent provider key, and returns only an ephemeral provider session secret.
8. Legacy creator identity/authentication modules were removed from the public `src/core/security/index.ts` barrel. The source files remain disconnected for now because the 1200-stage registry and historical tests still reference them; removing them before migrating those references would damage audit integrity.
9. Added `scripts/novin_web_asset_manifest.mjs`. `build:web` now writes a manifest with source digest, index hash, per-file hashes, byte counts and asset list.
10. `verify_android_web_distribution.mjs` validates the manifest. Gradle's `novinVerifyWebAssets` now fails closed if the manifest is absent, source/config digest is stale, an asset hash/size differs, or the index references an unmanifested file.
11. Added tamper/source-drift tests for the manifest and regenerated `src/generated/novinNeuralEngineeringIndex.ts` from current source.
12. Normalized every project directory to traversable `0755` permissions. The source ZIP had directory entries with mode `040000`, which removes traversal permissions on strict extractors; the repaired archive is now checked by `test:archive-permissions`.
13. Added file-level pre-change copies under `.engineering_backups/identity-runtime-retirement-20261013/before/` and stored logs/results under `artifacts/identity-retirement-20261013/`.

## Evidence from execution

- `npm run test:all`: PASS (exit 0).
- `npm run test:rebuild-integrity`: PASS (exit 0).
- `npm run test:identity-retirement`: PASS.
- `npm run test:web-asset-manifest`: PASS; manifest write/verify passed, asset tampering was blocked, source drift was blocked.
- `npm run test:android-asset-boundary`: PASS for static build contract; generated asset state remains NOT_VERIFIED.
- `npm run test:archive-cleanliness`: PASS.
- `npm run test:archive-permissions`: PASS, 1,376 directories and 7,783 files checked.
- `node --experimental-strip-types --check server.ts`: PASS.
- Realtime broker test exercised a missing-provider path and a successful mocked provider response without live network access. The permanent test key was never returned.

Machine-readable evidence: `artifacts/identity-retirement-20261013/RESULTS.json` and logs beside it.

The realtime broker endpoint is now present in the server source, but a source search found no production instantiation of `NovinRealtimeAndroidRuntime` from `AndroidAvatarRuntime`. Therefore the broker is tested independently and the avatar-to-realtime end-to-end connection remains **NOT_VERIFIED**; this is a next-stage integration task, not a claimed completion.

## Current blockers, not waived

- All 31 declared npm dependencies are absent in the current extracted environment; `build:web` and full TypeScript typecheck have not been verified.
- Gradle 8.13 distribution download is blocked by network/DNS in this environment. Android SDK variables are not configured here.
- Current Android WebView assets do not have `novin-web-build-manifest.json`. Running the verifier produced `WEB_BUILD_MANIFEST_MISSING`. This is an expected fail-closed result, not a successful build.
- The Android asset bundle has not been rebuilt, and no APK was built, signed, installed, or run on a physical device during this stage.

## Next work in sequence

1. Restore a compatible, lockfile-exact npm toolchain and build the Web bundle.
2. Verify the generated manifest against current source, then run `cap sync android`.
3. Run the Gradle freshness gate and compile Android; repair any real compile errors.
4. Verify APK signature, package ID, version, permissions and artifact hash.
5. Trace `EnvironmentCommandEngine` and the active voice path; decide whether to wire `NovinRealtimeAndroidRuntime` into the avatar or keep native STT/TTS plus governed gateway as the canonical route. Do not create a parallel command spine.
6. Install and run on the target Redmi Note 11 / Android 13 only after the build gates pass, capture startup logs and verify text/brain first.
7. Only after startup is stable, test memory, STT, TTS, camera/vision, realtime provider, avatar and lifecycle one subsystem at a time.

## Truth boundary

Source and local contract tests are PASS. Android bundle freshness is BLOCKED. APK/device runtime is NOT VERIFIED. This stage does not authorize installation.
