# NOVIN NEXUS Stage 06: Dependency Audit Coverage

Date: 2026-10-15
Baseline archive: `NOVIN_NEXUS_R259_ANDROID_TEST_20261007.zip`
Project version: `0.9.32-unified`

## Change
Expanded `scripts/novin_dependency_recovery_audit.mjs` to inspect every direct dependency declared in `dependencies` and `devDependencies`, in addition to host-specific native packages and type-support packages. Each item reports whether it is locked and whether its installed `package.json` is present. The audit also reports `directDependencyCount` and `missingDirectDependencies` separately.

## Why
The earlier audit checked the platform-native esbuild/Rollup packages and TypeScript types, but did not cover every direct dependency. That could under-report a missing runtime/build dependency such as Vite. A lockfile entry is not evidence that a package is installed.

## Regression coverage
- Existing blocked-registry scenario remains `BLOCKED`.
- Fully provisioned fixture remains `READY_FOR_BUILD_CHECKS`.
- New regression fixture proves that a consistent lockfile plus missing direct dependencies (`react`, `vite`) remains `BLOCKED` and identifies both missing packages.
- Lockfile mismatch remains `BLOCKED`.

## Live environment observation
- Host: Linux x64, Node v22.16.0.
- `package.json` and `package-lock.json` versions align at `0.9.32-unified`; lockfile v3.
- Direct dependencies declared: 31.
- Direct dependencies missing from `node_modules`: 31.
- Total required direct/native/type package entries missing from `node_modules`: 33.
- `registry.npmjs.org` DNS probe: failed (`getent` exit 2).
- Dependency audit result: `BLOCKED`.

## Verification
- `node --test scripts/test_novin_dependency_recovery_audit.mjs`: PASS.
- `node --test scripts/test_novin_diagnostic_recovery_plan.mjs`: PASS.
- `node --test scripts/test_novin_integrated_os_contract.mjs`: PASS.
- Full `npm run test:all`: PASS, exit code 0 (completed after the regression change).
- Web build, APK build, and physical-device runtime remain unverified; this audit does not claim them.

## Next safe action
Restore dependencies from the exact lockfile on a network-enabled compatible host or with a trusted complete cache. Do not bypass native dependency preflight, alter locked versions to mask installation failure, or infer APK/device success from source tests.
