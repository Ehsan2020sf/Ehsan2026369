# NOVIN Repeatable Build / Dependency Reality Hardening — 2026-09-23

## Scope
فقط بخش Repeatable Build / Dependency Integrity بررسی شد.

## یافته‌های واقعی
- `package-lock.json` در آرشیو وجود دارد.
- `package.json` و lockfile از نظر نام و نسخه ریشه‌ای منطبق هستند.
- برای dependencyهای مستقیم، lockfile دارای spec متناظر و package entry است.
- Gradle wrapper JAR واقعی در `android/gradle/wrapper/gradle-wrapper.jar` وجود دارد.
- `npm ci --dry-run --offline` موفق شد و lockfile قابل تفسیر است.
- اجرای واقعی `npm ci --offline` در این محیط به‌دلیل نبودن tarball کش‌شده `zustand@5.0.15` متوقف شد. این شکست، کمبود cache/network است و به‌تنهایی نشانه خراب بودن lockfile نیست.
- `node_modules` در آرشیو موجود نیست و نباید به‌عنوان production dependency installation گزارش شود.

## اصلاحات
`src/core/production/dependencyIntegrity.ts` سخت‌گیرانه‌تر شد:
- تطبیق `package.json` و lockfile برای name/version ریشه‌ای.
- تطبیق دقیق dependency spec، نه فقط وجود نام.
- بررسی وجود package entry برای هر dependency مستقیم.

تست مستقل اضافه شد:
`src/core/production/dependencyIntegrity.test.ts`

و `test:dependency-integrity` اکنون ابتدا تست Reality Boundary و سپس بررسی محیط واقعی را اجرا می‌کند.

## Evidence
- `DEPENDENCY_INTEGRITY_REALITY_PASS`: PASS
- lockfile dry-run: PASS
- Gradle wrapper JAR present: PASS
- Full dependency installation in current offline environment: BLOCKED
- Production build: NOT VERIFIED

## Truth Boundary
وجود lockfile یا wrapper به‌تنهایی اثبات Build موفق نیست. تا زمانی که dependency installation و Android build واقعی اجرا نشوند، وضعیت Build همچنان `NOT VERIFIED` است.
