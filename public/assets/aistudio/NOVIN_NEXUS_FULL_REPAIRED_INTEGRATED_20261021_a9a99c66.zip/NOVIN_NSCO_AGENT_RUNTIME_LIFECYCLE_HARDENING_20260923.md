# NOVIN NSCO Agent Runtime Lifecycle Hardening — 2026-09-23

## Scope
فقط بخش NSCO ↔ Agent Runtime / Autonomous Mission Lifecycle بررسی و اصلاح شد.

## Finding
`NSCOAutonomousRun.state` از همان state ماشین عملیاتی (`RUNNING/STOPPED/PAUSED/BLOCKED`) استفاده می‌کرد. در نتیجه یک مأموریت که همه مراحلش با موفقیت تمام می‌شد، در پایان همچنان `RUNNING` گزارش می‌شد.
این وضعیت با `finishedAt` و ثبت `JOB_COMPLETED` هم‌خوان نبود و می‌توانست مصرف‌کننده را درباره پایان واقعی مأموریت دچار ابهام کند.

## Fix
- state اجرای مأموریت از state ماشین Autonomous Plane جدا شد.
- `NSCOAutonomousRunState` اضافه شد: `RUNNING | COMPLETE | PAUSED | BLOCKED`.
- مأموریت فقط وقتی `COMPLETE` می‌شود که تمام stepهای مأموریت با موفقیت اجرا و verificationهای موجود PASS شده باشند.
- حالت‌های توقف/approval/failure همچنان `PAUSED` یا `BLOCKED` باقی می‌مانند.
- تست lifecycle واقعی اضافه شد.
- تست یکپارچه NSCO ↔ Agent Runtime با وضعیت نهایی `COMPLETE` به‌روزرسانی شد.

## Evidence
- `NSCO_RUN_LIFECYCLE_REALITY_PASS`
- `NSCO_CHIEF_AGENT_RUNTIME_INTEGRATION` = PASS
- `NSCO_AUTONOMOUS_PLAN_TEST` = PASS

## Reality Boundary
- این PASS فقط مربوط به اصلاح source-level و تست‌های متمرکز Agent Runtime/Lifecycle است.
- APK build/install/device E2E همچنان NOT VERIFIED است.
- اجرای خارجی یا اثر واقعی دستگاه از این تست‌ها نتیجه‌گیری نشده است.

## Coordination Boundary
در این چرخه هیچ تغییری در Memory، AI Gateway، Security/Authorization، Build/Deploy، Recovery یا Android اعمال نشد.
